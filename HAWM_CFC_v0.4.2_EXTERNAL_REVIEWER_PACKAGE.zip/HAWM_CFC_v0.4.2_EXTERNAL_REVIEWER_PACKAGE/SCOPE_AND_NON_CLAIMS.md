# SCOPE AND NON-CLAIMS

## Frozen boundary

The CFC Anchor controller remains frozen. The v0.4.2 work is outside that
controller: Windows runtime extraction, source pinning, verification, bounded
handoff logic, and presentation.

## Supported handoff

The current HAWM→CFC handoff is deliberately narrow. The supported synthetic
claim is exactly:

`DemoSubject is safe.`

Evidence rows are manually mapped by an operator to bounded fixture fields.

## Not implemented

No generic arbitrary-natural-language semantic mapper is enabled.

## Non-claims

This package does not claim:

- truth of arbitrary real-world claims;
- real-world independence merely because source IDs look distinct;
- correctness of an operator-supplied independence attestation;
- hostile same-process Python security;
- production readiness;
- universal correctness;
- independent replication until an outside reviewer actually performs and
  reports a replay.
