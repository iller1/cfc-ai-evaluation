# EXTERNAL REVIEW PROTOCOL — v0.4.2

## Objective

Independently verify whether the supplied v0.4.2 package reproduces the same
bounded wrapper/integration behavior on another machine without modifying the
frozen CFC controller.

## Minimum replay

Run, in order:

```bat
py -3 scripts\setup_frozen_cfc.py
py -3 scripts\verify_prototype.py
```

Do not edit files before the replay.

## Evidence to retain

Please retain:

- operating system/version;
- Python version;
- complete setup output;
- complete verifier output;
- whether `RESULT: PASS` was observed;
- any antivirus/network/runtime error exactly as shown;
- any manual changes, if any.

## Optional UI check

After a successful verifier run:

```bat
py -3 app.py
```

Expected clean startup state:

- Frozen Anchor status: `VERIFIED`
- engine-ref: `OK`
- api: `OK`
- pinned runner/schema: verified
- initial CFC presentation: `UNRESOLVED`

The initial `UNRESOLVED` is expected because generic HAWM→CFC semantic mapping
is intentionally disabled.

## Interpretation rules

A PASS means only that the supplied bounded wrapper checkpoint reproduced the
encoded checks on that machine.

A FAIL should be reported as observed. Do not retry by silently changing the
package or weakening checks.

If setup cannot reach GitHub or the environment blocks execution, record that
as an environment/setup failure rather than changing the frozen artifacts.

## Important trust-boundary note

`DISTINCT` does not itself certify evidence independence.

The bounded `VERIFIED` option represents an explicit synthetic host-authority
independence attestation. Closure under that condition means the frozen
controller accepted the supplied trust assumption; it does not establish
real-world independence.
