# START HERE — HAWM + CFC v0.4.2 External Review

This package is designed for a **5-minute independent replay** of the locally
validated v0.4.2 wrapper checkpoint.

## What to do

1. Unpack `HAWM_CFC_CHAT_PROTOTYPE_v0.4.2_HARDENED.zip`.
2. Open a terminal/CMD in the unpacked folder.
3. Run:

```bat
py -3 scripts\setup_frozen_cfc.py
py -3 scripts\verify_prototype.py
```

4. Record your actual outputs in `REVIEW_RESULT_FORM.md`.

Optional UI launch:

```bat
py -3 app.py
```

Then open `http://localhost:8000`.

## Expected success markers

The setup should end with:

`Frozen CFC Anchor + pinned adapter setup: PASS`

The verifier should end with:

`RESULT: PASS`

Do **not** treat those expected strings as observed results. Record what your
machine actually returns.

## Validated artifact identity

Prototype ZIP SHA-256:

`2ceb687004485c8aeef93150f80a0a6675185e403767a3163c1de51177d95a09`

The corresponding local release-validation package had SHA-256:

`36ee356d1e860f5369ecb09f453c9dc5571063e4dad65c5d5bb7f4facbd87230`

## Scope

This is a replay of a **bounded wrapper/integration checkpoint** around an
unchanged frozen CFC Anchor. It is not a test of arbitrary natural-language
semantic mapping, real-world truth, real-world source independence, production
security, universal correctness, or external validation of CFC as a whole.
