"""Offline integrity check. No application modules imported."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "P74_MANIFEST.json").read_text(encoding="utf-8"))
expected = manifest["files_sha256"]

for name, wanted in sorted(expected.items()):
    path = root / name
    if not path.is_file():
        raise SystemExit("FAIL_MISSING: " + name)
    found = hashlib.sha256(path.read_bytes()).hexdigest()
    if found != wanted:
        raise SystemExit("FAIL_HASH: " + name)

print("P74_OFFLINE_FILE_HASHES: PASS_" + str(len(expected)))
print("AUTHENTICITY_OF_MANIFEST: NOT_PROVEN")
print("INDEPENDENT_REPLICATION: NOT_PROVEN")
print("CFC_EXECUTED: NO")
