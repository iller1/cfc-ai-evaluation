EVIDENCE COPILOT - P74 REPLICATION CANDIDATE
================================================

STATUS
LOCAL DEMONSTRATOR. NOT VERIFIED FOR PRODUCTION.
NOT independently replicated.
AI answers are unverified and require human review.
CFC is frozen. M6 HOLD. Full E2E 0/6. CP-15 not connected.

REQUIREMENTS
- Windows with Python 3 (tested locally with Python 3.14.7)
- Ollama installed and running locally
- Local model: qwen3:1.7b
- A web browser
- Optional: pypdf for PDF import
- No Node.js required for normal operation

SETUP (Windows PowerShell)
1. Extract this ZIP into a new folder.
2. Open PowerShell inside the extracted folder.
3. Check the package:
   python -B verify_package.py
4. Install and start Ollama if needed.
5. Install the model:
   ollama pull qwen3:1.7b
6. To enable PDF import (optional):
   python -m pip install pypdf
7. Start the server:
   python -B portable_server.py
8. Open this exact URL in the browser:
   http://127.0.0.1:8780/

The server binds to 127.0.0.1 only.
It requires port 8780 to be available.
Stop the server using Ctrl+C.
The local model may require additional download and startup time.

REPLICATION TEST
A. Open the interface.
B. Attach a synthetic TXT document with these rules:
   Rule A: Every document requires manager approval before publication.
   Rule B: Urgent documents may be published without manager approval.
C. Ask whether the rules conflict or need clarification.
D. Record the model response and the displayed source SHA-256.
E. Confirm MODEL COMPLETE, ANSWER UNVERIFIED,
   HUMAN REVIEW REQUIRED and CFC NOT RUN.
F. Try POST /api/native/execute and POST /api/cfc/execute.
   Both should return HTTP 403.
G. Record errors as FAIL or INCONCLUSIVE, not PASS.

WHAT THE PACKAGE DOES NOT PROVE
- Correct semantic reasoning by the model
- Source authenticity
- Authorization to publish or execute actions
- Production-grade application security
- Independent custody or external replication
- Full HAWM/CFC end-to-end integration

PACKAGE CONTENTS
- Workspace HTML, CSS and JavaScript
- Isolated RAM document importer
- Local Ollama document analysis bridge
- Loopback-only HTTP demonstrator
- SHA-256 manifest and offline package verifier

NOTES
The model runs via the local Ollama service.
Imported document contents are sent to that local model.
The package does not include model weights or Ollama.
The server intentionally blocks ordinary chat and HAWM/CFC routes.
PDF support requires a separate pypdf installation.
