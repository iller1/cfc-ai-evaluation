"""P71 standalone local demonstrator. No HAWM/CFC execution routes."""
import json
import os
import sys
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8780
ORIGIN = "http://127.0.0.1:8780"
MODEL = "qwen3:1.7b"

os.environ["CFC_CHAT_MODE"] = "LOCAL_MODEL"
os.environ["CFC_LOCAL_MODEL_BASE_URL"] = "http://127.0.0.1:11434/v1"
os.environ["CFC_LOCAL_MODEL_NAME"] = MODEL

import document_intake
import document_ai_bridge


class Handler(BaseHTTPRequestHandler):
    def json_response(self, status, result):
        data = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlsplit(self.path).path

        if path == "/api/general-chat/status":
            return self.json_response(200, {
                "configured": True,
                "native_hawm_required": False,
                "model_reachability": "PREFLIGHT_TAGS_ONLY",
                "cfc_executed": False,
                "passport_cp15": "NOT_CONNECTED"
            })

        if path == "/api/native/status":
            return self.json_response(503, {
                "native_hawm_available": False,
                "native_hawm_runtime_verified": False,
                "reason": "P71_NATIVE_HAWM_DISCONNECTED",
                "passport_cp15": "NOT_CONNECTED"
            })

        if path.startswith("/api/"):
            return self.json_response(403, {
                "error": "P71_API_ROUTE_BLOCKED"
            })

        assets = {
            "/": ("workspace.html", "text/html"),
            "/workspace.html": ("workspace.html", "text/html"),
            "/workspace.js": ("workspace.js", "text/javascript"),
            "/workspace.css": ("workspace.css", "text/css")
        }

        if path not in assets:
            return self.json_response(404, {"error": "NOT_FOUND"})

        name, media_type = assets[path]
        data = (ROOT / name).read_bytes()

        self.send_response(200)
        self.send_header("Content-Type", media_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; "
            "style-src 'self'; connect-src 'self'; "
            "img-src 'self' data:; object-src 'none'; base-uri 'none'"
        )
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = urlsplit(self.path).path
        limits = {
            "/api/document-intake/parse": 2100000,
            "/api/document-intake/ai-review": 2500
        }

        if path not in limits:
            return self.json_response(403, {
                "error": "P71_POST_ROUTE_BLOCKED"
            })

        if self.headers.get("Origin") != ORIGIN:
            return self.json_response(403, {
                "error": "P71_ORIGIN_REFUSED"
            })

        media_type = self.headers.get("Content-Type", "")
        if media_type.split(";")[0].strip().lower() != "application/json":
            return self.json_response(415, {
                "error": "P71_CONTENT_TYPE_REFUSED"
            })

        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            return self.json_response(413, {
                "error": "P71_LENGTH_REFUSED"
            })

        if not 1 <= length <= limits[path]:
            return self.json_response(413, {
                "error": "P71_SIZE_REFUSED"
            })

        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("INVALID_JSON_OBJECT")

            if path == "/api/document-intake/parse":
                result = document_intake.parse(payload)

                if (
                    result.get("authority_verified") is not False
                    or result.get("cfc_evaluated_document") is not False
                    or result.get("uploaded_file_persisted") is not False
                ):
                    raise ValueError("IMPORT_TRUST_BOUNDARY_REFUSED")

                print("P71_IMPORT_SHA256:",
                      result.get("source_sha256"), flush=True)
                return self.json_response(200, result)

            result = document_ai_bridge.analyze(payload)

            if (
                result.get("cfc_run") is not False
                or result.get("cfc_evaluated_document") is not False
                or result.get("native_hawm_written") is not False
                or result.get("source_verified") is not False
                or result.get("human_approval") is not False
                or result.get("model_provider_reported") != MODEL
            ):
                raise ValueError("AI_TRUST_BOUNDARY_REFUSED")

            print("P71_MODEL:", result.get("model_provider_reported"), flush=True)
            print("P71_FINISH:", result.get("finish_reason"), flush=True)
            print("P71_COMPLETE:", result.get("complete"), flush=True)

            return self.json_response(200, result)

        except Exception as exc:
            print("P71_REFUSED_OR_ERROR:",
                  type(exc).__name__, str(exc)[:160], flush=True)
            return self.json_response(409, {
                "error": "P71_LOCAL_ANALYSIS_REFUSED"
            })

    def log_message(self, fmt, *args):
        print("HTTP:", fmt % args, flush=True)


def main():
    try:
        with urllib.request.urlopen(
            "http://127.0.0.1:11434/api/tags", timeout=5
        ) as response:
            tags = json.load(response)
        names = [m.get("name") for m in tags.get("models", [])]
        if MODEL not in names:
            raise RuntimeError("MODEL_NOT_INSTALLED")
    except Exception as exc:
        raise SystemExit("STOP_OLLAMA_PREFLIGHT: " + str(exc))

    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("P71: PORTABLE_SERVER_LISTENING", flush=True)
    print("MODEL:", MODEL, flush=True)
    print("URL:", ORIGIN + "/", flush=True)
    print("HAWM_ROUTES: BLOCKED", flush=True)
    print("CFC_ROUTES: BLOCKED", flush=True)
    print("STOP: Ctrl+C", flush=True)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("P71: SERVER_STOPPED", flush=True)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()