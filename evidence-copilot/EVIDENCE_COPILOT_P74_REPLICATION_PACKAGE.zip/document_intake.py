"""Bounded, local-only document extraction and exact excerpt link for CFC x HAWM.

No automated evidence admission, no CFC execution, no publication authorization.
Files are not written to disk. Extracted text remains in process RAM until expiry.
An explicit operator action may append a provenance-only digest link to the
existing local document journal, after an exact excerpt was saved in native HAWM.
"""
from __future__ import annotations
import base64
import binascii
import hashlib
import io
import re
import secrets
import threading
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Callable



MAX_SOURCE_BYTES = 1_500_000
MAX_TEXT_CHARS = 100_000
MAX_PAGES = 30
CACHE_TTL_SECONDS = 3600
ALLOWED = frozenset({'.txt', '.md', '.csv', '.docx', '.pdf'})
_CACHE: dict[str, dict] = {}
_LOCK = threading.Lock()

class IntakeRefused(ValueError):
    pass

def sha(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()

def check_text(text: str) -> str:
    if not isinstance(text, str) or not text.strip():
        raise IntakeRefused('EMPTY_EXTRACTED_TEXT')
    if len(text) > MAX_TEXT_CHARS:
        raise IntakeRefused('EXTRACTED_TEXT_LIMIT_EXCEEDED_NO_TRUNCATION')
    if '\x00' in text:
        raise IntakeRefused('NUL_CHARACTER_IN_TEXT')
    # Normalize CRLF so pasted excerpts use exactly the displayed text.
    return text.replace('\r\n', '\n').replace('\r', '\n')

def clean_name(name: str) -> str:
    if not isinstance(name, str) or not 1 <= len(name) <= 120:
        raise IntakeRefused('INVALID_FILENAME')
    if '/' in name or '\\' in name or name in ('.', '..') or '..' in Path(name).parts or any(ord(c) < 32 for c in name):
        raise IntakeRefused('INVALID_FILENAME')
    if Path(name).suffix.lower() not in ALLOWED:
        raise IntakeRefused('UNSUPPORTED_FILE_TYPE')
    return name

def decode_text(data: bytes) -> str:
    if data.startswith((b'\xff\xfe', b'\xfe\xff')):
        try: return data.decode('utf-16')
        except UnicodeError as exc: raise IntakeRefused('UNSUPPORTED_TEXT_ENCODING') from exc
    try:
        return data.decode('utf-8-sig')
    except UnicodeError as exc:
        raise IntakeRefused('UNSUPPORTED_TEXT_ENCODING_ONLY_UTF8_UTF16_BOM') from exc

def docx_text(data: bytes) -> tuple[str, list[str]]:
    if not zipfile.is_zipfile(io.BytesIO(data)):
        raise IntakeRefused('INVALID_DOCX_ARCHIVE')
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
            if len(infos) > 500 or any(i.file_size > 4_000_000 for i in infos) or sum(i.file_size for i in infos) > 10_000_000:
                raise IntakeRefused('DOCX_EXPANSION_LIMIT_EXCEEDED')
            if z.testzip() is not None:
                raise IntakeRefused('DOCX_CRC_FAILED')
            names = [i.filename for i in infos]
            if len(set(names)) != len(names) or 'word/document.xml' not in names:
                raise IntakeRefused('DOCX_STRUCTURE_INVALID')
            if any('vbaProject' in n or n.endswith('.bin') for n in names):
                raise IntakeRefused('ACTIVE_CONTENT_DOCX_REFUSED')
            xml = z.read('word/document.xml')
            if b'<!DOCTYPE' in xml.upper() or b'<!ENTITY' in xml.upper():
                raise IntakeRefused('DOCX_XML_ENTITIES_REFUSED')
            if b'<w:ins' in xml or b'<w:del' in xml or b'<w:moveFrom' in xml:
                raise IntakeRefused('TRACKED_CHANGES_DOCX_REFUSED')
            root = ET.fromstring(xml)
            ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
            paragraphs = []
            for paragraph in root.iter('{%s}p' % ns):
                fragments = []
                for node in paragraph.iter():
                    if node.tag == '{%s}t' % ns and node.text:
                        fragments.append(node.text)
                    elif node.tag == '{%s}tab' % ns:
                        fragments.append('\t')
                    elif node.tag in ('{%s}br' % ns, '{%s}cr' % ns):
                        fragments.append('\n')
                if fragments:
                    paragraphs.append(''.join(fragments))
            warnings = ['WORD_LAYOUT_TABLE_STRUCTURE_NOT_PRESERVED', 'HEADER_FOOTER_AND_COMMENTS_NOT_EXTRACTED']
            return '\n'.join(paragraphs), warnings
    except (zipfile.BadZipFile, ET.ParseError, KeyError, EOFError) as exc:
        raise IntakeRefused('DOCX_PARSE_FAILED') from exc

def pdf_text(data: bytes) -> tuple[str, list[str]]:
    if not data.startswith(b'%PDF-'):
        raise IntakeRefused('NOT_A_PDF_FILE')
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise IntakeRefused('PDF_READER_NOT_INSTALLED_INSTALL_PYPDF_SEPARATELY') from exc
    try:
        reader = PdfReader(io.BytesIO(data), strict=True)
        if reader.is_encrypted:
            raise IntakeRefused('ENCRYPTED_PDF_REFUSED')
        if len(reader.pages) > MAX_PAGES:
            raise IntakeRefused('PDF_PAGE_LIMIT_EXCEEDED')
        pages = [p.extract_text() or '' for p in reader.pages]
    except IntakeRefused:
        raise
    except Exception as exc:
        raise IntakeRefused('PDF_PARSE_FAILED') from exc
    if not pages or not ''.join(pages).strip():
        raise IntakeRefused('NO_EXTRACTABLE_PDF_TEXT_NO_OCR')
    warnings = ['PDF_TEXT_ONLY_LAYOUT_READING_ORDER_NOT_VERIFIED', 'NO_OCR_IMAGES_MAY_BE_OMITTED']
    return '\n\n'.join(pages), warnings

def _stash(record: dict) -> str:
    token = secrets.token_urlsafe(24)
    with _LOCK:
        now = time.monotonic()
        for old in list(_CACHE):
            if now - _CACHE[old]['created_monotonic'] > CACHE_TTL_SECONDS:
                del _CACHE[old]
        while len(_CACHE) >= 3:
            oldest = min(_CACHE, key=lambda t: _CACHE[t]['created_monotonic'])
            del _CACHE[oldest]
        _CACHE[token] = {**record, 'created_monotonic': now}
    return token

def parse(payload: dict) -> dict:
    if not isinstance(payload, dict) or payload.get('mode') not in ('file', 'paste'):
        raise IntakeRefused('INVALID_IMPORT_MODE')
    mode = payload['mode']
    if mode == 'paste':
        if set(payload) != {'mode', 'text'} or not isinstance(payload['text'], str):
            raise IntakeRefused('INVALID_PASTE_PAYLOAD')
        text = check_text(payload['text'])
        name = 'operator_pasted_text.txt'
        original = payload['text'].encode('utf-8')
        if len(original) > MAX_SOURCE_BYTES:
            raise IntakeRefused('PASTE_BYTE_LIMIT_EXCEEDED')
        warnings = ['OPERATOR_PASTED_TEXT_NOT_AUTHENTICATED']
    else:
        if set(payload) != {'mode', 'filename', 'content_b64'}:
            raise IntakeRefused('INVALID_FILE_PAYLOAD')
        name = clean_name(payload['filename'])
        encoded = payload['content_b64']
        if not isinstance(encoded, str) or len(encoded) > ((MAX_SOURCE_BYTES + 2)//3)*4 + 4:
            raise IntakeRefused('SOURCE_BYTE_LIMIT_EXCEEDED')
        try:
            original = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise IntakeRefused('INVALID_BASE64') from exc
        if not 0 < len(original) <= MAX_SOURCE_BYTES:
            raise IntakeRefused('SOURCE_BYTE_LIMIT_EXCEEDED')
        suffix = Path(name).suffix.lower()
        if suffix == '.pdf':
            text, warnings = pdf_text(original)
        elif suffix == '.docx':
            text, warnings = docx_text(original)
        else:
            text = decode_text(original)
            warnings = ['PLAIN_TEXT_FORMATTING_NOT_VERIFIED'] if suffix in ('.md', '.csv') else []
        text = check_text(text)
    source_sha = sha(original)
    extraction_sha = sha(text.encode('utf-8'))
    token = _stash({'name': name, 'format': Path(name).suffix.lower(), 'source_sha256': source_sha,
                    'extracted_sha256': extraction_sha, 'text': text, 'warnings': list(warnings)})
    return {'schema': 'CFC_HAWM_DOCUMENT_INTAKE_V0_1', 'token': token, 'name': name,
            'format': Path(name).suffix.lower(), 'source_sha256': source_sha,
            'extracted_sha256': extraction_sha, 'extracted_length': len(text),
            'text': text, 'warnings': warnings, 'authority_verified': False,
            'cfc_evaluated_document': False, 'uploaded_file_persisted': False,
            'meaning': 'UNTRUSTED_LOCAL_TEXT_EXTRACTION_NOT_CFC_EVIDENCE'}

