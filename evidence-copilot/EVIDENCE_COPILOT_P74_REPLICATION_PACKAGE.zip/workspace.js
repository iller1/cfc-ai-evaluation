(()=>{'use strict';
const $=id=>document.getElementById(id);
const hash='77a7547c02ce4aac3d3abc759bbd266f4251de9149da2308454527c7f2dea5c0';
const TASK_PREFIX='Native HAWM state → human-confirmed mapping → frozen CFC run.';
const DRAFT_BOUNDARY='\nUNTRUSTED_SAMPLE_ARTICLE_KB_DEMO_001_NOT_CFC_EVIDENCE:\n';
const SAMPLE_DRAFT='Welcome to the company! New team members should read the onboarding checklist and ask their manager about anything unclear. This is fictional demonstration content, not an approved policy or instruction.';
const DRAFT_MAX=420;
function draftFromTask(task){const s=String(task||'');const idx=s.indexOf(DRAFT_BOUNDARY);return idx<0?'':s.slice(idx+DRAFT_BOUNDARY.length);}
function taskFromDraft(txt){return TASK_PREFIX+DRAFT_BOUNDARY+txt.trim();}

const cases={
 independence:{note:'Two current records, but no certified independent support set. The claim may be supported without permission to close.',count:2,required:2,prov:'DISTINCT',ind:'NONE',scope:'EXPECTED',rows:['POSITIVE_CURRENT','POSITIVE_CURRENT'],unresolved:'The two sources have not been certified independent.'},
 attested:{note:'Same two records; only synthetic host-provided independence authority changes. This does not prove real source independence.',count:2,required:2,prov:'DISTINCT',ind:'VERIFIED',scope:'EXPECTED',rows:['POSITIVE_CURRENT','POSITIVE_CURRENT'],unresolved:'The independence certificate in this demo is synthetic, not external real-world authority.'},
 scope:{note:'A VERIFIED claim may still be STOPPED because the decision has the wrong audit scope.',count:1,required:1,prov:'DISTINCT',ind:'NONE',scope:'WRONG',rows:['POSITIVE_CURRENT'],unresolved:'Decision scope does not match the expected audit scope.'},
 stale:{note:'The record exists but is outside its temporal validity window.',count:1,required:1,prov:'DISTINCT',ind:'NONE',scope:'EXPECTED',rows:['POSITIVE_STALE'],unresolved:'Current, temporally valid supporting evidence is missing.'},
 contradiction:{note:'One positive and one negative record conflict; there is no authorized conflict resolution.',count:2,required:1,prov:'DISTINCT',ind:'NONE',scope:'EXPECTED',rows:['POSITIVE_CURRENT','NEGATIVE_CURRENT'],unresolved:'Direct contradictory evidence has not been resolved.'}
};
let busy=false;
let displayedChatMode='OFFLINE TEST ADAPTER';
let generalChatConfigured=false; // Separate general-chat proxy configuration, not a HAWM availability signal.
const session={native:false,initialized:false,prepared:false,confirmed:false,executed:false,latest:null,hawms:null,editedAfterConfirm:false,effectReceipt:null};
let docReviewInfo=null;
let importedDocument=null; // Untrusted extract held in this tab; server also holds a bounded RAM cache.
let quickDocumentReview=null; // Only the current imported document, never a CFC verdict.
let quickReportZipB64=null;
let currentDocumentAi=null; // Ephemeral: not native HAWM and not a CFC result.
let restoredHistoricalChat=false; // Persisted messages only; never an active attachment or result.
// v0.4.9: the last native HAWM reply is current ONLY for the import token,
// original SHA and exact native question/reply pair recorded by THIS tab.
// Never reconstruct current authority from chat history or same-named files.
let activeNativeReplyBinding=null;
function nativeReplyCurrentForImport(doc,history,binding){
 if(!doc||!binding||!doc.token||!doc.hash||binding.token!==doc.token||binding.sha!==doc.hash)return false;
 if(!Array.isArray(history)||history.length<2)return false;
 const u=history.at(-2),a=history.at(-1);
 if(u?.role!=='user'||a?.role!=='assistant')return false;
 const raw=String(u.content||'');
 const m=raw.match(/\nsha256=([a-f0-9]{64})\n/);
 return raw.startsWith(DOC_CHAT_TAG+'\n')&&m?.[1]===doc.hash&&
   raw===binding.question&&String(a.content||'')===binding.reply;
}
function invalidateDocumentFeedback(){
 // Inline action feedback and toast are UI messages, not native HAWM evidence.
 // Never leave a previous 'Send DONE' or ZIP-download DONE looking current.
 for(const id of ['homeChatSend','homeQuickExport']){
  const btn=$(id);if(!btn)continue;
  const holder=btn.closest('.button-line')||btn.closest('.chat-home-input')||btn;
  const note=holder.nextElementSibling;
  if(note?.classList.contains('operation-feedback')){
   note.dataset.state='historical';
   note.textContent='HISTORYCZNY STATUS · Poprzednia operacja dotyczyła wcześniejszego importu. Analizuj aktualny dokument dopiero po Send.';
  }
 }
 const toast=$('actionToast');if(toast)toast.hidden=true;
}

// v0.4.2: untrusted file identity and question are recorded in the NATIVE HAWM chat.
// A new empty native workspace also gets an untrusted task pointer. Never write claims,
// evidence, certificate status or a controller mapping from an imported file.
const DOC_CHAT_TAG='[CFC_HAWM_DOCUMENT_REFERENCE_V1]';
const DOC_TASK_TAG='UNVERIFIED_DOCUMENT_POINTER_V1';
const NATIVE_CHAT_LIMIT=600;
function safeDocName(name){
 return String(name||'document').replace(/[\r\n\t\x00-\x1f]/g,' ').replace(/[<>]/g,'').trim().slice(0,56)||'document';
}
function docTaskPointer(doc){
 return DOC_TASK_TAG+'\nsource_name='+safeDocName(doc.name)+'\noriginal_sha256='+doc.hash+
  '\nextracted_sha256='+doc.extractedSha+'\nsource_verified=NO; cfc_document_evaluated=NO; text_not_stored_in_task=YES';
}
function nativeMessageForDocument(question,doc){
 // The raw source text is never silently truncated or claimed to be included.
 const name=safeDocName(doc.name);
 const header=DOC_CHAT_TAG+'\nfile='+name+'\nsha256='+doc.hash+'\n';
 const footer='\nQUESTION: '+question;
 const text=String(doc.text||'');
 const full=header+'TEXT_UNTRUSTED_BEGIN\n'+text+'\nTEXT_UNTRUSTED_END'+footer;
 if(full.length<=NATIVE_CHAT_LIMIT)return {message:full,fullTextPassed:true};
 const meta=header+'TEXT_NOT_INCLUDED_IN_NATIVE_HAWM_CHAT; ONLY_BOUND_TO_LOCAL_QUICKCHECK'+footer;
 if(meta.length>NATIVE_CHAT_LIMIT)throw Error('Pytanie z powiązaniem PDF jest za długie dla natywnego HAWM (600 znaków). Skróć pytanie; niczego nie ucinamy automatycznie.');
 return {message:meta,fullTextPassed:false};
}
async function attachUnverifiedDocumentContext(doc){
 const s=await req('/api/native/state');
 if(!s||typeof s!=='object')throw Error('Cannot read current native HAWM state for document context.');
 // Do not touch non-empty, synthetic or previously approved states.
 const emptyTask=!String(s.task||'').trim();
 const hasDecisionContext=!!s.mapping_draft||!!s.last_fixture_result||
  (s.claims||[]).length>0||(s.evidence||[]).length>0||(s.unresolved||[]).length>0||(s.constraints||[]).length>0;
 if(emptyTask&&!hasDecisionContext){
  const pointer=docTaskPointer(doc);
  const changed=await req('/api/native/manual',{field:'task',value:pointer});
  if(changed?.task!==pointer)throw Error('Native HAWM did not confirm document pointer; chat not sent.');
  refreshState(changed);
  return 'NATIVE_HAWM_TASK_DOCUMENT_POINTER_RECORDED';
 }
 if(String(s.task||'')===docTaskPointer(doc))return 'NATIVE_HAWM_TASK_DOCUMENT_POINTER_CURRENT';
 // Preserve existing task and mappings. The document reference remains in the
 // new HAWM chat entry, and is never presented as CFC evidence or approval.
 return 'NATIVE_HAWM_EXISTING_TASK_PRESERVED_CHAT_REFERENCE_ONLY';
}
function visibleUserChatContent(raw){
 if(!raw.startsWith(DOC_CHAT_TAG+'\n'))return null;
 const sep='\nQUESTION: ';
 const idx=raw.lastIndexOf(sep);
 if(idx<0)return null;
 const name=(raw.match(/\nfile=([^\n]*)/)||[])[1]||'document';
 const textIncluded=raw.includes('TEXT_UNTRUSTED_BEGIN\n');
 return {question:raw.slice(idx+sep.length),name,textIncluded};
}

let productView='document';
let productInspector='none';
// Session-only general chat. No HAWM state, CFC control or persisted evidence.
let chatScope='free'; // Chat-first default; attaching a file visibly switches to HAWM.
let generalHistory=[];
// Unsent drafts belong to one explicitly chosen mode. Switching NEVER
// transfers free-chat text into persisted native HAWM conversation.
const chatDrafts={free:'',hawm:''};
// v0.9.11: display-language preference is local browser UI only. Never changes
// messages sent to HAWM, saved evidence, reviewer decisions, or CFC outputs.
let uiLanguage='en';
const UI_TEXT={
 en:{m26Source:'Add source',m26SourceDetail:'Import a file or paste text',m26Ask:'Ask a question',m26AskDetail:'Local AI or HAWM review',m26Review:'Inspect the result',m26ReviewDetail:'AI ≠ evidence verification',m26SourceBoundary:'Source identity: unverified',m26AiBoundary:'AI response: unchecked',m26CfcBoundary:'Frozen CFC: separate test',m26DocumentHeading:'01 · Add a document',m26QuestionHeading:'Ask a question',m26QuestionSubtitle:'The AI answer is a suggestion, not a CFC decision.',m26ResultHeading:'Review what was found',m26ResultSubtitle:'Separate model output, limited text checks and controller status.',m26JourneyHeading:'CHAT → OPTIONAL ATTACHMENT → REVIEW',m26DocumentUnverified:'LOCAL INPUT · NOT VERIFIED',heroTitle:'Ask anything. Attach evidence when it matters.',heroLead:'Start with a conversation. Attach a document only when you need it. AI responses are not verified by CFC automatically.',conversationLabel:'DOCUMENT REVIEW',conversationTitle:'Your conversation',messageLabel:'Message',sendLabel:'Send ↗',boundary:'AI can be wrong. Your decision is required; this chat does not approve documents or run CFC.',toolsTitle:'Want to see the details?',toolsLead:'Open a document review or the technical CFC test. Nothing is approved automatically.',hawmButton:'HAWM — document and your decision',cfcButton:'CFC — technical demo',scopeFree:'General chat',scopeHawm:'Document review · HAWM',scopeFreeNote:'General chat goes to the local model without HAWM state. This conversation exists only in this browser tab; reloading loses it. No CFC check.',scopeHawmNote:'HAWM mode uses the saved HAWM working state and native chat history. It can generate suggestions; only you may confirm them. No CFC run.',scopeEmpty:'This is a new, temporary conversation. Ask anything; HAWM and CFC will not be used.',scopeReceived:'General AI reply received. Not verified and not saved in HAWM.',scopeIncomplete:'General AI reply incomplete. Do not treat it as a finished result.',scopeUnavailable:'Start the product with its LOCAL AI launcher to use general chat.',placeholder:'Message Evidence Copilot…',roleUser:'YOU',roleAI:'AI ANSWER · NOT CHECKED',roleError:'MODEL ERROR · NO ANSWER',roleOffline:'OFFLINE TEST · NOT AI',roleIncomplete:'AI ANSWER · INCOMPLETE',roleMeta:'AI ANSWER · TECHNICAL DATA INCOMPLETE',cardTitle:'Check this answer against the document',cardExact:'This answer followed a review request containing exactly the saved document text. That does not mean the answer is correct.',cardGeneral:'This is a general chat answer. We cannot confirm that the AI examined this exact saved version of the document.',savedTitle:'What the saved document actually says',cardCheck:'Your check: Does the document really contradict itself? Did AI confuse different terms or steps? Do not treat the AI finding as proven.',cardAction:'Open HAWM to record your assessment ↗',cardBoundary:'A general chat answer cannot be retroactively linked to a saved version. Only a document-specific review can record a version-bound human assessment. CFC has not evaluated this document.',technicalTitle:'Technical details and limits',technicalExact:'SOURCE LINK: review prompt text exactly matched the saved article text. This is a local UI comparison, not source authenticity attestation.',technicalGeneral:'NOT SOURCE-BOUND: no established link between this general chat answer and a specific saved article version.',technicalEnd:'Original HAWM retains the raw text. No publication approval or frozen-CFC evaluation of the document.',empty:'Write a question below to start. Open HAWM for the full conversation history.',archive:'Showing the most recent 30 messages. HAWM has the full history.',helpIncomplete:'Incomplete model response or proposal metadata. Do not rely on this as a complete answer; original raw text stays in HAWM.',helpMeta:'Proposal metadata was not parsed. Review HAWM before relying on this answer.',modeAI:'Local AI · not verified',modeOffline:'Offline test · not AI',statusNoState:'No saved review. Open HAWM below to create or restore a local project.',statusUnavailable:'Local AI unavailable. Check the model service.',statusConnected:'Local AI connected. Answers are not verified and do not run CFC.',statusWaiting:'Waiting for the local model. The answer will need checking.',statusError:'The model returned an error. No answer was completed. Check details in HAWM.',statusEmpty:'The model did not produce a complete answer. See the saved record in HAWM.',statusIncomplete:'The AI response was cut short; raw output is kept in HAWM. No approval occurred.',statusMeta:'Technical proposal data was not parsed. Inspect HAWM before relying on the response.',statusReceived:'Answer saved in HAWM. Not verified. CFC was not run.',size:'characters',sizeExceeded:'Too long: the full text stays here; shorten it before sending.'},
 pl:{m26Source:'Dodaj źródło',m26SourceDetail:'Wybierz plik albo wklej tekst',m26Ask:'Zadaj pytanie',m26AskDetail:'Lokalne AI lub przegląd HAWM',m26Review:'Sprawdź wynik',m26ReviewDetail:'AI ≠ weryfikacja dowodów',m26SourceBoundary:'Pochodzenie źródła: niezweryfikowane',m26AiBoundary:'Odpowiedź AI: niesprawdzona',m26CfcBoundary:'Zamrożony CFC: osobny test',m26DocumentHeading:'01 · Dodaj dokument',m26QuestionHeading:'Zadaj pytanie',m26QuestionSubtitle:'Odpowiedź AI nie jest decyzją CFC.',m26ResultHeading:'Sprawdź wynik',m26ResultSubtitle:'Oddziel odpowiedź modelu, test tekstu i stan kontrolera.',m26JourneyHeading:'CZAT → OPCJONALNY ZAŁĄCZNIK → PRZEGLĄD',m26DocumentUnverified:'WEJŚCIE LOKALNE · NIEZWERYFIKOWANE',heroTitle:'Zapytaj o wszystko. W razie potrzeby dołącz źródło.',heroLead:'Najpierw rozmowa. Dokument dołącz tylko wtedy, gdy go potrzebujesz. Odpowiedź AI nie jest automatycznie weryfikowana przez CFC.',conversationLabel:'PRZEGLĄD DOKUMENTU',conversationTitle:'Twoja rozmowa',messageLabel:'Wiadomość',sendLabel:'Wyślij ↗',boundary:'AI może się mylić. Decyzję podejmuje człowiek; ten czat nie zatwierdza dokumentów ani nie uruchamia CFC.',toolsTitle:'Chcesz zobaczyć szczegóły?',toolsLead:'Otwórz przegląd dokumentu albo techniczny test CFC. Nic nie jest zatwierdzane automatycznie.',hawmButton:'HAWM — dokument i Twoja decyzja',cfcButton:'CFC — demonstracja techniczna',scopeFree:'Zwykły czat',scopeHawm:'Przegląd dokumentu · HAWM',scopeFreeNote:'Zwykły czat korzysta z lokalnego AI bez stanu HAWM. Rozmowa istnieje tylko w tej karcie; odświeżenie ją usuwa. Bez kontroli CFC.',scopeHawmNote:'Ten tryb korzysta z zapisanego stanu i rozmowy HAWM. Model może zgłaszać propozycje; tylko Ty możesz je zatwierdzić. Bez uruchamiania CFC.',scopeEmpty:'Nowa, tymczasowa rozmowa. Możesz pytać o cokolwiek — bez HAWM i CFC.',scopeReceived:'Lokalne AI odpowiedziało. Wynik niesprawdzony, nie zapisany w HAWM.',scopeIncomplete:'Odpowiedź zwykłego czatu jest niepełna. Nie traktuj jej jako zakończonej.',scopeUnavailable:'Uruchom produkt z lokalnym modelem AI, aby korzystać ze zwykłego czatu.',placeholder:'Napisz wiadomość…',roleUser:'TY',roleAI:'ODPOWIEDŹ AI · NIESPRAWDZONA',roleError:'BŁĄD MODELU · BRAK ODPOWIEDZI',roleOffline:'TEST OFFLINE · TO NIE AI',roleIncomplete:'ODPOWIEDŹ AI · NIEPEŁNA',roleMeta:'ODPOWIEDŹ AI · NIEPEŁNE DANE TECHNICZNE',cardTitle:'Sprawdź odpowiedź z tekstem dokumentu',cardExact:'Ta odpowiedź powstała po poleceniu zawierającym dokładnie zapisany tekst dokumentu. Nie oznacza to, że odpowiedź jest poprawna.',cardGeneral:'To odpowiedź ze zwykłego czatu. Nie możemy potwierdzić, że AI analizowało dokładnie tę zapisaną wersję dokumentu.',savedTitle:'Co naprawdę mówi zapisany dokument',cardCheck:'Sprawdź sam: Czy w dokumencie rzeczywiście jest sprzeczność? Czy AI pomyliło różne pojęcia lub etapy? Ocena AI nie jest dowodem.',cardAction:'Otwórz HAWM i zapisz swoją ocenę ↗',cardBoundary:'Odpowiedzi ze zwykłego czatu nie można później automatycznie przypisać do wersji dokumentu. Tylko specjalny przegląd dokumentu zapisuje ocenę człowieka powiązaną z wersją. CFC nie oceniał tego dokumentu.',technicalTitle:'Szczegóły i ograniczenia techniczne',technicalExact:'SOURCE LINK: treść polecenia przeglądu dokładnie odpowiadała zapisanemu artykułowi. To porównanie w interfejsie, nie niezależne poświadczenie źródła.',technicalGeneral:'NOT SOURCE-BOUND: nie ma potwierdzonego powiązania odpowiedzi zwykłego czatu z daną wersją artykułu.',technicalEnd:'Oryginalny HAWM przechowuje surową odpowiedź. Nie było zgody na publikację ani oceny dokumentu przez zamrożony CFC.',empty:'Wpisz pytanie poniżej. Pełna historia znajduje się w HAWM.',archive:'Pokazano 30 ostatnich wiadomości. Pełna historia jest w HAWM.',helpIncomplete:'Odpowiedź modelu lub metadane propozycji są niepełne. Nie traktuj tego jak zakończonej analizy; oryginalny zapis pozostał w HAWM.',helpMeta:'Nie odczytano danych technicznych propozycji. Sprawdź oryginalny zapis HAWM.',modeAI:'Lokalne AI · niesprawdzone',modeOffline:'Test offline · to nie AI',statusNoState:'Brak zapisanej sesji. Otwórz HAWM poniżej, aby utworzyć lub przywrócić projekt.',statusUnavailable:'Lokalne AI niedostępne. Sprawdź usługę modelu.',statusConnected:'Lokalne AI połączone. Odpowiedzi nie są zweryfikowane i nie uruchamiają CFC.',statusWaiting:'Czekam na lokalny model. Odpowiedź będzie wymagała sprawdzenia.',statusError:'Model zwrócił błąd. Nie ukończono odpowiedzi. Szczegóły w HAWM.',statusEmpty:'Model nie wygenerował kompletnej odpowiedzi. Sprawdź zapis HAWM.',statusIncomplete:'Odpowiedź AI została ucięta. Surowy zapis pozostał w HAWM; niczego nie zatwierdzono.',statusMeta:'Nie odczytano technicznych danych propozycji. Sprawdź HAWM przed wykorzystaniem odpowiedzi.',statusReceived:'Odpowiedź zapisana w HAWM. Niesprawdzona. CFC nie został uruchomiony.',size:'znaków',sizeExceeded:'Za dużo znaków: cały tekst pozostaje w polu. Skróć go przed wysłaniem.'}
};
const ui=key=>UI_TEXT[uiLanguage][key]||UI_TEXT.en[key]||key;
function setUILanguage(lang){
 uiLanguage=lang==='pl'?'pl':'en';
 try{localStorage.setItem('cfc_hawm_chat_language_v011',uiLanguage)}catch(_){}
 for(const element of document.querySelectorAll('[data-ui-key]'))element.textContent=ui(element.dataset.uiKey);
 const button=$('uiLanguageToggle');button.textContent=uiLanguage==='pl'?'English':'Polski';button.lang=uiLanguage==='pl'?'en':'pl';
 button.setAttribute('aria-label',uiLanguage==='pl'?'Switch chat language to English':'Przełącz język czatu na polski');
 $('homeChatText').placeholder=ui('placeholder');
 updateChatScopeLabels();
 // Presentation only: re-render existing chat from native HAWM without API calls.
 if(session.hawms)renderHomeChat(session.hawms);
 else renderHomeChat({chat:[]});
 refreshChatAttachmentUI();updateHomeMessageSize();updateHomeControls();
}

function updateChatScopeLabels(){
 $('chatScopeFree').setAttribute('aria-pressed',String(chatScope==='free'));
 $('chatScopeHawm').setAttribute('aria-pressed',String(chatScope==='hawm'));
 $('chatScopeStatus').textContent=ui(chatScope==='free'?'scopeFreeNote':'scopeHawmNote');
}
function setChatScope(which,allowWhileBusy=false){
 if(busy&&!allowWhileBusy)return;
 const next=which==='hawm'?'hawm':'free';
 if(next===chatScope)return;
 // Preserve each draft only within its own in-tab mode. A previously
 // typed general-chat request is NEVER reused as an HAWM request.
 chatDrafts[chatScope]=$('homeChatText').value;
 chatScope=next;
 $('homeChatText').value=chatDrafts[next];
 updateHomeMessageSize();
 updateChatScopeLabels();
 refreshChatAttachmentUI();
 renderHomeChat(session.hawms||{chat:[]});
 updateHomeControls();
}
function renderGeneralChat(){
 const holder=$('homeChatStream');holder.replaceChildren();
 if(!generalHistory.length){setupLatestAiPanel(null,null,true);const empty=document.createElement('p');empty.className='chat-home-empty';empty.textContent=ui('scopeEmpty');holder.append(empty);return;}
  const recent=generalHistory.slice(-30);
  const latest=generalHistory.at(-1);
  const separated=setupLatestAiPanel(latest,generalHistory.at(-2),true);
  for(const [i,m] of recent.entries()){
  const el=document.createElement('article');el.className='chat-home-message '+(m.role==='user'?'user':'assistant')+(m.incomplete?' incomplete':'');
  const label=document.createElement('div');label.className='chat-home-role';
  label.textContent=m.role==='user'?ui('roleUser'):m.incomplete?ui('roleIncomplete'):ui('roleAI');
  const body=document.createElement('div');body.className='chat-home-text';body.textContent=m.content;
   el.append(label,body);
   if(separated&&m.role==='assistant'&&i===recent.length-1)$('homeAiBody').append(el);else holder.append(el);
 }
}
function setProductInspector(which){
 // Presentation only: both HAWM and the bounded CFC lab use the SAME native state.
 const open=which!=='none';
 productInspector=open?'process':'none';
 document.body.dataset.inspector=productInspector;
 // M26 UI navigation only: closing advanced view returns to document view.
 selectProductView(open?'lab':'document');
 $('openHawm').setAttribute('aria-expanded',String(open));
 $('openCfc').setAttribute('aria-expanded',String(open));
 $('openProcess').setAttribute('aria-expanded',String(open));
 $('openProcess').textContent=open?'Ukryj proces zaawansowany':'Pokaż cały proces HAWM + CFC';
 if(open){
  // Advanced HAWM links must reveal the original document tools even in compact lab mode.
  if(which==='hawm'){
    $('productDetails').classList.add('flow-show-technical');
    $('flowDetailsToggle').setAttribute('aria-expanded','true');
    $('flowDetailsToggle').textContent='▾ Hide technical details, document tools and reviewer notes';
  }
  if(which==='cfc')selectFlowStep(3,false);
  const id=which==='hawm'?'documentPanel':which==='cfc'?'mappingPanel':'flowHub';
  $(id).scrollIntoView({behavior:'smooth',block:'start'});
 }
}
function inspectHawmForSetup(){
 if(productInspector==='none')setProductInspector('hawm');
 $('startPanel').scrollIntoView({behavior:'smooth',block:'center'});
}
// A native HAWM reply can contain unfinished final-line proposal JSON when the
// local model exhausts output tokens. This is a VIEW ONLY diagnostic: original
// HAWM keeps the exact reply, and no proposal is interpreted or confirmed here.
const MODEL_TRUNCATION_MARKER='[CFC_LOCAL_MODEL_OUTPUT_TRUNCATED_NOT_COMPLETE]';
function inspectChatReply(value){
 const raw=String(value||'');
 const hasTruncation=raw.includes(MODEL_TRUNCATION_MARKER);
 const cleaned=raw.replaceAll(MODEL_TRUNCATION_MARKER,'').trim();
 let display=cleaned;
 let tailIssue='';
 // Native HAWM requires a stand-alone final JSON line. An incomplete or
 // inline JSON tail is not a model answer and must not be treated as complete.
 const pattern=/\{\s*"proposals"\s*:\s*\[/g;
 let match,last=null;
 while((match=pattern.exec(cleaned))!==null)last=match;
 if(last && last.index>0){
  const tail=cleaned.slice(last.index).trim();
  let isSchema=false;
  try{const parsed=JSON.parse(tail);isSchema=!!parsed&&typeof parsed==='object'&&Array.isArray(parsed.proposals)}catch(_){/* incomplete tail */}
  // Don't silently hide an illustrative JSON snippet inside a code block.
  const earlier=cleaned.slice(0,last.index);
  const fences=(earlier.match(/```/g)||[]).length;
  if(fences%2===0){
   display=earlier.trimEnd();
   tailIssue=isSchema?'UNPARSED_PROPOSAL_TAIL':'INCOMPLETE_PROPOSAL_TAIL';
  }
 }
 const incomplete=hasTruncation||tailIssue==='INCOMPLETE_PROPOSAL_TAIL';
 return {raw,display:display||'(No usable conversational reply; inspect original HAWM history.)',incomplete,tailIssue,hasTruncation};
}
// v0.4.3: latest assistant answer is displayed in a SEPARATE, labeled result area.
// Presentation only: never alter the native HAWM conversation, controller or evidence.
function setupLatestAiPanel(last, previousUser, general=false){
 const card=$('homeLatestAiResult'), body=$('homeAiBody'), note=$('homeAiWarning');
 body.replaceChildren();note.hidden=true;note.textContent='';
 if(!last||last.role!=='assistant'){card.hidden=true;delete card.dataset.replyState;return false;}
 const isError=last.model_mode==='error';
 const offline=!general&&last.model_mode!=='openai_compatible'&&!isError;
 const raw=String(last.content||'').trim();
 const missing=!raw||/^(?:\(model returned no conversational text\)|\(no answer text\)|\(no usable conversational reply; inspect original HAWM history\.\))$/i.test(raw);
 const diag=!isError?inspectChatReply(raw):null;
 const bad=isError||missing||!!diag?.incomplete||!!diag?.tailIssue||!!last.incomplete;
 card.hidden=false;card.dataset.replyState=isError||missing?'missing':bad?'incomplete':offline?'offline':'model';
 set('homeAiHeading',isError?'BŁĄD ODPOWIEDZI':missing?(offline?'BRAK ODPOWIEDZI ADAPTERA':'BRAK ODPOWIEDZI MODELU'):offline?'ODPOWIEDŹ ADAPTERA OFFLINE':'ODPOWIEDŹ MODELU');
 set('homeAiScope',general?'Zwykły czat · CFC NIE SPRAWDZAŁ':offline?'TEST OFFLINE · NIE AI · CFC NIE SPRAWDZAŁ':'NIEZWERYFIKOWANE · CFC NIE SPRAWDZAŁ');
 const recorded=general?null:visibleUserChatContent(String(previousUser?.content||''));
 const warnings=[];
 if(recorded&&!recorded.textIncluded)warnings.push('Pełny tekst załącznika NIE został przekazany modelowi w tej wiadomości (limit natywnego HAWM). Sam identyfikator pliku nie wystarcza do analizy treści.');
 if(missing)warnings.push((offline?'Adapter offline':'Model')+' nie zwrócił użytecznej odpowiedzi tekstowej. Nie jest to ukończona analiza AI. Wynik Quickcheck, jeśli występuje, pochodzi z osobnego testu offline.');
 else if(isError)warnings.push('Natywny HAWM zgłosił błąd. Zobacz zapis techniczny w trybie zaawansowanym.');
 else if(bad)warnings.push('Odpowiedź jest niepełna albo zawiera nieprzetworzone metadane. Nie należy jej traktować jako ukończonej analizy.');
 if(warnings.length){note.textContent=warnings.join(' ');note.hidden=false;}
 return true;
}
// Only a presentation layer over existing native HAWM chat.
// Never turn assistant words, historical results or review prompts into CFC authorization.
function renderHomeChat(s){
 if(chatScope==='free'){renderGeneralChat();return;}
 const history=Array.isArray(s?.chat)?s.chat:[];
 const holder=$('homeChatStream');holder.replaceChildren();
 const windowed=history.slice(-30);
 // Comparison is intentionally read-only and displays the exact HAWM task text.
 // Ordinary chat answers are NOT bound to this article/version unless the
 // saved document-specific review prompt matches byte-for-byte.
 const savedArticle=draftFromTask(s?.task);
  const lastIndex=history.length-1;
  const staleForImport=!!importedDocument &&
   !nativeReplyCurrentForImport(importedDocument,history,activeNativeReplyBinding);
  const separated=restoredHistoricalChat||staleForImport?false:
   setupLatestAiPanel(history.at(-1),history.at(-2),false);
 if(restoredHistoricalChat||staleForImport){
  // Do not pull the last historical HAWM answer into the ACTIVE model panel.
  $('homeLatestAiResult').hidden=true;
  $('homeAiBody').replaceChildren();
  $('homeAiWarning').hidden=true;
  $('homeLatestAiResult').hidden=true;
  delete $('homeLatestAiResult').dataset.replyState;
  const reminder=document.createElement('p');reminder.className='chat-home-archive';
  reminder.textContent=restoredHistoricalChat?
   'ODTWORZONA HISTORIA HAWM · Wpisy są historyczne. Załącznik i wyniki AI/Quickcheck nie zostały przywrócone. Wczytaj plik ponownie przed analizą.':
   'HISTORIA HAWM · Odpowiedzi poniżej należą do wcześniejszych pytań/importów. NIE dotyczą aktualnie załączonego dokumentu. Nowy wynik wymaga Send.';
  holder.append(reminder);
 }
 if(history.length>30){const note=document.createElement('p');note.className='chat-home-archive';note.textContent=`${ui("archive")} (${history.length}).`;holder.append(note);}
 if(!history.length){const empty=document.createElement('p');empty.className='chat-home-empty';empty.textContent=ui('empty');holder.append(empty);appendChatFile(holder);return;}
 for(const [messageOffset,msg] of windowed.entries()){
  const role=msg.role==='user'?'user':'assistant';
  const entry=document.createElement('article');entry.className='chat-home-message '+role;
  const label=document.createElement('div');label.className='chat-home-role';
  const problem=msg.model_mode==='error';const offline=role==='assistant'&&msg.model_mode!=='openai_compatible'&&!problem;
  label.textContent=role==='user'?ui('roleUser'):problem?ui('roleError'):offline?ui('roleOffline'):ui('roleAI');
  const text=document.createElement('div');text.className='chat-home-text';
  const raw=String(msg.content||'');
  const diagnostic=role==='assistant'&&!problem?inspectChatReply(raw):null;
  let docMarker=null;
  if(role==='user'&&raw.startsWith(REVIEW_MARKER)){
   text.textContent='Document review request (raw prompt preserved in HAWM).';
  }else if(role==='user'&&visibleUserChatContent(raw)){
   const recorded=visibleUserChatContent(raw);
   text.textContent=recorded.question;
   const marker=document.createElement('p');marker.className='chat-home-help';
   marker.textContent='📎 '+recorded.name+' · plik niezweryfikowany · '+
    (recorded.textIncluded?'pełny tekst krótkiego dokumentu w historii HAWM':'pełny tekst NIE przekazany do historii HAWM')+
    ' · CFC NIE OCENIAŁ dokumentu';
   docMarker=marker;
  }else{text.textContent=diagnostic?diagnostic.display:raw;}
  if(diagnostic?.incomplete){entry.classList.add('incomplete');label.textContent=ui('roleIncomplete');}
  else if(diagnostic?.tailIssue){entry.classList.add('incomplete');label.textContent=ui('roleMeta');}
   if(problem)entry.classList.add('error');
   if((staleForImport||restoredHistoricalChat)&&role==='assistant'){
    entry.classList.add('historical');
    label.textContent='HISTORIA HAWM · NIE DOTYCZY AKTUALNEGO IMPORTU · '+label.textContent;
   }
   if(separated&&(history.length-windowed.length+messageOffset)===lastIndex&&role==='assistant'&&$('homeLatestAiResult').dataset.replyState==='missing')entry.classList.add('incomplete');
  entry.append(label,text);
  if(docMarker)entry.append(docMarker);
  // One optional, closed source-comparison card for the newest COMPLETE
  // model answer. Do not infer citation provenance from topic similarity.
  const position=history.length-windowed.length+messageOffset;
  if(position===lastIndex && role==='assistant' && !problem && !offline &&
     !diagnostic?.incomplete && !diagnostic?.tailIssue && savedArticle){
   const previous=history[position-1];
   const exactReview=previous?.role==='user' &&
     String(previous.content||'')===reviewPrompt(savedArticle);
   const checker=document.createElement('details');checker.className='source-compare';
   const title=document.createElement('summary');title.textContent=ui('cardTitle');checker.append(title);
   const scope=document.createElement('p');scope.className='source-compare-note';
   scope.textContent=exactReview?ui('cardExact'):ui('cardGeneral');
   checker.append(scope);
   const tag=document.createElement('strong');tag.textContent=ui('savedTitle');checker.append(tag);
   const source=document.createElement('blockquote');source.className='source-compare-article';
   source.textContent=savedArticle;checker.append(source);
   const guide=document.createElement('p');guide.className='source-compare-note';
   guide.textContent=ui('cardCheck');
   checker.append(guide);
   const actionButton=document.createElement('button');actionButton.type='button';
   actionButton.className='source-compare-action';actionButton.textContent=ui('cardAction');
   actionButton.addEventListener('click',()=>{
    if(productInspector==='none')setProductInspector('hawm');
    $('documentPanel').scrollIntoView({behavior:'smooth',block:'start'});
   });checker.append(actionButton);
   const boundary=document.createElement('p');boundary.className='source-compare-note';
   boundary.textContent=ui('cardBoundary');
   checker.append(boundary);
   const tech=document.createElement('details');tech.className='source-compare-technical';
   const techTitle=document.createElement('summary');techTitle.textContent=ui('technicalTitle');tech.append(techTitle);
   const techScope=document.createElement('p');techScope.textContent=exactReview?ui('technicalExact'):ui('technicalGeneral');tech.append(techScope);
   const techEnd=document.createElement('p');techEnd.textContent=ui('technicalEnd');tech.append(techEnd);
   checker.append(tech);entry.classList.add('with-source-compare');entry.append(checker);
  }
  if(diagnostic?.incomplete||diagnostic?.tailIssue){
   const alert=document.createElement('p');alert.className='chat-home-help';
   alert.textContent=diagnostic.incomplete?
    ui('helpIncomplete'):
    ui('helpMeta');
   entry.append(alert);
  }
   if(separated&&position===lastIndex&&role==='assistant')$('homeAiBody').append(entry);else holder.append(entry);
  }
  appendChatFile(holder);
 // Restoring history must not force scroll; user might be reading old entries.
}
// v0.4.8 PRIVATE: compare TWO unverified signals for one active source + question.
// Presentation-only diagnostic. No CFC approval, HAWM writes, or semantic verifier.
function computeReviewRequiredSignal(doc,qc,ai){
 const stop=(state,why)=>({state,why,aiLabel:null});
 if(!doc||!qc)return null;
 if(typeof doc.hash!=='string'||!/^[0-9a-f]{64}$/.test(doc.hash)||
    typeof doc.extractedSha!=='string'||!/^[0-9a-f]{64}$/.test(doc.extractedSha)||
    typeof doc.text!=='string'||!doc.token)
  return stop('STOP_SOURCE_BINDING','Niekompletny identyfikator aktualnego dokumentu.');
 if(qc.schema!=='CFC_HAWM_DOCUMENT_QUICKCHECK_V0_1'||
    qc.mode!=='BOUNDED_OFFLINE_LEXICAL_RULE_NOT_AI'||
    !['POTENTIAL_CONTRADICTION','NO_PATTERN_MATCH_NOT_CLEARANCE'].includes(qc.kind)||
    qc.decision!=='NOT_CHECKED_BY_CFC'||qc.cfc_evaluated_document!==false||
    qc.controller_executed!==false||qc.action_authorized!==false||
    qc.source_authority_verified!==false||qc.sources_independently_verified!==false)
  return stop('STOP_QC_CONTRACT','Nieobsługiwany wynik lub niedozwolona deklaracja autorytetu Quickcheck.');
 if(qc.source_sha256!==doc.hash||qc.extracted_sha256!==doc.extractedSha||
    qc.source_filename_untrusted!==doc.name||qc._ui_bound_token!==doc.token)
  return stop('STOP_SOURCE_BINDING','Quickcheck i aktywny załącznik nie mają identycznego powiązania.');
 if(typeof qc.question!=='string'||!qc.question.trim()||qc._ui_bound_question!==qc.question)
  return stop('STOP_QUESTION_BINDING','Brak potwierdzenia pytania użytego dla Quickcheck.');
 const quotes=qc.quotes;
 if(!Array.isArray(quotes)||quotes.length!==(qc.kind==='POTENTIAL_CONTRADICTION'?2:0)||
    !quotes.every(q=>q&&Number.isInteger(q.extracted_start_char)&&Number.isInteger(q.extracted_end_char)&&
       q.extracted_start_char>=0&&q.extracted_start_char<q.extracted_end_char&&
       q.extracted_end_char<=doc.text.length&&q.exact_in_extracted_text===true&&
       doc.text.slice(q.extracted_start_char,q.extracted_end_char)===q.text))
  return stop('STOP_QC_QUOTES','Cytaty Quickcheck nie pasują dokładnie do aktywnego tekstu lub offsetów.');
 if(!ai)return {state:'WAITING_FOR_AI',why:'Quickcheck wykonany; oczekiwanie na osobną odpowiedź Qwen. Nie jest to ocena CFC.',aiLabel:null};
 if(ai.source_sha256!==doc.hash||ai.extracted_sha256!==doc.extractedSha||
    ai._ui_bound_token!==doc.token||ai._ui_bound_question!==qc.question||
    ai.document_characters_sent!==doc.text.length)
  return stop('STOP_AI_SOURCE_OR_QUESTION_BINDING','Odpowiedź Qwen nie ma identycznego źródła i pytania. Porównanie wstrzymane.');
 if(ai.complete!==true||typeof ai.answer!=='string')
  return {state:'REVIEW_REQUIRED_AI_UNAVAILABLE',why:'Brak kompletnej odpowiedzi modelu. Nie wolno wyciągać wniosków z Quickcheck ani CFC.',aiLabel:null};
 const first=ai.answer.split(/\r?\n/).map(x=>x.trim()).find(Boolean)||'';
 if(!['SPRZECZNE','SPOJNE','NIEJEDNOZNACZNE'].includes(first))
  return {state:'REVIEW_REQUIRED_AI_LABEL_UNPARSEABLE',why:'Brak jednoznacznej etykiety w pierwszym wierszu odpowiedzi AI. Nie zgadujemy jej z uzasadnienia.',aiLabel:null};
 if(qc.kind==='POTENTIAL_CONTRADICTION'&&first==='SPOJNE')
  return {state:'REVIEW_REQUIRED_AI_QC_DISAGREEMENT',why:'AI wskazał SPOJNE, ale ograniczony Quickcheck wykrył możliwą sprzeczność. Sprawdź cytaty i źródło. Żaden z wyników nie jest autorytatywny.',aiLabel:first};
 if(qc.kind==='POTENTIAL_CONTRADICTION')
  return {state:'POSSIBLE_CONTRADICTION_REVIEW',why:'Quickcheck znalazł możliwy konflikt. Etykieta AI nie potwierdza poprawności dokumentu.',aiLabel:first};
 return {state:'NO_PATTERN_MATCH_NOT_CLEARANCE',why:'Quickcheck nie znalazł swojej pary wzorców. To NIE oznacza poprawności dokumentu ani odpowiedzi AI (również gdy AI jest zbyt pewny).',aiLabel:first};
}
function ensureReviewRequiredPanel(){
 let panel=$('homeReviewRequired');if(panel)return panel;
 const anchor=$('homeDocumentAiResult');if(!anchor)return null;
 panel=document.createElement('section');panel.id='homeReviewRequired';panel.className='home-quick-review';
 panel.hidden=true;panel.setAttribute('role','status');panel.setAttribute('aria-live','polite');
 panel.setAttribute('aria-label','Porównanie dwóch niezweryfikowanych sygnałów');
 const heading=document.createElement('h3');heading.id='homeReviewRequiredTitle';
 const body=document.createElement('p');body.id='homeReviewRequiredMessage';
 const notice=document.createElement('small');notice.id='homeReviewRequiredLimit';
 notice.textContent='PRYWATNY PROTOTYP v0.4.8 · Tylko sygnał UI; nie ocena znaczenia, nie wynik CFC ani dowód autoryzacji. M6 OPEN.';
 panel.append(heading,body,notice);anchor.after(panel);return panel;
}
function renderReviewRequired(){
 const panel=ensureReviewRequiredPanel();if(!panel)return;
 const result=computeReviewRequiredSignal(importedDocument,quickDocumentReview,currentDocumentAi);
 if(!result){panel.hidden=true;panel.dataset.state='NO_CURRENT_PAIR';return;}
 panel.hidden=false;panel.dataset.state=result.state;
 set('homeReviewRequiredTitle',result.state);
 set('homeReviewRequiredMessage',result.why+(result.aiLabel?' · Etykieta AI: '+result.aiLabel:'')+' · Wymagana ocena człowieka; bez decyzji CFC.');
}

// Document-specific local AI, bound to the EXACT importer token and source digest.
// Deliberately separate from native HAWM conversation and offline lexical Quickcheck.
function renderDocumentAi(){
 const box=$('homeDocumentAiResult');if(!box)return;
 const v=currentDocumentAi;
 if(!v||!importedDocument||v.source_sha256!==importedDocument.hash){box.hidden=true;renderReviewRequired();return;}
 box.hidden=false;
 box.dataset.result=v.complete===true?'reply':'missing';
 set('homeDocumentAiHeading',v.complete?'ODPOWIEDŹ LOKALNEGO AI NA DOKUMENT':'BRAK KOMPLETNEJ ODPOWIEDZI AI');
 set('homeDocumentAiMeta',v.model_reported+' · pełny tekst '+v.document_characters_sent+' znaków · SHA-256: '+v.source_sha256.slice(0,16)+'…');
 set('homeDocumentAiAnswer',v.answer?.trim()||'(Model nie zwrócił tekstu odpowiedzi.)');
 set('homeDocumentAiNote',v.complete?'NIEZWERYFIKOWANE. To osobne wywołanie Ollama z pełnym tekstem, NIE zapisano odpowiedzi w HAWM. Quickcheck i CFC pozostają odrębne.':'NIEKOMPLETNE. Przyczyna: '+String(v.finish_reason||'brak tekstu')+'. Nie uznawaj za zakończoną analizę.');
 renderReviewRequired();
}
// A bounded offline lexical review, NOT model output and never a CFC verdict.
function renderQuickDocumentReview(){
 const card=$('homeQuickReview');if(!card)return;
 const item=quickDocumentReview;
 if(!item||!importedDocument||item.source_sha256!==importedDocument.hash){
   card.hidden=true;set('homeQuickTitle','');set('homeQuickDetails','');$('homeQuickQuotes').replaceChildren();$('homeQuickExport').disabled=true;renderReviewRequired();return;
 }
 card.hidden=false;set('homeQuickTitle',item.headline);set('homeQuickDetails',item.details);
 const holder=$('homeQuickQuotes');holder.replaceChildren();
 for(const q of item.quotes||[]){const node=document.createElement('blockquote');node.textContent=q.text;holder.append(node);}
 set('homeQuickScope','OGRANICZONY TEST LEKSYKALNY OFFLINE · NIE AI · CFC NIE OCENIAŁ');
 $('homeQuickExport').disabled=!quickReportZipB64;
 renderReviewRequired();
}
function exportQuickReport(){
 if(!quickReportZipB64||!importedDocument||quickDocumentReview?.source_sha256!==importedDocument.hash)
   throw Error('No current bound quickcheck ZIP. Recheck the document.');
 const bin=atob(quickReportZipB64),data=new Uint8Array(bin.length);
 for(let i=0;i<bin.length;i++)data[i]=bin.charCodeAt(i);
 const u=URL.createObjectURL(new Blob([data],{type:'application/zip'}));
 const a=document.createElement('a');a.href=u;a.download='CFC_HAWM_DOCUMENT_QUICKCHECK_NOT_CFC.zip';document.body.append(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(u),1000);
}
async function ensureExistingHawmForChat(){
 if(session.initialized)return;
 if(!session.native)throw Error('Native HAWM unavailable. No session created.');
 let s=await req('/api/native/state');
 // Reuse any existing state and history; NEVER replace a populated project.
 const populated=Boolean(String(s.project_name||'').trim()||(s.chat||[]).length||
   (s.claims||[]).length||(s.evidence||[]).length||(s.unresolved||[]).length||
   String(s.task||'').trim()||(s.ledger||[]).length||s.mapping_draft);
 if(!populated){
   await req('/api/native/new-project',{project_name:'CFC × HAWM / Document working session'});
   s=await req('/api/native/state');
 }
 session.initialized=true;session.prepared=false;session.confirmed=false;session.executed=false;session.latest=null;
 refreshState(s);
}
// Reviewer v0.3 UI verdict. Presentation only; no controller modification or action authority.
function statusProjection(){
 if(importedDocument)return {kind:'not-checked',title:'NIE SPRAWDZONO',scope:'Dokument: '+importedDocument.name,
   reason:'Dokument odczytano jako niezweryfikowany. CFC nie kontrolował jego treści; stary wynik syntetyczny nie dotyczy tego pliku.'};
 const raw=session.executed?session.latest?.result?.raw:null;
 if(!session.confirmed||!raw||raw.engine_sha256!==hash||typeof raw.control_closure!=='boolean')
  return {kind:'not-checked',title:'NIE SPRAWDZONO',scope:'Bieżąca rozmowa',reason:'Nie ma aktualnego wyniku CFC dla rozmowy. Chat i adapter offline nie przyznają uprawnień.'};
 if(raw.control_closure===true)return {kind:'go',title:'GO',scope:'Tylko przypadek syntetyczny',
  reason:'CFC dopuścił zamknięcie ograniczonego przypadku. NIE jest to zatwierdzenie dokumentu ani realnej akcji.'};
 const g=raw.gates||{};
 const hard=g.scope_adequacy_valid===false||g.global_consistency_valid===false||
  (raw.claim_states||[]).some(x=>x.status==='QUARANTINED');
 if(hard)return {kind:'stop',title:'STOP',scope:'Tylko przypadek syntetyczny',
  reason:'CFC nie pozwala zamknąć przypadku: wykryto przeszkodę. Surowe control_closure=false; zobacz bramki w trybie zaawansowanym.'};
 return {kind:'hold',title:'HOLD',scope:'Tylko przypadek syntetyczny',
  reason:'Brak podstaw do zamknięcia decyzji. CFC zwrócił control_closure=false; wynik nie upoważnia do działania.'};
}
function renderStatusProjection(){
 const v=statusProjection(),node=$('homeResultCard');if(!node)return;
 node.dataset.verdict=v.kind;set('homeResultVerdict',v.title);set('homeResultScope',v.scope);set('homeResultReason',v.reason);
 set('homeResultBoundary','M6: ZNANA OTWARTA GRANICA · NIE jest to autoryzacja realnej akcji · surowy ślad w trybie zaawansowanym.');
}
function appendChatFile(holder){
 if(!importedDocument)return;
 const node=document.createElement('article');node.className='chat-attachment';
 const title=document.createElement('strong');title.textContent='📎 '+importedDocument.name;
 const meta=document.createElement('p');meta.textContent='Plik lokalny · SHA-256: '+importedDocument.hash.slice(0,16)+'… · NIEZWERYFIKOWANY · CFC NIE OCENIAŁ PLIKU';
 node.append(title,meta);holder.append(node);
}
const HOME_MESSAGE_LIMIT=3000;
function updateHomeMessageSize(){
 const total=$('homeChatText').value.length;
 const over=total>HOME_MESSAGE_LIMIT;
 set('homeChatLength',total+' / '+HOME_MESSAGE_LIMIT+' '+ui('size')+(over?' · '+ui('sizeExceeded'):''));
 $('homeChatLength').style.color=over?'#ffc2a6':'';
}
function updateHomeControls(){
 const localModel=chatScope==='free'?generalChatConfigured:(session.native&&displayedChatMode.includes('LOCAL AI MODEL'));
 const ready=chatScope==='free'?generalChatConfigured:session.native;
 $('homeChatText').disabled=!ready;$('homeChatSend').disabled=!ready;
 $('homeStart').disabled=!session.native||session.initialized;$('homeSetup').hidden=true;
 set('homeModelMode',localModel?ui('modeAI'):ui('modeOffline'));
 const status=chatScope==='free'?(!localModel?ui('scopeUnavailable'):ui('scopeFreeNote')):
 !session.native?ui('statusUnavailable'):
 !session.initialized?ui('statusNoState'):
 !localModel?'Adapter testowy: możesz wysłać wiadomość do HAWM. To nie model AI.':ui('statusConnected');
 set('homeChatStatus',status);
}
async function sendHomeChat(){
 if(chatScope==='hawm'&&!session.native)throw Error('HAWM is unavailable.');
 if(chatScope==='free'&&!generalChatConfigured)throw Error('General chat requires a configured local AI model.');
  // P51: source-bound document analysis uses the separate local AI route.
 if(chatScope==='hawm')await ensureExistingHawmForChat();
 const msg=$('homeChatText').value.trim();if(!msg)return {cancelled:true};
 if(msg.length>HOME_MESSAGE_LIMIT)throw Error('Message is '+msg.length+' characters, above the '+HOME_MESSAGE_LIMIT+'-character send limit. Nothing sent; the full text remains in the box.');
 if(importedDocument && msg.length>600)throw Error('Pytanie do załącznika: maks. 600 znaków w obecnym ograniczonym teście.');
 set('homeChatStatus',ui('statusWaiting'));
 if(chatScope==='free'){
   if(importedDocument){
    const doc=importedDocument;
    const v=await req('/api/document-intake/ai-review',{
     token:doc.token,question:msg,expected_source_sha256:doc.hash
    });
    if(!importedDocument||importedDocument.token!==doc.token||
       importedDocument.hash!==doc.hash||
       v?.schema!=='CFC_HAWM_DOCUMENT_LOCAL_AI_V0_4_4'||
       v.source_sha256!==doc.hash||v.extracted_sha256!==doc.extractedSha||
       v.mode!=='LOCAL_OLLAMA_UNCHECKED_NOT_CFC'||
       v.cfc_run!==false||v.cfc_evaluated_document!==false||
       v.native_hawm_written!==false||v.source_verified!==false||
       v.human_approval!==false||v.full_extracted_text_sent!==true||
       v.document_characters_sent!==doc.text.length||
       typeof v.answer!=='string'||typeof v.complete!=='boolean'){
      throw Error('P51_DOCUMENT_SOURCE_OR_TRUST_BOUNDARY_REFUSED');
    }
    const incomplete=!v.complete||!v.answer.trim();
    generalHistory.length=0;
    generalHistory.push(
     {role:'user',content:msg},
     {role:'assistant',content:incomplete?'BRAK UKOŃCZONEJ ODPOWIEDZI AI':v.answer,incomplete}
    );
    $('homeChatText').value='';updateHomeMessageSize();
    renderHomeChat(session.hawms||{chat:[]});
     // P61-R5: presentation-only information for source-bound AI reply.
     set('homeAiScope','DOCUMENT AI | CFC NOT RUN');
     const p61Note=$('homeAiWarning');
     p61Note.textContent=
      'MODEL COMPLETE: '+(incomplete?'NO':'YES')+
      ' | ANSWER UNVERIFIED | HUMAN REVIEW REQUIRED'+
      ' | SOURCE: '+doc.name+' | SHA-256: '+doc.hash+
      (incomplete?' | INCOMPLETE ANSWER':'');
     p61Note.hidden=false;
    set('homeChatStatus','DOKUMENT NIEZWERYFIKOWANY · AI NIESPRAWDZONA · CFC NIE OCENIAŁ');
    say(incomplete?'P51 DOCUMENT AI INCOMPLETE':'P51 DOCUMENT AI RECEIVED · NO CFC');
    return {incomplete,general:true};
   }
  // The request contains only general chat turns; native HAWM is never contacted.
  const messages=generalHistory.slice(-10).map(x=>({role:x.role,content:x.content}));
  messages.push({role:'user',content:msg});
  const result=await req('/api/general-chat',{messages});
  if(result?.mode!=='GENERAL_LOCAL_AI_EPHEMERAL'||result?.hawm_written!==false||result?.cfc_run!==false||typeof result.answer!=='string'){
   throw Error('Unexpected general-chat response. No HAWM or CFC claim accepted.');
  }
  generalHistory.push({role:'user',content:msg},{role:'assistant',content:result.answer||'(No answer text)',incomplete:result.incomplete===true});
  // Only a bounded in-tab history; no localStorage, no native HAWM writes.
  if(generalHistory.length>24)generalHistory=generalHistory.slice(-24);
  $('homeChatText').value='';updateHomeMessageSize();renderHomeChat(session.hawms||{chat:[]});
  set('homeChatStatus',ui(result.incomplete?'scopeIncomplete':'scopeReceived'));
  say(result.incomplete?'GENERAL CHAT INCOMPLETE: no controller run, no HAWM state change.':'General model reply received. No HAWM state change or CFC run.');
  return {incomplete:result.incomplete===true,general:true};
 }
 activeNativeReplyBinding=null;
 // While another question is in flight, the preceding native reply is history.
 renderHomeChat(session.hawms||{chat:[]});
 currentDocumentAi=null;quickDocumentReview=null;quickReportZipB64=null;renderDocumentAi();renderQuickDocumentReview();
 const boundToken=importedDocument?.token||null;
 // Bind source identity into the same native HAWM history as the question.
 // The file is not made evidence, and existing task/mapping is never overwritten.
 let nativeMessage=msg;
 let contextStatus='NO_DOCUMENT_ATTACHED';
 let documentAiIncomplete=false;
 if(boundToken){
  const boundDoc=importedDocument;
  const docMessage=nativeMessageForDocument(msg,boundDoc);
  contextStatus=await attachUnverifiedDocumentContext(boundDoc);
  if(!importedDocument||importedDocument.token!==boundToken)
   throw Error('Document switched during HAWM binding; message refused.');
  nativeMessage=docMessage.message;
 }
 const next=await req('/api/native/chat',{message:nativeMessage});
 if(boundToken && (!importedDocument||importedDocument.token!==boundToken))
  throw Error('Document switched while native HAWM answered. Historical reply not bound to current import.');
 if(boundToken){
  const recorded=(next.chat||[]).some(x=>x.role==='user'&&x.content===nativeMessage);
  if(!recorded)throw Error('HAWM did not return the exact source-bound question. Treat reply as incomplete; no CFC action.');
 }
 $('homeChatText').value='';updateHomeMessageSize();
 const lastNative=Array.isArray(next.chat)?next.chat.at(-1):null;
 activeNativeReplyBinding=boundToken && lastNative?.role==='assistant'?
  {token:boundToken,sha:importedDocument.hash,question:nativeMessage,reply:String(lastNative.content||'')}:null;
 restoredHistoricalChat=false; // Only a new successful native write ends historical display.
 refreshState(next);
 if(boundToken){
   // This is a separate, deliberately narrow diagnostic. The chat message is
   // saved in HAWM, but neither its answer nor this diagnostic enters CFC.
   quickDocumentReview=null;quickReportZipB64=null;renderQuickDocumentReview();
   if(!importedDocument||importedDocument.token!==boundToken)throw Error('Document changed during chat: no result bound.');
   const review=await req('/api/document-intake/quickcheck',{token:boundToken,question:msg});
   if(review?.result?.cfc_evaluated_document!==false||review?.result?.controller_executed!==false||
      review.result.source_sha256!==importedDocument.hash||review.result.decision!=='NOT_CHECKED_BY_CFC')
     throw Error('Quickcheck trust boundary mismatch: result refused.');
   if(importedDocument?.token!==boundToken)throw Error('Document switched during Quickcheck: stale result refused.');
   quickDocumentReview={...review.result,_ui_bound_token:boundToken,_ui_bound_question:msg};quickReportZipB64=review.report_zip_b64;
   renderQuickDocumentReview();
   // An HTTP 200 is not a visible result. Fail explicitly if this panel does not render.
   const visibleReview=$('homeQuickReview');
   if(!visibleReview || visibleReview.hidden || !$('homeQuickTitle').textContent.trim() ||
      $('homeQuickQuotes').children.length!==(Array.isArray(review.result.quotes)?review.result.quotes.length:0))
     throw Error('QUICKCHECK_DISPLAY_INCOMPLETE: server returned a result but the UI did not render it');
   visibleReview.scrollIntoView({behavior:'auto',block:'center'});
   // v0.4.4: invoke Ollama through a separate EXACT token-bound endpoint.
   // Native HAWM 600-char limit does NOT control this full-text request.
   if(displayedChatMode.includes('LOCAL AI MODEL')){
     try{
       const v=await req('/api/document-intake/ai-review',{token:boundToken,question:msg,expected_source_sha256:importedDocument.hash});
       if(!importedDocument||importedDocument.token!==boundToken||v?.schema!=='CFC_HAWM_DOCUMENT_LOCAL_AI_V0_4_4'||
          v.source_sha256!==importedDocument.hash||v.extracted_sha256!==importedDocument.extractedSha||
          v.mode!=='LOCAL_OLLAMA_UNCHECKED_NOT_CFC'||v.cfc_run!==false||v.cfc_evaluated_document!==false||
          v.native_hawm_written!==false||v.full_extracted_text_sent!==true||v.document_characters_sent!==importedDocument.text.length||
          typeof v.answer!=='string'||typeof v.complete!=='boolean')
         throw Error('DOCUMENT_AI_TRUST_BOUNDARY_OR_SOURCE_MISMATCH');
       currentDocumentAi={...v,_ui_bound_token:boundToken,_ui_bound_question:msg};renderDocumentAi();
       documentAiIncomplete=!v.complete;
       if(v.complete)$('homeDocumentAiResult').scrollIntoView({behavior:'auto',block:'center'});
       if(!v.complete)set('homeChatStatus','BRAK KOMPLETNEJ ODPOWIEDZI LOKALNEGO AI. Quickcheck wykonano osobno.');
       else set('homeChatStatus','ODPOWIEDŹ QWEN NA PEŁNY TEKST PDF: pokazana osobno pod Wyślij. NIEZWERYFIKOWANA · CFC NIE SPRAWDZAŁ.');
     }catch(e){
       documentAiIncomplete=true;
       if(importedDocument?.token!==boundToken){currentDocumentAi=null;renderDocumentAi();throw Error('Document switched during Ollama request: refusing stale AI result.');}
       currentDocumentAi={source_sha256:importedDocument.hash,extracted_sha256:importedDocument.extractedSha,
                          _ui_bound_token:boundToken,_ui_bound_question:msg,
                          model_reported:'Ollama',document_characters_sent:importedDocument.text.length,
                          answer:'',complete:false,finish_reason:'LOCAL_AI_ERROR: '+String(e.message||e)};
       renderDocumentAi();
       set('homeChatStatus','ANALIZA AI NIEUDANA: '+String(e.message||e)+'. Quickcheck pozostaje osobny.');
     }
   }
 }
  const last=(next.chat||[]).at(-1);
  const emptyModelReply=last?.role==='assistant'&&last?.model_mode==='openai_compatible'&&(!String(last.content||'').trim()||/^\(model returned no conversational text\)$/i.test(String(last.content||'').trim()));
 if(last?.model_mode==='error')set('homeChatStatus',ui('statusError'));
  else if(emptyModelReply)set('homeChatStatus','BRAK ODPOWIEDZI AI: model nie zwrócił tekstu rozmowy. Quickcheck (jeśli wykonany) jest osobnym testem offline.');
 else if(last?.role==='assistant'&&last.model_mode!=='openai_compatible'){set('homeChatStatus','TEST OFFLINE: odpowiedź adaptera zapisana w HAWM. To NIE AI; CFC NIE URUCHOMIONO.');say('HAWM offline adapter, not a model. No CFC run.');}
 else if(last?.role!=='assistant')set('homeChatStatus',ui('statusEmpty'));
 else if(inspectChatReply(last?.content).incomplete){
  if(!currentDocumentAi?.complete){set('homeChatStatus',ui('statusIncomplete'));say('BLOCKED: incomplete local AI response in HAWM; no CFC run.');return {incomplete:true};}
  set('homeChatStatus','Osobna odpowiedź AI na pełny tekst dokumentu jest dostępna poniżej. Natywny HAWM zwrócił wynik niekompletny.');
 }else if(inspectChatReply(last?.content).tailIssue){
  if(!currentDocumentAi?.complete){set('homeChatStatus',ui('statusMeta'));say('BLOCKED: unparsed proposal metadata in HAWM; no CFC run.');return {incomplete:true};}
  set('homeChatStatus','Osobna odpowiedź AI na pełny tekst dokumentu jest poniżej. Natywne metadane HAWM są niekompletne.');
 }else set('homeChatStatus',ui('statusReceived'));
 if(boundToken&&quickDocumentReview&&quickDocumentReview.source_sha256===importedDocument?.hash){
  if(currentDocumentAi?.complete)set('homeChatStatus','ODPOWIEDŹ LOKALNEGO AI NA PEŁNY DOKUMENT + QUICKCHECK: pokazane osobno; CFC NIE SPRAWDZAŁ.');
   if(!currentDocumentAi?.complete)set('homeChatStatus',emptyModelReply?'BRAK ODPOWIEDZI NATYWNEGO HAWM; wynik osobnej analizy AI i Quickcheck są poniżej.':'Quickcheck: wynik znajduje się poniżej pola Wyślij. Analiza AI odrębna.');
  if(documentAiIncomplete){say('BLOCKED: niekompletna analiza Ollama, ale Quickcheck został wykonany poprawnie. CFC NIE SPRAWDZAŁ.');return {incomplete:true};}
  say('QUICKCHECK DONE: wynik i cytaty pod Wyślij; raport ZIP dostępny; źródło zapisane w historii HAWM ('+contextStatus+'). To NIE AI ani decyzja CFC.');
 }else say('HAWM chat recorded. No local-model answer authorizes CFC closure.');
}
function selectProductView(view){
 productView=view==='lab'?'lab':'document';
 document.body.classList.toggle('document-mode',productView==='document');
 document.body.classList.toggle('lab-mode',productView==='lab');
 $('viewDoc').setAttribute('aria-pressed',String(productView==='document'));
 $('viewLab').setAttribute('aria-pressed',String(productView==='lab'));
 updateJourney();
}
// Navigation is presentation-only: never records approval or triggers CFC.
function navigateDocumentSection(n){
 const section=$('docSegment'+n);
 if(!section)return;
 for(let i=1;i<=4;i++){
  const button=$('docStage'+i);const selected=i===n;
  button.classList.toggle('selected',selected);
  if(selected)button.setAttribute('aria-current','location');
  else button.removeAttribute('aria-current');
 }
 const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 section.scrollIntoView({behavior:reduced?'auto':'smooth',block:'start'});
 section.focus({preventScroll:true});
}

function currentArticleAI(s){
 const saved=draftFromTask(s?.task),chat=Array.isArray(s?.chat)?s.chat:[];
 if(!saved)return {kind:'missing',message:'Save an article in HAWM first.'};
 for(let i=chat.length-2;i>=0;i--){
  const u=chat[i],a=chat[i+1];
  if(u?.role!=='user'||a?.role!=='assistant'||!String(u.content||'').startsWith(REVIEW_MARKER))continue;
  if(String(u.content||'')!==reviewPrompt(saved))continue;
  if(a.model_mode==='error')return {kind:'error',message:String(a.content||'Model adapter error')};
  if(a.model_mode!=='openai_compatible')continue;
  const reply=String(a.content||'');
  if(inspectChatReply(reply).incomplete||inspectChatReply(reply).tailIssue)return {kind:'incomplete',message:reply};
  return {kind:'reply',message:reply};
 }
 return {kind:'missing',message:'No AI response for this exact saved article. Older answers refer to other versions.'};
}
function showCurrentArticleAI(s){
 const ai=currentArticleAI(s);
 const labels={missing:'No current AI review',error:'Model request failed — no review',incomplete:'Incomplete model output — not a completed review',reply:'Local AI output · UNCHECKED'};
 set('latestReplyLabel',labels[ai.kind]);set('latestArticleReply',ai.message);
 $('latestArticleReply').dataset.state=ai.kind;
}
function updateDocumentProgress(){
 document.body.dataset.workingState=session.initialized?'true':'false';
 const saved=!!draftFromTask(session.hawms?.task)&&!$('articleDraft').dataset.dirty;
 const ai=saved?currentArticleAI(session.hawms):{kind:'missing'};
 const reviewed=ai.kind==='reply' && !!docReviewInfo?.ai_reply_sha256 && docReviewInfo.ai_review==='LOCAL_AI_RESPONSE_RECORDED_UNCHECKED';
 const disposition=reviewed&&!!docReviewInfo?.human_disposition;
 const milestones=[saved,reviewed,disposition,disposition&&!!docReviewInfo?.version_captured];
 const next=!session.initialized?'Start a local working state.':!saved?'Save the article before AI review.':!docReviewInfo?.version_captured?'Capture the saved article version.':!reviewed?(ai.kind==='error'?'Model request failed; inspect the error before retrying.':ai.kind==='incomplete'?'AI reply incomplete; do not treat it as reviewed.':'Ask the local AI to review this saved version.'):
 !disposition?'Read the model output; record a human decision with a reason.':'The operator decision is recorded. Export the review ZIP for inspection; this is not publication approval.';
 for(let n=1;n<=4;n++){
  const el=$('docStage'+n);if(!el)continue;
  const isDone=!!milestones[n-1];const isCurrent=!isDone&&(n===1||milestones[n-2]);
  el.classList.toggle('done',isDone);el.classList.toggle('current',isCurrent);
  const label=el.querySelector('.nav-progress');if(label)label.textContent=isDone?(n===4?'Dostępny':'Zapisano'):isCurrent?'Aktualny etap':'Do zrobienia';
 }
 set('docFlowStatus','NEXT: '+next);
 if(productView==='document'){
  set('plainStatus',disposition?'Human review recorded':reviewed?'AI response ready for human review':saved?'Saved article ready':'Start document review');
  set('plainDetail','Human review is distinct from CFC closure; no document publication authority is granted.');
 }
}

const set=(id,s)=>{$(id).textContent=String(s)};
function say(s){set('notice',s)}

// v0.9.18 UI DRAFT: navigation only. All action requests, approvals and gates stay in original handlers.
let selectedFlowStep=1;
const FLOW_DESCRIPTIONS={
  1:['01 · Start a review','Choose a synthetic scenario and create a local HAWM working state. Existing work is replaced only after explicit confirmation.'],
  2:['02 · Prepare a mapping','Prepare a draft from the current HAWM state. This does not certify evidence or grant action permission.'],
  3:['03 · Approve exact mapping','Inspect bounded operator assertions and explicitly confirm the exact state. Historical approval cannot authorize a new action.'],
  4:['04 · Run frozen CFC','Run the original frozen CFC on the confirmed input. Claim status and closure are separate from real-world authorization.'],
  5:['05 · Attempt local-only release','A fresh frozen-CFC gate decides whether to create a local JSON token; no external action is performed.']
};
function updateFlowNavigation(){
  if(!$('flowHub'))return;
  const receipt=session.effectReceipt;
  const persistedApproval=!!(session.hawms?.mapping_draft?.status==='CONFIRMED');
  const states=[
    {label:session.initialized?'STATE READY':'START HERE',state:session.initialized?'done':'ready'},
    {label:session.prepared?'DRAFT READY':session.initialized?'AVAILABLE':'WAITING',state:session.prepared?'done':session.initialized?'ready':'waiting'},
    {label:session.confirmed?'CONFIRMED':persistedApproval?'REAPPROVE':session.prepared?'AVAILABLE':'WAITING',state:session.confirmed?'done':session.prepared||persistedApproval?'ready':'waiting'},
    {label:session.executed?'RESULT READY':receipt?'HISTORICAL':session.confirmed?'AVAILABLE':'WAITING',state:session.executed?'done':session.confirmed?'ready':'waiting'},
    {label:receipt?(receipt.decision==='BLOCKED'?'BLOCKED':'LOCAL TOKEN'):session.executed?'AVAILABLE':'WAITING',state:receipt?'done':session.executed?'ready':'waiting'}
  ];
  states.forEach(({label,state},i)=>{
    const n=i+1,button=$('flowNav'+n);if(!button)return;
    button.dataset.flowState=state;
    const flag=$('flowFlag'+n);if(flag)flag.textContent=label;
  });
}
function selectFlowStep(n,doScroll=true){
  if(!Number.isInteger(n)||n<1||n>5||!$('flowHub'))return;
  selectedFlowStep=n;
  const details=$('productDetails');details.dataset.flowStep=String(n);
  for(let i=1;i<=5;i++){
    const b=$('flowNav'+i);if(i===n)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');
  }
  const d=FLOW_DESCRIPTIONS[n];$('flowStageTitle').textContent=d[0];$('flowStageHelp').textContent=d[1];
  $('flowPrev').disabled=n===1;$('flowNext').disabled=n===5;
  updateFlowNavigation();
  if(doScroll){
    const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const node=[$('startPanel'),$('flowPrepareControl'),$('flowApproveControl'),$('decisionPanel'),$('effectPanel')][n-1];
    if(node){node.scrollIntoView({behavior:reduced?'auto':'smooth',block:'start'});}
  }
}
function showFiveStepLab(){
  productInspector='process';document.body.dataset.inspector='process';selectProductView('lab');
  $('openProcess').setAttribute('aria-expanded','true');
  $('openProcess').textContent='Ukryj proces zaawansowany';
  selectFlowStep(selectedFlowStep,false);
  const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  $('flowHub').scrollIntoView({behavior:reduced?'auto':'smooth',block:'start'});
}
function showDocumentWorkspace(){
  productInspector='process';document.body.dataset.inspector='process';selectProductView('document');
  $('openProcess').setAttribute('aria-expanded','true');
  $('openProcess').textContent='Ukryj proces zaawansowany';
  const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  $('chatHome').scrollIntoView({behavior:reduced?'auto':'smooth',block:'start'});
}
function initializeFlow(){
  for(let n=1;n<=5;n++)$('flowNav'+n).addEventListener('click',()=>selectFlowStep(n));
  $('flowPrev').addEventListener('click',()=>selectFlowStep(Math.max(1,selectedFlowStep-1)));
  $('flowNext').addEventListener('click',()=>selectFlowStep(Math.min(5,selectedFlowStep+1)));
  $('flowDetailsToggle').addEventListener('click',()=>{
    const expanded=$('productDetails').classList.toggle('flow-show-technical');
    $('flowDetailsToggle').setAttribute('aria-expanded',String(expanded));
    $('flowDetailsToggle').textContent=expanded?'▾ Hide technical details, document tools and reviewer notes':'▸ Show technical details, document tools and reviewer notes';
  });
  selectFlowStep(1,false);
}

function updateJourney(){
 const level=session.effectReceipt?5:session.executed?4:session.confirmed?3:session.prepared?2:session.initialized?1:0;
 for(let n=1;n<=5;n++){const item=$('stage'+n);if(!item)continue;item.className=n<=level?'done':n===level+1?'current':'';}
 const e=session.effectReceipt;
 const title=e?(e.decision==='BLOCKED'?'Release denied (test)':'Local demo token created'):
 session.executed?'Controller result available':session.confirmed?'Approval recorded — run CFC':session.prepared?'Review and approve mapping':session.initialized?'HAWM state ready':'Create a working state';
 set('plainStatus',title);
 set('plainDetail',e?'This is a local JSON-only effect, not a company workflow authorization.':
 'The local AI can discuss the case, but cannot approve evidence or execute any action.');
 updateDocumentProgress();
 updateFlowNavigation();
}

function banner(s,kind=''){set('decisionBanner',s);$('decisionBanner').className='banner '+kind;}
function clearEffect(message='NO ACTION ATTEMPTED'){
 session.effectReceipt=null;$('attemptEffect').disabled=true;$('downloadEffect').disabled=true;$('downloadBundle').disabled=true;
 set('effectBanner',message);$('effectBanner').className='banner';set('effectReason','Requires a CURRENT confirmed CFC run. Local JSON effect only.');
}
function emptyResult(message='NOT EVALUATED'){
 clearEffect();
 session.latest=null;session.executed=false;$('exportTrace').disabled=true;
 banner(message);renderStatusProjection();set('claimStatus','—');set('closureStatus','—');set('decisionWhy','No current CFC result for these inputs.');set('gates','No current CFC run.');
}
async function req(p,body){const i=body===undefined?{cache:'no-store'}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};
 const resp=await fetch(p,i);const obj=await resp.json();if(!resp.ok||obj.error)throw Error(obj.error||'HTTP '+resp.status);return obj;}
// Document review ledger is not connected to original CFC closure semantics.
async function refreshDocReview(){
 if(!session.initialized||!session.native){docReviewInfo=null;return;}
 try{
  const info=await req('/api/document-review/status');docReviewInfo=info;
  const decision=info.human_disposition;
  const labels={ISSUE_REMAINS:'Issue remains',REVISION_ADDRESSED_ISSUE_OPERATOR_ASSERTION:'Operator believes revision addresses issue (NOT verified)',AI_FINDING_REJECTED_BY_OPERATOR:'AI finding rejected by operator'};
  const msg=`Document SHA-256: ${info.document_sha256||'NO SAVED DOCUMENT'} · versions captured: ${info.saved_version_count} · model: ${info.ai_review} · human: ${decision?(labels[decision.decision]+' — '+decision.note):'NO CURRENT HUMAN DISPOSITION'} · no publication authority.`;
  set('docReviewStatus',msg);
  const captured=!!info.version_captured;
  $('docCapture').disabled=!!$('articleDraft').dataset.dirty||!info.document_sha256||captured;
  set('docCapture',captured?'✓ Version '+info.saved_version_count+' captured':'1. Capture saved version');
  $('docCapture').dataset.captured=captured?'true':'false';
  set('docCaptureResult',!info.document_sha256?'No saved article to capture.':captured?
    '✓ SAVED · Article version recorded ('+info.saved_version_count+' version(s)). SHA-256: '+info.document_sha256.slice(0,16)+'… · NOT publication authority.':
    'NOT YET CAPTURED · Save this exact article version before recording a human assessment.');
  $('docCaptureResult').dataset.state=captured?'success':'neutral';
  if(!decision){const feedback=$('docRecord').closest('.button-line')?.nextElementSibling;if(feedback?.classList.contains('operation-feedback')&&feedback.dataset.state==='success'){feedback.textContent='HISTORICAL · Previous operation applied to another article version. No CURRENT human decision.';feedback.dataset.state='warning';}}
  set('docRecordResult',decision?
    '✓ HUMAN DECISION RECORDED for this article version: '+(labels[decision.decision]||decision.decision)+'. No permission to publish.':
    'NO HUMAN DECISION for the current article version.');
  $('docRecordResult').dataset.state=decision?'success':'neutral';
  $('docRefresh').disabled=false;
  $('docRecord').disabled=!!$('articleDraft').dataset.dirty||!info.document_sha256||!info.version_captured||info.ai_review!=='LOCAL_AI_RESPONSE_RECORDED_UNCHECKED'||!info.ai_reply_sha256;
  $('docExport').disabled=!info.document_sha256;await refreshBoundClaim();updateJourney();
 }catch(e){docReviewInfo=null;set('docCaptureResult','ERROR: Could not read the document version — '+e.message);$('docCaptureResult').dataset.state='error';set('docRecordResult','No current decision status available.');set('docReviewStatus','DOCUMENT REVIEW UNAVAILABLE: '+e.message);$('docRecord').disabled=true;$('docCapture').disabled=true;$('docExport').disabled=true;}
}
// v0.9.14: bind a HUMAN-ASSERTED claim to an EXACT quote in the current document.
// This is NOT CFC assessment, source verification, or publication authority.
let boundClaimInfo=null;
async function refreshBoundClaim(){
 if(!session.native||!session.initialized){boundClaimInfo=null;return;}
 try{
  const x=await req('/api/document-review/claim/status');boundClaimInfo=x;
  const available=x.version_captured&&!$('articleDraft').dataset.dirty;
  $('bindDocClaim').disabled=!available;
  $('refreshDocClaim').disabled=false;
  const last=x.last_binding;
  if(!last){set('docClaimStatus','No claim bound to this article version. CFC NOT EVALUATED for this document.');await refreshAuthorityStatus();return;}
  set('docClaimStatus',(last.exact_source_still_matches?'✓ Exact quotation remains in the saved article. ':'Source quote is stale or missing. ')+
      (last.same_structured_hawm_state?'HAWM structured snapshot unchanged. ':'HAWM structured state changed since binding. ')+
      'Claim: '+last.claim+' | CFC: NOT EVALUATED. No external authority or publication approval.');
  await refreshAuthorityStatus();
 }catch(e){boundClaimInfo=null;$('bindDocClaim').disabled=true;set('docClaimStatus','Source link unavailable: '+e.message);$('authSave').disabled=true;set('authStatus','Powiązanie źródła niedostępne — brak autoryzacji.');}
}
async function bindBoundClaim(){
 if(!boundClaimInfo?.version_captured||$('articleDraft').dataset.dirty)throw Error('Capture the saved article version first');
 const claim=$('boundClaim').value.trim(),exact_quote=$('boundQuote').value;
 if(claim.length<8||claim.length>300||exact_quote.length<8||exact_quote.length>420)throw Error('Enter a claim and an exact source quotation');
 const h=await req('/api/document-review/claim/status');
 if(!h.document_sha256||!h.version_captured)throw Error('Document has not been captured');
 // UI has no authority to certify the source or independent evidence.
 if(!window.confirm('Save this operator-asserted claim and literal source quotation?\n\nCLAIM: '+claim+'\nQUOTE: '+exact_quote+'\n\nNo CFC evaluation or publication approval.'))return {cancelled:true};
 await req('/api/document-review/claim/bind',{expected_document_sha256:h.document_sha256,
   expected_hawm_state_sha256:h.hawm_state_sha256,claim,exact_quote});
 await refreshBoundClaim();
 set('docClaimStatus','✓ SOURCE LINK SAVED. The exact quotation is recorded; the claim has not been verified. CFC: NOT EVALUATED.');
 say('Bound operator claim to exact saved document text; no controller run, publication approval or external attestation.');
}
// v0.9.15: operator-reported authority metadata is never an attestation.
let currentAuthorityInfo=null;
// User-facing summary is descriptive only; technical negative codes remain unchanged.
const AUTH_NEGATIVE_PL={
 ISSUED_IN_FUTURE_PER_LOCAL_CLOCK:'Data wystawienia jest w przyszłości (wg zegara urządzenia).',
 NOT_YET_VALID_PER_LOCAL_CLOCK:'Poświadczenie jeszcze nie obowiązuje (wg zegara urządzenia).',
 EXPIRED_PER_LOCAL_CLOCK:'Poświadczenie wygasło (wg zegara urządzenia).',
 DECLARED_SCOPE_MISMATCH:'Deklarowany zakres nie obejmuje planowanej czynności.',
 REPORTED_REVOCATION:'Zgłoszono cofnięcie poświadczenia; status nie został niezależnie sprawdzony.'
};
async function refreshAuthorityStatus(){
 if(!session.native||!session.initialized){currentAuthorityInfo=null;return;}
 try{
  const x=await req('/api/document-review/authority/status');currentAuthorityInfo=x;
  $('authSave').disabled=!x.binding_current||!!$('articleDraft').dataset.dirty;
  $('authRefresh').disabled=false;
  const raw=$('authRawCodes');
  if(!x.binding_current){set('authStatus','Brak aktualnego powiązania twierdzenia z cytatem.\nAutorytet: NIEZWERYFIKOWANY. CFC: NOT EVALUATED.');raw.textContent='SOURCE_BINDING_NOT_CURRENT';return;}
  if(!x.last_review){set('authStatus','Cytat jest powiązany z dokumentem. Nie zapisano jeszcze deklaracji poświadczenia.\nAutorytet: NIEZWERYFIKOWANY. CFC: NOT EVALUATED.');raw.textContent='NO_DECLARED_AUTHORITY_METADATA';return;}
  const r=x.last_review,flags=Array.isArray(r.negative_flags)?r.negative_flags:[];
  const problems=flags.length?flags.map(f=>'• '+(AUTH_NEGATIVE_PL[f]||('Wykryta przeszkoda: '+f))).join('\n'):
       'Nie wykryto przeszkód w podanych danych. To NIE jest potwierdzenie autentyczności poświadczenia.';
  const intended=r.intended_action==='PUBLIC_RELEASE'?'publikacja dokumentu':'przegląd wewnętrzny';
  set('authStatus',`Podany wystawca: ${r.issuer_claimed}\nPlanowana czynność: ${intended}\n\n${problems}\n\nAutorytet: NIEZWERYFIKOWANY.\nCFC: NOT EVALUATED. Publikacja: NIEAUTORYZOWANA.`);
  raw.textContent=flags.length?flags.join(' · '):'NO_NEGATIVE_FLAGS_IN_DECLARED_METADATA';
 }catch(e){currentAuthorityInfo=null;$('authSave').disabled=true;set('authStatus','Nie udało się sprawdzić deklaracji: '+e.message+'\nBrak zweryfikowanego autorytetu.');$('authRawCodes').textContent='STATUS_UNAVAILABLE';}
}
async function refreshAuthorityFromButton(){
 await refreshAuthorityStatus();
 if(!currentAuthorityInfo)throw Error('Brak aktualnego wyniku sprawdzenia poświadczenia.');
 say('Sprawdzono aktualność deklarowanych danych poświadczenia. Wynik znajduje się w panelu poniżej. Autorytet NIEZWERYFIKOWANY; CFC: NOT EVALUATED.');
}
async function recordAuthority(){
 if(!currentAuthorityInfo?.binding_current||$('articleDraft').dataset.dirty)throw Error('Najpierw zapisz aktualne powiązanie twierdzenia i cytatu.');
 const issuer_claimed=$('authIssuer').value.trim(),issued_at=$('authIssued').value,valid_from=$('authFrom').value,valid_to=$('authTo').value;
 if(issuer_claimed.length<3||issuer_claimed.length>120||!issued_at||!valid_from||!valid_to)throw Error('Wprowadź wystawcę i trzy daty.');
 const x=await req('/api/document-review/authority/status');
 if(!x.binding_current)throw Error('Powiązanie źródła jest nieaktualne.');
 if(!window.confirm('Zapisujemy wyłącznie Twoje deklaracje o poświadczeniu. Nie potwierdzamy wystawcy, podpisu ani cofnięcia. Nie będzie oceny CFC i zgody na publikację. Kontynuować?'))return {cancelled:true};
 await req('/api/document-review/authority/review',{
  expected_document_sha256:x.document_sha256,expected_hawm_state_sha256:x.hawm_state_sha256,
  expected_binding_event_sha256:x.binding_event_sha256,issuer_claimed,issued_at,valid_from,valid_to,
  declared_scope:$('authScope').value,intended_action:$('authAction').value,revocation_report:$('authRevocation').value
 });
 await refreshAuthorityStatus();
 say('Zapisano deklarowane dane i przeszkody. Autorytet pozostaje NIEZWERYFIKOWANY. Brak wykonania CFC.');
}
async function captureDoc(){
 if(!docReviewInfo?.document_sha256||$('articleDraft').dataset.dirty)throw Error('Save the exact document in HAWM first');
 const x=await req('/api/document-review/capture',{expected_document_sha256:docReviewInfo.document_sha256});
 await refreshDocReview();await refreshBoundClaim();say(x.already_captured?'Version already captured.':'Captured current untrusted document version; no publication authority.');
}
async function recordDoc(){
 const current=docReviewInfo;
 if(!current?.version_captured||!current.ai_reply_sha256||$('articleDraft').dataset.dirty)throw Error('Capture and review this exact saved document first');
 const decision=$('docDecision').value,note=$('docNote').value.trim();
 if(!decision)throw Error('Choose a human assessment explicitly before recording');
 if(note.length<8||note.length>350)throw Error('Enter 8–350 characters explaining your assessment');
 if(!window.confirm('Record the following human decision for this exact document?\n\nDECISION: '+$('docDecision').selectedOptions[0].textContent+'\nREASON: '+note+'\n\nThis is NOT permission to publish.'))return {cancelled:true};
 await req('/api/document-review/record',{expected_document_sha256:current.document_sha256,expected_ai_reply_sha256:current.ai_reply_sha256,decision,note});
 $('docNote').value='';$('docDecision').value='';await refreshDocReview();say('Human decision recorded for this document version only — no CFC authorization.');
}
async function exportDoc(){
 if(!docReviewInfo?.document_sha256)throw Error('No saved document');
 const link=document.createElement('a');link.href='/api/document-review/export';link.download='CFC_HAWM_DOCUMENT_REVIEW_v0_9_1.zip';document.body.append(link);link.click();link.remove();say('Document review ZIP requested; verify saved file. This export is not independent custody.');
}
function scenario(){return cases[$('scenario').value]}
function fillCase(){const previousHistory=restoredHistoricalChat?session.hawms:null;restoredHistoricalChat=false;const c=scenario();set('scenarioNote',c.note);$('required').value=c.required;$('provenance').value=c.prov;$('independence').value=c.ind;$('scope').value=c.scope;$('e1').value=c.rows[0];$('e2').value=c.rows[1]||'POSITIVE_CURRENT';$('e2Group').hidden=c.count===1;
 session.initialized=false;session.prepared=false;session.confirmed=false;session.hawms=null;session.editedAfterConfirm=false;$('articleDraft').value=SAMPLE_DRAFT;delete $('articleDraft').dataset.dirty;$('articleDraft').disabled=true;$('saveDraft').disabled=true;$('discussDraft').disabled=true;set('draftStatus','Create a HAWM working state first.');set('draftSavedPreview','No saved article.');set('draftReviewStatus','Article AI review: NOT ATTEMPTED');set('docReviewStatus','No active document.');set('docClaimStatus','No claim bound for this version.');set('authStatus','Brak aktualnego powiązania. Autorytet NIEZWERYFIKOWANY.');$('authSave').disabled=true;$('bindDocClaim').disabled=true;set('docCaptureResult','No article version captured.');$('docCaptureResult').dataset.state='neutral';set('docRecordResult','No human decision for this document.');$('docRecordResult').dataset.state='neutral';set('docCapture','1. Capture saved version');docReviewInfo=null;$('docRecord').disabled=true;$('docCapture').disabled=true;$('docExport').disabled=true;$('docRefresh').disabled=true;set('chatEvidence','Chat evidence: 0 local AI replies.');set('bundleCompleteness','No export yet.');
 $('prepare').disabled=true;$('confirm').disabled=true;$('run').disabled=true;$('saveState').disabled=true;$('unresolvedEditor').disabled=true;$('sendChat').disabled=true;$('chatText').disabled=true;
 emptyResult();set('claimPreview','—');set('evidencePreview','No state created');set('nativeState','Create a new HAWM state for the selected case.');set('mappingSummary','No draft prepared.');set('bindingStatus','No confirmation.');set('stateFingerprint','Snapshot: not confirmed');set('chatStream','No messages yet.');set('proposalWarning','');
 say('Scenario changed. Create a NEW original HAWM state to begin. The previous controller result is historical.');renderHomeChat({chat:[]});updateHomeControls();updateJourney();if(previousHistory)restoreDocumentConversationReadOnly(previousHistory);}
// Keep article review separate from HAWM's synthetic claim review. This is an
// observation of chat relevance, NOT validation of article truth or policy.
const REVIEW_MARKER='DOCUMENT_REVIEW_KB_DEMO_001|';
function reviewPrompt(d){return REVIEW_MARKER+'Review ARTICLE only: cite conflicting/unclear phrases, or write NO ISSUE FOUND. Ignore DemoSubject and evidence. No release authorization. ARTICLE:\n'+d;}
function reviewObservation(s){
 const chat=Array.isArray(s?.chat)?s.chat:[];
 const saved=draftFromTask(s?.task);
 for(let i=chat.length-2;i>=0;i--){
  const u=chat[i],a=chat[i+1];
  if(u.role!=='user'||a.role!=='assistant'||a.model_mode!=='openai_compatible'||!String(u.content||'').startsWith(REVIEW_MARKER))continue;
  if(String(u.content||'')!==reviewPrompt(saved))return {kind:'OLD_DRAFT'};
  const response=String(a.content||'');
  if(inspectChatReply(response).incomplete||inspectChatReply(response).tailIssue)return {kind:'INCOMPLETE'};
  if(/\bDemoSubject\b|\bsource independence\b|\b(certified|certification) (independence|sources)\b/i.test(response))return {kind:'OFF_TOPIC'};
  return {kind:'RECORDED_UNCHECKED'};
 }
 return {kind:'NOT_RECORDED'};
}
function refreshState(s){session.hawms=s;if(!$('articleDraft').dataset.dirty){$('articleDraft').value=draftFromTask(s.task)||SAMPLE_DRAFT;}set('draftStatus',draftFromTask(s.task)?'Saved in native HAWM as UNTRUSTED task context. Not CFC evidence.':'Demo draft not yet saved in HAWM. Save it before AI discussion.');$('saveDraft').disabled=false;$('articleDraft').disabled=false;$('discussDraft').disabled=displayedChatMode.indexOf('LOCAL AI MODEL')===-1||!draftFromTask(s.task)||!!$('articleDraft').dataset.dirty;set('claimPreview',(s.claims||[]).join('; ')||'No claim');
 set('evidencePreview',(s.evidence||[]).map((x,i)=>/^[Ee]\d+\s*:/.test(String(x))?x:'E'+(i+1)+': '+x).join('\n')||'No evidence');
 $('unresolvedEditor').value=(s.unresolved||[]).join('\n');set('nativeState',`Project: ${s.project_name||'—'} · ${s.evidence?.length||0} evidence rows · ${s.unresolved?.length||0} unresolved notes`);
 renderHomeChat(s);updateHomeControls();renderStatusProjection();
 const stream=$('chatStream');stream.replaceChildren();for(const msg of (s.chat||[]).slice(-16)){
  const el=document.createElement('div');el.className='message '+(msg.role==='user'?'user':'assistant');const label=document.createElement('span');label.className='role';label.textContent=msg.role==='user'?'REVIEWER':msg.model_mode==='openai_compatible'?'LOCAL AI · UNCHECKED':msg.model_mode==='error'?'MODEL ADAPTER ERROR':'OFFLINE HAWM · TEST';
  const content=document.createElement('span');content.textContent=String(msg.content||'');el.append(label,content);stream.append(el);
 }
 if(!(s.chat||[]).length)set('chatStream','No messages yet.');
 const replies=(s.chat||[]).filter(m=>m.role==='assistant'&&m.model_mode==='openai_compatible').length;const offline=(s.chat||[]).filter(m=>m.role==='assistant'&&m.model_mode!=='openai_compatible'&&m.model_mode!=='error').length;set('chatEvidence',`Chat evidence: ${replies} local AI repl${replies===1?'y':'ies'} · ${offline} offline adapter replies · ${s.chat?.length||0} messages. ${replies?'Local AI response recorded, NOT verified or bound to an assessment.':'No local AI response recorded.'}`);
 const review=reviewObservation(s);
 showCurrentArticleAI(s);
 const reviewText={INCOMPLETE:'INCOMPLETE: Local model reached the response-token limit. This is NOT a complete review; do not record a decision based on it.',OFF_TOPIC:'OFF TOPIC: AI talked about CFC / evidence, NOT the article. Negative result — do not claim document review.',RECORDED_UNCHECKED:'Document-focused AI reply recorded; content accuracy NOT verified. No release authority.',OLD_DRAFT:'Historical document reply refers to a different draft. Review this exact saved draft again.',NOT_RECORDED:'No completed AI review of the exact saved article.'};
 set('draftReviewStatus','Article AI review: '+reviewText[review.kind]);
 const savedDraft=draftFromTask(s.task);
 set('draftSavedPreview',savedDraft?'SAVED EXACT ARTICLE: '+savedDraft:'NO SAVED ARTICLE. The text in the editor is an unsaved example. Click Save draft in HAWM before discussion.');updateJourney();
 if($('docReviewStatus'))void refreshDocReview();
 if($('issueLineagePanel'))void refreshIssueLineage();
 const pending=(s.pending_proposals||[]).filter(x=>x.status==='PENDING').length;
 set('proposalWarning',pending?`${pending} HAWM proposal(s) pending. Review below in this product; proposals grant no authority.`:'Chat does not automatically change verified evidence or issue authority.');
 if($('refreshReview')){ $('refreshReview').disabled=false; void refreshReviewInbox();}
}
function data(){const c=scenario();const evidence=[{source_index:0,...row($('e1').value)}];if(c.count===2)evidence.push({source_index:1,...row($('e2').value)});
 return {conclusion:'POSITIVE',required_independent_supports:+$('required').value,provenance_shape:$('provenance').value,independence_authority:$('independence').value,scope:$('scope').value,evidence};}
function row(x){let a=x.split('_');return {polarity:a[0],validity:a[1]}}
function mappingText(d){return `${d.evidence.length} selected record(s) · ${d.required_independent_supports} independent support(s) required\nSource relationship: ${d.provenance_shape}\nIndependence authority: ${d.independence_authority==='VERIFIED'?'SYNTHETIC HOST CERTIFICATE':'NOT CERTIFIED'}\nAudit scope: ${d.scope}\nEvidence mappings: ${d.evidence.map((x,i)=>`E${i+1} ${x.polarity} / ${x.validity}`).join(', ')}`;}
function refreshMapping(){const d=data();set('mappingSummary',mappingText(d));}
async function create(){if(session.initialized&&!window.confirm('START A NEW PROJECT? This replaces the current HAWM working state and chat. Export evidence first if needed.'))return {cancelled:true};emptyResult();set('bindingStatus','No confirmation.');
 session.prepared=false;session.confirmed=false;session.editedAfterConfirm=false;
 await req('/api/native/new-project',{project_name:'CFC × HAWM / Reviewer scenario: '+$('scenario').value});
 const c=scenario();const source=c.rows.map((v,i)=>`E${i+1}: synthetic ${v.replace('_',' / ').toLowerCase()} record for DemoSubject/state/safe; no external attestation.`);
 await req('/api/native/manual',{field:'goal',value:'Review whether closure is justified in an explicitly bounded synthetic scenario.'});
 await req('/api/native/manual',{field:'task',value:TASK_PREFIX});
 await req('/api/native/manual',{field:'claims',value:['DemoSubject is safe.']});
 await req('/api/native/manual',{field:'evidence',value:source});
 const state=await req('/api/native/manual',{field:'unresolved',value:[c.unresolved]});
 session.initialized=true;delete $('articleDraft').dataset.dirty;refreshState(state);
 $('prepare').disabled=false;$('saveState').disabled=false;$('unresolvedEditor').disabled=false;$('sendChat').disabled=false;$('chatText').disabled=false;
 $('confirm').disabled=true;$('run').disabled=true;refreshMapping();say('Original HAWM state created. Next: prepare, inspect and explicitly approve the mapping.');}
async function prepare(){emptyResult('MAPPING NOT YET CONFIRMED');const x=await req('/api/native/prepare',{});const d=x.mapping_draft;
 if(!d||d.status!=='PENDING_USER_CONFIRMATION')throw Error(d?.reason||'Native HAWM refused the mapping');
 session.prepared=true;session.confirmed=false;session.editedAfterConfirm=false;refreshState(x);
 $('confirm').disabled=false;$('run').disabled=true;refreshMapping();set('bindingStatus','Draft created against native HAWM state '+d.source_state_hash.slice(0,18)+'… — review and approve.');set('stateFingerprint','Draft HAWM SHA-256: '+d.source_state_hash);
 say('Native draft ready. Mapping fields below are explicit operator assertions, not inferred evidence truth.');}
async function confirm(){const d=data();if(d.provenance_shape==='SHARED_LINEAGE'&&d.independence_authority==='VERIFIED')throw Error('Cannot certify independent records while declaring shared lineage');
 const x=await req('/api/native/confirm',{candidate:d});const hand=x.mapping_draft;if(hand?.status!=='CONFIRMED')throw Error('No valid original HAWM confirmation');
 session.confirmed=true;session.prepared=true;session.editedAfterConfirm=false;refreshState(x);emptyResult('MAPPING APPROVED · CFC NOT YET RUN');
 $('run').disabled=false;set('bindingStatus','Operator confirmed exact state '+hand.confirmed_state_hash.slice(0,18)+'…');set('stateFingerprint','Confirmed HAWM SHA-256: '+hand.confirmed_state_hash);
 say('Mapping confirmed by HAWM. You can now run frozen CFC against this exact state.');}
function decisionWhy(raw,status){const gates=Object.entries(raw.gates||{}).filter(([,v])=>v===false).map(([k])=>k);
 if(raw.control_closure)return 'Closure conditions satisfied within this synthetic input contract. This is NOT a real-world action authorization.';
 if(gates.includes('scope_adequacy_valid'))return 'STOP: the claim may be VERIFIED but the audit scope is wrong.';
 if(gates.includes('support_set_common_mode_coverage_valid'))return 'STOP: source independence or common-mode coverage was not established.';
 if(status==='UNRESOLVED')return 'STOP: supporting evidence is missing, stale, or epistemically unavailable.';
 if(status==='QUARANTINED')return 'STOP: conflicting evidence has not been resolved.';
 return 'STOP: required controller gates are not all satisfied. Inspect technical details.';}
async function run(){emptyResult('RUNNING · NO NEW RESULT YET');$('run').disabled=true;
 try{const x=await req('/api/native/run',{});const raw=x.result?.raw;
  if(!raw||raw.engine_sha256!==hash||typeof raw.control_closure!=='boolean')throw Error('Missing verified raw frozen CFC result');
  session.executed=true;session.latest=x;session.editedAfterConfirm=false;refreshState(x.state);renderStatusProjection();
  const cs=(raw.claim_states||[]).map(z=>z.status).filter(Boolean).join(', ')||'NO CLAIM EMITTED';const closure=raw.control_closure?'ALLOW':'STOP';
  set('claimStatus',cs);set('closureStatus',closure);banner('CURRENT EXACT-STATE RESULT · '+closure,raw.control_closure?'allow':'stop');set('decisionWhy',decisionWhy(raw,cs));
  const failed=Object.entries(raw.gates||{}).filter(([,v])=>v===false).map(([k])=>k);set('gates',failed.length?failed.join('\n'):'No failed raw gates. Raw stop_type: '+raw.stop_type);
  set('stateFingerprint','CFC run bound to: '+(x.state?.mapping_draft?.confirmed_state_hash||'—'));$('exportTrace').disabled=false;
  $('attemptEffect').disabled=false;
  say(`Native HAWM → original frozen CFC: claim ${cs}; closure ${closure}. You can now test whether the live action gate blocks or permits a local-only token.`);
 }catch(e){const stale=String(e.message).includes('STALE_MAPPING_DRAFT');emptyResult(stale?'BLOCKED BEFORE CFC':'NO ACCEPTED CFC RESULT');
  banner(stale?'BLOCKED BEFORE CFC':'BLOCKED · NO NEW RESULT','blocked');set('closureStatus','BLOCKED');set('claimStatus','NOT EVALUATED');
  set('decisionWhy',stale?'HAWM rejected the stale mapping after the working state changed. No new CFC decision was made.':'A valid new controller result was not obtained. Historical ALLOW/STOP must not be presented as current.');
  session.confirmed=false;session.prepared=false;$('confirm').disabled=true;$('prepare').disabled=!session.initialized;
  set('bindingStatus','Previous mapping not usable. Prepare and approve another mapping.');set('gates','No new controller gates evaluated.');say('BLOCKED: '+e.message);
  return;
 }finally{$('run').disabled=!session.confirmed;}}
async function attemptEffect(){
 if(!session.executed||!session.latest||!session.confirmed)throw Error('A CURRENT approved CFC decision is required');
 $('attemptEffect').disabled=true;
 set('effectBanner','CHECKING ORIGINAL HAWM + RUNNING FRESH CFC…');set('effectReason','No action token issued yet.');
 const m=session.latest.state?.mapping_draft;
 try{
  if(!m?.handoff_id||!m?.confirmed_state_hash||!m?.run_at)throw Error('Missing prior verified handoff binding');
  const x=await req('/api/live-effect/attempt',{expected_handoff_id:m.handoff_id,expected_state_hash:m.confirmed_state_hash,expected_run_at:m.run_at});
  const receipt=x.receipt;if(!receipt||!['BLOCKED','EXECUTED_LOCAL_ONLY'].includes(receipt.decision))throw Error('Invalid live gate receipt');
  session.effectReceipt=receipt;
  set('effectBanner',receipt.decision==='BLOCKED'?'BLOCKED · NO EXECUTION TOKEN':'LOCAL TOKEN CREATED · NO EXTERNAL ACTION');
  $('effectBanner').className='banner '+(receipt.decision==='BLOCKED'?'stop':'allow');
  set('effectReason',(receipt.reason_codes||[]).join(', ')||'Controller closure passed for this synthetic fixture.');
  $('downloadEffect').disabled=false;$('downloadBundle').disabled=false;set('bundleCompleteness',((session.hawms?.chat||[]).some(m=>m.role==='assistant'&&m.model_mode==='openai_compatible')?'Local AI reply recorded (unchecked, no content authorization).':'PARTIAL: no local AI response recorded. Export will disclose this gap.'));
  // A fresh CFC run has changed run_at. Reapproval not necessary, but the previous UI run binding is historical.
  session.executed=false;session.latest=null;$('attemptEffect').disabled=true;$('exportTrace').disabled=true;renderStatusProjection();
  updateJourney();
  say('Local live gate: '+receipt.decision+'. Fresh frozen CFC result checked by server. Re-run step 4 before any new attempt.');
 }catch(e){
  clearEffect('FAIL CLOSED · NO ACCEPTED EFFECT');
  set('effectReason',e.message);say('Live gate denied or unavailable: '+e.message);
  session.executed=false;session.latest=null;$('exportTrace').disabled=true;
 }
}
async function edit(){if(!session.initialized)throw Error('Create HAWM state first');const text=$('unresolvedEditor').value.trim();if(text.length>3000)throw Error('Unresolved field too long');const entries=text?text.split('\n').map(v=>v.trim()).filter(Boolean):[];
 const before=(session.hawms?.unresolved||[]).join('\n');if(before===entries.join('\n')){say('No state changes to save.');return;}
 const state=await req('/api/native/manual',{field:'unresolved',value:entries});refreshState(state);session.editedAfterConfirm=true;
 emptyResult('HAWM STATE CHANGED · OLD RESULT INVALIDATED');set('decisionWhy','The HAWM state changed; any earlier ALLOW or STOP is historical. An attempt to run the old mapping should be BLOCKED before CFC.');
 if(!session.confirmed){session.prepared=false;$('confirm').disabled=true;$('prepare').disabled=false;set('bindingStatus','New state requires a new handoff and approval.');}
 else {set('bindingStatus','State changed AFTER approval — previous mapping is stale. Run will ask native HAWM to enforce the boundary.');}
 say('Native HAWM state updated. Old CFC presentation cleared; confirmed mapping may now be invalid.');}
// v0.9.4: version-scoped OPERATOR labels for legacy HAWM issues.
// Never infer origin, never edit native HAWM unresolved notes from this panel.
let issueLineageInfo=null;
const applicabilityLabels={
 HISTORICAL_FOR_CURRENT_OPERATOR_ASSERTION:'Historical for this article version (operator assessment)',
 CURRENT_FOR_DOCUMENT_OPERATOR_ASSERTION:'Still applies to this article version (operator assessment)',
 UNRELATED_TO_ARTICLE_OPERATOR_ASSERTION:'Unrelated to this article (operator assessment)',
 NEEDS_REVIEW_OPERATOR_ASSERTION:'Needs further review (operator assessment)'
};
async function refreshIssueLineage(){
 if(!session.native||!session.initialized){issueLineageInfo=null;return;}
 try{
  const info=await req('/api/document-review/issues');
  if(!info.available){issueLineageInfo=null;set('issueLineageStatus','No saved article; save and capture a version first.');$('issueLineageItems').replaceChildren();return;}
  issueLineageInfo=info;
  $('issueLineageRefresh').disabled=false;
  set('issueLineageStatus',`Current version: ${info.document_sha256.slice(0,16)}… · ${info.native_unresolved_count} native unresolved note(s) · ${info.historical_operator_labels} operator-labelled historical for THIS version · ${info.unclassified_count} unclassified · ${info.native_pending_count} pending AI proposal(s). Native HAWM is unchanged.`);
  const holder=$('issueLineageItems');holder.replaceChildren();
  for(const r of info.notes){
   const item=document.createElement('div');item.className='review-item';
   const title=document.createElement('strong');title.textContent='HAWM Unresolved #'+(r.index+1)+' · origin version UNKNOWN';
   const para=document.createElement('p');para.textContent=r.text;
   const current=document.createElement('p');current.className='tiny';current.textContent='Current operator label: '+(applicabilityLabels[r.human_applicability]||'NOT CLASSIFIED')+(r.operator_note?' · Reason: '+r.operator_note:'');
   const hint=document.createElement('p');hint.className='tiny';hint.textContent=r.hint.possible_old_wording?'Possible wording carried from v1; narrow heuristic ONLY. No automatic historical verdict.':'Origin unproven — inspect before labelling.';
   const sel=document.createElement('select');sel.setAttribute('aria-label','Applicability of HAWM issue '+(r.index+1));
   for(const [key,label] of Object.entries(applicabilityLabels)){
    const opt=document.createElement('option');opt.value=key;opt.textContent=label;sel.append(opt);
   }
   sel.value=applicabilityLabels[r.human_applicability]?r.human_applicability:'NEEDS_REVIEW_OPERATOR_ASSERTION';
   const reason=document.createElement('textarea');reason.rows=2;reason.maxLength=350;reason.placeholder='Why does this label apply to the CURRENT article version? (8–350 chars)';reason.setAttribute('aria-label','Reason for issue '+(r.index+1));
   const button=document.createElement('button');button.type='button';button.textContent='Save version-specific label';button.disabled=!info.version_captured;
   const result=document.createElement('p');result.className='operation-result';result.textContent=info.version_captured?'No new label saved.':'Capture current document version first.';
   button.addEventListener('click',async()=>{
    if(busy)return;
    if(reason.value.trim().length<8){result.textContent='✕ FAILED · Enter a reason of at least 8 characters.';result.dataset.state='error';return;}
    busy=true;button.disabled=true;button.textContent='… Saving';result.textContent='… Recording an operator assertion for this exact version';result.dataset.state='running';
    try{
     const payload={expected_document_sha256:info.document_sha256,expected_review_hash:info.expected_review_hash,
       issue_sha256:r.issue_sha256,classification:sel.value,note:reason.value.trim()};
     const answer=await req('/api/document-review/issue/label',payload);
     result.textContent=answer.already_recorded?'✓ Already recorded for this version.':'✓ SAVED · Operator label recorded for this version only; HAWM unresolved unchanged.';result.dataset.state='success';
     await refreshIssueLineage();say('Version-scoped issue label recorded. HAWM unresolved and frozen CFC unchanged.');
    }catch(e){result.textContent='✕ FAILED · '+e.message;result.dataset.state='error';say('ISSUE LABEL REFUSED: '+e.message);}
    finally{busy=false;button.disabled=false;button.textContent='Save version-specific label';}
   });
   item.append(title,para,current,hint,sel,reason,button,result);holder.append(item);
  }
  if(!info.notes.length){const el=document.createElement('p');el.className='tiny';el.textContent='No native HAWM unresolved notes.';holder.append(el)}
  for(const p of info.pending){const item=document.createElement('p');item.className='audit-indicator';item.textContent='PENDING NATIVE AI PROPOSAL · '+p.text+(p.hint.possible_old_wording?' · POSSIBLE OLD WORDING (not proof).':'')+' Review via the HAWM proposal panel above. Never auto-confirm.';holder.append(item);}
 }catch(e){issueLineageInfo=null;set('issueLineageStatus','ISSUE LABELS UNAVAILABLE: '+e.message);$('issueLineageItems').replaceChildren();$('issueLineageRefresh').disabled=true;}
}
let reviewInbox=null;
async function refreshReviewInbox(){
 if(!session.initialized||!session.native)return;
 try{
  const info=await req('/api/native/proposal-inbox');reviewInbox=info;
  const pending=info.pending||[];const duplicates=info.duplicate_groups||[];
  set('reviewInboxStatus',`${pending.length} pending suggestion(s) · ${info.existing_unresolved_count} stored unresolved note(s) · ${duplicates.length} duplicate group(s). No publication authorization.`);
  const box=$('reviewItems');box.replaceChildren();
  if(!pending.length){const msg=document.createElement('p');msg.className='tiny';msg.textContent='No pending suggestions. Previously confirmed notes stay in HAWM until changed by a human.';box.append(msg)}
  for(const p of pending){
    const item=document.createElement('div');item.className='review-item';
    const label=document.createElement('strong');label.textContent=`${p.field} · ${p.action}${p.duplicate_candidate?' · POSSIBLE DUPLICATE':''}`;
    const value=document.createElement('p');value.textContent=p.value;
    const note=document.createElement('p');note.className='tiny';note.textContent=p.reviewable?'Review the actual statement; this is an AI suggestion, not a verified fact.':'Other field type: confirmation disabled here; reject or use technical HAWM.';
    const controls=document.createElement('div');controls.className='button-line';
    for(const [d,text] of [['CONFIRM','Accept as unresolved'],['REJECT','Reject'],['DUPLICATE','Mark duplicate (reject)']]){
      const b=document.createElement('button');b.textContent=text;b.type='button';
      b.disabled=d==='CONFIRM'?(!p.reviewable||p.duplicate_candidate):d==='DUPLICATE'?!p.duplicate_candidate:false;
      b.addEventListener('click',()=>{void reviewProposal(p.id,d)});controls.append(b);
    }
    item.append(label,value,note,controls);box.append(item);
  }
  const dupBox=$('duplicateIssues');dupBox.replaceChildren();
  for(const group of duplicates){
    const item=document.createElement('div');item.className='review-item';
    const title=document.createElement('strong');title.textContent=`${group.count} similar recorded issues · manual cleanup available`;
    const first=document.createElement('p');first.textContent='KEEP: '+group.kept_text;
    const details=document.createElement('p');details.className='tiny';details.textContent='REMOVE EXTRA: '+group.remove_texts.join(' | ')+(group.heuristic?' · narrow KB-demo wording heuristic, not semantic proof.':'');
    const button=document.createElement('button');button.textContent='Remove extra notes; keep first';button.type='button';
    button.addEventListener('click',()=>{void cleanupReviewDuplicates(group.issue_key)});
    item.append(title,first,details,button);dupBox.append(item);
  }
 }catch(e){set('reviewInboxStatus','REVIEW INBOX UNAVAILABLE: '+e.message);reviewInbox=null;}
}
function afterReviewStateChanged(state,description){
 session.confirmed=false;session.prepared=false;session.executed=false;session.latest=null;
 session.editedAfterConfirm=true;
 emptyResult('HUMAN REVIEW CHANGED STATE · REAPPROVAL REQUIRED');
 $('confirm').disabled=true;$('run').disabled=true;$('prepare').disabled=false;
 set('bindingStatus','Review action performed; old mapping and controller result may be historical. Prepare a fresh handoff.');
 refreshState(state);say(description+' The article itself remains unapproved.');updateJourney();
}
async function reviewProposal(id,decision){
 if(!reviewInbox||busy)return;
 const p=(reviewInbox.pending||[]).find(x=>x.id===id);if(!p)return;
 const question=decision==='CONFIRM'?`Record this AI suggestion as an UNRESOLVED issue?\n\n${p.value}`:
  decision==='DUPLICATE'?`Reject this possible duplicate? The original issue remains.\n\n${p.value}`:
  `Reject this proposal?\n\n${p.value}`;
 if(!window.confirm(question))return;
 busy=true;
 try{const out=await req('/api/native/review-proposal',{id,decision,expected_review_hash:reviewInbox.review_hash});
  afterReviewStateChanged(out.state,`HAWM recorded ${out.native_resolution}; ${decision==='DUPLICATE'?'duplicate was REJECTED, not certified.':'operator decision '+decision+'.'}`);
 }catch(e){say('REVIEW REFUSED: '+e.message+'. Refresh suggestions and inspect the current HAWM state.');}
 finally{busy=false;await refreshReviewInbox();}
}
async function cleanupReviewDuplicates(issue_key){
 if(!reviewInbox||busy)return;
 const group=(reviewInbox.duplicate_groups||[]).find(x=>x.issue_key===issue_key);if(!group)return;
 const question=`Remove ${group.count-1} duplicate unresolved note(s), retaining the FIRST one? This changes original HAWM state and invalidates earlier CFC mapping.\n\nKEEP: ${group.kept_text}\n\nREMOVE: ${group.remove_texts.join(' | ')}`;
 if(!window.confirm(question))return;
 busy=true;
 try{const out=await req('/api/native/cleanup-duplicate',{issue_key,expected_review_hash:reviewInbox.review_hash});
  afterReviewStateChanged(out.state,`Removed ${out.removed.length} extra note(s), retaining one unresolved issue.`);
 }catch(e){say('CLEANUP REFUSED: '+e.message+'. Refresh suggestions.');}
 finally{busy=false;await refreshReviewInbox();}
}

// Chat-first document entry. Both views share the same importedDocument token and HAWM state.
// M27: Presentation-only attachment chip and unified composer. No CFC controls.
function refreshChatAttachmentUI(){
 const attached=!!importedDocument;
 $('chatAttachmentChip').hidden=!attached;
 $('chatAttachedDetails').hidden=!attached;
 if(attached){
  $('chatAttachmentName').textContent='📎 '+safeDocName(importedDocument.name)+(uiLanguage==='pl'?' · NIEZWERYFIKOWANY':' · UNVERIFIED');
  $('chatAttachmentNotice').textContent=uiLanguage==='pl'?
   'Załącznik NIEZWERYFIKOWANY. Lokalna analiza AI nie jest oceną CFC.':
   'UNVERIFIED attachment. Local AI analysis is not a CFC decision.';
 } else {
  $('chatAttachmentName').textContent=uiLanguage==='pl'?'Brak załącznika':'No attachment';
  $('chatAttachmentNotice').textContent=uiLanguage==='pl'?'Opcjonalnie: dołącz plik przez 📎. Tekst wpisuj tylko w tym polu czatu.':'Optional: attach a file with 📎. Text goes into this one chat box.';
  $('chatAttachedDetails').open=false;
 }
}
function removeChatAttachment(){
 if(!importedDocument)return;
 // Removing UI context does not mutate the native HAWM state or past messages.
 activeNativeReplyBinding=null;
 invalidateDocumentFeedback();
 generalHistory.length=0;importedDocument=null;currentDocumentAi=null;quickDocumentReview=null;quickReportZipB64=null;
 $('homeDocFile').value='';$('homeDocPaste').value='';
 $('homeDocPreview').value='';$('homeDocExcerpt').value='';$('homeDocLoaded').hidden=true;
 renderDocumentAi();renderQuickDocumentReview();renderStatusProjection();
 renderHomeChat(session.hawms||{chat:[]});
 refreshChatAttachmentUI();
 set('homeChatStatus','Attachment removed from current chat context. Earlier HAWM history remains historical; CFC not run.');
}

async function homeDocumentLoad(){
 const file=$('homeDocFile').files?.[0];
 const pasted=$('homeDocPaste').value;
 if(!file&&!pasted.trim())throw Error('Wybierz plik lub wklej tekst.');
 if(file&&pasted.trim())throw Error('Wybierz jedno źródło: plik ALBO wklejony tekst.');
 // import routine is the same one used in technical HAWM view; no alternate parser.
 await intakeRead(file?'file':'paste',true);
}
function homeDocumentUse(){
 if(!importedDocument)throw Error('Najpierw wczytaj dokument.');
 const excerpt=$('homeDocExcerpt').value.trim();
 if(!excerpt||excerpt.length>420)throw Error('Wprowadź dokładny fragment długości 1–420 znaków.');
 if(!importedDocument.text.includes(excerpt))throw Error('Fragment nie jest dokładnym cytatem z tego dokumentu.');
 if(!session.initialized){
  setProductInspector('hawm');
  throw Error('Utwórz stan HAWM przez Start new local review, a następnie ponów przeniesienie fragmentu. Nie zastępujemy stanu automatycznie.');
 }
 $('articleDraft').value=excerpt;articleChanged();
 set('intakeLinkStatus','Fragment przeniesiony z czatu do edytora, ale NIEZAPISANY. Kliknij Save draft in HAWM; następnie Capture saved version i powiąż źródło.');
 set('homeDocStatus','Wybrany fragment przeniesiono do edytora HAWM (NIEZAPISANY). Wymagany zapis i ocena człowieka. CFC: NOT EVALUATED.');
 setProductInspector('hawm');
 $('articleDraft').scrollIntoView({behavior:'smooth',block:'center'});
}
async function intakeRead(mode,fromHome=false){
 // An import attempt invalidates visible source-specific results immediately.
 // Preserve native HAWM history; invalidate only presentation + ephemeral bindings.
 activeNativeReplyBinding=null;
 invalidateDocumentFeedback();
 set('homeChatStatus','NOWY IMPORT · poprzednia odpowiedź HAWM jest historyczna; brak aktualnej analizy.');
 if(session.hawms)renderHomeChat(session.hawms);
 let payload;
 if(mode==='paste'){
  const text=$(fromHome?'homeDocPaste':'intakePaste').value;
  if(!text.trim()||text.length>100000)throw Error('Wklej od 1 do 100 000 znaków.');
  payload={mode:'paste',text};
 }else{
  const f=$(fromHome?'homeDocFile':'intakeFile').files?.[0];
  if(!f)throw Error('Najpierw wybierz plik.');
  if(f.size===0||f.size>1500000)throw Error('Plik musi mieć od 1 bajtu do 1,5 MB.');
  const bytes=new Uint8Array(await f.arrayBuffer());
  let raw='';const CHUNK=16384;
  for(let i=0;i<bytes.length;i+=CHUNK)raw+=String.fromCharCode(...bytes.subarray(i,i+CHUNK));
  payload={mode:'file',filename:f.name,content_b64:btoa(raw)};
 }
 // Do not silently bind a new file to an earlier source selection or prior CFC result.
 generalHistory.length=0;importedDocument=null;quickDocumentReview=null;quickReportZipB64=null;currentDocumentAi=null;renderDocumentAi();renderQuickDocumentReview();refreshChatAttachmentUI();
 $('homeDocLoaded').hidden=true;$('homeDocPreview').value='';$('homeDocExcerpt').value='';renderStatusProjection();set('homeDocStatus','Odczytywanie dokumentu… CFC NOT EVALUATED.');set('intakeLinkStatus','Nowy import. Poprzednie powiązanie nie dotyczy tego pliku.');
 const result=await req('/api/document-intake/parse',payload);
 if(result.authority_verified!==false||result.cfc_evaluated_document!==false)throw Error('Importer naruszył granicę zaufania.');
 importedDocument={token:result.token,hash:result.source_sha256,extractedSha:result.extracted_sha256,text:result.text,name:result.name};
  if(fromHome && chatScope!=='free')setChatScope('free',true); // P51 isolated only
 refreshChatAttachmentUI();
 renderQuickDocumentReview();
 $('intakePreview').value=result.text;
 $('homeDocPreview').value=result.text;
 $('homeDocExcerpt').value=result.text.trim().length<=420?result.text.trim():'';
 $('homeDocLoaded').hidden=false;
 renderHomeChat(session.hawms||{chat:[]});renderStatusProjection();
 set('homeChatStatus','NOWY DOKUMENT WCZYTANY · brak bieżącej odpowiedzi AI/Quickcheck. Poprzednie odpowiedzi HAWM są historyczne. Wyślij nowe pytanie.');
 set('homeDocStatus',`ODCZYT ZAKOŃCZONY: ${result.name} · ${result.extracted_length} znaków · SHA-256: ${result.source_sha256} · ostrzeżenia: ${(result.warnings||[]).join(', ')||'brak'}. Tekst NIEZWERYFIKOWANY; CFC NIE OCENIAŁ dokumentu. ${result.text.trim().length>420?'Wybierz konkretny fragment (max 420 znaków); nie obcinamy tekstu.':'Krótki tekst jest przygotowany jako propozycja fragmentu — bez automatycznego zapisu.'}`);
 set('intakeStatus',`ODCZYTANO: ${result.name} · ${result.extracted_length} znaków · SHA-256 pliku: ${result.source_sha256} · ostrzeżenia: ${(result.warnings||[]).join(', ')||'brak'}. SOURCE UNVERIFIED · NOT CFC EVIDENCE.`);
 say('Wczytano dokument lokalnie. Zaznacz fragment, przenieś do HAWM, zapisz go i przechwyć wersję. Pełny dokument nie został zapisany w HAWM ani oceniony przez CFC.');
}
function intakeUseSelection(){
 if(!importedDocument)throw Error('Najpierw wczytaj dokument.');
 if(!session.initialized)throw Error('Najpierw kliknij Start new local review.');
 const field=$('intakePreview');const from=field.selectionStart,to=field.selectionEnd;
 if(to<=from)throw Error('Zaznacz fragment w podglądzie dokumentu.');
 const excerpt=field.value.slice(from,to).trim();
 if(!excerpt||excerpt.length>420)throw Error('Zaznacz od 1 do 420 znaków. Pełny dokument zostaje w podglądzie.');
 if(!importedDocument.text.includes(excerpt))throw Error('Fragment nie pasuje do importu.');
 $('articleDraft').value=excerpt;articleChanged();
 set('intakeLinkStatus','Fragment w edytorze, ale jeszcze NIEZAPISANY. Kliknij Save draft in HAWM, następnie Capture saved version, a potem powiąż z plikiem.');
 say('Wybrany fragment został tylko przeniesiony do edytora HAWM. Zapisz go świadomie; pełny plik nie trafia do CFC.');
}
async function intakeBindExcerpt(){
 if(!importedDocument)throw Error('Najpierw wczytaj źródło.');
 if($('articleDraft').dataset.dirty)throw Error('Zapisz fragment w HAWM przed powiązaniem.');
 const excerpt=$('articleDraft').value.trim();
 if(!excerpt||!importedDocument.text.includes(excerpt))throw Error('Aktualny fragment nie występuje dokładnie we wczytanym źródle.');
 const status=await req('/api/document-review/status');
 if(!status.version_captured||!status.document_sha256)throw Error('Kliknij najpierw 1. Capture saved version.');
 const result=await req('/api/document-intake/bind',{token:importedDocument.token,excerpt,expected_document_sha256:status.document_sha256});
 set('intakeLinkStatus',`SOURCE LINK RECORDED · event ${result.event_sha256} · source ${result.source_original_sha256} · UNVERIFIED, NOT CFC EVIDENCE.`);
 say('Zapisano lokalny digest-link między oryginalnym plikiem i dokładnym fragmentem HAWM. To NIE jest certyfikat źródła ani wynik CFC.');
}
function articleChanged(){
 if(!session.initialized)return;
 const saved=draftFromTask(session.hawms?.task);
 const changed=$('articleDraft').value.trim()!==saved;
 if(!changed){delete $('articleDraft').dataset.dirty;set('draftStatus','Draft matches current native HAWM state.');$('discussDraft').disabled=displayedChatMode.indexOf('LOCAL AI MODEL')===-1||!saved;return;}
 set('intakeLinkStatus','Zmiana fragmentu HAWM: wcześniejsze powiązania są historyczne.');
 $('articleDraft').dataset.dirty='1';session.confirmed=false;session.prepared=false;session.executed=false;session.latest=null;
 emptyResult('UNSAVED DOCUMENT CHANGE · REAPPROVAL REQUIRED');$('prepare').disabled=true;$('confirm').disabled=true;$('run').disabled=true;
 $('discussDraft').disabled=true;$('sendChat').disabled=true;$('chatText').disabled=true;set('bindingStatus','Document edited: save in HAWM, prepare new mapping, approve and run CFC again.');
 $('bindDocClaim').disabled=true;set('docClaimStatus','Document edited; save and capture this version before binding a claim.');$('authSave').disabled=true;set('authStatus','Zmieniono dokument: wcześniejsze dane poświadczenia są historyczne. Autorytet NIEZWERYFIKOWANY.');set('draftStatus','UNSAVED EDIT: must save before AI discussion or CFC. Previous mapping and effect are historical.');set('latestReplyLabel','Unsaved draft');set('latestArticleReply','Previous AI answers refer to the saved article, not these unsaved edits.');set('docReviewStatus','UNSAVED EDIT — prior human disposition and AI answer are historical, not current.');set('issueLineageStatus','UNSAVED EDIT · Version-specific issue labels are not current until this text is saved and captured.');$('issueLineageItems').replaceChildren();set('docCaptureResult','UNSAVED DRAFT · Save in HAWM first. Earlier capture remains historical.');$('docCaptureResult').dataset.state='warning';set('docRecordResult','HISTORICAL · Previous human decision is not current for an unsaved edit.');$('docRecordResult').dataset.state='warning';$('docRecord').disabled=true;$('docCapture').disabled=true;
 say('Untrusted draft edited. Earlier closure is not usable for this changed document.');updateJourney();
}
async function saveDraft(){if(!session.initialized)throw Error('Create state first');const text=$('articleDraft').value.trim();if(!text||text.length>DRAFT_MAX)throw Error('Draft must contain 1–420 characters');
 if(text.includes(DRAFT_BOUNDARY.trim()))throw Error('Reserved delimiter in draft');
 const s=await req('/api/native/manual',{field:'task',value:taskFromDraft(text)});
 delete $('articleDraft').dataset.dirty;$('docDecision').value='';$('docNote').value='';refreshState(s);$('sendChat').disabled=false;$('chatText').disabled=false;session.confirmed=false;session.prepared=false;session.executed=false;session.latest=null;
 emptyResult('DOCUMENT SAVED · NEW APPROVAL REQUIRED');$('prepare').disabled=false;$('confirm').disabled=true;$('run').disabled=true;
 set('bindingStatus','Saved document changes the exact HAWM state. Prepare and approve the mapping again.');
 say(text===SAMPLE_DRAFT?'DEFAULT SAMPLE saved. To test a contradiction, replace the example text and SAVE again. No CFC evidence or authorization was created.':'Exact edited draft saved to original HAWM task as untrusted context. New mapping approval required.');
}
async function discussDraft(){if(displayedChatMode.indexOf('LOCAL AI MODEL')<0)throw Error('A local AI model is required for this function');
 if($('articleDraft').dataset.dirty)throw Error('Save draft in HAWM first');
 const d=draftFromTask(session.hawms?.task);if(!d||d.length>DRAFT_MAX)throw Error('No valid saved draft');
 const prompt=reviewPrompt(d);
 if(prompt.length>600)throw Error('Bounded chat message too long');
 const s=await req('/api/native/chat',{message:prompt});refreshState(s);
 const review=reviewObservation(s);
 say(review.kind==='OFF_TOPIC'?'MODEL RESPONSE OFF TOPIC: it referred to DemoSubject or evidence independence, not the article. This is a negative result, not a completed document review.': 'Local AI answered the document-focused prompt. Answer quality is NOT verified and no release is authorized.');
}
async function chat(){const msg=$('chatText').value.trim();if(!msg)return;if(msg.length>600)throw Error('Message too long');const x=await req('/api/native/chat',{message:msg});$('chatText').value='';refreshState(x);say('Original HAWM '+displayedChatMode+' replied. Conversation is UNCHECKED and did not run CFC.');}
const BOUND_FIELDS=['project_name','goal','task','branch','claims','evidence','constraints','unresolved'];
function bindingMatches(current){
 const previous=session.latest?.state||session.hawms;
 if(!previous||!current)return false;
 if(!BOUND_FIELDS.every(k=>JSON.stringify(current[k]??null)===JSON.stringify(previous[k]??null)))return false;
 const m=current.mapping_draft,old=previous.mapping_draft;
 return !!(m&&old&&m.status==='CONFIRMED'&&m.handoff_id===old.handoff_id&&m.confirmed_state_hash===old.confirmed_state_hash);
}
function invalidateExternalState(){
 clearEffect('HISTORICAL EFFECT — NOT CURRENT');
 if(!session.latest&&!session.confirmed)return;
 emptyResult('HAWM STATE CHANGED OUTSIDE THIS SCREEN');
 banner('BLOCKED · HISTORICAL RESULT ONLY','blocked');set('claimStatus','NOT EVALUATED');set('closureStatus','BLOCKED');
 set('decisionWhy','Original HAWM state or mapping differs from the last confirmed execution. The previous decision is historical, not current. Create a new handoff.');
 set('gates','No new controller gates evaluated.');say('Original HAWM changed outside this workspace. Historical result cleared; reapprove and rerun.');
}
async function recheckExternal(){
 if((!session.latest&&!session.confirmed)||busy||!session.native)return;
 try{const cur=await req('/api/native/state');if(!bindingMatches(cur))invalidateExternalState();}
 catch(e){emptyResult('CURRENT STATE CANNOT BE VERIFIED');$('run').disabled=true;say('Native HAWM current state unavailable: '+e.message)}
}
async function exportTrace(){
 if(!session.executed||!session.latest)throw Error('A fresh native run is required');
 const x=await req('/api/native/export');
 const raw=session.latest.result.raw;
 if(!bindingMatches(x.state)||JSON.stringify(x.state.last_fixture_result?.raw)!==JSON.stringify(raw)){
  invalidateExternalState();throw Error('HAWM state or last CFC run changed; refused stale export');
 }
 save({schema:'CFC_HAWM_NATIVE_TRACE_V0_4_NOT_CP15',original_hawm_export:x,raw_original_cfc_result:raw,reviewer_scenario:$('scenario').value,limitations:['SYNTHETIC_INPUTS',displayedChatMode.includes('LOCAL AI')?'LOCAL_MODEL_PROVIDER_REPORTED':'OFFLINE_TEST_ADAPTER_NOT_LLM','NOT_INFORMATION_PASSPORT_CP15','NOT_EXTERNAL_AUTHORITY','NO_ACTION_EXECUTION']},'CFC_HAWM_NATIVE_TRACE_V0_4_NOT_CP15.json');}
function save(o,name){const blob=new Blob([JSON.stringify(o,null,2)],{type:'application/json'});const uri=URL.createObjectURL(blob);const el=document.createElement('a');el.href=uri;el.download=name;document.body.append(el);el.click();el.remove();setTimeout(()=>URL.revokeObjectURL(uri),1000)}
async function reset(){if(!window.confirm('CLEAR CURRENT HAWM STATE? This replaces the current state and chat. Export first if needed.'))return {cancelled:true};await req('/api/native/new-project',{project_name:'New empty review workspace'});fillCase();say('HAWM state reset. Downloaded traces are not deleted.');}
function changedMapping(){emptyResult('MAPPING INPUT CHANGED · REAPPROVAL REQUIRED');session.confirmed=false;session.prepared=false;$('confirm').disabled=true;$('run').disabled=true;$('prepare').disabled=!session.initialized;refreshMapping();set('bindingStatus','Mapping fields changed. Prepare and approve exact new mapping before running.');say('Changed mapping is NOT approved. Native HAWM may still hold the previous confirmed mapping, but this UI refuses to reuse it.');updateJourney();}
// Product UX recovery: the original HAWM saves its working state on disk.
// Restoring a browser view is NOT restoring authority: require fresh mapping approval
// and a new frozen-CFC run before any simulated action or trace export.
// v0.4.7 — presentation-only recovery for document-first HAWM sessions.
// The synthetic CFC reviewer-case restore retains its existing strict gates.
// No document body, source token, quickcheck or Ollama answer is revived from
// a stale browser tab. These messages are historical, never a new CFC result.
function restoreDocumentConversationReadOnly(st){
 const chat=Array.isArray(st?.chat)?st.chat:[];
 const references=chat.filter(m=>m?.role==='user'&&String(m.content||'').startsWith(DOC_CHAT_TAG+'\n'));
 if(!references.length)return false;
 if((st.claims||[]).includes('DemoSubject is safe.'))return false; // never bypass synthetic-case restoration
 session.initialized=true; // populated state: destructive create() must ask for confirmation
 session.prepared=false;session.confirmed=false;session.executed=false;
 session.latest=null;session.effectReceipt=null;session.editedAfterConfirm=false;
 session.hawms=st;
 restoredHistoricalChat=true;
 activeNativeReplyBinding=null;
 importedDocument=null;currentDocumentAi=null;quickDocumentReview=null;quickReportZipB64=null;
 renderDocumentAi();renderQuickDocumentReview();
 renderHomeChat(st);
 const stream=$('chatStream');stream.replaceChildren();
 for(const msg of chat.slice(-16)){
  const el=document.createElement('div');el.className='message '+(msg.role==='user'?'user':'assistant');
  const role=document.createElement('span');role.className='role';
  role.textContent=msg.role==='user'?'REVIEWER · HISTORY':msg.model_mode==='openai_compatible'?'LOCAL AI · HISTORICAL · UNCHECKED':msg.model_mode==='error'?'MODEL ERROR · HISTORICAL':'OFFLINE TEST · HISTORICAL';
  const content=document.createElement('span');content.textContent=String(msg.content||'');
  el.append(role,content);stream.append(el);
 }
 const ai=chat.filter(m=>m.role==='assistant'&&m.model_mode==='openai_compatible').length;
 set('chatEvidence',`HISTORICAL HAWM: ${chat.length} messages, ${references.length} document reference(s), ${ai} local AI replies. None is a current document analysis or CFC result.`);
 set('nativeState',`Recovered document chat history ONLY (${chat.length} entries). No active source attachment or CFC mapping.`);
 set('claimPreview',(st.claims||[]).join('; ')||'No verified claim');
 set('evidencePreview',(st.evidence||[]).join('\n')||'No verified evidence');
 $('prepare').disabled=true;$('confirm').disabled=true;$('run').disabled=true;
 $('attemptEffect').disabled=true;$('downloadEffect').disabled=true;
 $('downloadBundle').disabled=true;$('exportTrace').disabled=true;
 // Synthetic reviewer controls remain disabled; native HAWM chat is still writable.
 updateHomeControls();updateJourney();renderStatusProjection();
 set('plainStatus','HAWM document history restored · no active document');
 set('homeChatStatus',`HISTORIA ODTWORZONA: ${chat.length} wiadomości i ${references.length} powiązania plików. Importowane pliki i poprzednie wyniki nie są aktywne. Załącz plik ponownie.`);
 say('READ-ONLY HISTORY VIEW: '+chat.length+' saved messages; no original document token, Quickcheck, Ollama answer, mapping or CFC action restored.');
 return true;
}
async function restoreExistingState(){
 const st=await req('/api/native/state');
 if(!st||!Array.isArray(st.claims)||!st.claims.includes('DemoSubject is safe.'))return false;
 const prefix='CFC × HAWM / Reviewer scenario: ';
 const project=String(st.project_name||'');
 if(!project.startsWith(prefix))return false;
 const key=project.slice(prefix.length);
 if(!Object.hasOwn(cases,key))return false;
 $('scenario').value=key;
 fillCase();
 const saved=st.mapping_draft?.candidate;
 if(saved && typeof saved==='object' && Array.isArray(saved.evidence)){
  const setOption=(id,value)=>{
   const el=$(id);const v=String(value);
   if([...el.options].some(x=>x.value===v))el.value=v;
  };
  setOption('required',saved.required_independent_supports);
  setOption('provenance',saved.provenance_shape);
  setOption('independence',saved.independence_authority);
  setOption('scope',saved.scope);
  for(const [i,name] of ['e1','e2'].entries()){
   const e=saved.evidence[i];
   if(e)setOption(name,String(e.polarity)+'_'+String(e.validity));
  }
 }
 session.initialized=true;
 session.prepared=false;session.confirmed=false;session.executed=false;
 session.latest=null;session.effectReceipt=null;session.editedAfterConfirm=false;
 refreshState(st);refreshMapping();
 $('prepare').disabled=false;$('confirm').disabled=true;$('run').disabled=true;
 $('saveState').disabled=false;$('unresolvedEditor').disabled=false;
 $('sendChat').disabled=false;$('chatText').disabled=false;
 $('attemptEffect').disabled=true;$('downloadEffect').disabled=true;$('downloadBundle').disabled=true;$('exportTrace').disabled=true;
 banner('HAWM SESSION RESTORED · REAPPROVAL REQUIRED','');
 set('claimStatus','NOT RE-EVALUATED');set('closureStatus','NOT AUTHORIZED');
 set('decisionWhy','Saved HAWM state and chat were restored. Historical controller results are not authorization: prepare, approve and rerun CFC before a new effect.');
 set('stateFingerprint','Restored state — mapping must be reapproved.');
 set('bindingStatus','Existing HAWM project restored (chat preserved). Previous approval is historical in this browser session.');
 say('Restored the saved native HAWM state and chat. Mapping reapproval required; no previous CFC authorization is active.');
 updateJourney();
 return true;
}
async function detect(){
 // General chat is a separate, ephemeral workflow. Do not require HAWM to report ready.
 try{
  const status=await req('/api/general-chat/status');
  generalChatConfigured=status.configured===true&&status.native_hawm_required===false;
 }catch(e){
  generalChatConfigured=false;
  say('General-chat configuration could not be checked: '+e.message);
 }
 try{const x=await req('/api/native/status');session.native=x.native_hawm_available===true&&x.native_hawm_runtime_verified===true;
 displayedChatMode=x.ordinary_chat==='LOCAL_MODEL'?'LOCAL AI MODEL · UNCHECKED':'OFFLINE TEST ADAPTER';
 set('chatMode', displayedChatMode);
 set('chatDescription', x.ordinary_chat==='LOCAL_MODEL'?'Responses are generated by your explicitly selected local AI model. The model receives confirmed HAWM state; its words are NOT verified evidence or CFC authorization.':'Offline replies are generated by the original deterministic test adapter, NOT a real AI model. Neither mode automatically runs CFC.');
 set('connection',session.native?'● ORIGINAL HAWM + FROZEN CFC · '+displayedChatMode:'● NATIVE RUNTIMES UNAVAILABLE');$('create').disabled=!session.native;say(session.native?'Native HAWM and frozen CFC detected. Checking for a saved reviewer workspace.':'Native HAWM / CFC unavailable: '+String(x.reason||'verification failed'));
 if(session.native){try{if(!await restoreExistingState()){const st=await req('/api/native/state');if(!restoreDocumentConversationReadOnly(st))say('No saved reviewer case or document history. Choose a scenario or start a new document chat.');}}catch(e){say('Native services detected but workspace recovery unavailable: '+e.message+'. Do not overwrite any historical state.');}}
 }catch(e){set('connection',generalChatConfigured?'● GENERAL CHAT CONFIGURED · HAWM UNAVAILABLE':'● NOT CONNECTED');$('create').disabled=true;say('Original native runtimes could not be confirmed: '+e.message);}finally{updateHomeControls();}}
function operationFeedback(id,kind,msg){
 const button=$(id), holder=button.closest('.button-line')||button.closest('.chat-home-input')||button;
 let feedback=holder.nextElementSibling;
 if(!feedback||!feedback.classList.contains('operation-feedback')){
  feedback=document.createElement('p');feedback.className='operation-feedback';
  feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');
  holder.insertAdjacentElement('afterend',feedback);
 }
 const names={running:'… IN PROGRESS',success:'✓ DONE',incomplete:'⚠ RESPONSE INCOMPLETE',error:'✕ FAILED',cancelled:'— CANCELLED'};
 feedback.dataset.state=kind;
 feedback.textContent=names[kind]+': '+button.dataset.actionName+' — '+msg;
 const toast=$('actionToast');toast.hidden=false;toast.dataset.state=kind;
 toast.textContent=feedback.textContent;
}
function action(id,fn){$(id).addEventListener('click',async e=>{
 e.preventDefault();if(busy)return;
 busy=true;const button=$(id),previousLabel=button.textContent;
 button.dataset.actionName=button.dataset.actionName||previousLabel.replace(/^✓ /,'');
 button.setAttribute('aria-busy','true');button.textContent='… Working';
 operationFeedback(id,'running','Please wait for confirmation.');
 try{
  const result=await fn();
  const msg=$('notice').textContent||'Action complete; inspect the result below.';
  const cancelled=result?.cancelled===true;
  const failed=/^(BLOCKED:|FAIL CLOSED|Live gate denied|DOCUMENT REVIEW UNAVAILABLE)/i.test(msg);
  operationFeedback(id,cancelled?'cancelled':result?.incomplete===true?'incomplete':failed?'error':'success',cancelled?'Nothing changed.':result?.incomplete===true?(result.general?'Temporary general chat reply incomplete; HAWM unchanged. No CFC run.':'Message saved in HAWM; local AI response incomplete. No CFC run, no authorization.'):msg);
 }catch(err){say('BLOCKED: '+err.message);operationFeedback(id,'error',err.message)}
 finally{if(button.textContent==='… Working')button.textContent=previousLabel;button.removeAttribute('aria-busy');busy=false;updateJourney()}
})}
document.addEventListener('DOMContentLoaded',()=>{
 let savedLanguage='pl';try{savedLanguage=localStorage.getItem('cfc_hawm_chat_language_v011')||'pl'}catch(_){}
 $('uiLanguageToggle').addEventListener('click',()=>setUILanguage(uiLanguage==='en'?'pl':'en'));
 $('chatScopeFree').addEventListener('click',()=>setChatScope('free'));$('chatScopeHawm').addEventListener('click',()=>setChatScope('hawm'));
 setUILanguage(savedLanguage);
 document.body.classList.add('chat-first');productInspector='none';document.body.dataset.inspector='none';selectProductView('document');initializeFlow();$('openHawm').addEventListener('click',()=>setProductInspector('hawm'));$('openCfc').addEventListener('click',()=>setProductInspector('cfc'));$('openProcess').addEventListener('click',()=>setProductInspector(productInspector==='none'?'process':'none'));action('homeStart',create);action('homeDocLoad',homeDocumentLoad);$('chatAttachFile').addEventListener('click',()=>$('homeDocFile').click());$('chatAttachmentRemove').addEventListener('click',removeChatAttachment);$('homeDocFile').addEventListener('change',()=>{if($('homeDocFile').files?.length&&!$('homeDocPaste').value.trim())$('homeDocLoad').click();});action('homeDocUse',homeDocumentUse);$('homeDocInspect').addEventListener('click',()=>setProductInspector('hawm')); action('homeQuickExport',exportQuickReport);action('homeChatSend',sendHomeChat);$('homeChatText').addEventListener('input',updateHomeMessageSize);updateHomeMessageSize();$('homeChatText').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('homeChatSend').click()}});$('viewDoc').addEventListener('click',showDocumentWorkspace);$('viewLab').addEventListener('click',showFiveStepLab);fillCase();$('scenario').addEventListener('change',fillCase);
 for(let n=1;n<=4;n++)$('docStage'+n).addEventListener('click',()=>navigateDocumentSection(n));
 for(const x of ['required','provenance','independence','scope','e1','e2'])$(x).addEventListener('change',changedMapping);
 action('create',create);action('prepare',prepare);action('confirm',confirm);action('run',run);action('saveState',edit);action('sendChat',chat);action('reset',reset);action('exportTrace',exportTrace);action('attemptEffect',attemptEffect);action('downloadEffect',async()=>{if(!session.effectReceipt)throw Error('No effect receipt');save(session.effectReceipt,'CFC_HAWM_PRODUCT_v0_9_1_EFFECT_RECEIPT.json')});
 action('downloadBundle',async()=>{const id=session.effectReceipt?.artifact_folder;if(!id||!/^attempt_[a-f0-9]{32}$/.test(id))throw Error('Missing verified attempt folder');const link=document.createElement('a');link.href='/api/review-bundle/'+encodeURIComponent(id);link.download='CFC_HAWM_REVIEW_BUNDLE_v0_9_1.zip';document.body.append(link);link.click();link.remove();say('Reviewer bundle download requested for '+id+'. Includes the local HAWM snapshot, raw CFC output and effect receipt.');});
 action('intakeReadFile',()=>intakeRead('file'));action('intakeReadPaste',()=>intakeRead('paste'));action('intakeUseSelection',intakeUseSelection);action('intakeBindExcerpt',intakeBindExcerpt);
 action('refreshReview',refreshReviewInbox);action('issueLineageRefresh',refreshIssueLineage);action('docRefresh',refreshDocReview);action('docCapture',captureDoc);action('docRecord',recordDoc);action('docExport',exportDoc);action('bindDocClaim',bindBoundClaim);action('refreshDocClaim',refreshBoundClaim);action('authSave',recordAuthority);action('authRefresh',refreshAuthorityFromButton);action('saveDraft',saveDraft);action('discussDraft',discussDraft);$('articleDraft').addEventListener('input',articleChanged);
 $('chatText').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('sendChat').click()}});
 window.addEventListener('focus',()=>{void recheckExternal()});
 $('reviewForm').addEventListener('submit',e=>{e.preventDefault();save({schema:'CFC_HAWM_REVIEWER_FEEDBACK_V0_4',independent_review_not_yet_established:true,answers:Object.fromEntries(new FormData(e.target).entries())},'CFC_HAWM_REVIEWER_FEEDBACK_V0_4.json')});updateJourney();renderStatusProjection();refreshChatAttachmentUI();detect();});
})();
