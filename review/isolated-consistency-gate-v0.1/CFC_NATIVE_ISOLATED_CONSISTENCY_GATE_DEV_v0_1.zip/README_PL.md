# CFC — izolacja bramki spójności, wewnętrzny test syntetyczny v0.1

**Zakres:** zamrożony Anchor `0.2.90rc1`, bez zmian w wheelu. Pakiet nie używa NOAA, nie wywołuje publicznego `Controller.evaluate`, nie stanowi autoryzacji produkcyjnej. `F01=HOLD`, `G10/G13/G14=BLOCK`, `R273=NO_GO`.

## Pytanie badawcze

Czy przy dwóch wymaganych niezależnych potwierdzeniach `Alice is safe.` trzeci, sprzeczny rekord blokuje domknięcie **wyłącznie** na bramce globalnej spójności, a nie z powodu braku wsparcia lub certyfikatów?

## Metoda

Reproduktor najpierw weryfikuje SHA-256 **całego** niezmodyfikowanego wheela oraz pliku `cfc_anchor/_engine.py`. Następnie pobiera z AST oryginalne narzędzia wewnętrznych testów silnika (`ev`, `r23_reset`, `r23_case` i wymagane funkcje pomocnicze). W **lokalnym sterowniku testowym**, a nie w silniku, parametryzuje ostatni rekord `E3.value`: `safe` albo `unsafe`. Funkcja bazowa zachowuje w obu przypadkach wybór pierwszych dwóch dowodów i wymaganie dwóch niezależnych potwierdzeń. Funkcje wystawiające role/certyfikaty należą do **oryginalnych wewnętrznych mechanizmów testowych Anchora**, nie do rzeczywistego podmiotu nadającego uprawnienia. Zmiana treści wymusza regenerację pochodnego identyfikatora roli i innych artefaktów, co nie jest osobną ręczną zmianą dowodu.

Wynik:

| | `safe/safe/safe` | `safe/safe/unsafe` |
|---|---|---|
| Claim | `VERIFIED` | `VERIFIED` |
| `global_consistency_valid` | `true` | `false` |
| Inne bramki | wszystkie `true` | wszystkie `true` |
| `control_closure` | `true` | `false` |
| `stop_type` | `EPISTEMIC_STOP` | `NONE` |

Silnik wskazuje dwa konflikty: E1↔E3 i E2↔E3 (w reproduktorze oryginalne identyfikatory testowe to `R23CONTROLA/B/C`). Wariant sprzeczny ma **jedną niezaliczoną bramkę**: `global_consistency_valid`.

**Granice twierdzenia:** izolacja bramki zachodzi w syntetycznym trybie wewnętrznym. Nie udowodniono wykrycia rozbieżności NOAA przez Anchora, prawdziwej niezależności zewnętrznych źródeł, uruchomienia ścieżki F01 ani realnego uprawnienia do działania. `VERIFIED` i `EPISTEMIC_STOP` w środowisku testowym nie znaczą „zatwierdzono produkcyjnie”.

Niektóre identyfikatory pochodne mogą się zmieniać między wykonaniami. Test porównuje znaczenie, wejścia autorskie, bramki i decyzje, a nie identyczność wszystkich wewnętrznych identyfikatorów.

## Windows / PowerShell

Pobierz ZIP i zamrożony wheel do `Downloads`. **Archiwum jest płaskie**, bez dodatkowego katalogu wewnętrznego:

```powershell
$folder = "$env:USERPROFILE\Downloads\CFC_NATIVE_ISOLATED_CONSISTENCY_GATE_DEV_v0_1"
$wheel = "$env:USERPROFILE\Downloads\cfc_anchor-0.2.90rc1-py3-none-any.whl"
Expand-Archive -LiteralPath "$folder.zip" -DestinationPath $folder -Force
Set-Location $folder
py -3 .\reproduce_isolated.py --wheel "$wheel" --output .\WINDOWS_RESULT.json
$env:CFC_FROZEN_WHEEL = $wheel
py -3 -m unittest -v test_isolated.py
```

Oczekiwany status: `PASS_NATIVE_ONLY_GLOBAL_CONSISTENCY_GATE_FLIPS_SYNTHETIC_ONLY`, testy `Ran 16 tests` i `OK`. Jeśli nazwa pobranego wheela ma `(1)` albo inny przyrostek, ustaw poprawną ścieżkę `$wheel` bez zmieniania bajtów wheela.

Niezależny recenzent powinien też sprawdzić definicje „matching support”, reguły wyboru podzbioru i semantykę czasową oraz źródłową poza syntetycznym modelem.
