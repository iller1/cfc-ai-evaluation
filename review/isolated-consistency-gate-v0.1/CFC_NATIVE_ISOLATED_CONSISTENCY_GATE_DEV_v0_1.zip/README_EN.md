# CFC — internal synthetic consistency-gate isolation v0.1

**Scope:** immutable frozen Anchor `0.2.90rc1`. This package does not use NOAA, does not invoke the public `Controller.evaluate` F01 path, and grants no production authorization. Status remains `F01=HOLD`, `G10/G13/G14=BLOCK`, `R273=NO_GO`.

## Question

With two independent matching supports required for `Alice is safe.`, does a contradictory third record block closure **solely** because global consistency fails, without support-policy or certificate failures?

## Method and observations

The runner SHA-256 verifies both the unchanged wheel and the original `cfc_anchor/_engine.py`, then uses the original internal developer fixture helpers extracted from that verified AST. The **external test wrapper**, not the controller engine, parameterizes `E3.value` from `safe` to `unsafe`. The original R23 fixture's selection of the first two supports, two-support threshold, and internal role/certificate generation are used in both cases. Derived content-bound role identifiers and downstream artifacts update with the changed input.

| Property | `safe/safe/safe` | `safe/safe/unsafe` |
| --- | --- | --- |
| Claim state | `VERIFIED` | `VERIFIED` |
| `global_consistency_valid` | true | false |
| All other gates | true | true |
| Internal `control_closure` | true | false |
| `stop_type` | EPISTEMIC_STOP | NONE |

The controller reports two `MUTUALLY_EXCLUSIVE_STATE_CONFLICT` relations, E1–E3 and E2–E3. The only failed gate in the conflicting case is `global_consistency_valid`.

**Limitations:** synthetic developer test credentials are not trustworthy external authority; claim `VERIFIED` and test `EPISTEMIC_STOP` are not permissions to act. This is not NOAA ingestion, end-to-end F01, external evidence custody verification, or production integration. Source independence is modeled in the fixture; it is not independently established for real-world sources. Some downstream identifiers may differ between repetitions; observed decisions and meaningful gate projections must remain stable.

## Windows

The ZIP contains files at its root (no nested directory). After downloading the ZIP and the original frozen wheel to `Downloads`:

```powershell
$folder = "$env:USERPROFILE\Downloads\CFC_NATIVE_ISOLATED_CONSISTENCY_GATE_DEV_v0_1"
$wheel = "$env:USERPROFILE\Downloads\cfc_anchor-0.2.90rc1-py3-none-any.whl"
Expand-Archive -LiteralPath "$folder.zip" -DestinationPath $folder -Force
Set-Location $folder
py -3 .\reproduce_isolated.py --wheel "$wheel" --output .\WINDOWS_RESULT.json
$env:CFC_FROZEN_WHEEL = $wheel
py -3 -m unittest -v test_isolated.py
```

Expected: `PASS_NATIVE_ONLY_GLOBAL_CONSISTENCY_GATE_FLIPS_SYNTHETIC_ONLY` and `Ran 16 tests`, `OK`. Use the exact wheel filename if your download was renamed, but never change the wheel contents.

Reviewer challenge: examine matching-support universe construction, support subset selection and external trust semantics; this fixture is not independent validation of the model's production assumptions.
