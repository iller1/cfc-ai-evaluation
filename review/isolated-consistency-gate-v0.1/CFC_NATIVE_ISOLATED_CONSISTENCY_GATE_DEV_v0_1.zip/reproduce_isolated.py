#!/usr/bin/env python3
"""Read-only frozen CFC Anchor internal synthetic test; no production authority.

Uses the *original*, byte-verified Anchor engine and selected original developer
fixture helpers read from AST. Only the fixture-generated last evidence value
is parameterised in our test driver. Controller / engine code is never edited.
"""
from __future__ import annotations
import argparse
import ast
import copy
import hashlib
import importlib
import json
import sys
import zipfile
from pathlib import Path

WHEEL_SHA256 = 'b3b1f11e060289afa4e7da61072f2c31be7f0da1786be90682ec307d4e1f5303'
ENGINE_SHA256 = '77a7547c02ce4aac3d3abc759bbd266f4251de9149da2308454527c7f2dea5c0'
SCHEMA='CFC_NATIVE_ISOLATED_CONSISTENCY_GATE_DEV_v0.1'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_source(wheel: Path) -> bytes:
    if not wheel.is_file():
        raise ValueError('FROZEN_WHEEL_MISSING')
    if digest(wheel.read_bytes()) != WHEEL_SHA256:
        raise ValueError('FROZEN_WHEEL_SHA256_MISMATCH')
    with zipfile.ZipFile(wheel) as archive:
        source=archive.read('cfc_anchor/_engine.py')
    if digest(source) != ENGINE_SHA256:
        raise ValueError('FROZEN_ENGINE_SHA256_MISMATCH')
    return source


def run_experiment(wheel: Path) -> dict:
    src=checked_source(wheel)
    wp=str(wheel.resolve())
    sys.path.insert(0,wp)
    if 'cfc_anchor._engine' in sys.modules and wp not in str(getattr(sys.modules['cfc_anchor._engine'],'__file__','')):
        raise RuntimeError('ENGINE_IMPORT_COLLISION')
    engine=importlib.import_module('cfc_anchor._engine')
    if wp not in str(getattr(engine,'__file__','')):
        raise RuntimeError('ENGINE_IMPORT_NOT_FROM_VERIFIED_WHEEL')
    original=next((n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='self_tests'),None)
    if original is None: raise ValueError('SELF_TESTS_FUNCTION_MISSING')
    boundary=next((i for i,n in enumerate(original.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and
                  isinstance(n.value.func,ast.Name) and n.value.func.id=='add' and n.value.args and
                  isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='baseline_referent_consistent_closes'),None)
    if boundary is None:raise ValueError('ORIGINAL_FIXTURE_PREAMBLE_NOT_FOUND')
    preamble=copy.deepcopy(original.body[:boundary])
    helper_names=[n.name for n in preamble if isinstance(n,ast.FunctionDef)]
    if helper_names!=['add','dep','ev','_fixture_issue_set_certificates','run']:
        raise ValueError('FROZEN_FIXTURE_HELPER_SIGNATURE_CHANGED')
    helper_defs={n.name:copy.deepcopy(n) for n in original.body if isinstance(n,ast.FunctionDef)}
    if not {'r23_reset','r23_case'}.issubset(helper_defs):
        raise ValueError('FROZEN_R23_FIXTURE_HELPERS_NOT_FOUND')
    case=helper_defs['r23_case']
    case.args.args.append(ast.arg(arg='e3_value',annotation=None,type_comment=None))
    case.args.defaults.append(ast.Constant(value='safe'))
    edits=0
    for comp in ast.walk(case):
        if isinstance(comp,ast.ListComp) and isinstance(comp.elt,ast.Call) and isinstance(comp.elt.func,ast.Name) and comp.elt.func.id=='ev':
            if not isinstance(comp.elt.args[3],ast.Constant) or comp.elt.args[3].value!='safe':
                raise ValueError('FROZEN_R23_EVIDENCE_EXPRESSION_CHANGED')
            comp.elt.args[3]=ast.IfExp(
                test=ast.Compare(left=ast.Name(id='eid',ctx=ast.Load()),ops=[ast.Eq()],
                    comparators=[ast.Subscript(value=ast.Name(id='ids',ctx=ast.Load()),slice=ast.Constant(value=2),ctx=ast.Load())]),
                body=ast.Name(id='e3_value',ctx=ast.Load()),orelse=ast.Constant(value='safe'))
            edits+=1
    if edits!=1:raise ValueError('FROZEN_R23_EVIDENCE_FACTORY_AMBIGUOUS')

    # Same fixture setup and support selection in both cases. Original r23_reset
    # isolates the test registries. Engine receives different E3.value only.
    fixture='''
scenarios={}
for label,value in [('aligned','safe'),('conflicting','unsafe')]:
    scenario=r23_case('CONTROL',selection=True,classes='EXCLUDED_NOT_NEEDED',e3_value=value)
    out=scenario['out']
    scenarios[label]={
        'evidence':scenario['evidence'],
        'status':[{'status':c['status'],'reason':c['reason']} for c in out['claims']],
        'closure':out['control_closure'],'stop_type':out['stop_type'],
        'failed_gates':sorted(k for k,v in out['gates'].items() if v is False),
        'global_consistency':out['gates'].get('global_consistency_valid'),
        'global_consistency_violations':out['global_consistency_violations'],
        'policy_violations':out['claim_support_policy_violations'],
        'evidence_errors':out['evidence_errors'],
        'certificate_violations':out['certificate_violations'],
        'matching_support_evidence_ids':[list(u['matching_evidence_ids']) for u in out.get('matching_support_universes',[])],
    }
return scenarios
'''
    wrapper=ast.FunctionDef(name='_dev_isolated_gate_fixture',args=original.args,
        body=preamble+[helper_defs['r23_reset'],case]+ast.parse(fixture).body,
        decorator_list=[],returns=None,type_comment=None)
    mod=ast.fix_missing_locations(ast.Module(body=[wrapper],type_ignores=[]))
    exec(compile(mod,'<verified-wheel-internal-test-helper-subset>','exec'),engine.__dict__)
    try:
        first=engine._dev_isolated_gate_fixture()
        replay=engine._dev_isolated_gate_fixture()
    finally:
        engine.exit_self_test_role_scope()
        engine._SELF_TEST_FIXTURE_ROLE_AUTOREBIND=False
        del engine._dev_isolated_gate_fixture

    a,b=first['aligned'],first['conflicting']
    ea,eb=a['evidence'],b['evidence']
    if len(ea)!=3 or len(eb)!=3:raise ValueError('EXPECTED_THREE_EVIDENCE_RECORDS')
    def authored(seq):
        return [{key:copy.deepcopy(val) for key,val in ev.items() if key!='epistemic_role_record_id'} for ev in seq]
    aa=authored(ea); bb=authored(eb)
    bb[2]['value']='safe'
    ids=[x['evidence_id'] for x in ea]
    pairs={frozenset(x.get('evidence_ids',[])) for x in b['global_consistency_violations']
           if x.get('type')=='MUTUALLY_EXCLUSIVE_STATE_CONFLICT'}
    clean=lambda r: all(not r[k] for k in ('evidence_errors','certificate_violations','policy_violations'))
    project=lambda item: {k:v for k,v in item.items() if k!='evidence'}
    checks={
        'wheel_and_engine_exact_sha256':True,
        'three_records_same_ids': [x['evidence_id'] for x in ea]==[x['evidence_id'] for x in eb]==ids,
        'only_one_authored_field_changed':aa==bb and ea[2]['value']=='safe' and eb[2]['value']=='unsafe',
        'role_id_regenerated_from_changed_content': bool(ea[2].get('epistemic_role_record_id')) and ea[2].get('epistemic_role_record_id')!=eb[2].get('epistemic_role_record_id'),
        'sources_and_dependencies_unchanged': [x['provenance'] for x in ea]==[x['provenance'] for x in eb] and len(set(x['provenance']['source_id'] for x in ea))==3,
        'same_claim_and_two_support_policy':a['status'][0]['status']=='VERIFIED' and b['status'][0]['status']=='VERIFIED',
        'both_admitted_without_cert_or_support_policy_violations':clean(a) and clean(b),
        'aligned_no_gate_failures':a['failed_gates']==[] and a['global_consistency'] is True,
        'conflict_only_global_consistency_gate_fails':b['failed_gates']==['global_consistency_valid'] and b['global_consistency'] is False,
        'conflict_issued_for_E1_E3_and_E2_E3':pairs=={frozenset((ids[0],ids[2])),frozenset((ids[1],ids[2]))} and len(b['global_consistency_violations'])==2,
        'claim_status_verified_both_states':a['status'][0]['status']=='VERIFIED' and b['status'][0]['status']=='VERIFIED',
        'closure_flips_only_in_synthetic_fixture':a['closure'] is True and a['stop_type']=='EPISTEMIC_STOP' and b['closure'] is False and b['stop_type']=='NONE',
        'support_universe_recomputed_from_current_evidence':a['matching_support_evidence_ids']==[ids] and b['matching_support_evidence_ids']==[ids[:2]],
        'repeated_decision_projections_stable':all(project(first[k])==project(replay[k]) for k in ('aligned','conflicting')),
        'repeated_authored_evidence_stable':all(authored(first[k]['evidence'])==authored(replay[k]['evidence']) for k in ('aligned','conflicting')),
    }
    if not all(checks.values()):
        raise ValueError('SYNTHETIC_GATE_ISOLATION_CHECK_FAILED: '+json.dumps({k:v for k,v in checks.items() if not v}))
    return {
        'schema':SCHEMA,
        'status':'PASS_NATIVE_ONLY_GLOBAL_CONSISTENCY_GATE_FLIPS_SYNTHETIC_ONLY',
        'wheel_sha256':WHEEL_SHA256,'engine_sha256':ENGINE_SHA256,
        'execution':'unchanged original engine; selected frozen self-test helper AST with parameterized E3.value fixture input',
        'authored_counterfactual':'E3.value safe -> unsafe; derived role ID and downstream proof artifacts regenerated by engine fixture helpers',
        'claim':'Alice is safe.','required_independent_supports':2,
        'support_selection_rule':'original R23 self-test selection=True, excluded third matching support EXCLUDED_NOT_NEEDED',
        'cases':{k:project(v) | {'input_values':[e['value'] for e in v['evidence']],
                               'evidence_ids':[e['evidence_id'] for e in v['evidence']]} for k,v in first.items()},
        'checks':checks,
        'interpretation':{
            'observed':'Both claim statuses VERIFIED. With the single authored E3.value change, only global_consistency_valid fails, preventing internal synthetic control closure.',
            'boundary':'Synthetic self-test fixture credentials and explicit support selection; not independent source custody or real issuer authorisation.',
            'not_claimed':'Not NOAA ingestion, no public Controller.evaluate F01, not an authorized external action, not a production integration.'},
        'noaa_evidence_used':False,'public_api_controller_evaluate_called':False,'production_authorization':False,
        'decisions':{'anchor':'FROZEN','F01':'HOLD','G10':'BLOCK','G13':'BLOCK','G14':'BLOCK','R273':'NO_GO'},
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wheel',type=Path,required=True)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        report=run_experiment(args.wheel)
        if args.output:
            args.output.parent.mkdir(parents=True,exist_ok=True)
            args.output.write_text(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
        print(json.dumps({
            'status':report['status'],
            'aligned':{k:report['cases']['aligned'][k] for k in ('input_values','status','global_consistency','failed_gates','closure','stop_type')},
            'conflicting':{k:report['cases']['conflicting'][k] for k in ('input_values','status','global_consistency','global_consistency_violations','failed_gates','closure','stop_type')},
            'checks':report['checks'],
            'production_authorization':report['production_authorization'],
            'decisions':report['decisions']},indent=2,ensure_ascii=False))
        return 0
    except Exception as exc:
        print('REJECTED / NO POSITIVE RESULT:',type(exc).__name__,str(exc),file=sys.stderr)
        return 2

if __name__=='__main__':raise SystemExit(main())
