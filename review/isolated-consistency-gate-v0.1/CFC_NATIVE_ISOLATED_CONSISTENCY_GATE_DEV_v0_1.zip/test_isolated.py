"""Offline tests for synthetic internal native consistency gate isolation."""
import hashlib
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from reproduce_isolated import WHEEL_SHA256, ENGINE_SHA256, checked_source, run_experiment


class FrozenIsolatedGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        env=os.environ.get('CFC_FROZEN_WHEEL')
        if not env:
            raise RuntimeError('Set CFC_FROZEN_WHEEL to the frozen Anchor .whl file')
        cls.wheel=Path(env).resolve()
        cls.r=run_experiment(cls.wheel)
        cls.a=cls.r['cases']['aligned']
        cls.b=cls.r['cases']['conflicting']

    def test_01_frozen_sha256(self):
        self.assertEqual(hashlib.sha256(self.wheel.read_bytes()).hexdigest(),WHEEL_SHA256)
        self.assertEqual(hashlib.sha256(checked_source(self.wheel)).hexdigest(),ENGINE_SHA256)

    def test_02_exactly_three_records_in_both_cases(self):
        self.assertEqual(len(self.a['input_values']),3)
        self.assertEqual(self.a['evidence_ids'],self.b['evidence_ids'])

    def test_03_only_one_authored_field_changes(self):
        self.assertTrue(self.r['checks']['only_one_authored_field_changed'])
        self.assertEqual(self.a['input_values'],['safe']*3)
        self.assertEqual(self.b['input_values'],['safe','safe','unsafe'])

    def test_04_derived_role_id_regenerated(self):
        self.assertTrue(self.r['checks']['role_id_regenerated_from_changed_content'])

    def test_05_provenance_sources_unchanged(self):
        self.assertTrue(self.r['checks']['sources_and_dependencies_unchanged'])

    def test_06_two_support_policy_constant(self):
        self.assertEqual(self.r['required_independent_supports'],2)
        self.assertTrue(self.r['checks']['same_claim_and_two_support_policy'])

    def test_07_both_claims_verified(self):
        self.assertEqual(self.a['status'][0]['status'],'VERIFIED')
        self.assertEqual(self.b['status'][0]['status'],'VERIFIED')

    def test_08_aligned_can_close_synthetic_only(self):
        self.assertTrue(self.a['closure'])
        self.assertEqual(self.a['stop_type'],'EPISTEMIC_STOP')
        self.assertEqual(self.a['failed_gates'],[])

    def test_09_conflicting_does_not_close(self):
        self.assertFalse(self.b['closure'])
        self.assertEqual(self.b['stop_type'],'NONE')

    def test_10_only_global_consistency_fails(self):
        self.assertTrue(self.a['global_consistency'])
        self.assertFalse(self.b['global_consistency'])
        self.assertEqual(self.b['failed_gates'],['global_consistency_valid'])

    def test_11_conflicting_pair_ids_precise(self):
        ids=self.a['evidence_ids']
        expected={frozenset([ids[0],ids[2]]),frozenset([ids[1],ids[2]])}
        actual={frozenset(v['evidence_ids']) for v in self.b['global_consistency_violations']}
        self.assertEqual(expected,actual)

    def test_12_no_admission_certificate_policy_violations(self):
        for case in (self.a,self.b):
            for name in ('policy_violations','evidence_errors','certificate_violations'):
                self.assertEqual(case[name],[])

    def test_13_support_universe_derived_from_current_evidence(self):
        self.assertEqual(self.a['matching_support_evidence_ids'],[self.a['evidence_ids']])
        self.assertEqual(self.b['matching_support_evidence_ids'],[self.a['evidence_ids'][:2]])

    def test_14_replay_decision_stable(self):
        self.assertTrue(self.r['checks']['repeated_decision_projections_stable'])
        self.assertTrue(self.r['checks']['repeated_authored_evidence_stable'])

    def test_15_no_production_authorisation_or_NOAA(self):
        self.assertIs(self.r['production_authorization'],False)
        self.assertIs(self.r['noaa_evidence_used'],False)
        self.assertIs(self.r['public_api_controller_evaluate_called'],False)
        self.assertEqual(self.r['decisions']['F01'],'HOLD')
        self.assertEqual(self.r['decisions']['R273'],'NO_GO')

    def test_16_modified_and_missing_wheel_fail_without_result(self):
        script=Path(__file__).resolve().with_name('reproduce_isolated.py')
        with tempfile.TemporaryDirectory() as dirname:
            td=Path(dirname)
            bad=td/'tampered.whl'
            bad.write_bytes(self.wheel.read_bytes()+b'non-authoritative-byte')
            for w in [bad,td/'missing.whl']:
                result=td/'should-not-exist.json'
                p=subprocess.run([sys.executable,str(script),'--wheel',str(w),'--output',str(result)],capture_output=True,text=True)
                self.assertNotEqual(p.returncode,0)
                self.assertFalse(result.exists())
                self.assertIn('REJECTED / NO POSITIVE RESULT',p.stderr)

if __name__=='__main__':unittest.main()
