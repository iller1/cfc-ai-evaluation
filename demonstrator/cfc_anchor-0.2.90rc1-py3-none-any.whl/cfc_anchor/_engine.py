from __future__ import annotations

# KONTROLER AI MVP v0.2.81
# RESOLUTION/SELECTION REGISTRY KEYS BIND EXACT INTERNAL RECORD IDENTITIES
from dataclasses import dataclass, asdict, replace
from datetime import date
from enum import Enum
from itertools import combinations
from typing import Any, Dict, List, Optional, Tuple, Set
import copy, hashlib, json, re, sys, unicodedata


# ============================================================
# States
# ============================================================

class ClaimStatus(str, Enum):
    VERIFIED='VERIFIED'; SUPPORTED='SUPPORTED'; UNRESOLVED='UNRESOLVED'; QUARANTINED='QUARANTINED'; HYPOTHETICAL='HYPOTHETICAL'
class StopType(str, Enum):
    EPISTEMIC_STOP='EPISTEMIC_STOP'; RESOURCE_STOP='RESOURCE_STOP'; NONE='NONE'


# ============================================================
# Certificates
# ============================================================

@dataclass(frozen=True)
class IdentityCertificate:
    certificate_id:str; owner_type:str; owner_id:str; surface_subject:str
    domain_id:str; entity_id:str; event_id:str; version_id:str; registry_entry_id:str

@dataclass(frozen=True)
class TemporalCertificate:
    certificate_id:str; valid_from:str; valid_to:str; observed_at:str; available_at:str

@dataclass(frozen=True)
class DependencyStateJustificationCertificate:
    certificate_id:str; justification_id:str; dimension:str; state:str
    authority_id:str; scope_id:str; reason_hash:str; registry_hash:str

@dataclass(frozen=True)
class GenericRepresentationEquivalenceCertificate:
    certificate_id:str; equivalence_id:str; left_node_type:str; left_dimension:str
    right_node_type:str; right_dimension:str; semantic_node_type:str; semantic_dimension:str
    identifier_semantics:str; scope_id:str; ontology_id:str; policy_id:str; authorizer_id:str
    valid_from:str; valid_to:str; record_hash:str; policy_hash:str; certificate_result:str

@dataclass(frozen=True)
class GenericRepresentationDistinctnessCertificate:
    certificate_id:str; distinctness_id:str; left_node_type:str; left_dimension:str; left_identifier:str
    right_node_type:str; right_dimension:str; right_identifier:str; semantic_node_type:str; semantic_dimension:str
    identifier_semantics:str; retrieval_scope_id:str; as_of_date:str; ontology_id:str; policy_id:str; authorizer_id:str
    record_hash:str; policy_hash:str; certificate_result:str

@dataclass(frozen=True)
class DecisionGenericRepresentationCompletenessCertificate:
    certificate_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str; as_of_date:str
    decision_evidence_ownership_map_hash:str; decision_level_source_relation_universe_hash:str
    decision_level_relation_universe_hash:str; complete_raw_representation_inventory_hash:str
    representation_classes_present_hash:str; candidate_semantic_descriptor_records_hash:str
    cross_representation_pair_coverage_records_hash:str; proven_non_candidate_records_hash:str
    candidate_representation_pair_universe_hash:str; candidate_disposition_records_hash:str
    ontology_prefix_map_hash:str; source_discovery_signal_hash:str; typed_discovery_signal_hash:str
    active_equivalence_ids_hash:str; inactive_equivalence_records_hash:str
    equivalence_applicability_records_hash:str; contextual_equivalence_resolution_hash:str
    distinctness_registry_hash:str; distinctness_certificate_registry_hash:str; completeness_result:str

@dataclass(frozen=True)
class ProvenanceCertificate:
    certificate_id:str; evidence_id:str; source_id:str; root_origin_id:str; origin_id:str
    referent_entity_id:str; referent_event_id:str; referent_version_id:str
    extractor_id:str; common_mode_group:str; lineage:Tuple[str,...]
    dependencies:Tuple[Tuple[str,str,str,str],...]
    raw_dependencies:Tuple[Tuple[str,str,str,str],...]

@dataclass(frozen=True)
class ProvenanceCompletenessCertificate:
    certificate_id:str; evidence_id:str; provenance_certificate_id:str
    required_dimensions_hash:str; declared_dimensions_hash:str; completeness_result:str

@dataclass(frozen=True)
class DependencyOntologyConformanceCertificate:
    certificate_id:str; evidence_id:str; provenance_certificate_id:str
    dependency_entries:Tuple[Tuple[str,str,str,str,str,str,str],...]
    ontology_hash:str; allowed_shared_nodes_hash:str; conformance_result:str

@dataclass(frozen=True)
class SourceFailureDomainCertificate:
    certificate_id:str; evidence_id:str; source_id:str
    repository_id:str; producer_id:str; process_id:str; failure_domain_id:str
    canonical_failure_domain_id:str; semantics_registry_entry_id:str; semantics_authority_id:str
    resolution_state:str; synthetic_profile:bool
    ancestor_failure_domain_ids_hash:str; source_common_mode_ids_hash:str
    source_semantics_resolution_certificate_id:str
    provenance_certificate_id:str; authority_certificate_id:str
    source_policy_hash:str; source_semantics_policy_hash:str; semantics_entry_hash:str; result:str

@dataclass(frozen=True)
class SourceSemanticsResolutionCertificate:
    certificate_id:str; semantics_registry_entry_id:str; source_id:str
    repository_id:str; producer_id:str; process_id:str; failure_domain_id:str
    canonical_failure_domain_id:str; ancestor_failure_domain_ids_hash:str
    source_common_mode_ids_hash:str; resolution_state:str; semantics_entry_hash:str
    source_semantics_policy_hash:str; failure_domain_relation_registry_hash:str; result:str

@dataclass(frozen=True)
class EvidenceEpistemicRoleCertificate:
    certificate_id:str; role_record_id:str; evidence_id:str; assertion_commitment:str
    source_semantics_resolution_certificate_id:str; provenance_certificate_id:str
    authority_certificate_id:str; content_origin_id:str; epistemic_role:str
    role_authority_id:str; resolution_state:str; role_record_fingerprint:str
    role_policy_hash:str; authorization_artifact_id:str; authorization_artifact_fingerprint:str
    role_issuer_policy_hash:str; result:str

@dataclass(frozen=True)
class EvidenceEpistemicRoleAuthorizationArtifact:
    authorization_artifact_id:str; role_record_id:str; evidence_id:str; assertion_commitment:str
    semantic_assertion_identity:str; canonical_content_origin_id:str; epistemic_role:str
    issuer_grant_id:str; issuer_authority_id:str; issuer_grant_fingerprint:str
    pinned_role_policy_hash:str; pinned_role_issuer_policy_hash:str
    source_semantics_resolution_certificate_id:str; provenance_certificate_id:str; authority_certificate_id:str
    role_record_fingerprint:str; issuance_history_commitment:str; authority_scope:str
    authorization_artifact_fingerprint:str
    trusted_ancestry_version:Optional[str]=None
    trusted_ancestry_sequence:Optional[int]=None
    trusted_ancestry_predecessor_head:Optional[str]=None

@dataclass(frozen=True)
class TrustedRoleIssuanceAncestryEntry:
    sequence:int; authorization_artifact_id:str; evidence_id:str; role_record_id:str
    canonical_content_origin_id:str; predecessor_chain_head:str; resulting_chain_head:str

@dataclass(frozen=True)
class EvidenceIdentityRecord:
    evidence_id:str; evidence_identity_commitment:str; semantic_assertion_identity:str
    assertion_commitment:str; canonical_content_origin_id:str; rooted_provenance_identity:str
    stable_temporal_identity:str; first_authorization_artifact_id:str; first_history_commitment:str
    record_fingerprint:str

@dataclass(frozen=True)
class SourceIndependenceCertificate:
    certificate_id:str; independence_id:str; evidence_ids_hash:str; source_ids_hash:str
    failure_domain_ids_hash:str; generation_process_ids_hash:str
    authority_certificate_ids_hash:str; provenance_certificate_ids_hash:str
    source_failure_domain_certificate_ids_hash:str
    source_semantics_resolution_certificate_ids_hash:str
    failure_domain_relation_registry_hash:str; justification_reason_hash:str
    authorizer_id:str; policy_id:str; authorization_entry_hash:str
    source_policy_hash:str; source_semantics_policy_hash:str; ontology_hash:str; result:str

@dataclass(frozen=True)
class SupportSetIndependenceCertificate:
    certificate_id:str; independence_id:str; claim_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str; support_ids_hash:str
    source_semantics_resolution_certificate_ids_hash:str
    failure_domain_closure_hash:str; source_relation_ledger_hash:str
    set_relation_entry_hash:str; set_common_mode_registry_hash:str
    equivalence_as_of_date:str; generic_equivalence_contextual_resolution_hash:str
    source_policy_hash:str; source_semantics_policy_hash:str; ontology_hash:str; result:str

@dataclass(frozen=True)
class MatchingSupportUniverse:
    universe_id:str; claim_id:str; audit_context_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str
    matching_evidence_ids:Tuple[str,...]; matching_evidence_ids_hash:str
    matching_evidence_records_hash:str; claim_projection_hash:str; universe_hash:str

@dataclass(frozen=True)
class DecisionRelevantRelationUniverse:
    universe_id:str; claim_id:str; audit_context_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str
    matching_support_universe_hash:str; selected_support_ids_hash:str
    relation_ids:Tuple[str,...]; relation_ids_hash:str
    relation_instance_records_hash:str
    out_of_snapshot_relation_ids:Tuple[str,...]; out_of_snapshot_relation_ids_hash:str
    relation_registry_hash:str; relation_discovery_policy_hash:str; universe_hash:str

@dataclass(frozen=True)
class DecisionEvidenceOwnershipMap:
    map_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    claim_ids_hash:str; selected_support_map_hash:str; matching_support_universe_map_hash:str
    decision_node_ids_hash:str; ownership_records:Tuple[Any,...]; ownership_records_hash:str; map_hash:str

@dataclass(frozen=True)
class DecisionLevelRelationUniverse:
    universe_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    claim_ids_hash:str; selected_support_map_hash:str; matching_support_universe_map_hash:str
    decision_dependency_graph_hash:str; decision_node_ids_hash:str
    decision_evidence_ownership_map_hash:str; endpoint_claim_ownership_hash:str
    relation_ids:Tuple[str,...]; relation_ids_hash:str; relation_instance_records_hash:str
    evaluated_relation_ids_hash:str; evaluated_relation_records_hash:str
    non_decision_level_relation_ids_hash:str
    claim_local_covered_relation_ids_hash:str; claim_local_scope_sufficient_relation_ids_hash:str
    out_of_snapshot_relation_ids:Tuple[str,...]; out_of_snapshot_relation_ids_hash:str
    relation_registry_hash:str; relation_discovery_policy_hash:str; universe_hash:str

@dataclass(frozen=True)
class DecisionLevelSourceRelationUniverse:
    universe_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    claim_ids_hash:str; selected_support_map_hash:str; matching_support_universe_map_hash:str
    decision_dependency_graph_hash:str; decision_evidence_ownership_map_hash:str
    assessed_pair_ids:Tuple[Tuple[str,str],...]; assessed_pair_ids_hash:str; source_relation_records_hash:str
    decision_obligation_pair_ids:Tuple[Tuple[str,str],...]; decision_obligation_pair_ids_hash:str
    unresolved_pair_ids_hash:str; nonblocking_pair_ids_hash:str
    source_semantics_registry_hash:str; source_semantics_resolution_certificate_registry_hash:str
    failure_domain_relation_registry_hash:str; source_independence_policy_hash:str; source_semantics_policy_hash:str
    universe_hash:str

@dataclass(frozen=True)
class DecisionLevelGenericDependencyUniverse:
    universe_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    claim_ids_hash:str; selected_support_map_hash:str; matching_support_universe_map_hash:str
    decision_dependency_graph_hash:str; decision_evidence_ownership_map_hash:str
    assessed_dependency_nodes:Tuple[Tuple[str,str,str],...]; assessed_dependency_nodes_hash:str
    generic_dependency_records_hash:str; raw_representation_records_hash:str
    decision_obligation_nodes:Tuple[Tuple[str,str,str],...]; decision_obligation_nodes_hash:str
    allowed_shared_nodes_hash:str; nondecision_nodes_hash:str
    provenance_policy_hash:str; dependency_ontology_hash:str; dependency_justification_registry_hash:str
    representation_equivalence_policy_hash:str; representation_equivalence_registry_hash:str
    representation_equivalence_certificate_registry_hash:str; equivalence_resolution_records_hash:str
    active_equivalence_ids:Tuple[str,...]; active_equivalence_ids_hash:str
    inactive_equivalence_records:Tuple[Any,...]; inactive_equivalence_records_hash:str
    equivalence_applicability_records:Tuple[Any,...]; equivalence_applicability_records_hash:str
    contextual_equivalence_resolution_hash:str
    complete_raw_representation_inventory:Tuple[Any,...]; complete_raw_representation_inventory_hash:str
    representation_classes_present:Tuple[Any,...]; representation_classes_present_hash:str
    candidate_semantic_descriptor_records:Tuple[Any,...]; candidate_semantic_descriptor_records_hash:str
    cross_representation_pair_coverage_records:Tuple[Any,...]; cross_representation_pair_coverage_records_hash:str
    proven_non_candidate_records:Tuple[Any,...]; proven_non_candidate_records_hash:str
    candidate_representation_pair_universe:Tuple[Any,...]; candidate_representation_pair_universe_hash:str
    candidate_disposition_records:Tuple[Any,...]; candidate_disposition_records_hash:str
    ontology_prefix_map_hash:str; source_discovery_signal_hash:str; typed_discovery_signal_hash:str
    representation_distinctness_registry_hash:str; representation_distinctness_certificate_registry_hash:str
    representation_completeness_certificate_id:str; representation_completeness_certificate_hash:str
    universe_hash:str

@dataclass(frozen=True)
class SupportSelectionCertificate:
    certificate_id:str; selection_id:str; claim_id:str; audit_context_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str; matching_support_universe_hash:str
    selected_support_ids:Tuple[str,...]; excluded_support_ids:Tuple[str,...]
    selected_support_ids_hash:str; excluded_support_ids_hash:str
    exclusion_classifications:Tuple[Tuple[str,str],...]
    exclusion_classification_hash:str; exclusion_reason_hash:str
    relation_ledger_hash:str; relation_resolution_hash:str
    source_failure_domain_closure_hash:str; common_mode_registry_hash:str
    support_requirement_hash:str; justification_reason_hash:str
    support_universe_policy_hash:str; source_policy_hash:str; source_semantics_policy_hash:str
    ontology_hash:str; relation_decision_relevance_policy_hash:str; result:str

@dataclass(frozen=True)
class ClaimSupportUniverseCoverageCertificate:
    certificate_id:str; coverage_id:str; claim_id:str; audit_context_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str; matching_support_universe_hash:str
    selected_support_ids_hash:str; excluded_support_ids_hash:str
    support_selection_certificate_id:str; relation_ledger_hash:str; relation_resolution_hash:str
    decision_relevant_relation_universe_hash:str; decision_relevant_relation_ids_hash:str
    source_failure_domain_closure_hash:str; common_mode_registry_hash:str
    support_universe_policy_hash:str; source_policy_hash:str; source_semantics_policy_hash:str
    ontology_hash:str; relation_decision_relevance_policy_hash:str; coverage_result:str

@dataclass(frozen=True)
class RelationInstance:
    relation_id:str; relation_type:str; relation_effect:str
    evidence_ids:Tuple[str,...]; evidence_ids_hash:str
    claim_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    authority_id:str; policy_id:str; reason_hash:str; registry_entry_hash:str

@dataclass(frozen=True)
class RelationResolutionCertificate:
    certificate_id:str; resolution_id:str; relation_id:str
    relation_type:str; relation_effect:str; evidence_ids_hash:str
    claim_id:str; audit_context_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    matching_support_universe_hash:str; selected_support_ids_hash:str
    exclusion_classification_hash:str; source_failure_domain_closure_hash:str
    relation_registry_hash:str; support_universe_policy_hash:str; relation_resolution_policy_hash:str
    relation_decision_relevance_policy_hash:str; authorization_scope_hash:str
    authorizer_id:str; resolution_type:str; justification_hash:str; result:str

@dataclass(frozen=True)
class ExcludedSupportDispositionCertificate:
    certificate_id:str; disposition_id:str; claim_id:str; audit_context_id:str
    retrieval_scope_id:str; retrieval_snapshot_id:str
    excluded_evidence_id:str; selected_evidence_ids_hash:str
    supporting_relation_ids_hash:str; required_relation_effect:str
    matching_support_universe_hash:str; selected_support_ids_hash:str
    decision_relevant_relation_ids_hash:str; decision_relevant_relation_universe_hash:str
    authority_id:str; support_universe_policy_hash:str; relation_resolution_policy_hash:str
    relation_decision_relevance_policy_hash:str
    justification_hash:str; result:str

@dataclass(frozen=True)
class AuthorityCertificate:
    certificate_id:str; evidence_id:str; authority_id:str; predicate:str
    record_entity_id:str; record_event_id:str; record_version_id:str
    evidence_identity_certificate_id:str; provenance_certificate_id:str; policy_fingerprint:str

@dataclass(frozen=True)
class ReferentConsistencyCertificate:
    certificate_id:str; claim_id:str; evidence_id:str
    claim_identity_certificate_id:str; evidence_identity_certificate_id:str
    authority_certificate_id:str; provenance_certificate_id:str
    identity_tuple_hash:str; consistency_result:str

@dataclass(frozen=True)
class EvidenceSetCoverageCertificate:
    certificate_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    expected_evidence_ids_hash:str; supplied_evidence_ids_hash:str
    retrieval_registry_hash:str; coverage_result:str

@dataclass(frozen=True)
class SnapshotContentIntegrityCertificate:
    certificate_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    expected_record_manifest_hash:str; supplied_record_manifest_hash:str
    retrieval_registry_hash:str; integrity_result:str

@dataclass(frozen=True)
class SnapshotApplicabilityCertificate:
    certificate_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    applicability_group_id:str; retrieval_universe_id:str
    semantic_scope_hash:str; entity_ids_hash:str; event_ids_hash:str; version_ids_hash:str; predicates_hash:str
    snapshot_competition_certificate_id:str
    as_of_date:str; snapshot_version:int; retrieval_registry_hash:str; applicability_result:str

@dataclass(frozen=True)
class ClaimSnapshotProjectionCertificate:
    certificate_id:str; claim_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    projection_signature_hash:str; relational_neighborhood_hash:str
    relevant_evidence_ids_hash:str; relevant_record_hashes_hash:str
    as_of_date:str; retrieval_registry_hash:str; projection_result:str

@dataclass(frozen=True)
class DecisionRelevantOverlapCertificate:
    certificate_id:str; claim_ids_hash:str; candidate_scope_map_hash:str
    candidate_projection_map_hash:str; as_of_date:str; retrieval_registry_hash:str
    overlap_result:str

@dataclass(frozen=True)
class SnapshotSupersessionCertificate:
    certificate_id:str; claim_id:str; predecessor_scope_id:str; predecessor_snapshot_id:str
    successor_scope_id:str; successor_snapshot_id:str; supersession_authority_id:str
    carried_evidence_ids_hash:str; retracted_evidence_ids_hash:str
    predecessor_projection_hash:str; successor_projection_hash:str
    retrieval_registry_hash:str; supersession_result:str

@dataclass(frozen=True)
class SnapshotCompetitionCertificate:
    certificate_id:str; retrieval_scope_id:str; retrieval_snapshot_id:str
    retrieval_universe_id:str; candidate_scope_ids_hash:str; candidate_snapshot_ids_hash:str
    claim_candidate_map_hash:str; overlap_certificate_id:str; supersession_certificates_hash:str
    winning_scope_id:str; winning_snapshot_id:str; winning_version:int
    as_of_date:str; retrieval_registry_hash:str; competition_result:str

@dataclass(frozen=True)
class JustificationIndependenceCertificate:
    certificate_id:str; claim_id:str; support_ids_hash:str
    full_dependency_closure_hash:str; source_relation_ledger_hash:str
    source_independence_certificate_ids_hash:str; support_set_independence_certificate_id:str
    policy_hash:str; independence_result:str

@dataclass(frozen=True)
class SupportSetCertificate:
    certificate_id:str; claim_id:str; audit_context_id:str; required_supports:int
    support_ids_hash:str; direct_certificate_ids_hash:str; independence_certificate_id:str
    set_level_independence_certificate_id:str; matching_support_universe_hash:str
    support_selection_certificate_id:str; support_universe_coverage_certificate_id:str
    support_policy_hash:str; support_set_result:str

@dataclass(frozen=True)
class DecisionSupportClosureCertificate:
    certificate_id:str; audit_context_id:str; claim_ids_hash:str
    support_set_certificate_ids_hash:str; selected_support_map_hash:str
    matching_support_universe_map_hash:str; decision_relevant_relation_universe_map_hash:str
    support_selection_certificate_ids_hash:str
    support_universe_coverage_certificate_ids_hash:str
    union_dependency_graph_hash:str; cross_claim_shared_nodes_hash:str
    decision_evidence_ownership_map_hash:str
    decision_level_relation_universe_hash:str; decision_level_relation_ids_hash:str
    decision_level_relation_instance_records_hash:str; decision_level_relation_scope_coverage_hash:str
    decision_level_relation_resolution_artifacts_hash:str
    decision_level_source_relation_universe_hash:str; decision_level_source_relation_records_hash:str
    decision_level_source_obligation_pairs_hash:str; cross_channel_coverage_hash:str
    decision_level_generic_dependency_universe_hash:str; decision_level_generic_dependency_records_hash:str
    decision_level_generic_dependency_raw_representation_records_hash:str
    decision_level_generic_dependency_obligations_hash:str; decision_level_generic_dependency_accounting_hash:str
    generic_relation_source_identity_policy_hash:str; generic_representation_equivalence_registry_hash:str
    generic_representation_equivalence_certificate_registry_hash:str; generic_equivalence_resolution_records_hash:str
    generic_active_equivalence_ids_hash:str; generic_inactive_equivalence_records_hash:str
    generic_equivalence_applicability_records_hash:str; generic_contextual_equivalence_resolution_hash:str
    generic_complete_raw_representation_inventory_hash:str; generic_representation_classes_present_hash:str
    generic_candidate_semantic_descriptor_records_hash:str; generic_cross_representation_pair_coverage_records_hash:str
    generic_proven_non_candidate_records_hash:str
    generic_candidate_representation_pair_universe_hash:str; generic_candidate_disposition_records_hash:str
    generic_ontology_prefix_map_hash:str; generic_source_discovery_signal_hash:str; generic_typed_discovery_signal_hash:str
    generic_representation_distinctness_registry_hash:str; generic_representation_distinctness_certificate_registry_hash:str
    generic_representation_completeness_certificate_hash:str
    three_channel_composition_hash:str
    source_relation_ledger_hash:str; source_independence_certificate_ids_hash:str
    support_set_independence_certificate_ids_hash:str
    temporal_identity_compatibility_hash:str; closure_result:str

@dataclass(frozen=True)
class ClosurePolicyCertificate:
    certificate_id:str; policy_id:str; per_claim_requirements_hash:str
    support_artifact_context_id:str
    constraint_registry_hash:str; authority_registry_hash:str; provenance_policy_hash:str
    temporal_profile_hash:str; control_profile_hash:str; identity_registry_hash:str
    retrieval_registry_hash:str; dependency_justification_registry_hash:str; dependency_ontology_hash:str
    source_independence_policy_hash:str; source_semantics_policy_hash:str; source_semantics_registry_hash:str
    source_semantics_resolution_certificate_registry_hash:str
    failure_domain_alias_registry_hash:str; failure_domain_parent_registry_hash:str
    support_set_common_mode_registry_hash:str; support_set_independence_certificate_registry_hash:str
    source_independence_authorization_registry_hash:str; source_independence_certificate_registry_hash:str
    support_universe_policy_hash:str; support_selection_registry_hash:str
    matching_support_universe_registry_hash:str; support_selection_certificate_registry_hash:str
    claim_support_universe_coverage_certificate_registry_hash:str
    relation_discovery_policy_hash:str; decision_relevant_relation_universe_registry_hash:str
    relation_resolution_policy_hash:str; relation_decision_relevance_policy_hash:str; relation_resolution_registry_hash:str
    relation_resolution_certificate_registry_hash:str
    excluded_support_disposition_registry_hash:str; excluded_support_disposition_certificate_registry_hash:str
    closure_class_spec_hash:str; pinned_meta_authority_hash:str

@dataclass(frozen=True)
class PolicyAuthorizationCertificate:
    certificate_id:str; closure_policy_certificate_id:str; closure_class:str
    gate_registry_hash:str; waiver_set_hash:str; authorization_registry_hash:str
    authorizer_id:str; authorization_result:str

@dataclass(frozen=True)
class AuditContextCertificate:
    certificate_id:str; audit_context_id:str; input_hash:str; raw_evidence_hash:str
    claim_set_hash:str; claim_identity_map_hash:str; as_of_date:str
    scope_spec_hash:str; extraction_spec_hash:str; retrieval_scope_id:str; retrieval_universe_id:str
    evidence_set_coverage_certificate_id:str; snapshot_content_integrity_certificate_id:str
    snapshot_competition_certificate_id:str; snapshot_applicability_certificate_id:str
    closure_policy_certificate_id:str; policy_authorization_certificate_id:str; gate_registry_hash:str
    decision_runtime_authorization_state_hash:str

@dataclass(frozen=True)
class ControlBindingCertificate:
    certificate_id:str; condition_type:str; condition_id:str; audit_context_id:str
    input_hash:str; raw_evidence_hash:str; claim_set_hash:str; condition_spec_hash:str
    closure_policy_certificate_id:str; result:bool

@dataclass(frozen=True)
class AdequacyCertificate:
    certificate_id:str; adequacy_type:str; audit_context_id:str; profile_hash:str
    result:bool; validator_id:str

@dataclass(frozen=True)
class GateMetaAdequacyCertificate:
    certificate_id:str; closure_class:str; closure_class_spec_hash:str
    gate_registry_hash:str; obligation_gate_map_hash:str; pinned_meta_authority_hash:str
    meta_baseline_version:str; as_of_date:str
    schema_complete:bool; adequate_for_closure_class:bool
    live_spec_matches_pinned:bool; live_gate_map_matches_pinned:bool; live_gate_registry_matches_pinned:bool
    meta_baseline_version_applicable:bool; dependency_ontology_adequate:bool
    source_independence_policy_adequate:bool; source_semantics_policy_adequate:bool
    support_universe_policy_adequate:bool; relation_discovery_policy_adequate:bool
    relation_resolution_policy_adequate:bool; relation_decision_relevance_policy_adequate:bool

@dataclass(frozen=True)
class DirectCertificate:
    certificate_id:str; claim_id:str; evidence_id:str; audit_context_id:str
    claim_identity_certificate_id:str; evidence_identity_certificate_id:str
    authority_certificate_id:str; provenance_certificate_id:str
    provenance_completeness_certificate_id:str; dependency_ontology_conformance_certificate_id:str
    source_failure_domain_certificate_id:str; epistemic_role_certificate_id:str
    referent_consistency_certificate_id:str; temporal_certificate_id:str; evidence_fingerprint:str


@dataclass
class Claim:
    id:str; text:str; subject:str; predicate:str; value:str; polarity:str='POSITIVE'
    status:ClaimStatus=ClaimStatus.UNRESOLVED; reason:str=''
    identity:Optional[IdentityCertificate]=None; certificate:Optional[DirectCertificate]=None; support_set_certificate:Optional[SupportSetCertificate]=None

@dataclass(frozen=True)
class TrustedFact:
    evidence_id:str; subject:str; predicate:str; value:str; source:str; polarity:str
    identity:IdentityCertificate; temporal:TemporalCertificate
    provenance:ProvenanceCertificate; provenance_completeness:ProvenanceCompletenessCertificate
    dependency_ontology_conformance:DependencyOntologyConformanceCertificate
    source_failure_domain:SourceFailureDomainCertificate
    source_semantics_resolution:Optional[SourceSemanticsResolutionCertificate]
    authority:AuthorityCertificate; epistemic_role:str; content_origin_id:str
    epistemic_role_certificate:EvidenceEpistemicRoleCertificate


# R177 / v0.2.73: explicit question/answer transition records.
# R181 / v0.2.74: prior-state transport is separated from controller-owned predecessor authority.
# R185 / v0.2.75: canonical proposition history + protected transition authorization.
# R188 / v0.2.76: exact candidate binding for protected predecessor transitions.
# R192 / v0.2.77: controller-owned question/proposition semantic binding.
@dataclass(frozen=True)
class PriorEpistemicState:
    state_id:str; proposition_id:str; positive_status:str; negative_status:str
    epistemic_basis_hash:str; source_snapshot_id:str
    source_artifact_id:Optional[str]=None; source_artifact_fingerprint:Optional[str]=None
    source_sequence:Optional[int]=None; canonical_proposition_id:Optional[str]=None

@dataclass(frozen=True)
class PredecessorControlArtifact:
    artifact_id:str; proposition_id:str; claim_identity_id:str
    positive_claim_text_hash:str; negative_claim_text_hash:str
    positive_status:str; negative_status:str; epistemic_basis_hash:str
    source_retrieval_scope_id:str; source_snapshot_id:str; source_retrieval_scope_record_hash:str
    positive_audit_fingerprint:str; negative_audit_fingerprint:str
    sequence:int; predecessor_artifact_id:Optional[str]; issuance_history_commitment:str
    canonical_proposition_id:Optional[str]=None; transition_certificate_id:Optional[str]=None

@dataclass(frozen=True)
class QuestionAnswerBinding:
    binding_id:str; question_id:str; proposition_id:str; question_text_hash:str
    positive_claim_text:str; negative_claim_text:str; claim_identity_id:str
    yes_token:str; no_token:str; format_kind:str='BINARY_YES_NO'; epistemic_authority:str='NONE'
    canonical_proposition_id:Optional[str]=None; question_text:Optional[str]=None

@dataclass(frozen=True)
class PredecessorTransitionCertificate:
    certificate_id:str; canonical_proposition_id:str
    predecessor_artifact_id:str; predecessor_artifact_fingerprint:str; predecessor_sequence:int
    previous_positive_status:str; previous_negative_status:str
    candidate_positive_status:str; candidate_negative_status:str
    previous_epistemic_basis_hash:str; candidate_epistemic_basis_hash:str
    previous_scope_id:str; previous_snapshot_id:str; previous_scope_record_hash:str
    candidate_scope_id:str; candidate_snapshot_id:str; candidate_scope_record_hash:str
    transition_kind:str; candidate_transition_subject_hash:str; candidate_pre_certificate_commitment:str; authorization_mode:str
    snapshot_supersession_certificate_id:str; snapshot_supersession_certificate_fingerprint:str
    snapshot_supersession_edge_hash:str; snapshot_supersession_issuance_registry_hash:str
    issuance_history_commitment:str; as_of_date:str; result:str

@dataclass(frozen=True)
class TransitionAuditResult:
    transition_id:str; prior_state_id:str; binding_id:str; normalized_answer_token:str
    bound_polarity:str; bound_claim_text:Optional[str]
    prior_epistemic_basis_hash:str; current_epistemic_basis_hash:Optional[str]
    core_claim_status:Optional[str]; core_control_closure:bool
    transition_decision:str; reason:str


# ============================================================
# Generic helpers
# ============================================================

def sha(x:Any)->str:
    return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
def norm(s:str)->str: return unicodedata.normalize('NFC',s).strip()
def pkey(s:str)->str: return norm(s).casefold()
def nonblank(x:Any)->bool: return isinstance(x,str) and bool(x.strip())
def strict_date(s:str)->date:
    if not isinstance(s,str) or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}',s): raise ValueError
    return date.fromisoformat(s)

def canonical_hash(obj:Any)->str:
    def cv(x):
        if isinstance(x,dict): return {k:cv(v) for k,v in sorted(x.items())}
        if isinstance(x,(set,frozenset)): return sorted(cv(v) for v in x)
        if isinstance(x,(list,tuple)): return [cv(v) for v in x]
        return x
    return sha(cv(obj))

_UNKNOWN={'unknown','unk','n/a','not known'}
_ID_RE=re.compile(r'^[A-Za-z0-9._:@+\-]+$')
_NUM_RE=re.compile(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$')

def subject_shape_ok(s):
    if not nonblank(s): return False
    if s.startswith('ID:'): return bool(_ID_RE.fullmatch(s[3:]))
    if any(unicodedata.category(ch) in {'Cc','Cf'} for ch in s): return False
    if re.search(r'[\{\}\[\]\(\),;/|&+∨∧…]',s): return False
    words=[w.casefold() for w in s.split()]
    return 1<=len(words)<=6 and not any(w in {'and','or','either','plus','versus','vs','among','between'} for w in words)

def value_shape_ok(v,predicate):
    if not nonblank(v) or any(unicodedata.category(ch) in {'Cc','Cf'} for ch in v): return False
    if pkey(predicate)=='date':
        try: strict_date(v); return True
        except: return False
    if v.strip().casefold() in _UNKNOWN: return False
    if v.startswith('num:'): return bool(_NUM_RE.fullmatch(v[4:]))
    if v.startswith('id:'): return bool(_ID_RE.fullmatch(v[3:]))
    if v.startswith('str:'): return len(v[4:])>0
    if re.search(r'[\{\}\[\]\(\),;/|&+∨∧…]',v): return False
    words=[w.casefold() for w in v.split()]
    return 1<=len(words)<=5 and not any(w in {'either','or','and','between','plus','versus','vs','among','except','excluding','including','through','to'} for w in words)

def alias_skeleton(s):
    s=unicodedata.normalize('NFKC',s)
    amap={'’':"'",'‘':"'",'ʼ':"'",'�':"'",'`':"'"}; dmap={'‐':'-','‑':'-','‒':'-','–':'-','—':'-','−':'-'}
    out=[]
    for ch in s:
        if unicodedata.category(ch)=='Cf': continue
        out.append(amap.get(ch,dmap.get(ch,ch)))
    return re.sub(r'\s+',' ',''.join(out).strip()).casefold()


# ============================================================
# Parser
# ============================================================

def parse_claims(text:str)->List[Claim]:
    out=[]; parts=[x.strip() for x in re.split(r'(?<=[.!?])\s+',text.strip()) if x.strip()]
    for i,sentence in enumerate(parts,1):
        # MFR-01A: interrogative surface is not an asserted claim.
        # Preserve the speech-act distinction before punctuation normalization.
        if re.search(r'\?[!?]*\s*$',sentence):
            out.append(Claim(f'c{i}',sentence,'sentence','unmodelled',sentence,status=ClaimStatus.UNRESOLVED,reason='interrogative is not an assertion')); continue
        s=sentence.rstrip('.!?')
        if s.casefold().startswith(('maybe ','possibly ','perhaps ')):
            out.append(Claim(f'c{i}',sentence,'sentence','hypothesis',s,status=ClaimStatus.HYPOTHETICAL,reason='hypothesis')); continue
        pats=[
            (r'^the\s+(.+?)\s+date\s+is\s+(.+)$','date','POSITIVE'),
            (r'^(.+?)\s+is\s+not\s+in\s+(.+)$','location','NEGATIVE'),
            (r'^(.+?)\s+is\s+in\s+(.+)$','location','POSITIVE'),
            (r'^(.+?)\s+is\s+not\s+(.+)$','state','NEGATIVE'),
            (r'^(.+?)\s+is\s+(.+)$','state','POSITIVE'),
        ]
        for pat,pred,pol in pats:
            m=re.match(pat,s,re.I)
            if m:
                out.append(Claim(f'c{i}',sentence,m.group(1).strip(),pred,m.group(2).strip(),polarity=pol)); break
        else: out.append(Claim(f'c{i}',sentence,'sentence','unmodelled',s))
    return out

def claim_set_hash(claims):
    return sha([{'id':c.id,'text':c.text,'subject':c.subject,'predicate':c.predicate,'value':c.value,'polarity':c.polarity} for c in claims])


# ============================================================
# R177 / v0.2.73: question/answer epistemic transition control
# ============================================================

_TRANSITION_ABSTAIN_TOKENS=frozenset({'unknown','unresolved','abstain'})

def _transition_token_key(token):
    if not isinstance(token,str):return None
    k=norm(token).casefold()
    return k if k else None

def _question_text_hash(question_text):
    return sha({'question_text':question_text}) if isinstance(question_text,str) else None

# R185 / v0.2.75: caller labels are metadata; history authority uses controller-derived semantics.
def _canonical_proposition_id_from_semantics(identity_value,predicate,value):
    if not isinstance(identity_value,(tuple,list)) or len(identity_value)!=3:return None
    if not all(nonblank(x) for x in identity_value) or not nonblank(predicate) or not nonblank(value):return None
    payload={'schema':'CFC_BINARY_PROPOSITION_V1','identity_tuple':tuple(identity_value),
             'predicate':pkey(predicate),'value':norm(value)}
    return 'canon-prop:'+canonical_hash(payload)[:24]

def _canonical_proposition_id_from_claim_pair(positive_claim,negative_claim):
    if not isinstance(positive_claim,Claim) or not isinstance(negative_claim,Claim):return None
    if positive_claim.identity is None or negative_claim.identity is None:return None
    if identity_tuple(positive_claim.identity)!=identity_tuple(negative_claim.identity):return None
    if positive_claim.polarity!='POSITIVE' or negative_claim.polarity!='NEGATIVE':return None
    if (pkey(positive_claim.predicate),norm(positive_claim.value))!=(pkey(negative_claim.predicate),norm(negative_claim.value)):return None
    return _canonical_proposition_id_from_semantics(identity_tuple(positive_claim.identity),positive_claim.predicate,positive_claim.value)

def recompute_binding_canonical_proposition_id(binding):
    if not isinstance(binding,QuestionAnswerBinding):return None
    pc=parse_claims(binding.positive_claim_text);nc=parse_claims(binding.negative_claim_text)
    if len(pc)!=1 or len(nc)!=1:return None
    if binding.claim_identity_id not in IDENTITY_REGISTRY:return None
    if attach_claim_identities(pc,{'c1':binding.claim_identity_id}) or attach_claim_identities(nc,{'c1':binding.claim_identity_id}):return None
    return _canonical_proposition_id_from_claim_pair(pc[0],nc[0])

def _binding_payload(question_id,proposition_id,question_text_hash,positive_claim_text,negative_claim_text,
                     claim_identity_id,yes_token,no_token,format_kind='BINARY_YES_NO',epistemic_authority='NONE',
                     canonical_proposition_id=None,question_text=None):
    return {'question_id':question_id,'proposition_id':proposition_id,'question_text_hash':question_text_hash,
            'positive_claim_text':positive_claim_text,'negative_claim_text':negative_claim_text,
            'claim_identity_id':claim_identity_id,'yes_token':yes_token,'no_token':no_token,
            'format_kind':format_kind,'epistemic_authority':epistemic_authority,
            'canonical_proposition_id':canonical_proposition_id,'question_text':question_text}

def _binding_id_from_payload(payload):return 'qab:'+sha(payload)[:24]

def _prior_state_payload(proposition_id,positive_status,negative_status,epistemic_basis_hash,source_snapshot_id,
                         source_artifact_id=None,source_artifact_fingerprint=None,source_sequence=None,
                         canonical_proposition_id=None):
    return {'proposition_id':proposition_id,'positive_status':positive_status,'negative_status':negative_status,
            'epistemic_basis_hash':epistemic_basis_hash,'source_snapshot_id':source_snapshot_id,
            'source_artifact_id':source_artifact_id,'source_artifact_fingerprint':source_artifact_fingerprint,
            'source_sequence':source_sequence,'canonical_proposition_id':canonical_proposition_id}

def _prior_state_id_from_payload(payload):return 'prior-state:'+sha(payload)[:24]

def _binding_claim_pair(positive_claim_text,negative_claim_text,claim_identity_id):
    if not all(nonblank(x) for x in (positive_claim_text,negative_claim_text,claim_identity_id)):return None
    pc=parse_claims(positive_claim_text);nc=parse_claims(negative_claim_text)
    if len(pc)!=1 or len(nc)!=1:return None
    p,n=pc[0],nc[0]
    if p.predicate in {'unmodelled','hypothesis'} or n.predicate in {'unmodelled','hypothesis'}:return None
    if p.polarity!='POSITIVE' or n.polarity!='NEGATIVE':return None
    if (pkey(p.subject),pkey(p.predicate),norm(p.value))!=(pkey(n.subject),pkey(n.predicate),norm(n.value)):return None
    if claim_identity_id not in IDENTITY_REGISTRY:return None
    if attach_claim_identities(pc,{'c1':claim_identity_id}) or attach_claim_identities(nc,{'c1':claim_identity_id}):return None
    if p.identity is None or n.identity is None or identity_tuple(p.identity)!=identity_tuple(n.identity):return None
    canonical_id=_canonical_proposition_id_from_claim_pair(p,n)
    return None if canonical_id is None else (p,n,canonical_id)

_QUESTION_META_RE=re.compile(r'\b(evidence|data|establish(?:ed|es|ing)?|prove(?:d|s|n|ing)?|proof|conclude(?:d|s|ing)?|conclusion|infer(?:red|s|ring)?|entail(?:ed|s|ment)?|support(?:ed|s|ing)?|demonstrat(?:e|ed|es|ing)|justify|justified)\b',re.I)
_QUESTION_MODAL_RE=re.compile(r'\b(maybe|possibly|probably|likely|unlikely|certainly|definitely|necessarily|might|could|would|should|chance|probability|probable)\b',re.I)
_QUESTION_COMPOUND_RE=re.compile(r'\b(and|or|either|both)\b|[;,]',re.I)

def resolve_question_semantics(question_text,positive_claim_text,negative_claim_text,claim_identity_id):
    """Fail-closed R192 resolver for the narrow binary world-state surface used by transition control."""
    base={'question_semantic_kind':'OTHER_OR_UNRESOLVED','question_canonical_proposition_id':None,
          'question_polarity_mode':'UNRESOLVED','question_text_hash':_question_text_hash(question_text),
          'reason':'UNRESOLVED_QUESTION_SEMANTICS'}
    if not nonblank(question_text):return base
    pair=_binding_claim_pair(positive_claim_text,negative_claim_text,claim_identity_id)
    if pair is None:return {**base,'reason':'INVALID_BOUND_PROPOSITION_PAIR'}
    p,n,pair_canonical=pair
    q=norm(question_text)
    if re.search(r'\?[!?]*$',q) is None:return {**base,'reason':'QUESTION_MARK_REQUIRED'}
    if _QUESTION_META_RE.search(q):
        return {**base,'question_semantic_kind':'ENTAILMENT_OR_EVIDENCE_META','reason':'META_OR_EVIDENCE_QUESTION'}
    if _QUESTION_MODAL_RE.search(q):return {**base,'reason':'MODAL_OR_PROBABILITY_QUESTION'}
    if _QUESTION_COMPOUND_RE.search(q):return {**base,'reason':'COMPOUND_QUESTION'}
    core=re.sub(r'[!?]+$','',q).strip()
    # Preserve a narrow declarative-echo question surface (e.g. "Alice is safe?") as a question,
    # never as an assertion. This is useful for compatibility with earlier transition fixtures.
    p_surface=re.sub(r'[.!?]+$','',norm(positive_claim_text)).strip()
    n_surface=re.sub(r'[.!?]+$','',norm(negative_claim_text)).strip()
    if pkey(core)==pkey(p_surface):
        return {**base,'question_semantic_kind':'WORLD_STATE_BINARY','question_canonical_proposition_id':pair_canonical,
                'question_polarity_mode':'AFFIRMATIVE','reason':'DIRECT_DECLARATIVE_ECHO_WORLD_STATE'}
    if pkey(core)==pkey(n_surface):
        return {**base,'question_semantic_kind':'WORLD_STATE_BINARY','question_canonical_proposition_id':pair_canonical,
                'question_polarity_mode':'NEGATED','reason':'NEGATED_DECLARATIVE_ECHO_WORLD_STATE'}
    m=re.fullmatch(r'is\s+(.+)',core,re.I)
    if m is None:return base
    body=m.group(1).strip()
    subj=norm(p.subject)
    if len(body)<=len(subj) or pkey(body[:len(subj)])!=pkey(subj) or not body[len(subj)].isspace():
        return {**base,'reason':'QUESTION_SUBJECT_DOES_NOT_MATCH_BOUND_PROPOSITION'}
    rem=body[len(subj):].strip()
    polarity_mode='AFFIRMATIVE';pred='state';value=rem
    if re.match(r'^not\s+in\s+',rem,re.I):
        polarity_mode='NEGATED';pred='location';value=re.sub(r'^not\s+in\s+','',rem,count=1,flags=re.I)
    elif re.match(r'^in\s+',rem,re.I):
        pred='location';value=re.sub(r'^in\s+','',rem,count=1,flags=re.I)
    elif re.match(r'^not\s+',rem,re.I):
        polarity_mode='NEGATED';pred='state';value=re.sub(r'^not\s+','',rem,count=1,flags=re.I)
    if not nonblank(value):return base
    qcanon=_canonical_proposition_id_from_semantics(identity_tuple(p.identity),pred,value)
    if qcanon is None or qcanon!=pair_canonical or pkey(pred)!=pkey(p.predicate) or norm(value)!=norm(p.value):
        return {**base,'reason':'QUESTION_PROPOSITION_DOES_NOT_MATCH_BOUND_PROPOSITION'}
    return {**base,'question_semantic_kind':'WORLD_STATE_BINARY','question_canonical_proposition_id':qcanon,
            'question_polarity_mode':polarity_mode,'reason':'DIRECT_WORLD_STATE_QUESTION'}

def _binding_format_profile(yes_token,no_token):
    y=_transition_token_key(yes_token);n=_transition_token_key(no_token)
    if y=='yes' and n=='no':return 'BINARY_YES_NO'
    if y=='true' and n=='false':return 'BINARY_TRUE_FALSE'
    return None

def _binding_semantic_integrity_valid(binding):
    if not isinstance(binding,QuestionAnswerBinding) or not nonblank(binding.question_text):return False
    if _question_text_hash(binding.question_text)!=binding.question_text_hash:return False
    if binding.epistemic_authority!='NONE':return False
    profile=_binding_format_profile(binding.yes_token,binding.no_token)
    if profile is None or profile!=binding.format_kind:return False
    sem=resolve_question_semantics(binding.question_text,binding.positive_claim_text,binding.negative_claim_text,binding.claim_identity_id)
    canonical_id=recompute_binding_canonical_proposition_id(binding)
    if canonical_id is None or canonical_id!=binding.canonical_proposition_id:return False
    if sem.get('question_semantic_kind')!='WORLD_STATE_BINARY':return False
    if sem.get('question_polarity_mode')!='AFFIRMATIVE':return False
    if sem.get('question_canonical_proposition_id')!=canonical_id:return False
    payload=_binding_payload(binding.question_id,binding.proposition_id,binding.question_text_hash,
                             binding.positive_claim_text,binding.negative_claim_text,binding.claim_identity_id,
                             binding.yes_token,binding.no_token,binding.format_kind,binding.epistemic_authority,
                             binding.canonical_proposition_id,binding.question_text)
    return binding.binding_id==_binding_id_from_payload(payload)

def make_question_answer_binding(question_id,proposition_id,question_text,positive_claim_text,negative_claim_text,
                                 claim_identity_id,yes_token='YES',no_token='NO'):
    if not all(nonblank(x) for x in (question_id,proposition_id,question_text,positive_claim_text,negative_claim_text,claim_identity_id,yes_token,no_token)):
        return None
    if re.search(r'\?[!?]*\s*$',question_text) is None:return None
    pair=_binding_claim_pair(positive_claim_text,negative_claim_text,claim_identity_id)
    if pair is None:return None
    p,n,canonical_id=pair
    sem=resolve_question_semantics(question_text,positive_claim_text,negative_claim_text,claim_identity_id)
    if (sem.get('question_semantic_kind')!='WORLD_STATE_BINARY'
        or sem.get('question_polarity_mode')!='AFFIRMATIVE'
        or sem.get('question_canonical_proposition_id')!=canonical_id):return None
    format_kind=_binding_format_profile(yes_token,no_token)
    if format_kind is None:return None
    qh=_question_text_hash(question_text)
    payload=_binding_payload(question_id,proposition_id,qh,positive_claim_text,negative_claim_text,
                             claim_identity_id,yes_token,no_token,format_kind,'NONE',canonical_id,question_text)
    return QuestionAnswerBinding(_binding_id_from_payload(payload),question_id,proposition_id,qh,
                                 positive_claim_text,negative_claim_text,claim_identity_id,yes_token,no_token,
                                 format_kind,'NONE',canonical_id,question_text)

def validate_question_answer_binding(binding,current_question_text):
    if not isinstance(binding,QuestionAnswerBinding) or not nonblank(current_question_text):return False
    if not _binding_semantic_integrity_valid(binding):return False
    # This transition path is specifically the controller-owned literal YES/NO profile.
    if binding.format_kind!='BINARY_YES_NO':return False
    if _transition_token_key(binding.yes_token)!='yes' or _transition_token_key(binding.no_token)!='no':return False
    if _question_text_hash(current_question_text)!=binding.question_text_hash:return False
    if norm(current_question_text)!=norm(binding.question_text):return False
    sem=resolve_question_semantics(current_question_text,binding.positive_claim_text,binding.negative_claim_text,binding.claim_identity_id)
    if (sem.get('question_semantic_kind')!='WORLD_STATE_BINARY'
        or sem.get('question_polarity_mode')!='AFFIRMATIVE'
        or sem.get('question_canonical_proposition_id')!=binding.canonical_proposition_id):return False
    fresh=make_question_answer_binding(binding.question_id,binding.proposition_id,current_question_text,
                                       binding.positive_claim_text,binding.negative_claim_text,
                                       binding.claim_identity_id,binding.yes_token,binding.no_token)
    return fresh is not None and fresh==binding

def make_prior_epistemic_state(proposition_id,positive_status,negative_status,epistemic_basis_hash,source_snapshot_id,
                               source_artifact_id=None,source_artifact_fingerprint=None,source_sequence=None,
                               canonical_proposition_id=None):
    allowed={x.value for x in ClaimStatus}
    if not nonblank(proposition_id) or positive_status not in allowed or negative_status not in allowed:return None
    if not isinstance(epistemic_basis_hash,str) or re.fullmatch(r'[0-9a-f]{64}',epistemic_basis_hash) is None:return None
    if not nonblank(source_snapshot_id):return None
    if source_artifact_id is not None and not nonblank(source_artifact_id):return None
    if source_artifact_fingerprint is not None and (not isinstance(source_artifact_fingerprint,str)
        or re.fullmatch(r'[0-9a-f]{64}',source_artifact_fingerprint) is None):return None
    if source_sequence is not None and (type(source_sequence) is not int or source_sequence<1):return None
    if canonical_proposition_id is not None and (not isinstance(canonical_proposition_id,str) or re.fullmatch(r'canon-prop:[0-9a-f]{24}',canonical_proposition_id) is None):return None
    payload=_prior_state_payload(proposition_id,positive_status,negative_status,epistemic_basis_hash,source_snapshot_id,
                                 source_artifact_id,source_artifact_fingerprint,source_sequence,canonical_proposition_id)
    return PriorEpistemicState(_prior_state_id_from_payload(payload),proposition_id,positive_status,negative_status,
                               epistemic_basis_hash,source_snapshot_id,source_artifact_id,source_artifact_fingerprint,
                               source_sequence,canonical_proposition_id)

def validate_prior_epistemic_state(state):
    if not isinstance(state,PriorEpistemicState):return False
    fresh=make_prior_epistemic_state(state.proposition_id,state.positive_status,state.negative_status,
                                     state.epistemic_basis_hash,state.source_snapshot_id,
                                     state.source_artifact_id,state.source_artifact_fingerprint,state.source_sequence,
                                     state.canonical_proposition_id)
    return fresh is not None and fresh==state

def transition_epistemic_basis_hash(evidence,asof,scope,extract,retrieval_scope,req,claim_identity_id,waivers=None):
    # Deliberately excludes output-format instructions and YES/NO surface tokens.
    if not isinstance(evidence,list) or not nonblank(asof) or not nonblank(scope) or not nonblank(extract):return None
    if not nonblank(retrieval_scope) or not nonblank(claim_identity_id):return None
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope);ir=IDENTITY_REGISTRY.get(claim_identity_id)
    if rr is None or ir is None:return None
    try:strict_date(asof)
    except Exception:return None
    payload={
        'evidence_hash':canonical_hash([_evidence_epistemic_weight_projection(x) for x in evidence]),
        'retrieval_scope_id':retrieval_scope,
        'retrieval_snapshot_id':rr.get('snapshot_id'),
        'retrieval_scope_record_hash':canonical_hash(rr),
        'as_of_date':asof,'scope':scope,'extraction':extract,
        'claim_identity_id':claim_identity_id,'claim_identity_record_hash':canonical_hash(ir),
        'per_claim_requirement_hash':canonical_hash(req),
        'waiver_hash':canonical_hash(waivers or {}),
        'closure_class':CLOSURE_CLASS,'closure_class_spec_hash':closure_class_spec_hash(),
        'gate_registry_hash':gate_registry_hash(),
        'mandatory_gate_set_hash':canonical_hash(tuple(MANDATORY_GATES)),
        'provenance_policy_hash':provenance_policy_hash(),
        'source_independence_policy_hash':source_independence_policy_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
    }
    return canonical_hash(payload)

# R181 / v0.2.74: controller-owned predecessor authority.
def _transition_claim_text_hash(text):
    return sha({'claim_text':text}) if isinstance(text,str) else None

def _predecessor_artifact_payload(proposition_id,claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,
                                  positive_status,negative_status,epistemic_basis_hash,source_retrieval_scope_id,
                                  source_snapshot_id,source_retrieval_scope_record_hash,positive_audit_fingerprint,
                                  negative_audit_fingerprint,sequence,predecessor_artifact_id,issuance_history_commitment,
                                  canonical_proposition_id=None,transition_certificate_id=None):
    return {
        'proposition_id':proposition_id,'claim_identity_id':claim_identity_id,
        'positive_claim_text_hash':positive_claim_text_hash,'negative_claim_text_hash':negative_claim_text_hash,
        'positive_status':positive_status,'negative_status':negative_status,'epistemic_basis_hash':epistemic_basis_hash,
        'source_retrieval_scope_id':source_retrieval_scope_id,'source_snapshot_id':source_snapshot_id,
        'source_retrieval_scope_record_hash':source_retrieval_scope_record_hash,
        'positive_audit_fingerprint':positive_audit_fingerprint,'negative_audit_fingerprint':negative_audit_fingerprint,
        'sequence':sequence,'predecessor_artifact_id':predecessor_artifact_id,
        'issuance_history_commitment':issuance_history_commitment,
        'canonical_proposition_id':canonical_proposition_id,'transition_certificate_id':transition_certificate_id,
    }

def _predecessor_artifact_id_from_payload(payload):return 'pred-control:'+sha(payload)[:24]
def _predecessor_artifact_fingerprint(artifact):return canonical_hash(asdict(artifact)) if isinstance(artifact,PredecessorControlArtifact) else None

def _candidate_pre_certificate_payload_from_values(proposition_id,claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,
                                                   positive_status,negative_status,epistemic_basis_hash,source_retrieval_scope_id,
                                                   source_snapshot_id,source_retrieval_scope_record_hash,positive_audit_fingerprint,
                                                   negative_audit_fingerprint,sequence,predecessor_artifact_id,issuance_history_commitment,
                                                   canonical_proposition_id):
    payload=_predecessor_artifact_payload(
        proposition_id,claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,positive_status,negative_status,
        epistemic_basis_hash,source_retrieval_scope_id,source_snapshot_id,source_retrieval_scope_record_hash,
        positive_audit_fingerprint,negative_audit_fingerprint,sequence,predecessor_artifact_id,
        issuance_history_commitment,canonical_proposition_id,None)
    payload.pop('transition_certificate_id',None)
    return {'schema':'PREDECESSOR_CANDIDATE_PRE_CERTIFICATE_V1','candidate':payload}

def _candidate_pre_certificate_commitment_from_values(proposition_id,claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,
                                                       positive_status,negative_status,epistemic_basis_hash,source_retrieval_scope_id,
                                                       source_snapshot_id,source_retrieval_scope_record_hash,positive_audit_fingerprint,
                                                       negative_audit_fingerprint,sequence,predecessor_artifact_id,issuance_history_commitment,
                                                       canonical_proposition_id):
    return canonical_hash(_candidate_pre_certificate_payload_from_values(
        proposition_id,claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,positive_status,negative_status,
        epistemic_basis_hash,source_retrieval_scope_id,source_snapshot_id,source_retrieval_scope_record_hash,
        positive_audit_fingerprint,negative_audit_fingerprint,sequence,predecessor_artifact_id,issuance_history_commitment,
        canonical_proposition_id))

def _candidate_pre_certificate_commitment(artifact):
    if not isinstance(artifact,PredecessorControlArtifact):return None
    return _candidate_pre_certificate_commitment_from_values(
        artifact.proposition_id,artifact.claim_identity_id,artifact.positive_claim_text_hash,artifact.negative_claim_text_hash,
        artifact.positive_status,artifact.negative_status,artifact.epistemic_basis_hash,artifact.source_retrieval_scope_id,
        artifact.source_snapshot_id,artifact.source_retrieval_scope_record_hash,artifact.positive_audit_fingerprint,
        artifact.negative_audit_fingerprint,artifact.sequence,artifact.predecessor_artifact_id,
        artifact.issuance_history_commitment,artifact.canonical_proposition_id)

def _valid_hash64(value):return isinstance(value,str) and bool(re.fullmatch(r'[0-9a-f]{64}',value))

def _valid_canonical_proposition_id(value):
    return isinstance(value,str) and bool(re.fullmatch(r'canon-prop:[0-9a-f]{24}',value))

def _protected_predecessor_transition(previous_positive,previous_negative,candidate_positive,candidate_negative):
    v=ClaimStatus.VERIFIED.value
    if previous_positive==v and candidate_positive!=v:
        return 'VERIFIED_POSITIVE_TO_VERIFIED_NEGATIVE' if candidate_negative==v else 'VERIFIED_POSITIVE_LOSS'
    if previous_negative==v and candidate_negative!=v:
        return 'VERIFIED_NEGATIVE_TO_VERIFIED_POSITIVE' if candidate_positive==v else 'VERIFIED_NEGATIVE_LOSS'
    return None

def _candidate_transition_subject_hash(canonical_proposition_id,previous,positive_status,negative_status,basis,
                                       scope_id,snapshot_id,scope_record_hash):
    if not isinstance(previous,PredecessorControlArtifact):return None
    return canonical_hash({
        'schema':'PREDECESSOR_TRANSITION_SUBJECT_V1','canonical_proposition_id':canonical_proposition_id,
        'predecessor_artifact_id':previous.artifact_id,'predecessor_artifact_fingerprint':_predecessor_artifact_fingerprint(previous),
        'predecessor_sequence':previous.sequence,'previous_positive_status':previous.positive_status,
        'previous_negative_status':previous.negative_status,'candidate_positive_status':positive_status,
        'candidate_negative_status':negative_status,'previous_epistemic_basis_hash':previous.epistemic_basis_hash,
        'candidate_epistemic_basis_hash':basis,'previous_scope_id':previous.source_retrieval_scope_id,
        'previous_snapshot_id':previous.source_snapshot_id,'previous_scope_record_hash':previous.source_retrieval_scope_record_hash,
        'candidate_scope_id':scope_id,'candidate_snapshot_id':snapshot_id,'candidate_scope_record_hash':scope_record_hash,
    })

def _canonical_claim_desc_from_scope(canonical_proposition_id,scope_ids):
    if not _valid_canonical_proposition_id(canonical_proposition_id):return None
    for sid in scope_ids:
        rr=RETRIEVAL_SCOPE_REGISTRY.get(sid)
        if rr is None:continue
        for row in rr.get('record_projection_index',()):
            ident=(row.get('entity_id'),row.get('event_id'),row.get('version_id'))
            cid=_canonical_proposition_id_from_semantics(ident,row.get('predicate'),row.get('value_key'))
            if cid==canonical_proposition_id:
                return {'claim_id':'c1','entity_id':ident[0],'event_id':ident[1],'version_id':ident[2],
                        'predicate':pkey(row.get('predicate')),'value_key':norm(row.get('value_key')),'polarity':'POSITIVE'}
    return None

def _snapshot_supersession_certificate_fingerprint(cert):
    return canonical_hash(asdict(cert)) if isinstance(cert,SnapshotSupersessionCertificate) else None

def _snapshot_supersession_edge_hash(cert):
    if not isinstance(cert,SnapshotSupersessionCertificate):return None
    payload=asdict(cert);payload.pop('certificate_id',None);payload.pop('retrieval_registry_hash',None)
    return canonical_hash(payload)

def _transition_certificate_payload(canonical_proposition_id,previous,positive_status,negative_status,basis,
                                    scope_id,snapshot_id,scope_record_hash,transition_kind,subject_hash,
                                    candidate_pre_certificate_commitment,supersession_cert,issuance_history_commitment,as_of_date):
    return {
        'canonical_proposition_id':canonical_proposition_id,
        'predecessor_artifact_id':previous.artifact_id,
        'predecessor_artifact_fingerprint':_predecessor_artifact_fingerprint(previous),
        'predecessor_sequence':previous.sequence,
        'previous_positive_status':previous.positive_status,'previous_negative_status':previous.negative_status,
        'candidate_positive_status':positive_status,'candidate_negative_status':negative_status,
        'previous_epistemic_basis_hash':previous.epistemic_basis_hash,'candidate_epistemic_basis_hash':basis,
        'previous_scope_id':previous.source_retrieval_scope_id,'previous_snapshot_id':previous.source_snapshot_id,
        'previous_scope_record_hash':previous.source_retrieval_scope_record_hash,
        'candidate_scope_id':scope_id,'candidate_snapshot_id':snapshot_id,'candidate_scope_record_hash':scope_record_hash,
        'transition_kind':transition_kind,'candidate_transition_subject_hash':subject_hash,
        'candidate_pre_certificate_commitment':candidate_pre_certificate_commitment,
        'authorization_mode':'SNAPSHOT_SUPERSESSION',
        'snapshot_supersession_certificate_id':supersession_cert.certificate_id,
        'snapshot_supersession_certificate_fingerprint':_snapshot_supersession_certificate_fingerprint(supersession_cert),
        'snapshot_supersession_edge_hash':_snapshot_supersession_edge_hash(supersession_cert),
        'snapshot_supersession_issuance_registry_hash':supersession_cert.retrieval_registry_hash,
        'issuance_history_commitment':issuance_history_commitment,'as_of_date':as_of_date,'result':'PASS',
    }

def _transition_certificate_id_from_payload(payload):return 'pred-transition:'+sha(payload)[:24]

def predecessor_transition_certificate_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,PredecessorTransitionCertificate) else v)
                           for k,v in PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.items()})

def _issue_predecessor_transition_certificate(previous,binding,positive_status,negative_status,basis,
                                               scope_id,rr,asof,issuance_history_commitment,
                                               candidate_pre_certificate_commitment):
    if not isinstance(previous,PredecessorControlArtifact) or not isinstance(binding,QuestionAnswerBinding):return None
    if not _valid_hash64(candidate_pre_certificate_commitment):return None
    canonical_id=binding.canonical_proposition_id
    if canonical_id!=previous.canonical_proposition_id:return None
    kind=_protected_predecessor_transition(previous.positive_status,previous.negative_status,positive_status,negative_status)
    if kind is None:return None
    desc=_canonical_claim_desc_from_scope(canonical_id,(previous.source_retrieval_scope_id,scope_id))
    if desc is None:return None
    sup=make_snapshot_supersession_certificate(desc,previous.source_retrieval_scope_id,scope_id,asof)
    if sup is None:return None
    subject=_candidate_transition_subject_hash(canonical_id,previous,positive_status,negative_status,basis,
                                              scope_id,rr.get('snapshot_id'),canonical_hash(rr))
    if subject is None:return None
    payload=_transition_certificate_payload(canonical_id,previous,positive_status,negative_status,basis,scope_id,
                                            rr.get('snapshot_id'),canonical_hash(rr),kind,subject,
                                            candidate_pre_certificate_commitment,sup,issuance_history_commitment,asof)
    cert=PredecessorTransitionCertificate(_transition_certificate_id_from_payload(payload),**payload)
    if cert.certificate_id in PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY:return None
    PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY[cert.certificate_id]=cert
    return cert

def validate_predecessor_transition_certificate(cert,candidate_artifact=None):
    if not isinstance(cert,PredecessorTransitionCertificate):return False
    if PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.get(cert.certificate_id)!=cert:return False
    if not _valid_canonical_proposition_id(cert.canonical_proposition_id):return False
    if not all(_valid_hash64(x) for x in (cert.predecessor_artifact_fingerprint,cert.previous_epistemic_basis_hash,
                                          cert.candidate_epistemic_basis_hash,cert.previous_scope_record_hash,
                                          cert.candidate_scope_record_hash,cert.candidate_transition_subject_hash,
                                          cert.candidate_pre_certificate_commitment,
                                          cert.snapshot_supersession_certificate_fingerprint,cert.snapshot_supersession_edge_hash,
                                          cert.snapshot_supersession_issuance_registry_hash,cert.issuance_history_commitment)):return False
    if cert.authorization_mode!='SNAPSHOT_SUPERSESSION' or cert.result!='PASS':return False
    try: strict_date(cert.as_of_date)
    except Exception:return False
    previous=PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.get(cert.predecessor_artifact_id)
    if not isinstance(previous,PredecessorControlArtifact) or not validate_predecessor_control_artifact_record(previous):return False
    if type(cert.predecessor_sequence) is not int or cert.predecessor_sequence<1:return False
    if cert.predecessor_artifact_fingerprint!=_predecessor_artifact_fingerprint(previous) or cert.predecessor_sequence!=previous.sequence:return False
    if cert.canonical_proposition_id!=previous.canonical_proposition_id:return False
    if (cert.previous_positive_status!=previous.positive_status or cert.previous_negative_status!=previous.negative_status
        or cert.previous_epistemic_basis_hash!=previous.epistemic_basis_hash
        or cert.previous_scope_id!=previous.source_retrieval_scope_id or cert.previous_snapshot_id!=previous.source_snapshot_id
        or cert.previous_scope_record_hash!=previous.source_retrieval_scope_record_hash):return False
    kind=_protected_predecessor_transition(cert.previous_positive_status,cert.previous_negative_status,
                                           cert.candidate_positive_status,cert.candidate_negative_status)
    if kind is None or kind!=cert.transition_kind:return False
    prr=RETRIEVAL_SCOPE_REGISTRY.get(cert.previous_scope_id);crr=RETRIEVAL_SCOPE_REGISTRY.get(cert.candidate_scope_id)
    if (prr is None or crr is None or prr.get('snapshot_id')!=cert.previous_snapshot_id
        or crr.get('snapshot_id')!=cert.candidate_snapshot_id or canonical_hash(prr)!=cert.previous_scope_record_hash
        or canonical_hash(crr)!=cert.candidate_scope_record_hash):return False
    desc=_canonical_claim_desc_from_scope(cert.canonical_proposition_id,(cert.previous_scope_id,cert.candidate_scope_id))
    if desc is None:return False
    current_sup=make_snapshot_supersession_certificate(desc,cert.previous_scope_id,cert.candidate_scope_id,cert.as_of_date)
    if current_sup is None:return False
    # The exact semantic edge must still exist now. Historical certificate identity is then reconstructed
    # with the issuance-time retrieval-registry hash so unrelated later registry growth remains harmless.
    if _snapshot_supersession_edge_hash(current_sup)!=cert.snapshot_supersession_edge_hash:return False
    sup_payload=asdict(current_sup);sup_payload.pop('certificate_id',None)
    sup_payload['retrieval_registry_hash']=cert.snapshot_supersession_issuance_registry_hash
    reconstructed_sup=SnapshotSupersessionCertificate(sha(sup_payload),**sup_payload)
    if (reconstructed_sup.certificate_id!=cert.snapshot_supersession_certificate_id
        or _snapshot_supersession_certificate_fingerprint(reconstructed_sup)!=cert.snapshot_supersession_certificate_fingerprint
        or _snapshot_supersession_edge_hash(reconstructed_sup)!=cert.snapshot_supersession_edge_hash):return False
    expected_subject=_candidate_transition_subject_hash(cert.canonical_proposition_id,previous,cert.candidate_positive_status,
                                                        cert.candidate_negative_status,cert.candidate_epistemic_basis_hash,
                                                        cert.candidate_scope_id,cert.candidate_snapshot_id,cert.candidate_scope_record_hash)
    if expected_subject!=cert.candidate_transition_subject_hash:return False
    # Standalone certificate validation still resolves the exact one-to-one candidate from controller history.
    if candidate_artifact is None:
        matches=[a for a in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.values()
                 if isinstance(a,PredecessorControlArtifact) and a.transition_certificate_id==cert.certificate_id]
        if len(matches)!=1:return False
        candidate_artifact=matches[0]
    if not isinstance(candidate_artifact,PredecessorControlArtifact):return False
    if (candidate_artifact.canonical_proposition_id!=cert.canonical_proposition_id
        or candidate_artifact.predecessor_artifact_id!=cert.predecessor_artifact_id
        or candidate_artifact.sequence!=cert.predecessor_sequence+1
        or candidate_artifact.positive_status!=cert.candidate_positive_status
        or candidate_artifact.negative_status!=cert.candidate_negative_status
        or candidate_artifact.epistemic_basis_hash!=cert.candidate_epistemic_basis_hash
        or candidate_artifact.source_retrieval_scope_id!=cert.candidate_scope_id
        or candidate_artifact.source_snapshot_id!=cert.candidate_snapshot_id
        or candidate_artifact.source_retrieval_scope_record_hash!=cert.candidate_scope_record_hash
        or candidate_artifact.issuance_history_commitment!=cert.issuance_history_commitment
        or candidate_artifact.transition_certificate_id!=cert.certificate_id):return False
    if _candidate_pre_certificate_commitment(candidate_artifact)!=cert.candidate_pre_certificate_commitment:return False
    return True

def validate_predecessor_control_artifact_record(artifact):
    if not isinstance(artifact,PredecessorControlArtifact):return False
    allowed={x.value for x in ClaimStatus}
    if (not nonblank(artifact.proposition_id) or not nonblank(artifact.claim_identity_id)
        or artifact.claim_identity_id not in IDENTITY_REGISTRY or not _valid_canonical_proposition_id(artifact.canonical_proposition_id)):return False
    if artifact.positive_status not in allowed or artifact.negative_status not in allowed:return False
    if artifact.positive_status==ClaimStatus.VERIFIED.value and artifact.negative_status==ClaimStatus.VERIFIED.value:return False
    for h in (artifact.positive_claim_text_hash,artifact.negative_claim_text_hash,artifact.epistemic_basis_hash,
              artifact.source_retrieval_scope_record_hash,artifact.positive_audit_fingerprint,
              artifact.negative_audit_fingerprint,artifact.issuance_history_commitment):
        if not _valid_hash64(h):return False
    if not nonblank(artifact.source_retrieval_scope_id) or not nonblank(artifact.source_snapshot_id):return False
    if type(artifact.sequence) is not int or artifact.sequence<1:return False
    if artifact.predecessor_artifact_id is not None and not nonblank(artifact.predecessor_artifact_id):return False
    payload=_predecessor_artifact_payload(
        artifact.proposition_id,artifact.claim_identity_id,artifact.positive_claim_text_hash,
        artifact.negative_claim_text_hash,artifact.positive_status,artifact.negative_status,
        artifact.epistemic_basis_hash,artifact.source_retrieval_scope_id,artifact.source_snapshot_id,
        artifact.source_retrieval_scope_record_hash,artifact.positive_audit_fingerprint,
        artifact.negative_audit_fingerprint,artifact.sequence,artifact.predecessor_artifact_id,
        artifact.issuance_history_commitment,artifact.canonical_proposition_id,artifact.transition_certificate_id)
    if artifact.artifact_id!=_predecessor_artifact_id_from_payload(payload):return False
    if artifact.transition_certificate_id is not None and not nonblank(artifact.transition_certificate_id):return False
    return True

def predecessor_control_artifact_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,PredecessorControlArtifact) else v)
                           for k,v in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.items()})

def _predecessor_registry_chain_valid():
    by_prop={}
    for key,artifact in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.items():
        if key!=getattr(artifact,'artifact_id',None) or not validate_predecessor_control_artifact_record(artifact):return False
        rr=RETRIEVAL_SCOPE_REGISTRY.get(artifact.source_retrieval_scope_id)
        if (rr is None or rr.get('snapshot_id')!=artifact.source_snapshot_id
            or canonical_hash(rr)!=artifact.source_retrieval_scope_record_hash):return False
        by_prop.setdefault(artifact.canonical_proposition_id,[]).append(artifact)
    for canonical_proposition_id,items in by_prop.items():
        ordered=sorted(items,key=lambda a:a.sequence)
        if [a.sequence for a in ordered]!=list(range(1,len(ordered)+1)):return False
        if ordered[0].predecessor_artifact_id is not None:return False
        for prev,cur in zip(ordered,ordered[1:]):
            if cur.predecessor_artifact_id!=prev.artifact_id:return False
            protected=_protected_predecessor_transition(prev.positive_status,prev.negative_status,cur.positive_status,cur.negative_status)
            if protected is None:
                if cur.transition_certificate_id is not None:return False
            else:
                cert=PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.get(cur.transition_certificate_id)
                if cert is None or not validate_predecessor_transition_certificate(cert,cur):return False
        if ordered[0].transition_certificate_id is not None:return False
        if len({a.artifact_id for a in ordered})!=len(ordered):return False
    # No orphan or key-mismatched transition certificates.
    used={a.transition_certificate_id for a in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.values()
          if isinstance(a,PredecessorControlArtifact) and a.transition_certificate_id is not None}
    if set(PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY)!=used:return False
    for key,cert in PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.items():
        if key!=getattr(cert,'certificate_id',None) or not validate_predecessor_transition_certificate(cert):return False
    return True

def _latest_predecessor_artifact(canonical_proposition_id):
    if not _valid_canonical_proposition_id(canonical_proposition_id) or not _predecessor_registry_chain_valid():return None
    rows=[a for a in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.values()
          if isinstance(a,PredecessorControlArtifact) and a.canonical_proposition_id==canonical_proposition_id]
    return max(rows,key=lambda a:a.sequence) if rows else None

def _predecessor_runtime_authorized(artifact):
    if not isinstance(artifact,PredecessorControlArtifact) or _DECISION_REHYDRATION_ACTIVE:return False
    return _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS.get(artifact.artifact_id)==_predecessor_artifact_fingerprint(artifact)

def _authorize_fresh_predecessor_artifact(artifact):
    if isinstance(artifact,PredecessorControlArtifact) and not _DECISION_REHYDRATION_ACTIVE:
        _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS[artifact.artifact_id]=_predecessor_artifact_fingerprint(artifact)

def _core_transition_source_audit(claim_text,evidence,claim_identity_id,asof,scope,extract,retrieval_scope,req,waivers=None):
    cmap={'c1':claim_identity_id}
    try:
        bundle=prepare(claim_text,evidence,cmap,asof,scope,extract,retrieval_scope,req,waivers)
        out=audit_text(claim_text,evidence,cmap,asof,scope,extract,retrieval_scope,req,waivers,*bundle)
    except Exception:
        return None
    claims=out.get('claims',[]) if isinstance(out,dict) else []
    if len(claims)!=1:return None
    status=claims[0].get('status')
    if status not in {x.value for x in ClaimStatus}:return None
    return status,out

def issue_predecessor_control_artifact(binding,evidence,asof,scope,extract,retrieval_scope,req,
                                       waivers=None,current_question_text=None):
    if _DECISION_REHYDRATION_ACTIVE:return None
    if not validate_question_answer_binding(binding,current_question_text):return None
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope)
    if rr is None or not nonblank(rr.get('snapshot_id')):return None
    if not _predecessor_registry_chain_valid():return None
    basis=transition_epistemic_basis_hash(evidence,asof,scope,extract,retrieval_scope,req,binding.claim_identity_id,waivers)
    if basis is None:return None
    pos=_core_transition_source_audit(binding.positive_claim_text,evidence,binding.claim_identity_id,
                                      asof,scope,extract,retrieval_scope,req,waivers)
    neg=_core_transition_source_audit(binding.negative_claim_text,evidence,binding.claim_identity_id,
                                      asof,scope,extract,retrieval_scope,req,waivers)
    if pos is None or neg is None:return None
    pstatus,pout=pos;nstatus,nout=neg
    if pstatus==ClaimStatus.VERIFIED.value and nstatus==ClaimStatus.VERIFIED.value:return None
    # The source scope must remain exact throughout issuance.
    rr_now=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope)
    if rr_now is None or rr_now.get('snapshot_id')!=rr.get('snapshot_id') or canonical_hash(rr_now)!=canonical_hash(rr):return None
    canonical_id=recompute_binding_canonical_proposition_id(binding)
    if canonical_id is None or canonical_id!=binding.canonical_proposition_id:return None
    previous=_latest_predecessor_artifact(canonical_id)
    sequence=1 if previous is None else previous.sequence+1
    predecessor_id=None if previous is None else previous.artifact_id
    issuance_commitment=decision_persistence_history_commitment()
    positive_claim_text_hash=_transition_claim_text_hash(binding.positive_claim_text)
    negative_claim_text_hash=_transition_claim_text_hash(binding.negative_claim_text)
    source_scope_record_hash=canonical_hash(rr)
    positive_audit_fingerprint=canonical_hash(pout)
    negative_audit_fingerprint=canonical_hash(nout)
    candidate_pre_cert_commitment=_candidate_pre_certificate_commitment_from_values(
        binding.proposition_id,binding.claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,
        pstatus,nstatus,basis,retrieval_scope,rr['snapshot_id'],source_scope_record_hash,
        positive_audit_fingerprint,negative_audit_fingerprint,sequence,predecessor_id,issuance_commitment,canonical_id)
    transition_cert=None
    transition_kind=None if previous is None else _protected_predecessor_transition(previous.positive_status,previous.negative_status,pstatus,nstatus)
    if transition_kind is not None:
        transition_cert=_issue_predecessor_transition_certificate(
            previous,binding,pstatus,nstatus,basis,retrieval_scope,rr,asof,issuance_commitment,candidate_pre_cert_commitment)
        if transition_cert is None:return None
    transition_cert_id=None if transition_cert is None else transition_cert.certificate_id
    payload=_predecessor_artifact_payload(
        binding.proposition_id,binding.claim_identity_id,positive_claim_text_hash,negative_claim_text_hash,
        pstatus,nstatus,basis,retrieval_scope,rr['snapshot_id'],source_scope_record_hash,
        positive_audit_fingerprint,negative_audit_fingerprint,sequence,predecessor_id,issuance_commitment,
        canonical_id,transition_cert_id)
    artifact=PredecessorControlArtifact(_predecessor_artifact_id_from_payload(payload),binding.proposition_id,
        binding.claim_identity_id,payload['positive_claim_text_hash'],payload['negative_claim_text_hash'],pstatus,nstatus,
        basis,retrieval_scope,rr['snapshot_id'],payload['source_retrieval_scope_record_hash'],
        payload['positive_audit_fingerprint'],payload['negative_audit_fingerprint'],sequence,predecessor_id,issuance_commitment,
        canonical_id,transition_cert_id)
    if artifact.artifact_id in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY:
        if transition_cert_id is not None:PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.pop(transition_cert_id,None)
        return None
    PREDECESSOR_CONTROL_ARTIFACT_REGISTRY[artifact.artifact_id]=artifact
    if not _predecessor_registry_chain_valid():
        PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.pop(artifact.artifact_id,None)
        if transition_cert_id is not None:PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY.pop(transition_cert_id,None)
        return None
    _authorize_fresh_predecessor_artifact(artifact)
    return copy.deepcopy(artifact)

def prior_epistemic_state_from_artifact(artifact_id):
    artifact=PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.get(artifact_id)
    if not isinstance(artifact,PredecessorControlArtifact) or not _predecessor_runtime_authorized(artifact):return None
    latest=_latest_predecessor_artifact(artifact.canonical_proposition_id)
    if latest is None or latest.artifact_id!=artifact.artifact_id:return None
    fp=_predecessor_artifact_fingerprint(artifact)
    return make_prior_epistemic_state(artifact.proposition_id,artifact.positive_status,artifact.negative_status,
                                      artifact.epistemic_basis_hash,artifact.source_snapshot_id,
                                      artifact.artifact_id,fp,artifact.sequence,artifact.canonical_proposition_id)

def validate_authoritative_prior_epistemic_state(state,binding):
    if not validate_prior_epistemic_state(state) or not isinstance(binding,QuestionAnswerBinding):return False
    if not _binding_semantic_integrity_valid(binding):return False
    if _DECISION_REHYDRATION_ACTIVE:return False
    if not nonblank(state.source_artifact_id) or not _valid_hash64(state.source_artifact_fingerprint):return False
    if type(state.source_sequence) is not int or state.source_sequence<1:return False
    artifact=PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.get(state.source_artifact_id)
    if not isinstance(artifact,PredecessorControlArtifact) or not validate_predecessor_control_artifact_record(artifact):return False
    if not _predecessor_registry_chain_valid() or not _predecessor_runtime_authorized(artifact):return False
    latest=_latest_predecessor_artifact(state.canonical_proposition_id)
    if latest is None or latest.artifact_id!=artifact.artifact_id:return False
    canonical_id=recompute_binding_canonical_proposition_id(binding)
    if (canonical_id is None or canonical_id!=binding.canonical_proposition_id
        or state.canonical_proposition_id!=artifact.canonical_proposition_id
        or binding.canonical_proposition_id!=artifact.canonical_proposition_id):return False
    # Caller proposition labels are diagnostic metadata only. Identity registry aliases may differ
    # if they resolve to the same canonical claim identity; the canonical id is authoritative.
    if (_transition_claim_text_hash(binding.positive_claim_text)!=artifact.positive_claim_text_hash
        or _transition_claim_text_hash(binding.negative_claim_text)!=artifact.negative_claim_text_hash):return False
    if (state.positive_status!=artifact.positive_status or state.negative_status!=artifact.negative_status
        or state.epistemic_basis_hash!=artifact.epistemic_basis_hash or state.source_snapshot_id!=artifact.source_snapshot_id
        or state.source_sequence!=artifact.sequence):return False
    if state.source_artifact_fingerprint!=_predecessor_artifact_fingerprint(artifact):return False
    rr=RETRIEVAL_SCOPE_REGISTRY.get(artifact.source_retrieval_scope_id)
    if (rr is None or rr.get('snapshot_id')!=artifact.source_snapshot_id
        or canonical_hash(rr)!=artifact.source_retrieval_scope_record_hash):return False
    if state.positive_status==ClaimStatus.VERIFIED.value and state.negative_status==ClaimStatus.VERIFIED.value:return False
    return True

def _transition_result(prior,binding,normalized,bound_polarity,bound_claim_text,current_basis,
                       core_status,core_closure,decision,reason):
    payload={'prior_state_id':getattr(prior,'state_id','INVALID'),
             'binding_id':getattr(binding,'binding_id','INVALID'),'normalized_answer_token':normalized or '',
             'bound_polarity':bound_polarity,'bound_claim_text':bound_claim_text,
             'prior_epistemic_basis_hash':getattr(prior,'epistemic_basis_hash',''),
             'current_epistemic_basis_hash':current_basis,'core_claim_status':core_status,
             'core_control_closure':bool(core_closure),'transition_decision':decision,'reason':reason}
    return TransitionAuditResult('transition:'+sha(payload)[:24],payload['prior_state_id'],payload['binding_id'],
                                 payload['normalized_answer_token'],bound_polarity,bound_claim_text,
                                 payload['prior_epistemic_basis_hash'],current_basis,core_status,bool(core_closure),
                                 decision,reason)

def audit_answer_transition(prior_state,binding,answer_token,evidence,asof,scope,extract,retrieval_scope,req,
                            waivers=None,current_question_text=None):
    # current_question_text is required so a stale binding cannot be replayed against a changed question.
    normalized=_transition_token_key(answer_token)
    if not validate_authoritative_prior_epistemic_state(prior_state,binding):
        return _transition_result(prior_state,binding,normalized,'UNBOUND',None,None,None,False,'BLOCK','INVALID_OR_UNAUTHORIZED_PRIOR_STATE')
    if prior_state.canonical_proposition_id!=getattr(binding,'canonical_proposition_id',None):
        return _transition_result(prior_state,binding,normalized,'UNBOUND',None,None,None,False,'BLOCK','CANONICAL_PROPOSITION_BINDING_MISMATCH')
    if not validate_question_answer_binding(binding,current_question_text):
        return _transition_result(prior_state,binding,normalized,'UNBOUND',None,None,None,False,'BLOCK','INVALID_OR_STALE_QUESTION_BINDING')
    current_basis=transition_epistemic_basis_hash(evidence,asof,scope,extract,retrieval_scope,req,binding.claim_identity_id,waivers)
    if current_basis is None:
        return _transition_result(prior_state,binding,normalized,'UNBOUND',None,None,None,False,'BLOCK','CURRENT_EPISTEMIC_BASIS_UNAVAILABLE')
    if normalized in _TRANSITION_ABSTAIN_TOKENS:
        return _transition_result(prior_state,binding,normalized,'ABSTAIN',None,current_basis,None,False,
                                  'PRESERVE_UNRESOLVED','EXPLICIT_ABSTENTION_HAS_NO_CATEGORICAL_EPISTEMIC_AUTHORITY')
    y=_transition_token_key(binding.yes_token);n=_transition_token_key(binding.no_token)
    if normalized==y:
        polarity='POSITIVE';claim_text=binding.positive_claim_text
    elif normalized==n:
        polarity='NEGATIVE';claim_text=binding.negative_claim_text
    else:
        return _transition_result(prior_state,binding,normalized,'UNBOUND',None,current_basis,None,False,'BLOCK','ANSWER_TOKEN_NOT_EXPLICITLY_BOUND')
    # Reversal of a previously VERIFIED side needs ordinary update/rollback proof outside this thin wrapper.
    if ((polarity=='NEGATIVE' and prior_state.positive_status==ClaimStatus.VERIFIED.value)
        or (polarity=='POSITIVE' and prior_state.negative_status==ClaimStatus.VERIFIED.value)):
        return _transition_result(prior_state,binding,normalized,polarity,claim_text,current_basis,None,False,'BLOCK',
                                  'VERIFIED_REVERSAL_REQUIRES_EXTERNAL_UPDATE_AND_ROLLBACK_PROOF')
    cmap={'c1':binding.claim_identity_id}
    try:
        bundle=prepare(claim_text,evidence,cmap,asof,scope,extract,retrieval_scope,req,waivers)
        out=audit_text(claim_text,evidence,cmap,asof,scope,extract,retrieval_scope,req,waivers,*bundle)
    except Exception:
        return _transition_result(prior_state,binding,normalized,polarity,claim_text,current_basis,None,False,'BLOCK','CORE_AUDIT_FAILED_CLOSED')
    claims=out.get('claims',[]) if isinstance(out,dict) else []
    core_status=claims[0].get('status') if len(claims)==1 else None
    core_closure=bool(out.get('control_closure')) if isinstance(out,dict) else False
    if core_status==ClaimStatus.VERIFIED.value and core_closure:
        return _transition_result(prior_state,binding,normalized,polarity,claim_text,current_basis,core_status,True,'ALLOW',
                                  'BOUND_ASSERTION_INDEPENDENTLY_VERIFIED_BY_CORE')
    return _transition_result(prior_state,binding,normalized,polarity,claim_text,current_basis,core_status,core_closure,'BLOCK',
                              'BOUND_ASSERTION_NOT_INDEPENDENTLY_VERIFIED_BY_CORE')


# ============================================================
# Controller-owned registries / profiles (local fixtures)
# ============================================================

IDENTITY_REGISTRY={
    'id:alice:v1':{'surface_subject':'Alice','domain_id':'GENERAL_ENTITY','entity_id':'entity:alice','event_id':'event:current','version_id':'v1'},
    'id:bob:v1':{'surface_subject':'Bob','domain_id':'GENERAL_ENTITY','entity_id':'entity:bob','event_id':'event:current','version_id':'v1'},
    'id:door:v1':{'surface_subject':'Door','domain_id':'GENERAL_ENTITY','entity_id':'entity:door','event_id':'event:current','version_id':'v1'},
    'id:flight:v1':{'surface_subject':'flight','domain_id':'FLIGHT','entity_id':'entity:flight:001','event_id':'event:flight:001','version_id':'v1'},
    'id:registry:ABC123:v1':{'surface_subject':'ID:ABC123','domain_id':'REGISTRY_ENTITY','entity_id':'entity:ABC123','event_id':'event:current','version_id':'v1'},
    'id:registry:XYZ999:v1':{'surface_subject':'ID:XYZ999','domain_id':'REGISTRY_ENTITY','entity_id':'entity:XYZ999','event_id':'event:current','version_id':'v1'},
    "id:oconnor:v1":{'surface_subject':"O'Connor",'domain_id':'GENERAL_ENTITY','entity_id':'entity:oconnor','event_id':'event:current','version_id':'v1'},
}

PREDICATE_SCHEMA={
    'date':{'cardinality':'ONE','coverage':'COMPLETE'},
    'location':{'cardinality':'ONE','coverage':'COMPLETE'},
    'state':{'cardinality':'MANY','coverage':'PARTIAL'},
}
STATE_RELATIONS={
    frozenset(('alive','dead')):'CONFLICT', frozenset(('safe','unsafe')):'CONFLICT',
    frozenset(('open','closed')):'CONFLICT', frozenset(('enabled','disabled')):'CONFLICT',
    frozenset(('active','inactive')):'CONFLICT', frozenset(('locked','unlocked')):'CONFLICT',
}
AUTHORITY_POLICIES={
    'FLIGHT_RECORD_V5':{'predicates':{'date'},'domains':{'FLIGHT'},'source_prefix':'flight-registry:','root_prefix':'flight-registry:'},
    'GENERAL_RECORD_V5':{'predicates':{'state','location'},'domains':{'GENERAL_ENTITY'},'source_prefix':'general-record:','root_prefix':'general-record:'},
    'REGISTRY_RECORD_V5':{'predicates':{'state','location','date'},'domains':{'REGISTRY_ENTITY'},'source_prefix':'registry:','root_prefix':'registry:'},
}

DEPENDENCY_DIMENSIONS=('data_source','sensor_input','transform','model','extractor','cache','upstream_db','operator','preprocessing','runtime')
DEPENDENCY_PREFIX={
    'data_source':'data','sensor_input':'sensor','transform':'transform','model':'model','extractor':'extractor',
    'cache':'cache','upstream_db':'db','operator':'operator','preprocessing':'prep','runtime':'runtime',
}
DEPENDENCY_STATES={'KNOWN','KNOWN_NONE','NOT_APPLICABLE','UNKNOWN','UNRESOLVED'}
DEPENDENCY_JUSTIFICATION_REGISTRY={}

def _register_fixture_dependency_justification(justification_id:str, dimension:str, state:str, reason:str,
                                               authority_id:str='LOCAL_DEPENDENCY_AUTHORITY',
                                               scope_id:str='dependency-policy:v0.2.20',
                                               rule_id:str='rule:local-default',
                                               source_id:str='justification-source:local',
                                               validator_id:str='validator:local'):
    DEPENDENCY_JUSTIFICATION_REGISTRY[justification_id]={
        'dimension':dimension,'state':state,'reason':reason,
        'authority_id':authority_id,'scope_id':scope_id,'rule_id':rule_id,
        'source_id':source_id,'validator_id':validator_id
    }

PROVENANCE_POLICY={
    'algorithm':'TYPED_JUSTIFICATION_PROVENANCE_CLOSURE_V7',
    'required_dimensions':DEPENDENCY_DIMENSIONS,
    'blocking_states':{'UNKNOWN','UNRESOLVED'},
    'justification_required_states':{'KNOWN_NONE','NOT_APPLICABLE'},
    # Typed and scope-limited: only an actual runtime dependency gets this exception.
    'allowed_shared_nodes':{('DEPENDENCY','runtime','trusted-shared-runtime')},
}

# v0.2.20: source identity, failure-domain resolution and independence are distinct.
# UNKNOWN/UNRESOLVED semantics never count as evidence of distinctness.
PINNED_SOURCE_SEMANTICS_POLICY={
    'policy_id':'SOURCE_SEMANTICS_POLICY_V2',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'SOURCE_SEMANTICS_RESOLUTION_V2',
    'allowed_resolution_states':('KNOWN','UNKNOWN','UNRESOLVED'),
    'resolved_state':'KNOWN',
    'default_profile_resolution_state':'UNRESOLVED',
    'default_profile_can_prove_independence':False,
    'require_resolution_certificate_for_independence':True,
    'canonicalize_failure_domain_aliases':True,
    'include_failure_domain_ancestors':True,
    'set_level_common_mode_required':True,
    'allowed_semantics_authorities':('LOCAL_SOURCE_SEMANTICS_AUTHORITY',),
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
SOURCE_SEMANTICS_POLICY=dict(PINNED_SOURCE_SEMANTICS_POLICY)

PINNED_SOURCE_INDEPENDENCE_POLICY={
    'policy_id':'SOURCE_INDEPENDENCE_POLICY_V3',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'SOURCE_FAILURE_DOMAIN_RELATION_CERTIFICATE_KEY_BINDING_V3',
    'default_profile_mode':'SYNTHETIC_UNRESOLVED_PLACEHOLDER',
    'hard_block_shared_failure_domain':True,
    'certificate_required_shared_dimensions':('SOURCE','SOURCE_REPOSITORY','SOURCE_PRODUCER','SOURCE_PROCESS'),
    'relation_states':('SOURCE_SHARED_DEPENDENCY','SOURCE_INDEPENDENCE_JUSTIFIED','SOURCE_INDEPENDENCE_DISTINCT','SOURCE_RELATION_UNRESOLVED'),
    'allowed_authorizers':('LOCAL_SOURCE_INDEPENDENCE_AUTHORITY',),
    'allowed_semantics_authorities':('LOCAL_SOURCE_SEMANTICS_AUTHORITY',),
    'require_resolution_certificate_for_distinct':True,
    'require_set_level_independence_certificate':True,
    'certificate_registry_key_identity_binding_required':True,
    'certificate_registry_state_bound_to_audit_context':True,
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
SOURCE_INDEPENDENCE_POLICY=dict(PINNED_SOURCE_INDEPENDENCE_POLICY)

# v0.2.21: matching-support universe and explicit subset-selection policy.
# Central invariant: selection does not delete evidence relations.
SUPPORT_EXCLUSION_CLASSES=(
    'EXCLUDED_REDUNDANT','EXCLUDED_DEPENDENT','EXCLUDED_CONTRADICTORY',
    'EXCLUDED_NOT_NEEDED','EXCLUDED_UNRESOLVED',
)
SUPPORT_RELATION_RESOLUTIONS=(
    'REDUNDANT_RELATION_ACCOUNTED','DEPENDENCY_ACCOUNTED_NOT_COUNTED',
    'CONTRADICTION_RESOLVED','EXCLUDED_RELATION_DECISION_IRRELEVANT',
)
PINNED_SUPPORT_UNIVERSE_POLICY={
    'policy_id':'SUPPORT_UNIVERSE_POLICY_V6',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'MATCHING_SUPPORT_UNIVERSE_SELECTION_DECISION_GRAPH_RELATION_CLOSURE_V6',
    'universe_before_selection':True,
    'selection_does_not_delete_evidence_relations':True,
    'selected_classification':'SELECTED_JUSTIFICATORY',
    'allowed_exclusion_classes':SUPPORT_EXCLUSION_CLASSES,
    'blocking_exclusion_classes':('EXCLUDED_UNRESOLVED',),
    'allowed_relation_resolutions':SUPPORT_RELATION_RESOLUTIONS,
    'full_universe_auto_selection_allowed':True,
    'proper_subset_requires_explicit_selection':True,
    'exact_universe_binding_required':True,
    'claim_context_scope_snapshot_binding_required':True,
    'permutation_invariant_selection_required':True,
    'selected_selected_relation_coverage_required':True,
    'selected_excluded_relation_coverage_required':True,
    'decision_relevant_excluded_excluded_relation_coverage_required':True,
    'excluded_excluded_relation_relevance_rule':'EFFECT_SOURCE_AND_GENERIC_DEPENDENCY_PATH_CLOSURE',
    'generic_dependency_selected_support_path_closure_required':True,
    'generic_dependency_path_through_excluded_supports_preserved':True,
    'source_failure_domain_dependency_graph_required':True,
    'source_dependency_path_through_excluded_supports_preserved':True,
    'pair_summary_not_complete_semantic_state':True,
    'orthogonal_dependency_channels_preserved':True,
    'source_dependency_relevance_uses_source_state_independently':True,
    'excluded_redundant_disposition_closed_under_source_dependency_paths':True,
    'source_dependency_resolution_type':'DEPENDENCY_ACCOUNTED_NOT_COUNTED',
    'decision_level_dependency_graph_required':True,
    'cross_claim_justificatory_paths_preserved':True,
    'decision_dependency_accounting_exact_context_binding_required':True,
    'decision_dependency_accounting_resolution_type':'DEPENDENCY_ACCOUNTED_NOT_COUNTED',
    'decision_level_relation_discovery_required':True,
    'decision_level_relation_resolution_exact_binding_required':True,
    'unresolved_relation_fail_closed':True,
    'allowed_authorizers':('LOCAL_SUPPORT_UNIVERSE_AUTHORITY',),
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
SUPPORT_UNIVERSE_POLICY=dict(PINNED_SUPPORT_UNIVERSE_POLICY)

# v0.2.38: equivalence authority is context-applicable before it can affect semantic identity.
PINNED_RELATION_DISCOVERY_POLICY={
    'policy_id':'RELATION_DISCOVERY_POLICY_V4',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'OWNERSHIP_EFFECT_FIRST_DECISION_RELATION_DISCOVERY_V4',
    'matching_support_universe_is_not_relation_neighborhood':True,
    'discovery_precedes_decision_relevance_filtering':True,
    'one_selected_endpoint_can_trigger_discovery':True,
    'preserve_legacy_multi_matching_endpoint_discovery':True,
    'all_endpoints_must_be_in_retrieval_snapshot':True,
    'out_of_snapshot_relation_fail_closed':True,
    'exact_relation_id_set_binding_required':True,
    'exact_relation_instance_records_binding_required':True,
    'decision_level_discovery_over_composed_nodes':True,
    'decision_level_pair_and_nway_preserved':True,
    'decision_level_cross_claim_scope_supported':True,
    'decision_node_membership_is_not_complete_endpoint_ownership':True,
    'decision_endpoint_ownership_from_all_modeled_matching_universes':True,
    'local_scope_sufficiency_uses_complete_endpoint_ownership':True,
    'snapshot_only_endpoint_status_explicit':True,
    'complete_endpoint_ownership_before_graph_anchor_filtering':True,
    'cross_claim_modeled_endpoints_without_graph_anchor_require_decision_scope':True,
    'excluded_not_needed_preserves_cross_claim_relations':True,
    'relation_effect_and_ownership_precede_graph_membership':True,
    'decision_relation_universe_binds_evaluated_relation_rows':True,
    'allowed_relation_types':('COMMON_MODE','UNKNOWN'),
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
RELATION_DISCOVERY_POLICY=dict(PINNED_RELATION_DISCOVERY_POLICY)

# v0.2.22: relation identity and resolution are relation-instance-specific.
RELATION_EFFECTS=(
    'REDUNDANCY_ONLY','RELIABILITY_DEGRADING','SELECTED_SUPPORT_INVALIDATING',
    'CONTRADICTORY','NON_DECISION_RELEVANT','UNKNOWN',
)
RELATION_RESOLUTION_TYPES=(
    'REDUNDANT_RELATION_ACCOUNTED','RELIABILITY_DEGRADATION_RESOLVED',
    'CONTRADICTION_RESOLVED','NON_DECISION_RELEVANT_AUTHORIZED',
)
RELATION_EFFECT_RESOLUTION_COMPATIBILITY={
    'REDUNDANCY_ONLY':('REDUNDANT_RELATION_ACCOUNTED',),
    'RELIABILITY_DEGRADING':('RELIABILITY_DEGRADATION_RESOLVED',),
    'SELECTED_SUPPORT_INVALIDATING':tuple(),
    'CONTRADICTORY':('CONTRADICTION_RESOLVED',),
    'NON_DECISION_RELEVANT':('NON_DECISION_RELEVANT_AUTHORIZED',),
    'UNKNOWN':tuple(),
}
PINNED_RELATION_RESOLUTION_POLICY={
    'policy_id':'RELATION_RESOLUTION_POLICY_V3',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'RELATION_INSTANCE_RESOLUTION_KEY_IDENTITY_COVERAGE_V3',
    'relation_identity':'STABLE_RELATION_ID',
    'resolution_is_relation_specific_not_pair_generic':True,
    'one_resolution_per_relation_instance':True,
    'exact_endpoint_set_binding_required':True,
    'claim_context_scope_snapshot_binding_required':True,
    'exact_universe_binding_required':True,
    'exact_selected_subset_binding_required':True,
    'authorization_declaration_scope_must_cover_certificate_scope':True,
    'certificate_binding_cannot_repair_underbound_authorization_source':True,
    'non_decision_relevant_authorization_is_audit_context_specific':True,
    'issuance_must_not_add_unauthorized_epistemic_scope':True,
    'explicit_context_binding_step_required_for_pre_context_declarations':True,
    'registry_key_identity_binding_required':True,
    'support_selection_registry_typed_key_identity_binding_required':True,
    'registry_incoherence_fails_closed_globally':True,
    'relation_effects':RELATION_EFFECTS,
    'allowed_resolution_types':RELATION_RESOLUTION_TYPES,
    'effect_resolution_compatibility':RELATION_EFFECT_RESOLUTION_COMPATIBILITY,
    'unknown_fail_closed':True,
    'selected_support_invalidating_fail_closed':True,
    'redundant_exclusion_requires_disposition_certificate':True,
    'free_text_is_not_semantic_authority':True,
    'allowed_resolution_authorizers':('LOCAL_RELATION_RESOLUTION_AUTHORITY',),
    'allowed_disposition_authorizers':('LOCAL_EXCLUSION_DISPOSITION_AUTHORITY',),
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
RELATION_RESOLUTION_POLICY=dict(PINNED_RELATION_RESOLUTION_POLICY)

# v0.2.25: required handling is evaluated separately from final decision relevance.
# Central invariants:
#   NON_DECISION_RELEVANT LABEL != NONBLOCKING AUTHORIZATION
#   AUTHORIZATION PRECEDES NONBLOCKING STATUS
#   ENDPOINT DISPOSITION MUST NOT BYPASS REQUIRED AUTHORIZATION
#   RELEVANCE CLASSIFICATION != RESOLUTION-REQUIREMENT PREDICATE
PINNED_RELATION_DECISION_RELEVANCE_POLICY={
    'policy_id':'RELATION_DECISION_RELEVANCE_POLICY_V2',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'EFFECT_FIRST_REQUIRED_HANDLING_V2',
    'discovery_precedes_relevance_filtering':True,
    'relation_effect_precedes_endpoint_disposition':True,
    'excluded_support_not_epistemically_irrelevant':True,
    'endpoint_scope_cannot_erase_typed_blocking_effect':True,
    'authorization_precedes_nonblocking_status':True,
    'endpoint_disposition_cannot_bypass_required_handling':True,
    'relevance_classification_distinct_from_resolution_requirement':True,
    'implemented_handling_must_match_pinned_effect_policy':True,
    'always_decision_relevant_effects':(
        'RELIABILITY_DEGRADING','SELECTED_SUPPORT_INVALIDATING','CONTRADICTORY','UNKNOWN'
    ),
    'endpoint_scope_dependent_effects':('REDUNDANCY_ONLY','NON_DECISION_RELEVANT'),
    'effect_required_handling':{
        'REDUNDANCY_ONLY':'ENDPOINT_SCOPE',
        'RELIABILITY_DEGRADING':'RESOLUTION_REQUIRED',
        'SELECTED_SUPPORT_INVALIDATING':'FAIL_CLOSED',
        'CONTRADICTORY':'RESOLUTION_REQUIRED',
        'NON_DECISION_RELEVANT':'AUTHORIZATION_REQUIRED',
        'UNKNOWN':'FAIL_CLOSED',
    },
    'non_decision_relevant_requires_authorization':True,
    'non_decision_relevant_required_resolution_type':'NON_DECISION_RELEVANT_AUTHORIZED',
    'reliability_degrading_requires_resolution_all_endpoint_scopes':True,
    'selected_support_invalidating_fail_closed_all_endpoint_scopes':True,
    'unknown_fail_closed_all_endpoint_scopes':True,
    'contradictory_requires_resolution_all_endpoint_scopes':True,
    'redundancy_only_all_excluded_can_be_nonblocking':True,
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
RELATION_DECISION_RELEVANCE_POLICY=dict(PINNED_RELATION_DECISION_RELEVANCE_POLICY)

# Authoritative pre-prepare declarations and context-bound derived artifacts.
SUPPORT_SELECTION_REGISTRY={}
MATCHING_SUPPORT_UNIVERSE_REGISTRY={}
DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY={}
SUPPORT_SELECTION_CERTIFICATE_REGISTRY={}
CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY={}
RELATION_RESOLUTION_REGISTRY={}
RELATION_RESOLUTION_CERTIFICATE_REGISTRY={}
EXCLUDED_SUPPORT_DISPOSITION_REGISTRY={}
EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY={}

SOURCE_SEMANTICS_REGISTRY={}
SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY={}

# R197 / v0.2.78: assertion-level epistemic role is orthogonal to source provenance.
# R200 / v0.2.79: role integrity is separated from controller-owned issuer authority and runtime continuity.
PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY={
    'policy_id':'EVIDENCE_EPISTEMIC_ROLE_POLICY_V1',
    'allowed_roles':('DIRECT_WORLD_RECORD','EXTERNAL_DIAGNOSIS','SELF_REPORT','OBSERVED_OUTPUT','DERIVED_INFERENCE','ROLE_UNRESOLVED'),
    'direct_world_state_eligible_roles':('DIRECT_WORLD_RECORD','EXTERNAL_DIAGNOSIS'),
    'allowed_role_authorities':('LOCAL_EPISTEMIC_ROLE_AUTHORITY',),
    'resolved_state':'RESOLVED',
    'role_label_not_authority':True,
    'external_storage_does_not_upgrade_role':True,
    'source_provenance_distinct_from_epistemic_role':True,
}
EVIDENCE_EPISTEMIC_ROLE_POLICY=copy.deepcopy(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY)

PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY={
    'policy_id':'EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY_V1',
    'grants':(
        ('grant:direct-world-record:v1','CONTROLLER_DIRECT_WORLD_RECORD_ISSUER',('DIRECT_WORLD_RECORD',)),
        ('grant:external-diagnosis:v1','CONTROLLER_EXTERNAL_DIAGNOSIS_ISSUER',('EXTERNAL_DIAGNOSIS',)),
        ('grant:self-report:v1','CONTROLLER_SELF_REPORT_CLASSIFIER',('SELF_REPORT',)),
        ('grant:observed-output:v1','CONTROLLER_OBSERVED_OUTPUT_CLASSIFIER',('OBSERVED_OUTPUT',)),
        ('grant:derived-inference:v1','CONTROLLER_DERIVED_INFERENCE_CLASSIFIER',('DERIVED_INFERENCE',)),
        ('grant:role-unresolved:v1','CONTROLLER_ROLE_UNRESOLVED_CLASSIFIER',('ROLE_UNRESOLVED',)),
    ),
    'grant_scope':'EXACT_VALIDATED_EVIDENCE_CONTEXT',
    'caller_role_label_not_authority':True,
    'caller_authority_string_not_issuer_proof':True,
}
EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY=copy.deepcopy(PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY)

EVIDENCE_EPISTEMIC_ROLE_REGISTRY={}
EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY={}
EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY={}
EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY={}
# R203 / v0.2.80: one exact evidence/assertion/origin -> one authoritative role artifact.
EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX={}
# R206 / v0.2.81: one production evidence_id -> one immutable evidence identity.
EVIDENCE_ID_IDENTITY_REGISTRY={}
# R236 / v0.2.88: one controller-owned append-only ancestry chain for every production trusted-role issuance.
TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION='TRUSTED_ROLE_ISSUANCE_ANCESTRY_V1'
TRUSTED_ROLE_ISSUANCE_GENESIS_HEAD=canonical_hash({
    'ancestry_version':TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION,
    'genesis':'CONTROLLER_DEFINED_TRUSTED_ROLE_ISSUANCE_GENESIS',
})
TRUSTED_ROLE_ISSUANCE_CHAIN={}
TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD=TRUSTED_ROLE_ISSUANCE_GENESIS_HEAD
_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS={}
_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS={}
_EVIDENCE_ROLE_ISSUER_CAPABILITY=object()
_SELF_TEST_ROLE_ISSUER_CAPABILITY=object()
_SELF_TEST_ROLE_AUTHORITY_ACTIVE=False
_SELF_TEST_FIXTURE_ROLE_AUTOREBIND=False
# R206: self-test role authority is isolated from production history/persistence.
# R209: fixture authority is additionally bound to one explicit self-test scope generation.
_SELF_TEST_SCOPE_GENERATION_ID=None
_SELF_TEST_SCOPE_GENERATION_COUNTER=0
_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY={}
_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY={}
_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY={}
_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY={}
_SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX={}
_SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY={}
_SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS={}
_SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS={}
_SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS={}
_SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS={}

FAILURE_DOMAIN_ALIAS_REGISTRY={}
FAILURE_DOMAIN_PARENT_REGISTRY={}
SUPPORT_SET_COMMON_MODE_REGISTRY={}
SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY={}
SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY={}
SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY={}

# R181 / v0.2.74: append-only controller-owned predecessor control history.
# R185 / v0.2.75: protected predecessor transitions require independently bound transition authority.
PREDECESSOR_CONTROL_ARTIFACT_REGISTRY={}
PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY={}
_PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS={}

# v0.2.39: typed equivalence, explicit distinctness, and decision-level completeness are separate layers.
GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY={}
GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY={}
GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY={}
GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY={}
GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY={}
_DECISION_GENERIC_REPRESENTATION_COMPLETENESS_STATE_CACHE={}

# v0.2.65: persistence/rehydration anti-rollback binding for serialized decision rows.
# A current registry hash alone cannot distinguish a legal exact replay of A from a rollback
# that omitted later append-only history B. Rehydrated decision rows therefore require an
# independently persisted deterministic history commitment before they can be authoritative.
PERSISTENCE_HISTORY_COMMITMENT_VERSION='DECISION_PERSISTENCE_HISTORY_V6'
_DECISION_ROW_RUNTIME_AUTHORIZED_IDS=set()
_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS={}
_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS={}
_DECISION_REHYDRATION_ACTIVE=False
_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT=None
_DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT=None

SOURCE_SEMANTIC_NODE_TYPES=('SOURCE','SOURCE_REPOSITORY','SOURCE_PRODUCER','SOURCE_PROCESS','FAILURE_DOMAIN','FAILURE_DOMAIN_ANCESTOR','SOURCE_COMMON_MODE')
DEPENDENCY_NODE_TYPES=('DEPENDENCY','LINEAGE','COMMON_MODE','EXTRACTOR','JUSTIFICATION','DEPENDENCY_STATE',*SOURCE_SEMANTIC_NODE_TYPES)

# v0.2.38: raw representation remains auditable, while only context-ACTIVE typed equivalence
# records may affect semantic resolution. Inactive declarations remain visible but never canonicalize.
PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY={
    'policy_id':'GENERIC_RELATION_SOURCE_IDENTITY_POLICY_V4',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'algorithm':'COMPLETE_PAIR_COVERAGE_DESCRIPTOR_CONTEXTUAL_EQUIVALENCE_V5',
    'authorized_representation_mappings':(
        ('DEPENDENCY','extractor','DEPENDENCY','extractor'),
        ('EXTRACTOR','extractor','DEPENDENCY','extractor'),
    ),
    'authorization_required_representation_pairs':(
        ('LINEAGE','','DEPENDENCY','upstream_db','DEPENDENCY','upstream_db','CANONICAL_DEPENDENCY_LOCAL_ID'),
        ('COMMON_MODE','','DEPENDENCY','upstream_db','DEPENDENCY','upstream_db','CANONICAL_DEPENDENCY_LOCAL_ID'),
        ('LINEAGE','','COMMON_MODE','','DEPENDENCY','upstream_db','CANONICAL_DEPENDENCY_LOCAL_ID'),
    ),
    'allowed_equivalence_authorizers':('LOCAL_GENERIC_EQUIVALENCE_AUTHORITY',),
    'allowed_identifier_semantics':('EXACT_ID_EQUALITY','CANONICAL_DEPENDENCY_LOCAL_ID'),
    'raw_representation_must_remain_auditable':True,
    'canonicalize_before_independence':True,
    'canonicalize_before_decision_generic_universe':True,
    'canonical_nway_identity_required':True,
    'allowed_shared_applies_after_canonicalization':True,
    'foreign_namespace_merge_forbidden':True,
    'unknown_declared_equivalence_fail_closed':True,
    'transitive_equivalence_requires_consistent_semantic_class':True,
    'conflicting_equivalence_records_fail_closed':True,
    'equivalence_registry_and_certificates_hash_bound':True,
    'structural_validity_distinct_from_certificate_validity':True,
    'contextual_applicability_required':True,
    'contextual_semantic_resolution_required':True,
    'active_equivalence_requires_date_and_scope_match':True,
    'inactive_equivalence_auditable_not_canonicalized':True,
    'conflict_detection_active_context_only':True,
    'transitive_equivalence_same_context_only':True,
    'contextual_resolution_hash_bound':True,
    'complete_raw_representation_inventory_required':True,
    'candidate_discovery_not_limited_to_authority_allowlist':True,
    'ontology_prefix_match_creates_candidate_not_merge':True,
    'missing_equivalence_declaration_not_distinctness_proof':True,
    'proven_distinct_requires_exact_context_certificate':True,
    'decision_candidate_disposition_complete_required':True,
    'cross_channel_discovery_does_not_authorize_generic_equivalence':True,
    'complete_candidate_universe_hash_bound':True,
    'candidate_semantic_descriptor_layer_required':True,
    'complete_cross_representation_pair_coverage_required':True,
    'noncandidate_requires_typed_controller_basis':True,
    'empty_candidate_universe_requires_complete_pair_coverage':True,
    'not_a_candidate_distinct_from_proven_distinct':True,
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
GENERIC_RELATION_SOURCE_IDENTITY_POLICY=dict(PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY)

# The top-level evidence `source` field is a display locator in this local prototype, not a
# second source-identity channel.  Ambiguous non-display values fail admission instead of being
# silently ignored next to provenance.source_id.
PINNED_EVIDENCE_SOURCE_FIELD_POLICY={
    'policy_id':'EVIDENCE_SOURCE_FIELD_POLICY_V1',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'semantic_role':'DISPLAY_LOCATOR_NON_IDENTITY',
    'required_prefix':'display:',
    'non_identity_field_must_be_unambiguous':True,
    'provenance_source_id_is_authoritative_source_identity':True,
    'valid_from':'2000-01-01','valid_to':'2099-12-31',
}
EVIDENCE_SOURCE_FIELD_POLICY=dict(PINNED_EVIDENCE_SOURCE_FIELD_POLICY)

PINNED_DEPENDENCY_ONTOLOGY_SPEC={
    'ontology_id':'DEPENDENCY_ONTOLOGY_V5',
    'closure_class':'EPISTEMIC_FACT_AUDIT_V10',
    'required_dimensions':DEPENDENCY_DIMENSIONS,
    'dimension_prefixes':dict(DEPENDENCY_PREFIX),
    'node_types':DEPENDENCY_NODE_TYPES,
    'allowed_shared_nodes':tuple(sorted(PROVENANCE_POLICY['allowed_shared_nodes'])),
    'generic_relation_source_identity_policy_hash':canonical_hash(PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY),
    'evidence_source_field_policy_hash':canonical_hash(PINNED_EVIDENCE_SOURCE_FIELD_POLICY),
    'valid_from':'2000-01-01','valid_to':'2099-12-31'
}

TEMPORAL_PROFILE={'profile':'VALID_OBSERVED_AVAILABLE_ASOF_V3'}
CANONICAL_SCOPE='all decision-relevant factual claims in current input'
CANONICAL_EXTRACTION='deterministic extraction of all supported claim forms from current input and complete evidence records'
CONTROL_PROFILE={'profile':'BINDING_PLUS_ADEQUACY_V6','scope':CANONICAL_SCOPE,'extraction':CANONICAL_EXTRACTION}

# Controller-owned local retrieval snapshot registry. v0.2.19 preserves applicability/freshness metadata.
RETRIEVAL_SCOPE_REGISTRY={}

def _evidence_epistemic_weight_projection(record):
    if not isinstance(record,dict):return record
    # Assertion-role metadata controls admissibility but is not evidence for the asserted proposition.
    # Keep it out of evidence-weight/snapshot content commitments; its own controller registry and
    # certificate are separately integrity-bound and persistence-protected.
    return {k:v for k,v in record.items() if k!='epistemic_role_record_id'}

def evidence_record_hash(record:Dict[str,Any])->str:
    return sha(_evidence_epistemic_weight_projection(record))

def _record_scope_summary(records):
    entities=set(); events=set(); versions=set(); predicates=set()
    for r in records:
        rid=r.get('identity_registry_entry_id')
        ir=IDENTITY_REGISTRY.get(rid)
        if ir is not None:
            entities.add(ir['entity_id']);events.add(ir['event_id']);versions.add(ir['version_id'])
        if nonblank(r.get('predicate')): predicates.add(pkey(r['predicate']))
    return (tuple(sorted(entities)),tuple(sorted(events)),tuple(sorted(versions)),tuple(sorted(predicates)))

def canonical_retrieval_universe_id(semantic_scope,entities,events,versions,predicates):
    payload={'semantic_scope':semantic_scope,'entity_ids':tuple(entities),'event_ids':tuple(events),
             'version_ids':tuple(versions),'predicates':tuple(predicates)}
    return 'retrieval-universe:'+sha(payload)[:24]

def _register_fixture_retrieval_scope(scope_id:str, expected_records:List[Any], snapshot_id:str,
                                       applicability_group_id:Optional[str]=None,
                                       semantic_scope:str=CANONICAL_SCOPE,
                                       snapshot_created_at:str='2000-01-01',
                                       snapshot_available_at:str='2000-01-01',
                                       valid_from:str='2000-01-01', valid_to:str='2099-12-31',
                                       snapshot_version:int=1,
                                       supersedes:Optional[str]=None,
                                       retracted_evidence_ids:Optional[List[str]]=None,
                                       supersession_authority_id:str='LOCAL_RETRIEVAL_AUTHORITY',
                                       retrieval_universe_id:Optional[str]=None):
    records=[]
    for item in expected_records:
        if not isinstance(item,dict) or not nonblank(item.get('evidence_id')):
            raise ValueError('v0.2.19 retrieval fixture requires full evidence records, not bare IDs')
        records.append(item)
    ids=tuple(sorted(r['evidence_id'] for r in records))
    manifest={r['evidence_id']:evidence_record_hash(r) for r in records}
    if len(ids)!=len(set(ids)): raise ValueError('duplicate expected evidence IDs')
    try:
        created=strict_date(snapshot_created_at); available=strict_date(snapshot_available_at)
        vf=strict_date(valid_from); vt=strict_date(valid_to)
    except Exception: raise ValueError('invalid retrieval snapshot dates')
    if created>available or vf>vt or type(snapshot_version) is not int or snapshot_version<1:
        raise ValueError('invalid retrieval snapshot metadata')
    entities,events,versions,predicates=_record_scope_summary(records)
    derived_universe=canonical_retrieval_universe_id(semantic_scope,entities,events,versions,predicates)
    if retrieval_universe_id is not None and retrieval_universe_id!=derived_universe:
        raise ValueError('retrieval_universe_id does not match controller-derived decision universe')
    summaries=[]
    for rec in records:
        rid=rec.get('identity_registry_entry_id'); ir=IDENTITY_REGISTRY.get(rid)
        if ir is None:
            raise ValueError('retrieval record identity unresolved at registration')
        summaries.append({
            'evidence_id':rec['evidence_id'],'entity_id':ir['entity_id'],'event_id':ir['event_id'],
            'version_id':ir['version_id'],'predicate':pkey(rec.get('predicate','')),
            'value_key':norm(rec.get('value','')),'polarity':rec.get('polarity','POSITIVE'),
            'record_hash':manifest[rec['evidence_id']]
        })
    retracted=tuple(sorted(set(retracted_evidence_ids or [])))
    if any(not nonblank(x) for x in retracted):
        raise ValueError('invalid retracted evidence id')
    RETRIEVAL_SCOPE_REGISTRY[scope_id]={
        'expected_evidence_ids':ids,'expected_record_hashes':manifest,'record_projection_index':tuple(summaries),
        'snapshot_id':snapshot_id,'retrieval_authority_id':'LOCAL_RETRIEVAL_AUTHORITY',
        'applicability_group_id':applicability_group_id or scope_id,
        'retrieval_universe_id':derived_universe,
        'semantic_scope':semantic_scope,'entity_ids':entities,'event_ids':events,'version_ids':versions,
        'predicates':predicates,
        'snapshot_created_at':snapshot_created_at,'snapshot_available_at':snapshot_available_at,
        'valid_from':valid_from,'valid_to':valid_to,'snapshot_version':snapshot_version,
        'supersedes':supersedes,'retracted_evidence_ids':retracted,
        'supersession_authority_id':supersession_authority_id,
    }

CLOSURE_CLASS='EPISTEMIC_FACT_AUDIT_V10'

PINNED_CLOSURE_CLASS_SPEC={
    'closure_class':CLOSURE_CLASS,
    'obligations':(
        'epistemic_time_valid','identity_resolved','subject_provenance_referent_consistent',
        'authority_record_referent_consistent','provenance_dimensions_resolved',
        'dependency_state_justification','justification_common_mode_coverage',
        'dependency_ontology_adequacy','dependency_instance_ontology_conformance','source_independence_semantics',
        'source_failure_domain_resolution_complete','support_set_common_mode_coverage',
        'decision_relevant_relation_discovery_complete','support_relation_instance_resolution_coverage',
        'claim_support_universe_common_mode_coverage','support_selection_justification','evidence_id_universe_coverage',
        'retrieval_snapshot_content_integrity','retrieval_universe_membership',
        'claim_snapshot_projection_complete','relational_claim_neighborhood_complete',
        'decision_relevant_snapshot_overlap_complete','cross_universe_evidence_closure',
        'snapshot_supersession_valid','decision_level_support_closure',
        'cross_group_snapshot_competition','retrieval_universe_partition_adequacy',
        'retrieval_scope_applicability','snapshot_freshness',
        'constraint_relation_coverage','claim_specific_support','scope_adequacy','extraction_adequacy',
        'policy_authorization','meta_baseline_version_applicability'
    )
}
PINNED_OBLIGATION_GATE_MAP={
    'epistemic_time_valid':'accepted_certificates_revalidate',
    'identity_resolved':'identity_resolution_valid',
    'subject_provenance_referent_consistent':'referent_consistency_valid',
    'authority_record_referent_consistent':'referent_consistency_valid',
    'provenance_dimensions_resolved':'provenance_dependency_resolution_valid',
    'dependency_state_justification':'dependency_state_justification_valid',
    'justification_common_mode_coverage':'justification_common_mode_coverage_valid',
    'dependency_ontology_adequacy':'dependency_ontology_adequacy_valid',
    'dependency_instance_ontology_conformance':'dependency_instance_ontology_conformance_valid',
    'source_independence_semantics':'source_independence_semantics_valid',
    'source_failure_domain_resolution_complete':'source_failure_domain_resolution_complete_valid',
    'support_set_common_mode_coverage':'support_set_common_mode_coverage_valid',
    'decision_relevant_relation_discovery_complete':'decision_relevant_relation_discovery_complete_valid',
    'support_relation_instance_resolution_coverage':'support_relation_instance_resolution_coverage_valid',
    'claim_support_universe_common_mode_coverage':'claim_support_universe_common_mode_coverage_valid',
    'support_selection_justification':'support_selection_justification_valid',
    'evidence_id_universe_coverage':'evidence_id_universe_complete',
    'retrieval_snapshot_content_integrity':'retrieval_snapshot_content_matches',
    'retrieval_universe_membership':'retrieval_universe_membership_valid',
    'claim_snapshot_projection_complete':'claim_snapshot_projection_complete',
    'relational_claim_neighborhood_complete':'relational_claim_neighborhood_complete',
    'decision_relevant_snapshot_overlap_complete':'decision_relevant_snapshot_overlap_complete',
    'cross_universe_evidence_closure':'cross_universe_evidence_closure_valid',
    'snapshot_supersession_valid':'snapshot_supersession_valid',
    'decision_level_support_closure':'decision_support_closure_valid',
    'cross_group_snapshot_competition':'cross_group_snapshot_competition_resolved',
    'retrieval_universe_partition_adequacy':'retrieval_universe_partition_adequate',
    'retrieval_scope_applicability':'retrieval_snapshot_applicability_valid',
    'snapshot_freshness':'snapshot_freshness_valid',
    'constraint_relation_coverage':'constraint_relation_coverage_sufficient',
    'claim_specific_support':'claim_specific_support_policy_valid',
    'scope_adequacy':'scope_adequacy_valid',
    'extraction_adequacy':'extraction_adequacy_valid',
    'policy_authorization':'closure_policy_authorization_valid',
    'meta_baseline_version_applicability':'meta_baseline_version_applicable',
}
PINNED_MANDATORY_GATES=(
    'claim_set_nonempty','closure_policy_valid','closure_policy_authorization_valid','audit_context_valid',
    'evidence_admission_valid','unique_evidence_ids','no_identity_ambiguity','identity_resolution_valid',
    'provenance_completeness_valid','provenance_dependency_resolution_valid','dependency_state_justification_valid',
    'justification_common_mode_coverage_valid','dependency_ontology_adequacy_valid','dependency_instance_ontology_conformance_valid',
    'source_independence_semantics_valid','source_failure_domain_resolution_complete_valid',
    'support_set_common_mode_coverage_valid','decision_relevant_relation_discovery_complete_valid',
    'support_relation_instance_resolution_coverage_valid',
    'claim_support_universe_common_mode_coverage_valid',
    'support_selection_justification_valid','referent_consistency_valid',
    'evidence_id_universe_complete','retrieval_snapshot_content_matches','retrieval_universe_membership_valid',
    'claim_snapshot_projection_complete','relational_claim_neighborhood_complete',
    'decision_relevant_snapshot_overlap_complete','cross_universe_evidence_closure_valid',
    'snapshot_supersession_valid','decision_support_closure_valid',
    'cross_group_snapshot_competition_resolved','retrieval_universe_partition_adequate',
    'retrieval_snapshot_applicability_valid','snapshot_freshness_valid',
    'global_consistency_valid','constraint_relation_coverage_sufficient',
    'claim_specific_support_policy_valid','constraint_coverage_sufficient','no_critical_unresolved',
    'accepted_certificates_revalidate','scope_binding_valid','extraction_binding_valid','scope_adequacy_valid',
    'extraction_adequacy_valid','meta_baseline_version_applicable','gate_registry_binding_valid',
    'gate_registry_schema_complete','gate_registry_adequate_for_closure_class'
)
PINNED_META_AUTHORITY={
    'authority_id':'LOCAL_PINNED_META_AUTHORITY_V10','meta_baseline_version':'meta:v10',
    'closure_class':CLOSURE_CLASS,'valid_from':'2000-01-01','valid_to':'2099-12-31',
    'closure_class_spec_hash':canonical_hash(PINNED_CLOSURE_CLASS_SPEC),
    'obligation_gate_map_hash':canonical_hash(PINNED_OBLIGATION_GATE_MAP),
    'mandatory_gates_hash':canonical_hash(PINNED_MANDATORY_GATES),
    'dependency_ontology_hash':canonical_hash(PINNED_DEPENDENCY_ONTOLOGY_SPEC),
    'source_independence_policy_hash':canonical_hash(PINNED_SOURCE_INDEPENDENCE_POLICY),
    'source_semantics_policy_hash':canonical_hash(PINNED_SOURCE_SEMANTICS_POLICY),
    'support_universe_policy_hash':canonical_hash(PINNED_SUPPORT_UNIVERSE_POLICY),
    'relation_discovery_policy_hash':canonical_hash(PINNED_RELATION_DISCOVERY_POLICY),
    'relation_resolution_policy_hash':canonical_hash(PINNED_RELATION_RESOLUTION_POLICY),
    'relation_decision_relevance_policy_hash':canonical_hash(PINNED_RELATION_DECISION_RELEVANCE_POLICY),
}

CLOSURE_CLASS_SPEC=dict(PINNED_CLOSURE_CLASS_SPEC)
OBLIGATION_GATE_MAP=dict(PINNED_OBLIGATION_GATE_MAP)
MANDATORY_GATES=tuple(PINNED_MANDATORY_GATES)

WAIVER_REGISTRY={'waiver:calm-local-test':{'closure_class':CLOSURE_CLASS,'predicate':'state','value':'calm','waives':'require_constraint_coverage','valid_from':'2026-01-01','valid_to':'2026-12-31','authorizer_id':'LOCAL_ASSURANCE_AUTHORITY'}}
AUTHORIZATION_REGISTRY={CLOSURE_CLASS:{'authorizer_id':'LOCAL_ASSURANCE_AUTHORITY'}}

def identity_registry_hash(): return canonical_hash(IDENTITY_REGISTRY)
def constraint_registry_hash(): return canonical_hash({'schema':PREDICATE_SCHEMA,'relations':[(sorted(list(k)),v) for k,v in STATE_RELATIONS.items()]})
def authority_registry_hash(): return canonical_hash(AUTHORITY_POLICIES)
def generic_relation_source_identity_policy_hash(): return canonical_hash(GENERIC_RELATION_SOURCE_IDENTITY_POLICY)
def generic_representation_equivalence_registry_hash(): return canonical_hash(GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY)
def generic_representation_equivalence_certificate_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,GenericRepresentationEquivalenceCertificate) else v) for k,v in GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.items()})
def generic_representation_distinctness_registry_hash(): return canonical_hash(GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY)
def generic_representation_distinctness_certificate_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,GenericRepresentationDistinctnessCertificate) else v) for k,v in GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.items()})
def generic_representation_completeness_certificate_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,DecisionGenericRepresentationCompletenessCertificate) else v) for k,v in GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY.items()})
def evidence_source_field_policy_hash(): return canonical_hash(EVIDENCE_SOURCE_FIELD_POLICY)
def provenance_policy_hash(): return canonical_hash({'provenance':PROVENANCE_POLICY,'generic_relation_source_identity_policy':GENERIC_RELATION_SOURCE_IDENTITY_POLICY,'generic_representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),'generic_representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),'generic_representation_distinctness_registry_hash':generic_representation_distinctness_registry_hash(),'generic_representation_distinctness_certificate_registry_hash':generic_representation_distinctness_certificate_registry_hash(),'evidence_source_field_policy':EVIDENCE_SOURCE_FIELD_POLICY})
def temporal_profile_hash(): return canonical_hash(TEMPORAL_PROFILE)
def control_profile_hash(): return canonical_hash(CONTROL_PROFILE)
def retrieval_registry_hash(): return canonical_hash(RETRIEVAL_SCOPE_REGISTRY)
def dependency_justification_registry_hash(): return canonical_hash(DEPENDENCY_JUSTIFICATION_REGISTRY)
def dependency_ontology_hash(): return canonical_hash({'dimensions':DEPENDENCY_DIMENSIONS,'prefixes':DEPENDENCY_PREFIX,'node_types':DEPENDENCY_NODE_TYPES,'policy':PROVENANCE_POLICY,'generic_relation_source_identity_policy':GENERIC_RELATION_SOURCE_IDENTITY_POLICY,'generic_representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),'generic_representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),'generic_representation_distinctness_registry_hash':generic_representation_distinctness_registry_hash(),'generic_representation_distinctness_certificate_registry_hash':generic_representation_distinctness_certificate_registry_hash(),'evidence_source_field_policy':EVIDENCE_SOURCE_FIELD_POLICY})
def source_independence_policy_hash(): return canonical_hash(SOURCE_INDEPENDENCE_POLICY)
def source_semantics_policy_hash(): return canonical_hash(SOURCE_SEMANTICS_POLICY)
def support_universe_policy_hash(): return canonical_hash(SUPPORT_UNIVERSE_POLICY)
def relation_discovery_policy_hash(): return canonical_hash(RELATION_DISCOVERY_POLICY)
def relation_resolution_policy_hash(): return canonical_hash(RELATION_RESOLUTION_POLICY)
def relation_decision_relevance_policy_hash(): return canonical_hash(RELATION_DECISION_RELEVANCE_POLICY)
def _support_selection_registry_entry_identity(row):
    if not isinstance(row,dict):return None
    record_type=row.get('record_type')
    if record_type is None:return row.get('selection_id')
    if record_type==DECISION_RELATION_RESOLUTION_RECORD_TYPE:return row.get('resolution_id')
    if record_type in {DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE,
                       DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE}:
        return row.get('accounting_id')
    return None

def support_selection_registry_key_identity_coherent():
    for registry_key,row in SUPPORT_SELECTION_REGISTRY.items():
        if (not nonblank(registry_key)
            or _support_selection_registry_entry_identity(row)!=registry_key):return False
    return True

def relation_resolution_registry_key_identity_coherent():
    for registry_key,row in RELATION_RESOLUTION_REGISTRY.items():
        if (not nonblank(registry_key) or not isinstance(row,dict)
            or row.get('resolution_id')!=registry_key):return False
    return True

def support_selection_registry_hash(): return canonical_hash(SUPPORT_SELECTION_REGISTRY)
def relation_resolution_registry_hash(): return canonical_hash(RELATION_RESOLUTION_REGISTRY)
def relation_resolution_declaration_registry_hash():
    # Context identity must not form a hash cycle with the context-bound authorization fields.
    # Hash only the immutable pre-context declaration portion; the full bound registry is still
    # included in closure-policy fingerprints and prepare->audit revalidation.
    binding_fields={
        'authorization_binding_state','audit_context_id','matching_support_universe_hash',
        'decision_relevant_relation_universe_hash','decision_relevant_relation_ids_hash',
        'exclusion_classification_hash','source_failure_domain_closure_hash','relation_registry_hash',
        'support_universe_policy_hash','relation_discovery_policy_hash','authorization_scope_hash',
    }
    projected={}
    for key,row in RELATION_RESOLUTION_REGISTRY.items():
        projected[key]=({k:v for k,v in row.items() if k not in binding_fields} if isinstance(row,dict) else row)
    return canonical_hash(projected)
def excluded_support_disposition_registry_hash(): return canonical_hash(EXCLUDED_SUPPORT_DISPOSITION_REGISTRY)
def _artifact_rows(registry,audit_context_id=None):
    if audit_context_id is None:return registry
    out={}
    for k,v in registry.items():
        ctx=getattr(v,'audit_context_id',None)
        if ctx==audit_context_id:out[k]=v
    return out
def matching_support_universe_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(MATCHING_SUPPORT_UNIVERSE_REGISTRY,audit_context_id).items()})
def decision_relevant_relation_universe_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY,audit_context_id).items()})
def support_selection_certificate_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(SUPPORT_SELECTION_CERTIFICATE_REGISTRY,audit_context_id).items()})
def claim_support_universe_coverage_certificate_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY,audit_context_id).items()})
def relation_resolution_certificate_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(RELATION_RESOLUTION_CERTIFICATE_REGISTRY,audit_context_id).items()})
def excluded_support_disposition_certificate_registry_hash(audit_context_id=None):
    return canonical_hash({k:asdict(v) for k,v in _artifact_rows(EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY,audit_context_id).items()})
def source_semantics_registry_hash(): return canonical_hash(SOURCE_SEMANTICS_REGISTRY)
def source_semantics_resolution_certificate_registry_hash(): return canonical_hash({k:asdict(v) for k,v in SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.items()})
def evidence_epistemic_role_policy_hash(): return canonical_hash(EVIDENCE_EPISTEMIC_ROLE_POLICY)
def pinned_evidence_epistemic_role_policy_hash(): return canonical_hash(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY)
def evidence_epistemic_role_issuer_policy_hash(): return canonical_hash(EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY)
def pinned_evidence_epistemic_role_issuer_policy_hash(): return canonical_hash(PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY)
def evidence_epistemic_role_registry_hash(): return canonical_hash(EVIDENCE_EPISTEMIC_ROLE_REGISTRY)
def evidence_epistemic_role_certificate_registry_hash():
    return canonical_hash({k:asdict(v) for k,v in EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.items()})
def evidence_epistemic_role_authorization_registry_hash():
    return canonical_hash({k:asdict(v) for k,v in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.items()})
def evidence_epistemic_role_origin_history_hash(): return canonical_hash(EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY)
def exact_evidence_role_authorization_index_hash(): return canonical_hash(EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX)
def evidence_id_identity_registry_hash(): return canonical_hash({k:asdict(v) if isinstance(v,EvidenceIdentityRecord) else v for k,v in EVIDENCE_ID_IDENTITY_REGISTRY.items()})
def trusted_role_issuance_chain_registry_hash():
    return canonical_hash({k:(asdict(v) if isinstance(v,TrustedRoleIssuanceAncestryEntry) else v)
                           for k,v in TRUSTED_ROLE_ISSUANCE_CHAIN.items()})
def trusted_role_issuance_chain_head(): return TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD
def failure_domain_alias_registry_hash(): return canonical_hash(FAILURE_DOMAIN_ALIAS_REGISTRY)
def failure_domain_parent_registry_hash(): return canonical_hash(FAILURE_DOMAIN_PARENT_REGISTRY)
def failure_domain_relation_registry_hash(): return canonical_hash({'aliases':FAILURE_DOMAIN_ALIAS_REGISTRY,'parents':FAILURE_DOMAIN_PARENT_REGISTRY})
def support_set_common_mode_registry_hash(): return canonical_hash(SUPPORT_SET_COMMON_MODE_REGISTRY)
def support_set_independence_certificate_registry_hash(): return canonical_hash({k:asdict(v) for k,v in SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.items()})
def source_independence_authorization_registry_hash(): return canonical_hash(SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY)
def source_independence_certificate_registry_hash(): return canonical_hash({k:asdict(v) for k,v in SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.items()})

def _ordinary_support_selection_history_hash():
    """Hash persisted pre-context support-selection declarations, excluding decision rows."""
    projected={}
    decision_types={
        'DECISION_TYPED_RELATION_RESOLUTION',
        'DECISION_SOURCE_DEPENDENCY_ACCOUNTING',
        'DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING',
    }
    for key,row in SUPPORT_SELECTION_REGISTRY.items():
        if isinstance(row,dict) and row.get('record_type') in decision_types:
            continue
        projected[key]=row
    return canonical_hash(projected)

def decision_persistence_history_commitment():
    """Deterministic commitment to replay-sensitive persisted decision history.

    Rollback detection requires the latest value to be persisted independently and supplied
    to begin_decision_rehydration(); recomputing this value from a partial replay is not enough.
    """
    payload={
        'format_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'identity_registry_hash':identity_registry_hash(),
        'retrieval_registry_hash':retrieval_registry_hash(),
        'dependency_justification_registry_hash':dependency_justification_registry_hash(),
        'ordinary_support_selection_history_hash':_ordinary_support_selection_history_hash(),
        'relation_resolution_registry_hash':relation_resolution_registry_hash(),
        'excluded_support_disposition_registry_hash':excluded_support_disposition_registry_hash(),
        'generic_representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),
        'generic_representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),
        'generic_representation_distinctness_registry_hash':generic_representation_distinctness_registry_hash(),
        'generic_representation_distinctness_certificate_registry_hash':generic_representation_distinctness_certificate_registry_hash(),
        'source_semantics_registry_hash':source_semantics_registry_hash(),
        'source_semantics_resolution_certificate_registry_hash':source_semantics_resolution_certificate_registry_hash(),
        'evidence_epistemic_role_policy_hash':evidence_epistemic_role_policy_hash(),
        'pinned_evidence_epistemic_role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),
        'evidence_epistemic_role_issuer_policy_hash':evidence_epistemic_role_issuer_policy_hash(),
        'pinned_evidence_epistemic_role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),
        'evidence_epistemic_role_registry_hash':evidence_epistemic_role_registry_hash(),
        'evidence_epistemic_role_certificate_registry_hash':evidence_epistemic_role_certificate_registry_hash(),
        'evidence_epistemic_role_authorization_registry_hash':evidence_epistemic_role_authorization_registry_hash(),
        'evidence_epistemic_role_origin_history_hash':evidence_epistemic_role_origin_history_hash(),
        'exact_evidence_role_authorization_index_hash':exact_evidence_role_authorization_index_hash(),
        'evidence_id_identity_registry_hash':evidence_id_identity_registry_hash(),
        'trusted_role_issuance_ancestry_version':TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION,
        'trusted_role_issuance_chain_registry_hash':trusted_role_issuance_chain_registry_hash(),
        'trusted_role_issuance_chain_head':trusted_role_issuance_chain_head(),
        'failure_domain_alias_registry_hash':failure_domain_alias_registry_hash(),
        'failure_domain_parent_registry_hash':failure_domain_parent_registry_hash(),
        'support_set_common_mode_registry_hash':support_set_common_mode_registry_hash(),
        'support_set_independence_certificate_registry_hash':support_set_independence_certificate_registry_hash(),
        'source_independence_authorization_registry_hash':source_independence_authorization_registry_hash(),
        'source_independence_certificate_registry_hash':source_independence_certificate_registry_hash(),
        'predecessor_control_artifact_registry_hash':predecessor_control_artifact_registry_hash(),
        'predecessor_transition_certificate_registry_hash':predecessor_transition_certificate_registry_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
    }
    return canonical_hash(payload)

def export_decision_persistence_state():
    return {
        'format_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'history_commitment':decision_persistence_history_commitment(),
    }

def _valid_history_commitment_value(value):
    return isinstance(value,str) and bool(re.fullmatch(r'[0-9a-f]{64}',value))

def begin_decision_rehydration(persisted_state):
    """Pin the independently persisted latest history checkpoint before replay."""
    global _DECISION_REHYDRATION_ACTIVE,_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT
    if (not isinstance(persisted_state,dict)
        or persisted_state.get('format_version')!=PERSISTENCE_HISTORY_COMMITMENT_VERSION
        or not _valid_history_commitment_value(persisted_state.get('history_commitment'))):
        return False
    if _DECISION_REHYDRATION_ACTIVE:
        return False
    _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    # Production rehydration terminates any fixture-authority generation; it never rotates it forward.
    exit_self_test_role_scope()
    _DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT=persisted_state['history_commitment']
    _DECISION_REHYDRATION_ACTIVE=True
    return True

def _decision_persistence_record_id(row):
    if not isinstance(row,dict):return None
    rt=row.get('record_type')
    if rt=='DECISION_TYPED_RELATION_RESOLUTION':return row.get('resolution_id')
    if rt in {'DECISION_SOURCE_DEPENDENCY_ACCOUNTING','DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING'}:
        return row.get('accounting_id')
    return None

def _decision_row_has_persistence_binding(row):
    return (isinstance(row,dict)
            and row.get('persistence_history_commitment_version')==PERSISTENCE_HISTORY_COMMITMENT_VERSION
            and _valid_history_commitment_value(row.get('persistence_history_commitment')))

def complete_decision_rehydration():
    """Authorize rehydrated decision rows only after exact replay reaches the checkpoint."""
    global _DECISION_REHYDRATION_ACTIVE,_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT
    global _DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT
    if not _DECISION_REHYDRATION_ACTIVE:return False
    expected=_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT
    if decision_persistence_history_commitment()!=expected:
        return False
    if not _predecessor_registry_chain_valid():
        return False
    if not _evidence_role_authorization_registry_valid():
        return False
    authorized=set();authorized_commitments={};authorized_fingerprints={}
    for key,row in SUPPORT_SELECTION_REGISTRY.items():
        rid=_decision_persistence_record_id(row)
        if rid is None:continue
        if rid!=key or not _decision_row_has_persistence_binding(row):continue
        if (row.get('binding_state')=='BOUND'
            and row.get('persistence_history_commitment')!=expected):continue
        authorized.add(key)
        authorized_commitments[key]=row.get('persistence_history_commitment')
        authorized_fingerprints[key]=canonical_hash(row)
    _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.update(authorized)
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.update(authorized_commitments)
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.update(authorized_fingerprints)
    _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    for aid,artifact in PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.items():
        _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS[aid]=_predecessor_artifact_fingerprint(artifact)
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    for aid,artifact in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.items():
        if _evidence_role_authorization_artifact_structurally_valid(artifact):
            commitment=_evidence_role_runtime_authority_commitment(artifact)
            if commitment is not None:
                _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS[aid]=_evidence_role_authorization_artifact_fingerprint(artifact)
                _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS[aid]=commitment
    _DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT=expected
    _DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT=None
    _DECISION_REHYDRATION_ACTIVE=False
    return True

def decision_rehydration_status():
    return {
        'active':_DECISION_REHYDRATION_ACTIVE,
        'expected_history_commitment':_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT,
        'current_history_commitment':decision_persistence_history_commitment(),
        'last_validated_history_commitment':_DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT,
        'authorized_decision_row_ids':tuple(sorted(_DECISION_ROW_RUNTIME_AUTHORIZED_IDS)),
        'authorized_predecessor_artifact_ids':tuple(sorted(_PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS)),
        'authorized_evidence_role_artifact_ids':tuple(sorted(_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS)),
    }

def _decision_runtime_authorization_state_hash():
    """Deterministic prepare->audit pin for the private decision-row runtime state.

    The stable audit_context_id intentionally does not include this value: legal sequential
    bind operations may update row authorization while constructing one prepare context.
    The final AuditContextCertificate pins the state that existed when prepare completed.

    v0.2.71 additionally pins map-key presence separately from the stored value so that an
    absent commitment/fingerprint key is distinct from an explicitly present key with None.
    """
    record_ids=sorted(set(_DECISION_ROW_RUNTIME_AUTHORIZED_IDS)
                      | set(_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS)
                      | set(_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS))
    payload={
        'active':_DECISION_REHYDRATION_ACTIVE,
        'expected_history_commitment':_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT,
        'last_validated_history_commitment':_DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT,
        'authorized_row_state':tuple((rid,
            rid in _DECISION_ROW_RUNTIME_AUTHORIZED_IDS,
            rid in _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS,
            _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.get(rid),
            rid in _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS,
            _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(rid)) for rid in record_ids),
        'authorized_evidence_role_state':tuple(sorted(_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.items())),
        'authorized_evidence_role_commitments':tuple(sorted(_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.items())),
    }
    return canonical_hash(payload)

def _reset_decision_persistence_runtime_state_for_tests():
    global _DECISION_REHYDRATION_ACTIVE,_DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT
    global _DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT
    _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _PREDECESSOR_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    _rotate_self_test_scope_generation_if_active()
    _DECISION_REHYDRATION_ACTIVE=False
    _DECISION_REHYDRATION_EXPECTED_HISTORY_COMMITMENT=None
    _DECISION_REHYDRATION_LAST_VALIDATED_HISTORY_COMMITMENT=None

def _authorize_fresh_decision_row(record_id):
    if not _DECISION_REHYDRATION_ACTIVE:
        row=SUPPORT_SELECTION_REGISTRY.get(record_id)
        if _decision_persistence_record_id(row)==record_id and _decision_row_has_persistence_binding(row):
            _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(record_id)
            _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[record_id]=row.get('persistence_history_commitment')
            _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[record_id]=canonical_hash(row)

def _decision_row_runtime_authorized(record_id,row):
    return (not _DECISION_REHYDRATION_ACTIVE
            and record_id in _DECISION_ROW_RUNTIME_AUTHORIZED_IDS
            and _decision_row_has_persistence_binding(row)
            and _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.get(record_id)==row.get('persistence_history_commitment')
            and _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(record_id)==canonical_hash(row)
            and (row.get('binding_state')!='BOUND'
                 or row.get('persistence_history_commitment')==decision_persistence_history_commitment()))

def _pending_decision_row_history_current(record_id,row):
    return (_decision_row_runtime_authorized(record_id,row)
            and row.get('persistence_history_commitment')==decision_persistence_history_commitment())

def _certificate_registry_key_identity_coherent(registry,certificate_type,identity_field):
    """A certificate value is authority only under its exact declared registry identity."""
    for registry_key,cert in registry.items():
        if (not nonblank(registry_key) or not isinstance(cert,certificate_type)
            or getattr(cert,identity_field,None)!=registry_key):
            return False
    return True

def source_independence_certificate_registry_coherent():
    return _certificate_registry_key_identity_coherent(
        SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY,SourceIndependenceCertificate,'independence_id')

def support_set_independence_certificate_registry_coherent():
    return _certificate_registry_key_identity_coherent(
        SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY,SupportSetIndependenceCertificate,'independence_id')

def closure_class_spec_hash(): return canonical_hash(CLOSURE_CLASS_SPEC)
def gate_registry_hash(): return canonical_hash(MANDATORY_GATES)
def pinned_meta_authority_hash(): return canonical_hash(PINNED_META_AUTHORITY)
def authorization_registry_hash(): return canonical_hash({'waivers':WAIVER_REGISTRY,'authorizers':AUTHORIZATION_REGISTRY})


# ============================================================
# Identity
# ============================================================

def make_identity(owner_type,owner_id,surface_subject,registry_entry_id):
    r=IDENTITY_REGISTRY.get(registry_entry_id)
    if r is None or r['surface_subject']!=surface_subject: return None
    payload={'owner_type':owner_type,'owner_id':owner_id,'surface_subject':surface_subject,'domain_id':r['domain_id'],'entity_id':r['entity_id'],'event_id':r['event_id'],'version_id':r['version_id'],'registry_entry_id':registry_entry_id}
    return IdentityCertificate(sha(payload),**payload)

def validate_identity(cert,owner_type,owner_id,surface_subject,registry_entry_id):
    fresh=make_identity(owner_type,owner_id,surface_subject,registry_entry_id)
    return fresh is not None and asdict(fresh)==asdict(cert)

def identity_tuple(cert): return (cert.entity_id,cert.event_id,cert.version_id)


# ============================================================
# Dependency identity semantics
# ============================================================

def canonical_dependency_id(dim,raw_id):
    if dim not in DEPENDENCY_PREFIX or not nonblank(raw_id): return None
    s=raw_id.strip(); prefix=DEPENDENCY_PREFIX[dim]
    # Raw local IDs are allowed and are canonicalized into the dimension namespace.
    # Explicit namespaces must match the declared dimension; foreign namespaces fail closed.
    if ':' in s:
        left,right=s.split(':',1)
        if not right:return None
        if left in {prefix,dim}:return f'{prefix}:{right}'
        return None
    return f'{prefix}:{s}'

def dependency_local_id(dim,canonical_id):
    if dim not in DEPENDENCY_PREFIX or not nonblank(canonical_id):return None
    prefix=f'{DEPENDENCY_PREFIX[dim]}:'
    if not canonical_id.startswith(prefix):return None
    local=canonical_id[len(prefix):]
    return local if local else None

def typed_dependency_node(dim,canonical_id):
    local=dependency_local_id(dim,canonical_id)
    return None if local is None else ('DEPENDENCY',dim,local)

def typed_node(node_type,dimension,identifier):
    if node_type not in DEPENDENCY_NODE_TYPES or not isinstance(dimension,str) or not nonblank(identifier):return None
    return (node_type,dimension,identifier)

def _representation_class(node):
    return None if not isinstance(node,tuple) or len(node)!=3 else (node[0],node[1])

def _equivalence_pair_key(left_type,left_dim,right_type,right_dim):
    a=(left_type,left_dim);b=(right_type,right_dim)
    return tuple(sorted((a,b)))

def _candidate_equivalence_specs():
    """Pinned authority pairs. v0.2.39 candidate discovery is intentionally broader than this map."""
    out={}
    for lt,ld,rt,rd,st,sd,isem in GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('authorization_required_representation_pairs',()):
        out[_equivalence_pair_key(lt,ld,rt,rd)]=(st,sd,isem)
    return out

def _equivalence_authorization_specs_for_classes(left_type,left_dim,right_type,right_dim):
    """All semantic targets that exact authority may certify for a representation-class pair.

    v0.2.40 deliberately separates *candidate descriptor discovery* from authority.  Untyped
    LINEAGE/COMMON_MODE pairs may be authorized for any controller-known dependency dimension;
    actual raw identifiers still have to match that exact dimension before a record can resolve a
    candidate.  This is not a heuristic merge.
    """
    key=_equivalence_pair_key(left_type,left_dim,right_type,right_dim)
    specs=set()
    pinned=_candidate_equivalence_specs().get(key)
    if pinned is not None:specs.add(tuple(pinned))
    classes=((left_type,left_dim),(right_type,right_dim))
    typed=[c for c in classes if c[0]=='DEPENDENCY' and c[1] in DEPENDENCY_PREFIX]
    if len(typed)==1:
        other=classes[0] if classes[1]==typed[0] else classes[1]
        if other[0] in {'LINEAGE','COMMON_MODE'}:
            dim=typed[0][1];specs.add(('DEPENDENCY',dim,'CANONICAL_DEPENDENCY_LOCAL_ID'))
    # Two untyped provenance representations are dimension-discovered from their raw exact prefix.
    if {classes[0][0],classes[1][0]}=={'LINEAGE','COMMON_MODE'} and classes[0][1]==classes[1][1]=='':
        for dim in DEPENDENCY_DIMENSIONS:
            specs.add(('DEPENDENCY',dim,'CANONICAL_DEPENDENCY_LOCAL_ID'))
    return tuple(sorted(specs))

def _equivalence_authorization_spec_for_classes(left_type,left_dim,right_type,right_dim):
    """Compatibility helper: return a spec only when the class pair has one unambiguous target."""
    specs=_equivalence_authorization_specs_for_classes(left_type,left_dim,right_type,right_dim)
    return specs[0] if len(specs)==1 else None

def _raw_candidate_semantic_descriptors(raw_node):
    """Controller-derived exact candidate descriptors for one raw generic representation.

    Descriptors express *possible semantic identity only*.  They never authorize equivalence.
    Untyped representations require an explicit recognized namespace prefix; bare payloads and
    foreign prefixes yield no descriptor, preventing suffix/text similarity merges.
    """
    if not (isinstance(raw_node,tuple) and len(raw_node)==3):return tuple()
    nt,dim,ident=raw_node
    if not isinstance(ident,str) or not ident:return tuple()
    out=[]
    if nt=='DEPENDENCY' and dim in DEPENDENCY_PREFIX:
        # typed dependency nodes carry the canonical local id already
        out.append(('DEPENDENCY',dim,ident,'TYPED_DEPENDENCY_DIMENSION'))
    elif nt in {'LINEAGE','COMMON_MODE'} and dim=='':
        if ':' in ident:
            ns,payload=ident.split(':',1)
            if payload:
                for d in DEPENDENCY_DIMENSIONS:
                    if ns in {DEPENDENCY_PREFIX[d],d}:
                        out.append(('DEPENDENCY',d,payload,'EXACT_RECOGNIZED_NAMESPACE_PREFIX'))
    return tuple(sorted(set(out)))

def _candidate_semantic_spec_for_nodes(raw_a,raw_b):
    """Discover exact semantic-identity candidates independently of authority declarations."""
    if not (isinstance(raw_a,tuple) and isinstance(raw_b,tuple) and len(raw_a)==len(raw_b)==3):return None
    cls_a=(raw_a[0],raw_a[1]);cls_b=(raw_b[0],raw_b[1])
    if cls_a==cls_b:return None
    da=_raw_candidate_semantic_descriptors(raw_a);db=_raw_candidate_semantic_descriptors(raw_b)
    ia={(x[0],x[1],x[2]) for x in da};ib={(x[0],x[1],x[2]) for x in db}
    common=sorted(ia & ib)
    if len(common)!=1:return None
    st,sd,ident=common[0]
    isem='CANONICAL_DEPENDENCY_LOCAL_ID'
    key=_equivalence_pair_key(*cls_a,*cls_b)
    pinned=_candidate_equivalence_specs().get(key)
    basis='PINNED_AUTHORITY_PAIR_DESCRIPTOR' if pinned is not None and tuple(pinned)==(st,sd,isem) else 'CONTROLLER_EXACT_DESCRIPTOR_MATCH'
    return (st,sd,isem,ident,basis)

def _non_candidate_pair_reason(raw_a,raw_b):
    """Typed controller basis for why a cross-class raw pair is not a semantic candidate."""
    da=_raw_candidate_semantic_descriptors(raw_a);db=_raw_candidate_semantic_descriptors(raw_b)
    if not da and not db:return ('NO_CONTROLLER_DESCRIPTOR_EITHER_SIDE',da,db)
    if not da:return ('NO_CONTROLLER_DESCRIPTOR_LEFT',da,db)
    if not db:return ('NO_CONTROLLER_DESCRIPTOR_RIGHT',da,db)
    dims_a={x[1] for x in da};dims_b={x[1] for x in db}
    if dims_a.isdisjoint(dims_b):return ('EXACT_DIFFERENT_DEPENDENCY_DIMENSION',da,db)
    ids_a={(x[1],x[2]) for x in da};ids_b={(x[1],x[2]) for x in db}
    if ids_a.isdisjoint(ids_b):return ('EXACT_DIFFERENT_LOCAL_IDENTIFIER',da,db)
    return ('NO_EXACT_SHARED_DESCRIPTOR',da,db)

def _canonical_raw_node_pair(raw_a,raw_b):
    a=tuple(raw_a);b=tuple(raw_b)
    return tuple(sorted((a,b),key=str))

def register_generic_representation_equivalence(equivalence_id,left_node_type,left_dimension,right_node_type,right_dimension,
                                                semantic_node_type,semantic_dimension,identifier_semantics,
                                                scope_id='*',authorizer_id='LOCAL_GENERIC_EQUIVALENCE_AUTHORITY',
                                                valid_from='2000-01-01',valid_to='2099-12-31'):
    if equivalence_id in GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY:raise ValueError('duplicate equivalence id')
    if not all(nonblank(x) for x in (equivalence_id,left_node_type,right_node_type,semantic_node_type,semantic_dimension,identifier_semantics,scope_id,authorizer_id,valid_from,valid_to)):
        raise ValueError('invalid equivalence declaration')
    if left_node_type not in DEPENDENCY_NODE_TYPES or right_node_type not in DEPENDENCY_NODE_TYPES or semantic_node_type not in DEPENDENCY_NODE_TYPES:
        raise ValueError('invalid equivalence node type')
    if authorizer_id not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_equivalence_authorizers',())):
        raise ValueError('unauthorized equivalence authorizer')
    if identifier_semantics not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_identifier_semantics',())):
        raise ValueError('invalid identifier semantics')
    specs=_equivalence_authorization_specs_for_classes(left_node_type,left_dimension,right_node_type,right_dimension)
    if not specs:
        raise ValueError('representation pair not authorized for runtime equivalence')
    if (semantic_node_type,semantic_dimension,identifier_semantics) not in set(specs):raise ValueError('semantic class mismatch')
    try:
        if strict_date(valid_from)>strict_date(valid_to):raise ValueError
    except Exception:raise ValueError('invalid equivalence validity')
    row={'equivalence_id':equivalence_id,'left_node_type':left_node_type,'left_dimension':left_dimension,
         'right_node_type':right_node_type,'right_dimension':right_dimension,'semantic_node_type':semantic_node_type,
         'semantic_dimension':semantic_dimension,'identifier_semantics':identifier_semantics,'scope_id':scope_id,
         'ontology_id':PINNED_DEPENDENCY_ONTOLOGY_SPEC['ontology_id'],'policy_id':GENERIC_RELATION_SOURCE_IDENTITY_POLICY['policy_id'],
         'authorizer_id':authorizer_id,'valid_from':valid_from,'valid_to':valid_to}
    GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY[equivalence_id]=row
    return copy.deepcopy(row)

def issue_generic_representation_equivalence_certificate(equivalence_id):
    row=GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(equivalence_id)
    if not isinstance(row,dict):return None
    payload={**row,'record_hash':canonical_hash(row),'policy_hash':generic_relation_source_identity_policy_hash(),'certificate_result':'PASS'}
    cert=GenericRepresentationEquivalenceCertificate(sha(payload),**payload)
    GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY[equivalence_id]=cert
    return cert

def validate_generic_representation_equivalence_certificate(cert,equivalence_id=None):
    # Certificate validity is deliberately separate from structural validity and context applicability.
    if cert is None:return False
    eid=equivalence_id or getattr(cert,'equivalence_id',None)
    row=GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(eid)
    if not isinstance(row,dict):return False
    payload={**row,'record_hash':canonical_hash(row),'policy_hash':generic_relation_source_identity_policy_hash(),'certificate_result':'PASS'}
    try:fresh=GenericRepresentationEquivalenceCertificate(sha(payload),**payload)
    except Exception:return False
    try:return asdict(fresh)==asdict(cert)
    except Exception:return False

def validate_generic_representation_equivalence_structure(row,equivalence_id=None):
    # Structural validity proves shape/typing/authority/date well-formedness only.
    # Semantic target compatibility is intentionally checked later, only for ACTIVE records.
    if not isinstance(row,dict):return False
    required={'equivalence_id','left_node_type','left_dimension','right_node_type','right_dimension',
              'semantic_node_type','semantic_dimension','identifier_semantics','scope_id','ontology_id',
              'policy_id','authorizer_id','valid_from','valid_to'}
    if set(row)!=required:return False
    eid=row.get('equivalence_id')
    if equivalence_id is not None and eid!=equivalence_id:return False
    if not all(nonblank(row.get(k)) for k in ('equivalence_id','left_node_type','right_node_type','semantic_node_type',
                                               'semantic_dimension','identifier_semantics','scope_id','ontology_id','policy_id',
                                               'authorizer_id','valid_from','valid_to')):return False
    if not isinstance(row.get('left_dimension'),str) or not isinstance(row.get('right_dimension'),str):return False
    if row['left_node_type'] not in DEPENDENCY_NODE_TYPES or row['right_node_type'] not in DEPENDENCY_NODE_TYPES or row['semantic_node_type'] not in DEPENDENCY_NODE_TYPES:return False
    if row['authorizer_id'] not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_equivalence_authorizers',())):return False
    if row['identifier_semantics'] not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_identifier_semantics',())):return False
    if row['policy_id']!=GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('policy_id') or row['ontology_id']!=PINNED_DEPENDENCY_ONTOLOGY_SPEC.get('ontology_id'):return False
    if not _equivalence_authorization_specs_for_classes(row['left_node_type'],row['left_dimension'],row['right_node_type'],row['right_dimension']):return False
    try:
        if strict_date(row['valid_from'])>strict_date(row['valid_to']):return False
    except Exception:return False
    return True


def register_generic_representation_distinctness(distinctness_id,left_node_type,left_dimension,left_identifier,
                                                 right_node_type,right_dimension,right_identifier,
                                                 retrieval_scope_id,as_of_date,
                                                 authorizer_id='LOCAL_GENERIC_EQUIVALENCE_AUTHORITY'):
    """Register exact candidate-instance distinctness for one audit context.

    Unlike equivalence validity windows, PROVEN_DISTINCT is intentionally bound to one exact
    as_of_date and one exact retrieval scope. Absence of this record never proves distinctness.
    """
    if distinctness_id in GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY:raise ValueError('duplicate distinctness id')
    raw_a=typed_node(left_node_type,left_dimension,left_identifier);raw_b=typed_node(right_node_type,right_dimension,right_identifier)
    if raw_a is None or raw_b is None:raise ValueError('invalid distinctness raw node')
    spec=_candidate_semantic_spec_for_nodes(raw_a,raw_b)
    if spec is None:raise ValueError('distinctness requires an exact discovered candidate')
    if authorizer_id not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_equivalence_authorizers',())):
        raise ValueError('unauthorized distinctness authorizer')
    if not nonblank(retrieval_scope_id):raise ValueError('invalid distinctness retrieval scope')
    try:strict_date(as_of_date)
    except Exception:raise ValueError('invalid distinctness as_of_date')
    left,right=_canonical_raw_node_pair(raw_a,raw_b)
    st,sd,isem,ident,_=spec
    row={'distinctness_id':distinctness_id,'left_node_type':left[0],'left_dimension':left[1],'left_identifier':left[2],
         'right_node_type':right[0],'right_dimension':right[1],'right_identifier':right[2],
         'semantic_node_type':st,'semantic_dimension':sd,'identifier_semantics':isem,
         'retrieval_scope_id':retrieval_scope_id,'as_of_date':as_of_date,
         'ontology_id':PINNED_DEPENDENCY_ONTOLOGY_SPEC['ontology_id'],'policy_id':GENERIC_RELATION_SOURCE_IDENTITY_POLICY['policy_id'],
         'authorizer_id':authorizer_id}
    GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY[distinctness_id]=row
    return copy.deepcopy(row)

def issue_generic_representation_distinctness_certificate(distinctness_id):
    row=GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(distinctness_id)
    if not isinstance(row,dict):return None
    payload={**row,'record_hash':canonical_hash(row),'policy_hash':generic_relation_source_identity_policy_hash(),'certificate_result':'PASS'}
    cert=GenericRepresentationDistinctnessCertificate(sha(payload),**payload)
    GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY[distinctness_id]=cert
    return cert

def validate_generic_representation_distinctness_certificate(cert,distinctness_id=None):
    if cert is None:return False
    did=distinctness_id or getattr(cert,'distinctness_id',None)
    row=GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(did)
    if not isinstance(row,dict):return False
    required={'distinctness_id','left_node_type','left_dimension','left_identifier','right_node_type','right_dimension','right_identifier',
              'semantic_node_type','semantic_dimension','identifier_semantics','retrieval_scope_id','as_of_date','ontology_id','policy_id','authorizer_id'}
    if set(row)!=required:return False
    raw_a=typed_node(row['left_node_type'],row['left_dimension'],row['left_identifier']);raw_b=typed_node(row['right_node_type'],row['right_dimension'],row['right_identifier'])
    if raw_a is None or raw_b is None:return False
    spec=_candidate_semantic_spec_for_nodes(raw_a,raw_b)
    if spec is None or tuple(spec[:3])!=(row['semantic_node_type'],row['semantic_dimension'],row['identifier_semantics']):return False
    if row['ontology_id']!=PINNED_DEPENDENCY_ONTOLOGY_SPEC['ontology_id'] or row['policy_id']!=GENERIC_RELATION_SOURCE_IDENTITY_POLICY['policy_id']:return False
    if row['authorizer_id'] not in set(GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('allowed_equivalence_authorizers',())):return False
    try:strict_date(row['as_of_date'])
    except Exception:return False
    payload={**row,'record_hash':canonical_hash(row),'policy_hash':generic_relation_source_identity_policy_hash(),'certificate_result':'PASS'}
    try:fresh=GenericRepresentationDistinctnessCertificate(sha(payload),**payload)
    except Exception:return False
    try:return asdict(fresh)==asdict(cert)
    except Exception:return False

def _candidate_distinctness_state(raw_a,raw_b,as_of_date,retrieval_scope_id):
    pair=_canonical_raw_node_pair(raw_a,raw_b);active=[];invalid=[]
    for did,row in sorted(GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.items()):
        cert=GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(did)
        if not validate_generic_representation_distinctness_certificate(cert,did):
            invalid.append(did);continue
        rpair=((row['left_node_type'],row['left_dimension'],row['left_identifier']),
               (row['right_node_type'],row['right_dimension'],row['right_identifier']))
        if tuple(rpair)!=pair:continue
        if row['as_of_date']==as_of_date and row['retrieval_scope_id']==retrieval_scope_id:active.append(did)
    for did in GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY:
        if did not in GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY:invalid.append(did)
    if invalid:return ('CONFLICT',tuple(sorted(set(invalid))))
    return ('PROVEN_DISTINCT',tuple(sorted(active))) if active else ('UNRESOLVED',tuple())

def generic_representation_distinctness_registry_adequate():
    for did,row in GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.items():
        cert=GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(did)
        if not validate_generic_representation_distinctness_certificate(cert,did):return False
    return all(did in GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY for did in GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY)


def _equivalence_context_snapshot(as_of_date=None,retrieval_scope_id=None):
    active=[];inactive=[];invalid=[];app=[]
    try:t=None if as_of_date is None else strict_date(as_of_date)
    except Exception:t=None
    for eid,row in sorted(GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.items()):
        structural=validate_generic_representation_equivalence_structure(row,eid)
        cert=GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(eid)
        cert_valid=validate_generic_representation_equivalence_certificate(cert,eid) if structural else False
        reasons=[]
        applicability='INVALID'
        if not structural:
            reasons.append('STRUCTURAL_INVALID');invalid.append(eid)
        elif not cert_valid:
            reasons.append('CERTIFICATE_INVALID');invalid.append(eid)
        else:
            try:vf=strict_date(row['valid_from']);vt=strict_date(row['valid_to'])
            except Exception:
                reasons.append('STRUCTURAL_INVALID');invalid.append(eid);structural=False
            if structural:
                if t is None:reasons.append('AS_OF_DATE_UNAVAILABLE')
                else:
                    if t<vf:reasons.append('FUTURE')
                    if t>vt:reasons.append('EXPIRED')
                scope=row.get('scope_id')
                if scope!='*':
                    if retrieval_scope_id is None:reasons.append('RETRIEVAL_SCOPE_UNAVAILABLE')
                    elif scope!=retrieval_scope_id:reasons.append('WRONG_SCOPE')
                if not reasons:
                    applicability='ACTIVE';active.append(row)
                else:
                    applicability='INACTIVE';inactive.append((eid,'+'.join(reasons)))
        app.append((eid,structural,cert_valid,row.get('scope_id') if isinstance(row,dict) else None,
                    row.get('valid_from') if isinstance(row,dict) else None,row.get('valid_to') if isinstance(row,dict) else None,
                    as_of_date,retrieval_scope_id,applicability,'+'.join(reasons) if reasons else 'ACTIVE'))
    for eid in sorted(GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY):
        if eid not in GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY:
            invalid.append(eid);app.append((eid,False,False,None,None,None,as_of_date,retrieval_scope_id,'INVALID','ORPHAN_CERTIFICATE'))
    return {'active_records':tuple(active),'active_ids':tuple(sorted(r['equivalence_id'] for r in active)),
            'inactive_records':tuple(sorted(inactive)),'invalid_ids':tuple(sorted(set(invalid))),
            'applicability_records':tuple(sorted(app,key=str))}


def _valid_equivalence_records(as_of_date=None,retrieval_scope_id=None):
    snap=_equivalence_context_snapshot(as_of_date,retrieval_scope_id)
    return snap['active_records'],snap['invalid_ids']

def _resolved_equivalence_class_map(as_of_date=None,retrieval_scope_id=None):
    # class -> tuple[(semantic_type, semantic_dimension, identifier_semantics, ACTIVE record ids)]
    # Multiple dimension-specific mappings for one untyped class are legal in v0.2.40 because
    # exact namespace parsing decides which mapping can apply to each raw node.
    tmp={}
    for rt,rd,st,sd in GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get('authorized_representation_mappings',()):
        tmp.setdefault((rt,rd),{}).setdefault((st,sd,'EXACT_ID_EQUALITY'),set()).add('PINNED:'+rt+':'+rd)
    records,invalid=_valid_equivalence_records(as_of_date,retrieval_scope_id)
    conflicts=[];seen_exact={}
    for row in records:
        key=_equivalence_pair_key(row['left_node_type'],row['left_dimension'],row['right_node_type'],row['right_dimension'])
        target=(row['semantic_node_type'],row['semantic_dimension'],row['identifier_semantics'])
        allowed=set(_equivalence_authorization_specs_for_classes(row['left_node_type'],row['left_dimension'],row['right_node_type'],row['right_dimension']))
        if target not in allowed:
            conflicts.append(('ACTIVE_SEMANTIC_TARGET_CONFLICT',key,tuple(sorted(allowed)),target,row['equivalence_id']));continue
        exact_key=(key,target)
        # Duplicate exact semantic authorities are allowed only when they agree; their ids are jointly auditable.
        seen_exact.setdefault(exact_key,set()).add(row['equivalence_id'])
        for cls in ((row['left_node_type'],row['left_dimension']),(row['right_node_type'],row['right_dimension'])):
            tmp.setdefault(cls,{}).setdefault(target,set()).add(row['equivalence_id'])
    mapping={}
    for cls,targets in tmp.items():
        mapping[cls]=tuple(sorted((t[0],t[1],t[2],tuple(sorted(ids))) for t,ids in targets.items()))
    return mapping,tuple(sorted(invalid)),tuple(sorted(conflicts,key=str))

def generic_representation_equivalence_registry_adequate(as_of_date=None,retrieval_scope_id=None):
    _,invalid,conflicts=_resolved_equivalence_class_map(as_of_date,retrieval_scope_id)
    return not invalid and not conflicts

def generic_equivalence_contextual_resolution_state(as_of_date,retrieval_scope_id):
    snap=_equivalence_context_snapshot(as_of_date,retrieval_scope_id)
    mapping,invalid,conflicts=_resolved_equivalence_class_map(as_of_date,retrieval_scope_id)
    map_rows=tuple(sorted(((cls,tuple(v)) for cls,v in mapping.items()),key=str))
    payload={'as_of_date':as_of_date,'retrieval_scope_id':retrieval_scope_id,
             'active_equivalence_ids':snap['active_ids'],'inactive_equivalence_records':snap['inactive_records'],
             'invalid_equivalence_ids':invalid,'applicability_records':snap['applicability_records'],
             'resolved_class_map':map_rows,'active_conflicts':conflicts,
             'policy_hash':generic_relation_source_identity_policy_hash(),
             'registry_hash':generic_representation_equivalence_registry_hash(),
             'certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash()}
    return {**snap,'resolved_class_map':map_rows,'invalid_ids':invalid,'conflicts':conflicts,
            'contextual_resolution_hash':sha(payload)}

def _semantic_identifier(raw_node,semantic_type,semantic_dim,identifier_semantics):
    nt,dim,ident=raw_node
    if identifier_semantics=='EXACT_ID_EQUALITY':return ident
    if identifier_semantics=='CANONICAL_DEPENDENCY_LOCAL_ID':
        if semantic_type!='DEPENDENCY' or semantic_dim not in DEPENDENCY_PREFIX:return None
        if nt=='DEPENDENCY' and dim==semantic_dim:
            # typed dependency nodes already contain the canonical local identifier, which may itself contain ':'.
            return ident
        cid=canonical_dependency_id(semantic_dim,ident)
        return dependency_local_id(semantic_dim,cid) if cid else None
    return None

def _candidate_alias_state(raw_a,raw_b,as_of_date=None,retrieval_scope_id=None):
    if not (isinstance(raw_a,tuple) and isinstance(raw_b,tuple) and len(raw_a)==len(raw_b)==3):return ('NOT_A_CANDIDATE',None,tuple())
    spec=_candidate_semantic_spec_for_nodes(raw_a,raw_b)
    if spec is None:return ('NOT_A_CANDIDATE',None,tuple())
    st,sd,isem,ident,_basis=spec;node=(st,sd,ident);target=(st,sd,isem)
    cls_a=(raw_a[0],raw_a[1]);cls_b=(raw_b[0],raw_b[1]);pairkey=_equivalence_pair_key(*cls_a,*cls_b)
    eqsnap=_equivalence_context_snapshot(as_of_date,retrieval_scope_id)
    mapping,invalid,global_conflicts=_resolved_equivalence_class_map(as_of_date,retrieval_scope_id)
    dstate,drecs=_candidate_distinctness_state(raw_a,raw_b,as_of_date,retrieval_scope_id)
    candidate_conflicts=[]
    # Candidate-specific active authorities whose exact raw identifiers map to a different semantic target are conflicts.
    for row in eqsnap['active_records']:
        if _equivalence_pair_key(row['left_node_type'],row['left_dimension'],row['right_node_type'],row['right_dimension'])!=pairkey:continue
        rtarget=(row['semantic_node_type'],row['semantic_dimension'],row['identifier_semantics'])
        ia=_semantic_identifier(raw_a,*rtarget);ib=_semantic_identifier(raw_b,*rtarget)
        if ia is None or ib is None or ia!=ib:continue
        if rtarget!=target or ia!=ident:candidate_conflicts.append(('ACTIVE_CANDIDATE_TARGET_CONFLICT',row['equivalence_id'],rtarget,ia,target,ident))
    # Transitive semantic resolution is exact-target and exact-context: both raw classes must have
    # ACTIVE paths to the same candidate target, and each raw identifier must map to this exact id.
    def target_support(cls,raw):
        ids=set()
        for mt,md,mi,mids in mapping.get(cls,tuple()):
            if (mt,md,mi)!=target:continue
            sid=_semantic_identifier(raw,mt,md,mi)
            if sid==ident:ids.update(mids)
        return ids
    sa=target_support(cls_a,raw_a);sb=target_support(cls_b,raw_b)
    eq_resolved=bool(sa and sb);matching=tuple(sorted(sa|sb)) if eq_resolved else tuple()
    if invalid or global_conflicts or candidate_conflicts or dstate=='CONFLICT':
        recs=set(invalid);recs.update(drecs);recs.update(matching)
        recs.update(str(x) for x in candidate_conflicts);recs.update(str(x) for x in global_conflicts)
        return ('CONFLICT',node,tuple(sorted(recs)))
    if eq_resolved and dstate=='PROVEN_DISTINCT':return ('CONFLICT',node,tuple(sorted(set(matching)|set(drecs))))
    if eq_resolved:return ('RESOLVED',node,matching)
    if dstate=='PROVEN_DISTINCT':return ('PROVEN_DISTINCT',node,drecs)
    inactive=[]
    for eid,_reason in eqsnap['inactive_records']:
        row=GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(eid)
        if not isinstance(row,dict):continue
        rtarget=(row['semantic_node_type'],row['semantic_dimension'],row['identifier_semantics'])
        if rtarget!=target:continue
        # An inactive edge is relevant if it could map either candidate endpoint class/identifier.
        for rcls,raw in ((cls_a,raw_a),(cls_b,raw_b)):
            if rcls not in {(row['left_node_type'],row['left_dimension']),(row['right_node_type'],row['right_dimension'])}:continue
            sid=_semantic_identifier(raw,*rtarget)
            if sid==ident:inactive.append(eid);break
    return ('UNRESOLVED',node,tuple(sorted(set(inactive))))

def _fact_unresolved_equivalence_diagnostics(a,b,as_of_date=None,retrieval_scope_id=None):
    diags=[]
    for ra in sorted(raw_generic_dependency_nodes(a)):
        for rb in sorted(raw_generic_dependency_nodes(b)):
            state,node,recs=_candidate_alias_state(ra,rb,as_of_date,retrieval_scope_id)
            if state in {'UNRESOLVED','CONFLICT'}:
                diags.append(('GENERIC_REPRESENTATION_EQUIVALENCE_'+state,node,ra,rb,recs))
    return tuple(diags)

def make_dependency_justification_certificate(justification_id,dim,state):
    r=DEPENDENCY_JUSTIFICATION_REGISTRY.get(justification_id)
    if r is None:return None
    if r['dimension']!=dim or r['state']!=state:return None
    payload={'justification_id':justification_id,'dimension':dim,'state':state,
             'authority_id':r['authority_id'],'scope_id':r['scope_id'],
             'reason_hash':sha(r['reason']),'registry_hash':dependency_justification_registry_hash()}
    return DependencyStateJustificationCertificate(sha(payload),**payload)

def validate_dependency_justification_certificate(cert):
    fresh=make_dependency_justification_certificate(cert.justification_id,cert.dimension,cert.state)
    return fresh is not None and asdict(fresh)==asdict(cert)

def raw_dependency_row(dim,obj):
    if not isinstance(obj,dict):return None
    state=obj.get('state')
    if state not in DEPENDENCY_STATES:return None
    raw_id=obj.get('id') if state=='KNOWN' else ''
    jid=obj.get('justification_id') if state in PROVENANCE_POLICY['justification_required_states'] else ''
    return (dim,state,raw_id or '',jid or '')

def normalize_dependency_entry(dim,obj):
    if not isinstance(obj,dict): return None
    if set(obj.keys())-{'state','id','justification_id'}: return None
    state=obj.get('state')
    if state not in DEPENDENCY_STATES: return None
    if state=='KNOWN':
        if obj.get('justification_id') not in (None,''):return None
        cid=canonical_dependency_id(dim,obj.get('id'))
        if cid is None:return None
        return (dim,state,cid,'')
    if obj.get('id') not in (None,''): return None
    if state in PROVENANCE_POLICY['justification_required_states']:
        jid=obj.get('justification_id')
        if not nonblank(jid):return None
        cert=make_dependency_justification_certificate(jid,dim,state)
        if cert is None:return None
        return (dim,state,'',cert.certificate_id)
    if obj.get('justification_id') not in (None,''):return None
    return (dim,state,'','')

def normalize_dependencies(d):
    if not isinstance(d,dict) or set(d.keys())!=set(DEPENDENCY_DIMENSIONS): return None
    rows=[]
    for dim in DEPENDENCY_DIMENSIONS:
        row=normalize_dependency_entry(dim,d[dim])
        if row is None:return None
        rows.append(row)
    return tuple(rows)

def raw_dependencies(d):
    if not isinstance(d,dict) or set(d.keys())!=set(DEPENDENCY_DIMENSIONS):return None
    rows=[]
    for dim in DEPENDENCY_DIMENSIONS:
        row=raw_dependency_row(dim,d[dim])
        if row is None:return None
        rows.append(row)
    return tuple(rows)

def dependency_resolution_valid(prov):
    for _,state,_,_ in prov.dependencies:
        if state in PROVENANCE_POLICY['blocking_states']: return False
    return True

def dependency_state_justification_valid(prov):
    for dim,state,_,cert_id in prov.dependencies:
        if state in PROVENANCE_POLICY['justification_required_states']:
            matches=[]
            for jid,r in DEPENDENCY_JUSTIFICATION_REGISTRY.items():
                if r['dimension']==dim and r['state']==state:
                    c=make_dependency_justification_certificate(jid,dim,state)
                    if c and c.certificate_id==cert_id and validate_dependency_justification_certificate(c):
                        matches.append(c)
            if len(matches)!=1:return False
        elif cert_id!='':
            return False
    return True


# ============================================================
# Source identity / failure-domain semantics
# ============================================================

def _default_source_profile(source_id):
    # Synthetic identifiers are technical placeholders only. They intentionally do
    # NOT establish epistemic distinctness from any other source.
    return {
        'repository_id':f'repository:{source_id}',
        'producer_id':f'producer:{source_id}',
        'process_id':f'process:{source_id}',
        'failure_domain_id':f'fd:{source_id}',
        'authority_id':'LOCAL_SOURCE_SEMANTICS_AUTHORITY',
        'resolution_state':SOURCE_SEMANTICS_POLICY['default_profile_resolution_state'],
        'source_common_mode_ids':(),
    }

def canonical_failure_domain_id(failure_domain_id):
    if not nonblank(failure_domain_id):return None
    cur=failure_domain_id;seen=set()
    while cur in FAILURE_DOMAIN_ALIAS_REGISTRY:
        if cur in seen:return None
        seen.add(cur)
        nxt=FAILURE_DOMAIN_ALIAS_REGISTRY[cur]
        if not nonblank(nxt):return None
        cur=nxt
    return cur

def failure_domain_closure(failure_domain_id):
    root=canonical_failure_domain_id(failure_domain_id)
    if root is None:return None
    out=set();stack=[root]
    while stack:
        cur=canonical_failure_domain_id(stack.pop())
        if cur is None:return None
        if cur in out:continue
        out.add(cur)
        # Resolve parent edges dynamically through the alias registry so the semantic
        # graph is invariant to whether an alias or a parent edge was registered first.
        parents=set()
        for raw_child,raw_parents in FAILURE_DOMAIN_PARENT_REGISTRY.items():
            if canonical_failure_domain_id(raw_child)==cur:
                parents.update(raw_parents)
        for parent in parents:
            cp=canonical_failure_domain_id(parent)
            if cp is None:return None
            if cp not in out:stack.append(cp)
    return frozenset(out)

def register_failure_domain_alias(alias_id,canonical_id):
    if not all(nonblank(x) for x in (alias_id,canonical_id)) or alias_id==canonical_id:
        raise ValueError('invalid failure-domain alias')
    old=FAILURE_DOMAIN_ALIAS_REGISTRY.get(alias_id)
    FAILURE_DOMAIN_ALIAS_REGISTRY[alias_id]=canonical_id
    if canonical_failure_domain_id(alias_id) is None:
        if old is None:FAILURE_DOMAIN_ALIAS_REGISTRY.pop(alias_id,None)
        else:FAILURE_DOMAIN_ALIAS_REGISTRY[alias_id]=old
        raise ValueError('failure-domain alias cycle')

def register_failure_domain_parent(child_id,parent_id):
    if not all(nonblank(x) for x in (child_id,parent_id)):
        raise ValueError('invalid failure-domain parent')
    child=canonical_failure_domain_id(child_id);parent=canonical_failure_domain_id(parent_id)
    if child is None or parent is None or child==parent:raise ValueError('invalid failure-domain parent')
    old=tuple(FAILURE_DOMAIN_PARENT_REGISTRY.get(child,()))
    FAILURE_DOMAIN_PARENT_REGISTRY[child]=tuple(sorted(set(old+(parent,))))
    cl=failure_domain_closure(parent)
    if cl is None or child in cl:
        if old:FAILURE_DOMAIN_PARENT_REGISTRY[child]=old
        else:FAILURE_DOMAIN_PARENT_REGISTRY.pop(child,None)
        raise ValueError('failure-domain parent cycle')

def _semantics_common_modes(profile):
    vals=profile.get('source_common_mode_ids',())
    if not isinstance(vals,(list,tuple,set,frozenset)) or any(not nonblank(x) for x in vals):return None
    return tuple(sorted(set(vals)))

def make_source_semantics_resolution_certificate(semantics_id):
    profile=SOURCE_SEMANTICS_REGISTRY.get(semantics_id)
    if profile is None:return None
    required=('source_id','repository_id','producer_id','process_id','failure_domain_id','authority_id','resolution_state')
    if not all(nonblank(profile.get(k)) for k in required):return None
    if profile['authority_id'] not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):return None
    if profile['resolution_state'] not in set(SOURCE_SEMANTICS_POLICY['allowed_resolution_states']):return None
    cm=_semantics_common_modes(profile)
    if cm is None:return None
    canon=canonical_failure_domain_id(profile['failure_domain_id'])
    closure=failure_domain_closure(profile['failure_domain_id'])
    if canon is None or closure is None:return None
    ancestors=tuple(sorted(set(closure)-{canon}))
    payload={
        'semantics_registry_entry_id':semantics_id,'source_id':profile['source_id'],
        'repository_id':profile['repository_id'],'producer_id':profile['producer_id'],
        'process_id':profile['process_id'],'failure_domain_id':profile['failure_domain_id'],
        'canonical_failure_domain_id':canon,'ancestor_failure_domain_ids_hash':sha(ancestors),
        'source_common_mode_ids_hash':sha(cm),'resolution_state':profile['resolution_state'],
        'semantics_entry_hash':canonical_hash(profile),'source_semantics_policy_hash':source_semantics_policy_hash(),
        'failure_domain_relation_registry_hash':failure_domain_relation_registry_hash(),'result':'PASS',
    }
    return SourceSemanticsResolutionCertificate(sha(payload),**payload)

def issue_source_semantics_resolution_certificate(semantics_id):
    cert=make_source_semantics_resolution_certificate(semantics_id)
    if cert is None:raise ValueError('source semantics resolution certificate cannot be issued')
    SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY[semantics_id]=cert
    return cert

def validate_source_semantics_resolution_certificate(cert):
    if cert is None:return False
    fresh=make_source_semantics_resolution_certificate(cert.semantics_registry_entry_id)
    return fresh is not None and asdict(fresh)==asdict(cert)

def register_source_semantics(semantics_id,source_id,repository_id,producer_id,process_id,failure_domain_id,
                              authority_id='LOCAL_SOURCE_SEMANTICS_AUTHORITY',resolution_state='KNOWN',
                              source_common_mode_ids=(),issue_resolution_certificate=True):
    vals=[semantics_id,source_id,repository_id,producer_id,process_id,failure_domain_id,authority_id,resolution_state]
    if not all(nonblank(x) for x in vals):raise ValueError('invalid source semantics registration')
    if authority_id not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):raise ValueError('unauthorized source semantics authority')
    if resolution_state not in set(SOURCE_SEMANTICS_POLICY['allowed_resolution_states']):raise ValueError('invalid source semantics resolution state')
    cm=tuple(sorted(set(source_common_mode_ids or ())))
    if any(not nonblank(x) for x in cm):raise ValueError('invalid source common mode id')
    SOURCE_SEMANTICS_REGISTRY[semantics_id]={
        'source_id':source_id,'repository_id':repository_id,'producer_id':producer_id,
        'process_id':process_id,'failure_domain_id':failure_domain_id,'authority_id':authority_id,
        'resolution_state':resolution_state,'source_common_mode_ids':cm,
    }
    if issue_resolution_certificate:
        issue_source_semantics_resolution_certificate(semantics_id)

def _resolution_cert_for_semantics(semantics_id):
    cert=SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(semantics_id)
    return cert if validate_source_semantics_resolution_certificate(cert) else None

def make_source_failure_domain_certificate(eid,prov,auth,semantics_id=None):
    if prov is None or auth is None or not validate_provenance(prov,eid):return None
    synthetic=semantics_id is None
    sid=semantics_id or 'SOURCE_DEFAULT_FROM_ID'
    if semantics_id:
        profile=SOURCE_SEMANTICS_REGISTRY.get(semantics_id)
        if profile is None or profile.get('source_id')!=prov.source_id:return None
        resolution_cert=_resolution_cert_for_semantics(semantics_id)
        if resolution_cert is None:return None
    else:
        profile=_default_source_profile(prov.source_id);resolution_cert=None
    required=('repository_id','producer_id','process_id','failure_domain_id','authority_id','resolution_state')
    if not all(nonblank(profile.get(k)) for k in required):return None
    if profile['authority_id'] not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):return None
    cm=_semantics_common_modes(profile)
    canon=canonical_failure_domain_id(profile['failure_domain_id'])
    closure=failure_domain_closure(profile['failure_domain_id'])
    if cm is None or canon is None or closure is None:return None
    ancestors=tuple(sorted(set(closure)-{canon}))
    nodes=(
        typed_node('SOURCE','',prov.source_id),
        typed_node('SOURCE_REPOSITORY','source',profile['repository_id']),
        typed_node('SOURCE_PRODUCER','source',profile['producer_id']),
        typed_node('SOURCE_PROCESS','source',profile['process_id']),
        typed_node('FAILURE_DOMAIN','source',canon),
    )
    if any(n is None for n in nodes):return None
    entry_hash=canonical_hash(profile)
    payload={
        'evidence_id':eid,'source_id':prov.source_id,'repository_id':profile['repository_id'],
        'producer_id':profile['producer_id'],'process_id':profile['process_id'],
        'failure_domain_id':profile['failure_domain_id'],'canonical_failure_domain_id':canon,
        'semantics_registry_entry_id':sid,'semantics_authority_id':profile['authority_id'],
        'resolution_state':profile['resolution_state'],'synthetic_profile':synthetic,
        'ancestor_failure_domain_ids_hash':sha(ancestors),'source_common_mode_ids_hash':sha(cm),
        'source_semantics_resolution_certificate_id':'' if resolution_cert is None else resolution_cert.certificate_id,
        'provenance_certificate_id':prov.certificate_id,'authority_certificate_id':auth.certificate_id,
        'source_policy_hash':source_independence_policy_hash(),'source_semantics_policy_hash':source_semantics_policy_hash(),
        'semantics_entry_hash':entry_hash,'result':'PASS',
    }
    return SourceFailureDomainCertificate(sha(payload),**payload)

def validate_source_failure_domain_certificate(cert,prov,auth,eid):
    if cert is None:return False
    sid=None if cert.semantics_registry_entry_id=='SOURCE_DEFAULT_FROM_ID' else cert.semantics_registry_entry_id
    fresh=make_source_failure_domain_certificate(eid,prov,auth,sid)
    return fresh is not None and asdict(fresh)==asdict(cert)

def source_resolution_valid_for_independence(f):
    s=f.source_failure_domain
    if s.synthetic_profile or s.resolution_state!=SOURCE_SEMANTICS_POLICY['resolved_state']:return False
    cert=getattr(f,'source_semantics_resolution',None)
    return (cert is not None and validate_source_semantics_resolution_certificate(cert)
            and cert.certificate_id==s.source_semantics_resolution_certificate_id)

def source_failure_domain_nodes(f):
    s=f.source_failure_domain
    closure=failure_domain_closure(s.failure_domain_id)
    if closure is None:return set()
    canon=canonical_failure_domain_id(s.failure_domain_id)
    nodes={('FAILURE_DOMAIN','source',canon)}
    nodes|={('FAILURE_DOMAIN_ANCESTOR','source',x) for x in closure if x!=canon}
    return nodes

def source_common_mode_ids(f):
    s=f.source_failure_domain
    if s.semantics_registry_entry_id=='SOURCE_DEFAULT_FROM_ID':return set()
    profile=SOURCE_SEMANTICS_REGISTRY.get(s.semantics_registry_entry_id)
    cm=_semantics_common_modes(profile or {})
    return set(cm or ())

def source_semantic_nodes(f):
    s=f.source_failure_domain
    nodes={
        ('SOURCE','',s.source_id),
        ('SOURCE_REPOSITORY','source',s.repository_id),
        ('SOURCE_PRODUCER','source',s.producer_id),
        ('SOURCE_PROCESS','source',s.process_id),
    }
    nodes|=source_failure_domain_nodes(f)
    nodes|={('SOURCE_COMMON_MODE','source',x) for x in source_common_mode_ids(f)}
    return nodes

def _shared_failure_domain_nodes(a,b):
    ca=failure_domain_closure(a.source_failure_domain.failure_domain_id)
    cb=failure_domain_closure(b.source_failure_domain.failure_domain_id)
    if ca is None or cb is None:return None
    shared=set(ca)&set(cb)
    return sorted(('FAILURE_DOMAIN' if x in {canonical_failure_domain_id(a.source_failure_domain.failure_domain_id),canonical_failure_domain_id(b.source_failure_domain.failure_domain_id)} else 'FAILURE_DOMAIN_ANCESTOR','source',x) for x in shared)

def authorize_source_independence(independence_id,a,b,reason,authorizer_id='LOCAL_SOURCE_INDEPENDENCE_AUTHORITY'):
    if not all(nonblank(x) for x in (independence_id,reason,authorizer_id)):raise ValueError('invalid source independence authorization')
    if authorizer_id not in set(SOURCE_INDEPENDENCE_POLICY['allowed_authorizers']):raise ValueError('unauthorized source independence authorizer')
    if not source_resolution_valid_for_independence(a) or not source_resolution_valid_for_independence(b):
        raise ValueError('source semantics must be KNOWN before independence authorization')
    shared_fd=_shared_failure_domain_nodes(a,b)
    if shared_fd is None or shared_fd:raise ValueError('shared failure-domain closure cannot be authorized as independent in v0.2.20')
    if source_common_mode_ids(a)&source_common_mode_ids(b):raise ValueError('shared source common mode cannot be certified away')
    pair=tuple(sorted((a,b),key=lambda f:f.evidence_id))
    fds=tuple(sorted(canonical_failure_domain_id(f.source_failure_domain.failure_domain_id) for f in pair))
    SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY[independence_id]={
        'evidence_ids':tuple(f.evidence_id for f in pair),
        'source_ids':tuple(f.source_failure_domain.source_id for f in pair),
        'failure_domain_ids':fds,
        'generation_process_ids':tuple(f.source_failure_domain.process_id for f in pair),
        'source_semantics_resolution_certificate_ids':tuple(f.source_semantics_resolution.certificate_id for f in pair),
        'reason':reason,'authorizer_id':authorizer_id,'policy_id':SOURCE_INDEPENDENCE_POLICY['policy_id'],
    }

def make_source_independence_certificate(independence_id,a,b):
    r=SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.get(independence_id)
    if r is None:return None
    pair=tuple(sorted((a,b),key=lambda f:f.evidence_id))
    if not all(source_resolution_valid_for_independence(f) for f in pair):return None
    if tuple(f.evidence_id for f in pair)!=tuple(r['evidence_ids']):return None
    if tuple(f.source_failure_domain.source_id for f in pair)!=tuple(r['source_ids']):return None
    fds=tuple(sorted(canonical_failure_domain_id(f.source_failure_domain.failure_domain_id) for f in pair))
    if fds!=tuple(r['failure_domain_ids']) or len(set(fds))!=2:return None
    if _shared_failure_domain_nodes(*pair):return None
    if source_common_mode_ids(pair[0])&source_common_mode_ids(pair[1]):return None
    if tuple(f.source_failure_domain.process_id for f in pair)!=tuple(r['generation_process_ids']):return None
    res_ids=tuple(f.source_semantics_resolution.certificate_id for f in pair)
    if res_ids!=tuple(r['source_semantics_resolution_certificate_ids']):return None
    if r['authorizer_id'] not in set(SOURCE_INDEPENDENCE_POLICY['allowed_authorizers']):return None
    if r['policy_id']!=SOURCE_INDEPENDENCE_POLICY['policy_id'] or not nonblank(r['reason']):return None
    shared_dimensions=[]
    sa,sb=(f.source_failure_domain for f in pair)
    if sa.source_id==sb.source_id:shared_dimensions.append('SOURCE')
    if sa.repository_id==sb.repository_id:shared_dimensions.append('SOURCE_REPOSITORY')
    if sa.producer_id==sb.producer_id:shared_dimensions.append('SOURCE_PRODUCER')
    if sa.process_id==sb.process_id:shared_dimensions.append('SOURCE_PROCESS')
    if not shared_dimensions:return None
    payload={
        'independence_id':independence_id,
        'evidence_ids_hash':sha(tuple(f.evidence_id for f in pair)),
        'source_ids_hash':sha(tuple(f.source_failure_domain.source_id for f in pair)),
        'failure_domain_ids_hash':sha(fds),
        'generation_process_ids_hash':sha(tuple(f.source_failure_domain.process_id for f in pair)),
        'authority_certificate_ids_hash':sha(tuple(f.authority.certificate_id for f in pair)),
        'provenance_certificate_ids_hash':sha(tuple(f.provenance.certificate_id for f in pair)),
        'source_failure_domain_certificate_ids_hash':sha(tuple(f.source_failure_domain.certificate_id for f in pair)),
        'source_semantics_resolution_certificate_ids_hash':sha(res_ids),
        'failure_domain_relation_registry_hash':failure_domain_relation_registry_hash(),
        'justification_reason_hash':sha(r['reason']),'authorizer_id':r['authorizer_id'],'policy_id':r['policy_id'],
        'authorization_entry_hash':canonical_hash(r),'source_policy_hash':source_independence_policy_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),'ontology_hash':dependency_ontology_hash(),'result':'PASS',
    }
    return SourceIndependenceCertificate(sha(payload),**payload)

def issue_source_independence_certificate(independence_id,a,b):
    cert=make_source_independence_certificate(independence_id,a,b)
    if cert is None:raise ValueError('source independence certificate cannot be issued')
    SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY[independence_id]=cert
    return cert

def validate_source_independence_certificate(cert,a,b):
    if cert is None:return False
    fresh=make_source_independence_certificate(cert.independence_id,a,b)
    return fresh is not None and asdict(fresh)==asdict(cert)

def _valid_source_independence_certificate(a,b):
    if not source_independence_certificate_registry_coherent():return None
    matches=[]
    for registry_key,cert in SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.items():
        if registry_key!=getattr(cert,'independence_id',None):return None
        if validate_source_independence_certificate(cert,a,b):matches.append(cert)
    return matches[0] if len(matches)==1 else None

def evaluate_source_relation(a,b):
    if not validate_source_failure_domain_certificate(a.source_failure_domain,a.provenance,a.authority,a.evidence_id):
        return False,'SOURCE_RELATION_UNRESOLVED',[('SOURCE_RELATION','','INVALID_SOURCE_PROFILE:'+a.evidence_id)],None
    if not validate_source_failure_domain_certificate(b.source_failure_domain,b.provenance,b.authority,b.evidence_id):
        return False,'SOURCE_RELATION_UNRESOLVED',[('SOURCE_RELATION','','INVALID_SOURCE_PROFILE:'+b.evidence_id)],None
    shared_fd=_shared_failure_domain_nodes(a,b)
    if shared_fd is None:
        return False,'SOURCE_RELATION_UNRESOLVED',[('SOURCE_RELATION','','INVALID_FAILURE_DOMAIN_CLOSURE')],None
    if shared_fd:
        return False,'SOURCE_SHARED_DEPENDENCY',shared_fd,None
    shared_cm=sorted(source_common_mode_ids(a)&source_common_mode_ids(b))
    if shared_cm:
        return False,'SOURCE_SHARED_DEPENDENCY',[('SOURCE_COMMON_MODE','source',x) for x in shared_cm],None
    # Key R20 invariant: absence of a known shared FD is not a proof of distinctness.
    if not source_resolution_valid_for_independence(a) or not source_resolution_valid_for_independence(b):
        diag=[]
        if not source_resolution_valid_for_independence(a):diag.append(('SOURCE_RELATION','',f'SOURCE_SEMANTICS_UNRESOLVED:{a.evidence_id}'))
        if not source_resolution_valid_for_independence(b):diag.append(('SOURCE_RELATION','',f'SOURCE_SEMANTICS_UNRESOLVED:{b.evidence_id}'))
        return False,'SOURCE_RELATION_UNRESOLVED',diag,None
    sa,sb=a.source_failure_domain,b.source_failure_domain
    shared=[]
    for typ,va,vb in (
        ('SOURCE',sa.source_id,sb.source_id),('SOURCE_REPOSITORY',sa.repository_id,sb.repository_id),
        ('SOURCE_PRODUCER',sa.producer_id,sb.producer_id),('SOURCE_PROCESS',sa.process_id,sb.process_id)):
        if va==vb:shared.append((typ,'source' if typ!='SOURCE' else '',va))
    if shared:
        cert=_valid_source_independence_certificate(a,b)
        if cert is None:
            return False,'SOURCE_RELATION_UNRESOLVED',shared+[('SOURCE_RELATION','','SOURCE_INDEPENDENCE_CERTIFICATE_REQUIRED')],None
        return True,'SOURCE_INDEPENDENCE_JUSTIFIED',shared,cert
    return True,'SOURCE_INDEPENDENCE_DISTINCT',[],None

def source_relation_assessment(facts):
    ledger=[];cert_ids=[]
    for a,b in combinations(tuple(facts),2):
        ok,state,diag,cert=evaluate_source_relation(a,b)
        ledger.append((a.evidence_id,b.evidence_id,state,tuple(sorted(diag)),None if cert is None else cert.certificate_id))
        if cert is not None:cert_ids.append(cert.certificate_id)
        if not ok:return False,diag,tuple(sorted(set(cert_ids))),tuple(ledger)
    return True,[],tuple(sorted(set(cert_ids))),tuple(ledger)

def register_support_set_common_mode(common_mode_id,evidence_ids,reason,authority_id='LOCAL_SOURCE_SEMANTICS_AUTHORITY',
                                     relation_effect='UNKNOWN',claim_id='*',retrieval_scope_id='*'):
    eids=tuple(sorted(set(evidence_ids or ())))
    if common_mode_id in SUPPORT_SET_COMMON_MODE_REGISTRY:raise ValueError('duplicate support-set relation id')
    if not nonblank(common_mode_id) or len(eids)<2 or any(not nonblank(x) for x in eids) or not nonblank(reason):
        raise ValueError('invalid support-set common mode')
    if authority_id not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):raise ValueError('unauthorized common-mode authority')
    if relation_effect not in set(RELATION_EFFECTS):raise ValueError('invalid relation effect')
    if not nonblank(claim_id) or not nonblank(retrieval_scope_id):raise ValueError('invalid relation scope')
    SUPPORT_SET_COMMON_MODE_REGISTRY[common_mode_id]={
        'relation':'COMMON_MODE','relation_effect':relation_effect,
        'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,'evidence_ids':eids,
        'reason':reason,'authority_id':authority_id,'policy_id':RELATION_RESOLUTION_POLICY['policy_id'],
    }

def register_support_set_unknown(relation_id,claim_id,retrieval_scope_id,evidence_ids,reason,
                                 authority_id='LOCAL_SOURCE_SEMANTICS_AUTHORITY'):
    eids=tuple(sorted(set(evidence_ids or ())))
    if relation_id in SUPPORT_SET_COMMON_MODE_REGISTRY:raise ValueError('duplicate support-set relation id')
    if not all(nonblank(x) for x in (relation_id,claim_id,retrieval_scope_id,reason)) or len(eids)<2:
        raise ValueError('invalid support-set unknown relation')
    SUPPORT_SET_COMMON_MODE_REGISTRY[relation_id]={
        'relation':'UNKNOWN','relation_effect':'UNKNOWN',
        'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,'evidence_ids':eids,
        'reason':reason,'authority_id':authority_id,'policy_id':RELATION_RESOLUTION_POLICY['policy_id'],
    }

def _support_set_blocking_relation(eids):
    # Downward-monotone common-mode semantics: a relation that contains two selected
    # members remains relevant even when it also contains evidence outside the subset.
    es=set(eids)
    for rid,r in SUPPORT_SET_COMMON_MODE_REGISTRY.items():
        rs=set(r.get('evidence_ids',()))
        if len(rs)>=2 and len(rs & es)>=2 and r.get('relation') in {'COMMON_MODE','UNKNOWN'}:
            return rid,r
    return None

def _relevant_support_set_relation_hash(eids):
    es=set(eids);rows={}
    for rid,r in SUPPORT_SET_COMMON_MODE_REGISTRY.items():
        rs=set(r.get('evidence_ids',()));rel=r.get('relation')
        if len(rs)<2:continue
        if (rel in {'COMMON_MODE','UNKNOWN'} and len(rs & es)>=2) or (rel=='INDEPENDENT' and rs.issubset(es)):
            rows[rid]=r
    return canonical_hash(rows)

def _equivalence_context_date_for_facts(facts,as_of_date=None):
    if as_of_date is not None:
        try:strict_date(as_of_date);return as_of_date
        except Exception:return None
    vals={getattr(getattr(f,'temporal',None),'available_at',None) for f in tuple(facts)}
    vals.discard(None)
    if len(vals)==1:
        v=next(iter(vals))
        try:strict_date(v);return v
        except Exception:return None
    obs={getattr(getattr(f,'temporal',None),'observed_at',None) for f in tuple(facts)}
    obs.discard(None)
    if len(obs)==1:
        v=next(iter(obs))
        try:strict_date(v);return v
        except Exception:return None
    return None


def authorize_support_set_independence(independence_id,claim_id,retrieval_scope_id,facts,reason,
                                       authorizer_id='LOCAL_SOURCE_SEMANTICS_AUTHORITY',as_of_date=None):
    facts=tuple(sorted(tuple(facts),key=lambda f:f.evidence_id));eids=tuple(f.evidence_id for f in facts)
    if independence_id in SUPPORT_SET_COMMON_MODE_REGISTRY:raise ValueError('duplicate support-set relation id')
    if not all(nonblank(x) for x in (independence_id,claim_id,retrieval_scope_id,reason,authorizer_id)) or len(facts)<2:
        raise ValueError('invalid support-set independence authorization')
    if retrieval_scope_id not in RETRIEVAL_SCOPE_REGISTRY:raise ValueError('unknown retrieval scope')
    if authorizer_id not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):raise ValueError('unauthorized set independence authority')
    if not all(source_resolution_valid_for_independence(f) for f in facts):raise ValueError('source semantics unresolved')
    eq_asof=_equivalence_context_date_for_facts(facts,as_of_date)
    if eq_asof is None:raise ValueError('equivalence context date unresolved')
    ok,diag,_,_= _independence_assessment(facts,eq_asof,retrieval_scope_id)
    if not ok:raise ValueError(f'pairwise dependency prevents set independence: {diag}')
    if _support_set_blocking_relation(eids) is not None:raise ValueError('support set has COMMON_MODE/UNKNOWN relation')
    SUPPORT_SET_COMMON_MODE_REGISTRY[independence_id]={
        'relation':'INDEPENDENT','relation_effect':'NON_DECISION_RELEVANT',
        'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,'evidence_ids':eids,
        'reason':reason,'authority_id':authorizer_id,'policy_id':SOURCE_SEMANTICS_POLICY['policy_id'],
        'equivalence_as_of_date':eq_asof,
        'generic_equivalence_contextual_resolution_hash':generic_equivalence_contextual_resolution_state(eq_asof,retrieval_scope_id)['contextual_resolution_hash'],
    }

def make_support_set_independence_certificate(independence_id,claim_id,retrieval_scope_id,facts,as_of_date=None):
    r=SUPPORT_SET_COMMON_MODE_REGISTRY.get(independence_id)
    facts=tuple(sorted(tuple(facts),key=lambda f:f.evidence_id));eids=tuple(f.evidence_id for f in facts)
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None or rr is None or len(facts)<2:return None
    if r.get('relation')!='INDEPENDENT' or r.get('claim_id')!=claim_id or r.get('retrieval_scope_id')!=retrieval_scope_id:return None
    if tuple(r.get('evidence_ids',()))!=eids:return None
    if r.get('policy_id')!=SOURCE_SEMANTICS_POLICY['policy_id'] or r.get('authority_id') not in set(SOURCE_SEMANTICS_POLICY['allowed_semantics_authorities']):return None
    if not all(source_resolution_valid_for_independence(f) for f in facts):return None
    if _support_set_blocking_relation(eids) is not None:return None
    eq_asof=_equivalence_context_date_for_facts(facts,as_of_date)
    if eq_asof is None:return None
    eq_state=generic_equivalence_contextual_resolution_state(eq_asof,retrieval_scope_id)
    if eq_state['invalid_ids'] or eq_state['conflicts']:return None
    if r.get('equivalence_as_of_date')!=eq_asof or r.get('generic_equivalence_contextual_resolution_hash')!=eq_state['contextual_resolution_hash']:return None
    ok,diag,source_cert_ids,ledger=_independence_assessment(facts,eq_asof,retrieval_scope_id)
    if not ok:return None
    closures=[]
    for f in facts:
        cl=failure_domain_closure(f.source_failure_domain.failure_domain_id)
        if cl is None:return None
        closures.append((f.evidence_id,tuple(sorted(cl)),tuple(sorted(source_common_mode_ids(f)))))
    res_ids=tuple(sorted(f.source_semantics_resolution.certificate_id for f in facts))
    payload={
        'independence_id':independence_id,'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,
        'retrieval_snapshot_id':rr['snapshot_id'],'support_ids_hash':sha(eids),
        'source_semantics_resolution_certificate_ids_hash':sha(res_ids),
        'failure_domain_closure_hash':sha(closures),'source_relation_ledger_hash':sha(ledger),
        'set_relation_entry_hash':canonical_hash(r),'set_common_mode_registry_hash':_relevant_support_set_relation_hash(eids),
        'equivalence_as_of_date':eq_asof,'generic_equivalence_contextual_resolution_hash':eq_state['contextual_resolution_hash'],
        'source_policy_hash':source_independence_policy_hash(),'source_semantics_policy_hash':source_semantics_policy_hash(),
        'ontology_hash':dependency_ontology_hash(),'result':'PASS',
    }
    return SupportSetIndependenceCertificate(sha(payload),**payload)

def issue_support_set_independence_certificate(independence_id,claim_id,retrieval_scope_id,facts,as_of_date=None):
    cert=make_support_set_independence_certificate(independence_id,claim_id,retrieval_scope_id,facts,as_of_date)
    if cert is None:raise ValueError('support-set independence certificate cannot be issued')
    SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY[independence_id]=cert
    return cert

def validate_support_set_independence_certificate(cert,claim_id,retrieval_scope_id,facts,as_of_date=None):
    if cert is None:return False
    effective_asof=as_of_date if as_of_date is not None else getattr(cert,'equivalence_as_of_date',None)
    fresh=make_support_set_independence_certificate(cert.independence_id,claim_id,retrieval_scope_id,facts,effective_asof)
    return fresh is not None and asdict(fresh)==asdict(cert)

def _valid_support_set_independence_certificate(claim_id,retrieval_scope_id,facts,as_of_date=None):
    if not support_set_independence_certificate_registry_coherent():return None
    matches=[]
    for registry_key,cert in SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.items():
        if registry_key!=getattr(cert,'independence_id',None):return None
        if validate_support_set_independence_certificate(cert,claim_id,retrieval_scope_id,facts,as_of_date):matches.append(cert)
    return matches[0] if len(matches)==1 else None

# ============================================================
# Temporal
# ============================================================

def make_temporal(vf,vt,obs,avail):
    try: a,b,o,av=strict_date(vf),strict_date(vt),strict_date(obs),strict_date(avail)
    except: return None
    if not (a<=o<=b) or o>av: return None
    payload={'valid_from':vf,'valid_to':vt,'observed_at':obs,'available_at':avail}
    return TemporalCertificate(sha(payload),**payload)
def validate_temporal(t):
    fresh=make_temporal(t.valid_from,t.valid_to,t.observed_at,t.available_at); return fresh is not None and asdict(fresh)==asdict(t)
def world_active(t,asof):
    try:return strict_date(t.valid_from)<=strict_date(asof)<=strict_date(t.valid_to)
    except:return False
def epistemically_available(t,asof):
    try:return strict_date(t.observed_at)<=strict_date(t.available_at)<=strict_date(asof)
    except:return False
def temporal_overlap(a,b): return max(strict_date(a.valid_from),strict_date(b.valid_from))<=min(strict_date(a.valid_to),strict_date(b.valid_to))


# ============================================================
# Provenance
# ============================================================

PROV_KEYS={'source_id','root_origin_id','origin_id','referent_entity_id','referent_event_id','referent_version_id','extractor_id','common_mode_group','lineage','dependencies'}

def make_provenance(eid,p):
    if not isinstance(p,dict) or set(p.keys())!=PROV_KEYS: return None
    lin=p.get('lineage'); deps=normalize_dependencies(p.get('dependencies')); rawdeps=raw_dependencies(p.get('dependencies'))
    required=[p.get(k) for k in ['source_id','root_origin_id','origin_id','referent_entity_id','referent_event_id','referent_version_id','extractor_id','common_mode_group']]
    if not all(nonblank(x) for x in required) or not isinstance(lin,(list,tuple)) or not lin or deps is None or rawdeps is None:return None
    if canonical_dependency_id('extractor',p['extractor_id']) is None:return None
    lin=tuple(lin)
    if lin[0]!=p['root_origin_id'] or lin[-1]!=p['origin_id'] or len(set(lin))!=len(lin):return None
    payload={'evidence_id':eid,'source_id':p['source_id'],'root_origin_id':p['root_origin_id'],'origin_id':p['origin_id'],'referent_entity_id':p['referent_entity_id'],'referent_event_id':p['referent_event_id'],'referent_version_id':p['referent_version_id'],'extractor_id':p['extractor_id'],'common_mode_group':p['common_mode_group'],'lineage':list(lin),'dependencies':list(deps),'raw_dependencies':list(rawdeps)}
    return ProvenanceCertificate(sha(payload),eid,p['source_id'],p['root_origin_id'],p['origin_id'],p['referent_entity_id'],p['referent_event_id'],p['referent_version_id'],p['extractor_id'],p['common_mode_group'],lin,deps,rawdeps)
def validate_provenance(p,eid):
    depmap={}
    rawmap={d:(state,raw_id,jid) for d,state,raw_id,jid in p.raw_dependencies}
    if set(rawmap)!=set(DEPENDENCY_DIMENSIONS):return False
    for d,s,i,jc in p.dependencies:
        raw=rawmap.get(d)
        if raw is None or raw[0]!=s:return False
        row={'state':s}
        if s=='KNOWN':
            row['id']=raw[1]
            if canonical_dependency_id(d,raw[1])!=i:return False
        elif s in PROVENANCE_POLICY['justification_required_states']:
            jid=raw[2]
            c=make_dependency_justification_certificate(jid,d,s) if nonblank(jid) else None
            if c is None or c.certificate_id!=jc:return False
            row['justification_id']=jid
        depmap[d]=row
    fresh=make_provenance(eid,{'source_id':p.source_id,'root_origin_id':p.root_origin_id,'origin_id':p.origin_id,'referent_entity_id':p.referent_entity_id,'referent_event_id':p.referent_event_id,'referent_version_id':p.referent_version_id,'extractor_id':p.extractor_id,'common_mode_group':p.common_mode_group,'lineage':list(p.lineage),'dependencies':depmap})
    return fresh is not None and asdict(fresh)==asdict(p)

def make_prov_complete(eid,p):
    if p is None:return None
    payload={'evidence_id':eid,'provenance_certificate_id':p.certificate_id,'required_dimensions_hash':sha(list(DEPENDENCY_DIMENSIONS)),'declared_dimensions_hash':sha(list(p.dependencies)),'completeness_result':'PASS'}
    return ProvenanceCompletenessCertificate(sha(payload),**payload)
def validate_prov_complete(c,p,eid):
    fresh=make_prov_complete(eid,p);return fresh is not None and asdict(fresh)==asdict(c)


def make_dependency_ontology_conformance_certificate(eid,prov):
    if prov is None or not validate_provenance(prov,eid):return None
    rawmap={d:(state,raw_id,jid) for d,state,raw_id,jid in prov.raw_dependencies}
    depmap={d:(state,cid,jcert) for d,state,cid,jcert in prov.dependencies}
    if set(rawmap)!=set(DEPENDENCY_DIMENSIONS) or set(depmap)!=set(DEPENDENCY_DIMENSIONS):return None
    entries=[];allowed=set(PROVENANCE_POLICY['allowed_shared_nodes'])
    for dim in DEPENDENCY_DIMENSIONS:
        rstate,raw_id,jid=rawmap[dim]; state,cid,jcert=depmap[dim]
        if state!=rstate:return None
        prefix=DEPENDENCY_PREFIX[dim]
        if state=='KNOWN':
            canonical=canonical_dependency_id(dim,raw_id)
            if canonical is None or canonical!=cid:return None
            node=typed_dependency_node(dim,canonical)
            if node is None:return None
            classification='ALLOWED_SHARED' if node in allowed else 'NOT_ALLOWED_SHARED'
            node_type='DEPENDENCY'
        else:
            if raw_id!='' or cid!='':return None
            canonical=''
            node_type='JUSTIFICATION' if state in PROVENANCE_POLICY['justification_required_states'] else 'DEPENDENCY_STATE'
            classification='NOT_ALLOWED_SHARED'
        entries.append((dim,state,raw_id,canonical,prefix,node_type,classification))
    payload={'evidence_id':eid,'provenance_certificate_id':prov.certificate_id,'dependency_entries':tuple(entries),
             'ontology_hash':dependency_ontology_hash(),
             'allowed_shared_nodes_hash':canonical_hash(PROVENANCE_POLICY['allowed_shared_nodes']),
             'conformance_result':'PASS'}
    return DependencyOntologyConformanceCertificate(sha(payload),**payload)

def validate_dependency_ontology_conformance_certificate(cert,prov,eid):
    if cert is None:return False
    fresh=make_dependency_ontology_conformance_certificate(eid,prov)
    return fresh is not None and asdict(fresh)==asdict(cert)

def dependency_instance_ontology_conformance_valid(facts):
    return bool(facts) and all(validate_dependency_ontology_conformance_certificate(
        f.dependency_ontology_conformance,f.provenance,f.evidence_id) for f in facts)
def justification_certificate_from_id(cert_id,dim,state):
    for jid,r in DEPENDENCY_JUSTIFICATION_REGISTRY.items():
        if r['dimension']==dim and r['state']==state:
            c=make_dependency_justification_certificate(jid,dim,state)
            if c is not None and c.certificate_id==cert_id:
                return c,jid,r
    return None,None,None

def justification_dependency_nodes(dim,state,cert_id):
    cert,jid,r=justification_certificate_from_id(cert_id,dim,state)
    if cert is None:return {('JUSTIFICATION',dim,f'invalid:{state}')}
    nodes={
        ('JUSTIFICATION',dim,f'certificate:{cert.certificate_id}'),
        ('JUSTIFICATION',dim,f'authority:{cert.authority_id}'),
        ('JUSTIFICATION',dim,f'scope:{cert.scope_id}'),
        ('JUSTIFICATION',dim,f'reason:{cert.reason_hash}'),
        ('JUSTIFICATION',dim,f'registry:{cert.registry_hash}'),
        ('JUSTIFICATION',dim,f'rule:{r["rule_id"]}'),
        ('JUSTIFICATION',dim,f'source:{r["source_id"]}'),
        ('JUSTIFICATION',dim,f'validator:{r["validator_id"]}'),
    }
    if state=='KNOWN_NONE':nodes.add(('DEPENDENCY_STATE',dim,'KNOWN_NONE'))
    if state=='NOT_APPLICABLE':nodes.add(('DEPENDENCY_STATE',dim,'NOT_APPLICABLE'))
    return nodes

def dependency_nodes(f):
    nodes={('LINEAGE','',x) for x in f.provenance.lineage}
    nodes.add(('COMMON_MODE','',f.provenance.common_mode_group))
    for dim,state,cid,just_cert_id in f.provenance.dependencies:
        if state=='KNOWN':
            node=typed_dependency_node(dim,cid)
            if node is not None:nodes.add(node)
            else:nodes.add(('DEPENDENCY',dim,f'INVALID:{cid}'))
        elif state in PROVENANCE_POLICY['justification_required_states']:
            nodes |= justification_dependency_nodes(dim,state,just_cert_id)
    extractor_cid=canonical_dependency_id('extractor',f.provenance.extractor_id)
    extractor_local=dependency_local_id('extractor',extractor_cid) if extractor_cid else None
    nodes.add(('EXTRACTOR','extractor',extractor_local or f'INVALID:{f.provenance.extractor_id}'))
    nodes |= source_semantic_nodes(f)
    return nodes

def raw_generic_dependency_nodes(f):
    return {n for n in dependency_nodes(f) if n[0] not in SOURCE_SEMANTIC_NODE_TYPES}

def canonical_generic_dependency_node(raw_node,as_of_date=None,retrieval_scope_id=None):
    if not isinstance(raw_node,tuple) or len(raw_node)!=3:return None
    nt,dim,ident=raw_node
    if nt in SOURCE_SEMANTIC_NODE_TYPES or not isinstance(ident,str) or not ident:return None
    mapping,invalid,conflicts=_resolved_equivalence_class_map(as_of_date,retrieval_scope_id)
    if invalid or conflicts:return raw_node
    mapped=mapping.get((nt,dim),tuple())
    resolved=[]
    for st,sd,isem,_ids in mapped:
        sid=_semantic_identifier(raw_node,st,sd,isem)
        if sid is not None:resolved.append((st,sd,sid))
    resolved=tuple(sorted(set(resolved)))
    if len(resolved)==1:return resolved[0]
    # zero matches preserves raw identity; multiple semantic matches fail closed by refusing canonical merge.
    return raw_node

def generic_dependency_representation_records(f,as_of_date=None,retrieval_scope_id=None):
    rows=[]
    for raw in sorted(raw_generic_dependency_nodes(f)):
        semantic=canonical_generic_dependency_node(raw,as_of_date,retrieval_scope_id)
        if semantic is None:continue
        rows.append((semantic,raw))
    return tuple(rows)

def generic_dependency_nodes(f,as_of_date=None,retrieval_scope_id=None):
    return {semantic for semantic,_ in generic_dependency_representation_records(f,as_of_date,retrieval_scope_id)}

def canonical_allowed_shared_generic_nodes(as_of_date=None,retrieval_scope_id=None):
    out=set()
    for raw in PROVENANCE_POLICY.get('allowed_shared_nodes',set()):
        semantic=canonical_generic_dependency_node(tuple(raw),as_of_date,retrieval_scope_id)
        if semantic is not None:out.add(semantic)
    return out

def pair_independence(a,b,as_of_date=None,retrieval_scope_id=None):
    equiv_diag=_fact_unresolved_equivalence_diagnostics(a,b,as_of_date,retrieval_scope_id)
    if equiv_diag:return False,sorted(equiv_diag,key=str),'GENERIC_EQUIVALENCE_UNRESOLVED',None
    allowed=canonical_allowed_shared_generic_nodes(as_of_date,retrieval_scope_id)
    shared=(generic_dependency_nodes(a,as_of_date,retrieval_scope_id)&generic_dependency_nodes(b,as_of_date,retrieval_scope_id))-allowed
    if shared:return False,sorted(shared),None,None
    source_ok,state,diag,source_cert=evaluate_source_relation(a,b)
    if not source_ok:return False,sorted(diag),state,source_cert
    return True,[],state,source_cert

def _independence_assessment(facts,as_of_date=None,retrieval_scope_id=None):
    ledger=[];source_cert_ids=[]
    for a,b in combinations(tuple(facts),2):
        ok,diag,state,source_cert=pair_independence(a,b,as_of_date,retrieval_scope_id)
        ledger.append((a.evidence_id,b.evidence_id,state or 'GENERIC_DEPENDENCY',tuple(diag),None if source_cert is None else source_cert.certificate_id))
        if source_cert is not None:source_cert_ids.append(source_cert.certificate_id)
        if not ok:return False,diag,tuple(sorted(set(source_cert_ids))),tuple(ledger)
    return True,[],tuple(sorted(set(source_cert_ids))),tuple(ledger)

def independent_subset(facts,as_of_date=None,retrieval_scope_id=None):
    ok,diag,_,_=_independence_assessment(facts,as_of_date,retrieval_scope_id)
    return ok,diag

def make_justification_independence_certificate(claim_id,facts,retrieval_scope_id=None,as_of_date=None):
    eq_asof=_equivalence_context_date_for_facts(facts,as_of_date)
    ok,shared,source_cert_ids,ledger=_independence_assessment(facts,eq_asof,retrieval_scope_id)
    if not ok:return None
    if len(tuple(facts))>1:
        if retrieval_scope_id is None:
            if not support_set_independence_certificate_registry_coherent():return None
            candidates=[]
            for registry_key,cert in SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.items():
                if registry_key!=getattr(cert,'independence_id',None):return None
                if cert.claim_id==claim_id and validate_support_set_independence_certificate(cert,claim_id,cert.retrieval_scope_id,facts,eq_asof):
                    candidates.append(cert)
            set_cert=candidates[0] if len(candidates)==1 else None
        else:
            set_cert=_valid_support_set_independence_certificate(claim_id,retrieval_scope_id,facts,eq_asof)
        if set_cert is None:return None
        set_cert_id=set_cert.certificate_id
    else:
        set_cert_id='SINGLE_SUPPORT'
    closure=sorted((f.evidence_id,sorted(dependency_nodes(f))) for f in facts)
    eq_hash=(generic_equivalence_contextual_resolution_state(eq_asof,retrieval_scope_id)['contextual_resolution_hash']
             if eq_asof is not None and retrieval_scope_id is not None else sha(('NO_EQ_CONTEXT',eq_asof,retrieval_scope_id)))
    payload={'claim_id':claim_id,'support_ids_hash':sha(sorted(f.evidence_id for f in facts)),
             'full_dependency_closure_hash':sha((closure,eq_hash)),'source_relation_ledger_hash':sha(ledger),
             'source_independence_certificate_ids_hash':sha(source_cert_ids),
             'support_set_independence_certificate_id':set_cert_id,
             'policy_hash':sha({'provenance':provenance_policy_hash(),'source':source_independence_policy_hash(),
                                'source_semantics':source_semantics_policy_hash(),'set_common_mode':support_set_common_mode_registry_hash(),
                                'generic_equivalence_contextual_resolution_hash':eq_hash}),
             'independence_result':'PASS'}
    return JustificationIndependenceCertificate(sha(payload),**payload)

def validate_justification_independence_certificate(cert,claim_id,facts,retrieval_scope_id=None,as_of_date=None):
    fresh=make_justification_independence_certificate(claim_id,facts,retrieval_scope_id,as_of_date)
    return fresh is not None and asdict(fresh)==asdict(cert)


# ============================================================
# Authority / referent consistency
# ============================================================

def make_authority(eid,authority_id,predicate,eidcert,prov,record_entity_id,record_event_id,record_version_id):
    pol=AUTHORITY_POLICIES.get(authority_id)
    if pol is None:return None
    if pkey(predicate) not in pol['predicates'] or eidcert.domain_id not in pol['domains']:return None
    if not prov.source_id.startswith(pol['source_prefix']) or not prov.root_origin_id.startswith(pol['root_prefix']):return None
    if (record_entity_id,record_event_id,record_version_id)!=identity_tuple(eidcert):return None
    payload={'evidence_id':eid,'authority_id':authority_id,'predicate':pkey(predicate),'record_entity_id':record_entity_id,'record_event_id':record_event_id,'record_version_id':record_version_id,'evidence_identity_certificate_id':eidcert.certificate_id,'provenance_certificate_id':prov.certificate_id,'policy_fingerprint':canonical_hash(pol)}
    return AuthorityCertificate(sha(payload),**payload)
def validate_authority(a,f):
    fresh=make_authority(f.evidence_id,a.authority_id,f.predicate,f.identity,f.provenance,a.record_entity_id,a.record_event_id,a.record_version_id)
    return fresh is not None and asdict(fresh)==asdict(a)
def make_referent_consistency(c,f):
    tup=identity_tuple(c.identity)
    if identity_tuple(f.identity)!=tup:return None
    if (f.provenance.referent_entity_id,f.provenance.referent_event_id,f.provenance.referent_version_id)!=tup:return None
    if (f.authority.record_entity_id,f.authority.record_event_id,f.authority.record_version_id)!=tup:return None
    payload={'claim_id':c.id,'evidence_id':f.evidence_id,'claim_identity_certificate_id':c.identity.certificate_id,'evidence_identity_certificate_id':f.identity.certificate_id,'authority_certificate_id':f.authority.certificate_id,'provenance_certificate_id':f.provenance.certificate_id,'identity_tuple_hash':sha(tup),'consistency_result':'PASS'}
    return ReferentConsistencyCertificate(sha(payload),**payload)
def validate_referent_consistency(rc,c,f):
    fresh=make_referent_consistency(c,f);return fresh is not None and asdict(fresh)==asdict(rc)


# ============================================================
# Evidence-set coverage + snapshot content integrity
# ============================================================

def make_evidence_coverage(retrieval_scope_id,evidence):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None:return None
    expected=tuple(sorted(r['expected_evidence_ids']))
    supplied=tuple(sorted(x.get('evidence_id') for x in evidence if nonblank(x.get('evidence_id'))))
    if expected!=supplied:return None
    payload={'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':r['snapshot_id'],
             'expected_evidence_ids_hash':sha(expected),'supplied_evidence_ids_hash':sha(supplied),
             'retrieval_registry_hash':retrieval_registry_hash(),'coverage_result':'PASS'}
    return EvidenceSetCoverageCertificate(sha(payload),**payload)

def validate_evidence_coverage(cert,retrieval_scope_id,evidence):
    if cert is None:return False
    fresh=make_evidence_coverage(retrieval_scope_id,evidence)
    return fresh is not None and asdict(fresh)==asdict(cert)

def supplied_record_manifest(evidence):
    manifest={}
    for r in evidence:
        eid=r.get('evidence_id')
        if not nonblank(eid) or eid in manifest:return None
        manifest[eid]=evidence_record_hash(r)
    return manifest

def make_snapshot_content_integrity(retrieval_scope_id,evidence):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None:return None
    supplied=supplied_record_manifest(evidence)
    if supplied is None:return None
    expected=dict(r.get('expected_record_hashes') or {})
    if set(expected)!=set(supplied):return None
    if any(expected[eid]!=supplied[eid] for eid in expected):return None
    payload={'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':r['snapshot_id'],
             'expected_record_manifest_hash':sha(expected),'supplied_record_manifest_hash':sha(supplied),
             'retrieval_registry_hash':retrieval_registry_hash(),'integrity_result':'PASS'}
    return SnapshotContentIntegrityCertificate(sha(payload),**payload)

def validate_snapshot_content_integrity(cert,retrieval_scope_id,evidence):
    if cert is None:return False
    fresh=make_snapshot_content_integrity(retrieval_scope_id,evidence)
    return fresh is not None and asdict(fresh)==asdict(cert)



def claim_scope_summary(text,claim_identity_map):
    claims=parse_claims(text);claim_identity_map=claim_identity_map or {}
    entities=set();events=set();versions=set();predicates=set()
    for c in claims:
        if c.predicate in {'hypothesis','unmodelled'}:continue
        rid=claim_identity_map.get(c.id)
        ident=make_identity('CLAIM',c.id,c.subject,rid) if rid else None
        if ident is None:return None,None,None,None
        entities.add(ident.entity_id);events.add(ident.event_id);versions.add(ident.version_id);predicates.add(pkey(c.predicate))
    return tuple(sorted(entities)),tuple(sorted(events)),tuple(sorted(versions)),tuple(sorted(predicates))

def claim_descriptors(text,claim_identity_map):
    claims=parse_claims(text);claim_identity_map=claim_identity_map or {}
    out=[]
    for c in claims:
        if c.predicate in {'hypothesis','unmodelled'}:continue
        rid=claim_identity_map.get(c.id)
        ident=make_identity('CLAIM',c.id,c.subject,rid) if rid else None
        if ident is None:return None
        out.append({
            'claim_id':c.id,'entity_id':ident.entity_id,'event_id':ident.event_id,'version_id':ident.version_id,
            'predicate':pkey(c.predicate),'value_key':norm(c.value),'polarity':c.polarity
        })
    return out

def snapshot_freshness_valid(retrieval_scope_id,asof):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None:return False
    try:
        t=strict_date(asof);created=strict_date(r['snapshot_created_at']);available=strict_date(r['snapshot_available_at'])
        vf=strict_date(r['valid_from']);vt=strict_date(r['valid_to'])
    except Exception:return False
    return created<=available<=t and vf<=t<=vt

def retrieval_universe_membership_valid(retrieval_scope_id):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None:return False
    derived=canonical_retrieval_universe_id(r['semantic_scope'],tuple(r.get('entity_ids',())),
                                            tuple(r.get('event_ids',())),tuple(r.get('version_ids',())),
                                            tuple(r.get('predicates',())))
    return nonblank(r.get('retrieval_universe_id')) and r['retrieval_universe_id']==derived

def retrieval_universe_partition_adequate(asof):
    # Exact signatures still have one deterministic universe identity.
    buckets={}
    for sid,r in RETRIEVAL_SCOPE_REGISTRY.items():
        if not snapshot_freshness_valid(sid,asof):continue
        sig=(r.get('semantic_scope'),tuple(r.get('entity_ids',())),tuple(r.get('event_ids',())),
             tuple(r.get('version_ids',())),tuple(r.get('predicates',())))
        buckets.setdefault(sig,set()).add(r.get('retrieval_universe_id'))
        if not retrieval_universe_membership_valid(sid):return False
    return all(len(u)==1 and None not in u for u in buckets.values())

def relational_value_relation(claim_desc,row):
    if (row['entity_id'],row['event_id'],row['version_id'],row['predicate']) != (
        claim_desc['entity_id'],claim_desc['event_id'],claim_desc['version_id'],claim_desc['predicate']):
        return None
    cv=claim_desc['value_key']; rv=row['value_key']
    if rv==cv:
        return 'EXACT_VALUE'
    pred=claim_desc['predicate']
    if pred=='state':
        rel=STATE_RELATIONS.get(frozenset((pkey(cv),pkey(rv))))
        if rel is not None:
            return f'STATE_RELATION:{rel}'
    sch=PREDICATE_SCHEMA.get(pred)
    # For positive cardinality-ONE claims, another positive value is decision-relevant
    # because it can exclude the claimed value.
    if sch and sch.get('cardinality')=='ONE' and claim_desc.get('polarity')=='POSITIVE' and row.get('polarity')=='POSITIVE':
        return 'CARDINALITY_ONE_ALTERNATIVE'
    return None

def relational_claim_neighborhood(claim_desc):
    pred=claim_desc['predicate']; cv=claim_desc['value_key']
    out={'exact_value':cv,'predicate':pred,'related_values':[],'cardinality':None}
    if pred=='state':
        vals=[]
        for pair,rel in STATE_RELATIONS.items():
            if pkey(cv) in pair:
                other=next(iter(set(pair)-{pkey(cv)}),pkey(cv))
                vals.append((other,rel))
        out['related_values']=sorted(vals)
    sch=PREDICATE_SCHEMA.get(pred)
    if sch is not None:out['cardinality']=sch.get('cardinality')
    return out

def relational_claim_neighborhood_complete(text,claim_identity_map):
    descs=claim_descriptors(text,claim_identity_map)
    if descs is None or not descs:return False
    # Completeness here means: every modeled claim is evaluated against the
    # controller's declared relation/cardinality registry. An empty state
    # neighbourhood is still explicit; constraint coverage/authorized waiver
    # decides whether that is sufficient for closure.
    return all(d['predicate'] in PREDICATE_SCHEMA for d in descs)

def snapshot_projection_rows(retrieval_scope_id,claim_desc,asof):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None or not snapshot_freshness_valid(retrieval_scope_id,asof):return []
    rows=[]
    for x in r.get('record_projection_index',()):
        relation=relational_value_relation(claim_desc,x)
        if relation is None:continue
        y=dict(x);y['claim_relation']=relation
        rows.append(y)
    return sorted(rows,key=lambda z:z['evidence_id'])

def make_claim_snapshot_projection_certificate(retrieval_scope_id,claim_desc,asof):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    rows=snapshot_projection_rows(retrieval_scope_id,claim_desc,asof)
    if r is None or not rows:return None
    sig={'entity_id':claim_desc['entity_id'],'event_id':claim_desc['event_id'],
         'version_id':claim_desc['version_id'],'predicate':claim_desc['predicate'],
         'value_key':claim_desc['value_key'],'polarity':claim_desc['polarity']}
    neighborhood=relational_claim_neighborhood(claim_desc)
    payload={'claim_id':claim_desc['claim_id'],'retrieval_scope_id':retrieval_scope_id,
             'retrieval_snapshot_id':r['snapshot_id'],'projection_signature_hash':sha(sig),
             'relational_neighborhood_hash':sha(neighborhood),
             'relevant_evidence_ids_hash':sha([x['evidence_id'] for x in rows]),
             'relevant_record_hashes_hash':sha([(x['evidence_id'],x['record_hash'],x['polarity'],x['value_key'],x['claim_relation']) for x in rows]),
             'as_of_date':asof,'retrieval_registry_hash':retrieval_registry_hash(),'projection_result':'PASS'}
    return ClaimSnapshotProjectionCertificate(sha(payload),**payload)

def validate_claim_snapshot_projection_certificate(cert,retrieval_scope_id,claim_desc,asof):
    if cert is None:return False
    fresh=make_claim_snapshot_projection_certificate(retrieval_scope_id,claim_desc,asof)
    return fresh is not None and asdict(fresh)==asdict(cert)

def decision_relevant_candidate_map(text,claim_identity_map,scope_spec,asof):
    descs=claim_descriptors(text,claim_identity_map)
    if descs is None or not descs:return None,None
    cmap={}; pmap={}
    for d in descs:
        scopes=[];projs=[]
        for sid,r in RETRIEVAL_SCOPE_REGISTRY.items():
            if r.get('semantic_scope')!=scope_spec:continue
            if not retrieval_universe_membership_valid(sid):continue
            pc=make_claim_snapshot_projection_certificate(sid,d,asof)
            if pc is None:continue
            scopes.append(sid)
            projs.append((sid,pc.certificate_id))
        if not scopes:return None,None
        cmap[d['claim_id']]=tuple(sorted(scopes))
        pmap[d['claim_id']]=tuple(sorted(projs))
    return cmap,pmap

def make_decision_relevant_overlap_certificate(text,claim_identity_map,scope_spec,asof):
    descs=claim_descriptors(text,claim_identity_map)
    cmap,pmap=decision_relevant_candidate_map(text,claim_identity_map,scope_spec,asof)
    if descs is None or cmap is None:return None
    payload={'claim_ids_hash':sha(sorted(d['claim_id'] for d in descs)),
             'candidate_scope_map_hash':sha(cmap),'candidate_projection_map_hash':sha(pmap),
             'as_of_date':asof,'retrieval_registry_hash':retrieval_registry_hash(),'overlap_result':'PASS'}
    return DecisionRelevantOverlapCertificate(sha(payload),**payload)

def _resolve_supersedes_reference(ref):
    if not nonblank(ref):return None
    if ref in RETRIEVAL_SCOPE_REGISTRY:return ref
    for sid,r in RETRIEVAL_SCOPE_REGISTRY.items():
        if r.get('snapshot_id')==ref:return sid
    return None

def make_snapshot_supersession_certificate(claim_desc,predecessor_scope_id,successor_scope_id,asof):
    pre=RETRIEVAL_SCOPE_REGISTRY.get(predecessor_scope_id); suc=RETRIEVAL_SCOPE_REGISTRY.get(successor_scope_id)
    if pre is None or suc is None or predecessor_scope_id==successor_scope_id:return None
    if not snapshot_freshness_valid(predecessor_scope_id,asof) or not snapshot_freshness_valid(successor_scope_id,asof):return None
    ref=_resolve_supersedes_reference(suc.get('supersedes'))
    if ref!=predecessor_scope_id:return None
    if suc.get('retrieval_authority_id')!=pre.get('retrieval_authority_id'):return None
    if suc.get('supersession_authority_id')!=suc.get('retrieval_authority_id'):return None
    if type(suc.get('snapshot_version')) is not int or type(pre.get('snapshot_version')) is not int:return None
    if suc['snapshot_version']<=pre['snapshot_version']:return None
    pre_rows=snapshot_projection_rows(predecessor_scope_id,claim_desc,asof)
    suc_rows=snapshot_projection_rows(successor_scope_id,claim_desc,asof)
    if not pre_rows or not suc_rows:return None
    pre_by={x['evidence_id']:x for x in pre_rows}; suc_by={x['evidence_id']:x for x in suc_rows}
    retracted=set(suc.get('retracted_evidence_ids',()))
    carried=[];dropped=[]
    for eid,row in pre_by.items():
        if eid in suc_by and suc_by[eid]['record_hash']==row['record_hash']:
            carried.append(eid)
        elif eid in retracted:
            dropped.append(eid)
        else:
            return None
    # Retractions must name predecessor evidence only, never arbitrary IDs.
    if not retracted.issubset(set(pre.get('expected_evidence_ids',()))):return None
    payload={'claim_id':claim_desc['claim_id'],'predecessor_scope_id':predecessor_scope_id,
             'predecessor_snapshot_id':pre['snapshot_id'],'successor_scope_id':successor_scope_id,
             'successor_snapshot_id':suc['snapshot_id'],'supersession_authority_id':suc['supersession_authority_id'],
             'carried_evidence_ids_hash':sha(sorted(carried)),'retracted_evidence_ids_hash':sha(sorted(dropped)),
             'predecessor_projection_hash':sha(pre_rows),'successor_projection_hash':sha(suc_rows),
             'retrieval_registry_hash':retrieval_registry_hash(),'supersession_result':'PASS'}
    return SnapshotSupersessionCertificate(sha(payload),**payload)

def _valid_supersession_graph(claim_desc,candidates,asof):
    edges={sid:set() for sid in candidates}; certs=[]
    for pred in candidates:
        for suc in candidates:
            if pred==suc:continue
            cert=make_snapshot_supersession_certificate(claim_desc,pred,suc,asof)
            if cert is not None:
                edges[pred].add(suc);certs.append(cert)
    return edges,certs

def _reachable(edges,start,target,seen=None):
    if start==target:return True
    seen=set() if seen is None else seen
    if start in seen:return False
    seen.add(start)
    return any(_reachable(edges,n,target,seen.copy()) for n in edges.get(start,set()))

def resolve_claim_snapshot_winner(claim_desc,candidates,asof):
    candidates=tuple(sorted(set(candidates)))
    if len(candidates)==1:return candidates[0],[]
    edges,certs=_valid_supersession_graph(claim_desc,candidates,asof)
    winners=[]
    for candidate in candidates:
        if all(_reachable(edges,other,candidate) for other in candidates):
            winners.append(candidate)
    if len(winners)!=1:return None,certs
    return winners[0],certs

def claim_projection_complete(text,claim_identity_map,retrieval_scope_id,asof):
    descs=claim_descriptors(text,claim_identity_map)
    if descs is None or not descs:return False
    return all(make_claim_snapshot_projection_certificate(retrieval_scope_id,d,asof) is not None for d in descs)

def snapshot_supersession_valid_for_audit(text,claim_identity_map,scope_spec,retrieval_scope_id,asof):
    descs=claim_descriptors(text,claim_identity_map)
    cmap,_=decision_relevant_candidate_map(text,claim_identity_map,scope_spec,asof)
    if descs is None or cmap is None:return False
    for d in descs:
        candidates=cmap[d['claim_id']]
        winner,certs=resolve_claim_snapshot_winner(d,candidates,asof)
        if winner!=retrieval_scope_id:return False
        if len(candidates)>1 and not certs:return False
    return True

def make_snapshot_competition(text,claim_identity_map,scope_spec,retrieval_scope_id,asof):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None or not retrieval_universe_partition_adequate(asof):return None
    descs=claim_descriptors(text,claim_identity_map)
    cmap,pmap=decision_relevant_candidate_map(text,claim_identity_map,scope_spec,asof)
    overlap=make_decision_relevant_overlap_certificate(text,claim_identity_map,scope_spec,asof)
    if descs is None or cmap is None or overlap is None:return None
    all_scopes=set();all_snaps=set();all_supersession_certs=[]
    for d in descs:
        candidates=cmap[d['claim_id']]
        winner,certs=resolve_claim_snapshot_winner(d,candidates,asof)
        if winner!=retrieval_scope_id:return None
        all_scopes.update(candidates)
        all_snaps.update(RETRIEVAL_SCOPE_REGISTRY[s]['snapshot_id'] for s in candidates)
        all_supersession_certs.extend(c.certificate_id for c in certs)
    if not claim_projection_complete(text,claim_identity_map,retrieval_scope_id,asof):return None
    payload={'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':r['snapshot_id'],
             'retrieval_universe_id':r['retrieval_universe_id'],
             'candidate_scope_ids_hash':sha(sorted(all_scopes)),'candidate_snapshot_ids_hash':sha(sorted(all_snaps)),
             'claim_candidate_map_hash':sha(cmap),'overlap_certificate_id':overlap.certificate_id,
             'supersession_certificates_hash':sha(sorted(set(all_supersession_certs))),
             'winning_scope_id':retrieval_scope_id,'winning_snapshot_id':r['snapshot_id'],
             'winning_version':r['snapshot_version'],'as_of_date':asof,
             'retrieval_registry_hash':retrieval_registry_hash(),'competition_result':'PASS'}
    return SnapshotCompetitionCertificate(sha(payload),**payload)

def validate_snapshot_competition(cert,text,claim_identity_map,scope_spec,retrieval_scope_id,asof):
    if cert is None:return False
    fresh=make_snapshot_competition(text,claim_identity_map,scope_spec,retrieval_scope_id,asof)
    return fresh is not None and asdict(fresh)==asdict(cert)

def make_snapshot_applicability(text,claim_identity_map,scope_spec,retrieval_scope_id,asof):
    r=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if r is None:return None
    descs=claim_descriptors(text,claim_identity_map)
    if descs is None or r['semantic_scope']!=scope_spec:return None
    if not retrieval_universe_membership_valid(retrieval_scope_id):return None
    if not snapshot_freshness_valid(retrieval_scope_id,asof):return None
    if not claim_projection_complete(text,claim_identity_map,retrieval_scope_id,asof):return None
    competition=make_snapshot_competition(text,claim_identity_map,scope_spec,retrieval_scope_id,asof)
    if competition is None:return None
    entities=tuple(sorted({d['entity_id'] for d in descs}))
    events=tuple(sorted({d['event_id'] for d in descs}))
    versions=tuple(sorted({d['version_id'] for d in descs}))
    predicates=tuple(sorted({d['predicate'] for d in descs}))
    payload={'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':r['snapshot_id'],
             'applicability_group_id':r['applicability_group_id'],'retrieval_universe_id':r['retrieval_universe_id'],
             'semantic_scope_hash':sha(r['semantic_scope']),'entity_ids_hash':sha(entities),
             'event_ids_hash':sha(events),'version_ids_hash':sha(versions),'predicates_hash':sha(predicates),
             'snapshot_competition_certificate_id':competition.certificate_id,
             'as_of_date':asof,'snapshot_version':r['snapshot_version'],
             'retrieval_registry_hash':retrieval_registry_hash(),'applicability_result':'PASS'}
    return SnapshotApplicabilityCertificate(sha(payload),**payload)

def validate_snapshot_applicability(cert,text,claim_identity_map,scope_spec,retrieval_scope_id,asof):
    if cert is None:return False
    fresh=make_snapshot_applicability(text,claim_identity_map,scope_spec,retrieval_scope_id,asof)
    return fresh is not None and asdict(fresh)==asdict(cert)

# ============================================================
# Closure policy / authorization / gate meta-adequacy
# ============================================================

def normalize_requirements(claims,req):
    req=req or {};out={}
    for c in claims:
        if c.predicate=='hypothesis':continue
        d={'required_independent_supports':1,'require_constraint_coverage':True};d.update(req.get(c.id,{}))
        if type(d['required_independent_supports']) is not int or d['required_independent_supports']<1:raise ValueError
        if type(d['require_constraint_coverage']) is not bool:raise ValueError
        out[c.id]=d
    return out
def make_policy(claims,req=None,policy_id='closure-policy:v0.2.39',artifact_context_id=None):
    if not nonblank(policy_id):return None
    try:nr=normalize_requirements(claims,req)
    except:return None
    artifact_context_id=artifact_context_id or 'UNBOUND'
    payload={'policy_id':policy_id,'per_claim_requirements_hash':sha(nr),
             'support_artifact_context_id':artifact_context_id,
             'constraint_registry_hash':constraint_registry_hash(),'authority_registry_hash':authority_registry_hash(),
             'provenance_policy_hash':provenance_policy_hash(),'temporal_profile_hash':temporal_profile_hash(),
             'control_profile_hash':control_profile_hash(),'identity_registry_hash':identity_registry_hash(),
             'retrieval_registry_hash':retrieval_registry_hash(),
             'dependency_justification_registry_hash':dependency_justification_registry_hash(),
             'dependency_ontology_hash':dependency_ontology_hash(),
             'source_independence_policy_hash':source_independence_policy_hash(),
             'source_semantics_policy_hash':source_semantics_policy_hash(),
             'source_semantics_registry_hash':source_semantics_registry_hash(),
             'source_semantics_resolution_certificate_registry_hash':source_semantics_resolution_certificate_registry_hash(),
             'failure_domain_alias_registry_hash':failure_domain_alias_registry_hash(),
             'failure_domain_parent_registry_hash':failure_domain_parent_registry_hash(),
             'support_set_common_mode_registry_hash':support_set_common_mode_registry_hash(),
             'support_set_independence_certificate_registry_hash':support_set_independence_certificate_registry_hash(),
             'source_independence_authorization_registry_hash':source_independence_authorization_registry_hash(),
             'source_independence_certificate_registry_hash':source_independence_certificate_registry_hash(),
             'support_universe_policy_hash':support_universe_policy_hash(),
             'support_selection_registry_hash':support_selection_registry_hash(),
             'matching_support_universe_registry_hash':matching_support_universe_registry_hash(artifact_context_id),
             'support_selection_certificate_registry_hash':support_selection_certificate_registry_hash(artifact_context_id),
             'claim_support_universe_coverage_certificate_registry_hash':claim_support_universe_coverage_certificate_registry_hash(artifact_context_id),
             'relation_discovery_policy_hash':relation_discovery_policy_hash(),
             'decision_relevant_relation_universe_registry_hash':decision_relevant_relation_universe_registry_hash(artifact_context_id),
             'relation_resolution_policy_hash':relation_resolution_policy_hash(),
             'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
             'relation_resolution_registry_hash':relation_resolution_registry_hash(),
             'relation_resolution_certificate_registry_hash':relation_resolution_certificate_registry_hash(artifact_context_id),
             'excluded_support_disposition_registry_hash':excluded_support_disposition_registry_hash(),
             'excluded_support_disposition_certificate_registry_hash':excluded_support_disposition_certificate_registry_hash(artifact_context_id),
             'closure_class_spec_hash':closure_class_spec_hash(),'pinned_meta_authority_hash':pinned_meta_authority_hash()}
    return ClosurePolicyCertificate(sha(payload),**payload)
def validate_policy(cert,claims,req):
    if cert is None:return False
    fresh=make_policy(claims,req,cert.policy_id,cert.support_artifact_context_id)
    return fresh is not None and asdict(fresh)==asdict(cert)

def waiver_valid(wid,c,asof):
    w=WAIVER_REGISTRY.get(wid)
    if w is None:return False
    try:t=strict_date(asof);vf=strict_date(w['valid_from']);vt=strict_date(w['valid_to'])
    except:return False
    return w['closure_class']==CLOSURE_CLASS and w['waives']=='require_constraint_coverage' and pkey(c.predicate)==pkey(w['predicate']) and pkey(c.value)==pkey(w['value']) and vf<=t<=vt
def make_authorization(policy,claims,req,asof,waivers=None):
    if policy is None:return None
    try:nr=normalize_requirements(claims,req)
    except:return None
    waivers=waivers or {};used=[]
    for c in claims:
        if c.id in nr and nr[c.id]['require_constraint_coverage'] is False:
            wid=waivers.get(c.id)
            if not nonblank(wid) or not waiver_valid(wid,c,asof):return None
            used.append((c.id,wid))
    if set(waivers)!=set(cid for cid,_ in used):return None
    payload={'closure_policy_certificate_id':policy.certificate_id,'closure_class':CLOSURE_CLASS,'gate_registry_hash':gate_registry_hash(),'waiver_set_hash':sha(sorted(used)),'authorization_registry_hash':authorization_registry_hash(),'authorizer_id':AUTHORIZATION_REGISTRY[CLOSURE_CLASS]['authorizer_id'],'authorization_result':'PASS'}
    return PolicyAuthorizationCertificate(sha(payload),**payload)
def validate_authorization(cert,policy,claims,req,asof,waivers):
    if cert is None:return False
    fresh=make_authorization(policy,claims,req,asof,waivers);return fresh is not None and asdict(fresh)==asdict(cert)
def dependency_ontology_adequate(asof,retrieval_scope_id=None):
    try:t=strict_date(asof);vf=strict_date(PINNED_DEPENDENCY_ONTOLOGY_SPEC['valid_from']);vt=strict_date(PINNED_DEPENDENCY_ONTOLOGY_SPEC['valid_to'])
    except Exception:return False
    return (PINNED_DEPENDENCY_ONTOLOGY_SPEC['closure_class']==CLOSURE_CLASS
            and tuple(PINNED_DEPENDENCY_ONTOLOGY_SPEC['required_dimensions'])==tuple(DEPENDENCY_DIMENSIONS)
            and dict(PINNED_DEPENDENCY_ONTOLOGY_SPEC['dimension_prefixes'])==dict(DEPENDENCY_PREFIX)
            and tuple(PINNED_DEPENDENCY_ONTOLOGY_SPEC['node_types'])==tuple(DEPENDENCY_NODE_TYPES)
            and tuple(PINNED_DEPENDENCY_ONTOLOGY_SPEC['allowed_shared_nodes'])==tuple(sorted(PROVENANCE_POLICY['allowed_shared_nodes']))
            and PINNED_DEPENDENCY_ONTOLOGY_SPEC.get('generic_relation_source_identity_policy_hash')==canonical_hash(PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY)
            and PINNED_DEPENDENCY_ONTOLOGY_SPEC.get('evidence_source_field_policy_hash')==canonical_hash(PINNED_EVIDENCE_SOURCE_FIELD_POLICY)
            and GENERIC_RELATION_SOURCE_IDENTITY_POLICY==PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY
            and EVIDENCE_SOURCE_FIELD_POLICY==PINNED_EVIDENCE_SOURCE_FIELD_POLICY
            and generic_representation_equivalence_registry_adequate(asof,retrieval_scope_id)
            and generic_representation_distinctness_registry_adequate()
            and vf<=t<=vt)

def meta_baseline_version_applicable(asof):
    try:t=strict_date(asof);vf=strict_date(PINNED_META_AUTHORITY['valid_from']);vt=strict_date(PINNED_META_AUTHORITY['valid_to'])
    except Exception:return False
    return vf<=t<=vt and PINNED_META_AUTHORITY['closure_class']==CLOSURE_CLASS

def source_semantics_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(SOURCE_SEMANTICS_POLICY['valid_from']);vt=strict_date(SOURCE_SEMANTICS_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','allowed_resolution_states','resolved_state',
              'default_profile_resolution_state','default_profile_can_prove_independence',
              'require_resolution_certificate_for_independence','canonicalize_failure_domain_aliases',
              'include_failure_domain_ancestors','set_level_common_mode_required','allowed_semantics_authorities',
              'valid_from','valid_to'}
    return (set(SOURCE_SEMANTICS_POLICY)==required
            and SOURCE_SEMANTICS_POLICY['closure_class']==CLOSURE_CLASS
            and SOURCE_SEMANTICS_POLICY['resolved_state']=='KNOWN'
            and SOURCE_SEMANTICS_POLICY['default_profile_resolution_state']=='UNRESOLVED'
            and SOURCE_SEMANTICS_POLICY['default_profile_can_prove_independence'] is False
            and SOURCE_SEMANTICS_POLICY['require_resolution_certificate_for_independence'] is True
            and SOURCE_SEMANTICS_POLICY['canonicalize_failure_domain_aliases'] is True
            and SOURCE_SEMANTICS_POLICY['include_failure_domain_ancestors'] is True
            and SOURCE_SEMANTICS_POLICY['set_level_common_mode_required'] is True
            and canonical_hash(SOURCE_SEMANTICS_POLICY)==PINNED_META_AUTHORITY['source_semantics_policy_hash']
            and vf<=t<=vt)

def source_independence_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(SOURCE_INDEPENDENCE_POLICY['valid_from']);vt=strict_date(SOURCE_INDEPENDENCE_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','default_profile_mode','hard_block_shared_failure_domain',
              'certificate_required_shared_dimensions','relation_states','allowed_authorizers','allowed_semantics_authorities',
              'require_resolution_certificate_for_distinct','require_set_level_independence_certificate',
              'certificate_registry_key_identity_binding_required',
              'certificate_registry_state_bound_to_audit_context','valid_from','valid_to'}
    return (set(SOURCE_INDEPENDENCE_POLICY)==required
            and SOURCE_INDEPENDENCE_POLICY['closure_class']==CLOSURE_CLASS
            and SOURCE_INDEPENDENCE_POLICY['default_profile_mode']=='SYNTHETIC_UNRESOLVED_PLACEHOLDER'
            and SOURCE_INDEPENDENCE_POLICY['hard_block_shared_failure_domain'] is True
            and SOURCE_INDEPENDENCE_POLICY['require_resolution_certificate_for_distinct'] is True
            and SOURCE_INDEPENDENCE_POLICY['require_set_level_independence_certificate'] is True
            and SOURCE_INDEPENDENCE_POLICY['certificate_registry_key_identity_binding_required'] is True
            and SOURCE_INDEPENDENCE_POLICY['certificate_registry_state_bound_to_audit_context'] is True
            and set(SOURCE_INDEPENDENCE_POLICY['certificate_required_shared_dimensions'])=={'SOURCE','SOURCE_REPOSITORY','SOURCE_PRODUCER','SOURCE_PROCESS'}
            and {'SOURCE_SHARED_DEPENDENCY','SOURCE_INDEPENDENCE_JUSTIFIED','SOURCE_INDEPENDENCE_DISTINCT','SOURCE_RELATION_UNRESOLVED'}==set(SOURCE_INDEPENDENCE_POLICY['relation_states'])
            and canonical_hash(SOURCE_INDEPENDENCE_POLICY)==PINNED_META_AUTHORITY['source_independence_policy_hash']
            and vf<=t<=vt)

def support_universe_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(SUPPORT_UNIVERSE_POLICY['valid_from']);vt=strict_date(SUPPORT_UNIVERSE_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','universe_before_selection','selection_does_not_delete_evidence_relations',
              'selected_classification','allowed_exclusion_classes','blocking_exclusion_classes','allowed_relation_resolutions',
              'full_universe_auto_selection_allowed','proper_subset_requires_explicit_selection','exact_universe_binding_required',
              'claim_context_scope_snapshot_binding_required','permutation_invariant_selection_required',
              'selected_selected_relation_coverage_required','selected_excluded_relation_coverage_required',
              'decision_relevant_excluded_excluded_relation_coverage_required','excluded_excluded_relation_relevance_rule',
              'generic_dependency_selected_support_path_closure_required','generic_dependency_path_through_excluded_supports_preserved',
              'source_failure_domain_dependency_graph_required','source_dependency_path_through_excluded_supports_preserved',
              'pair_summary_not_complete_semantic_state','orthogonal_dependency_channels_preserved',
              'source_dependency_relevance_uses_source_state_independently',
              'excluded_redundant_disposition_closed_under_source_dependency_paths','source_dependency_resolution_type',
              'decision_level_dependency_graph_required','cross_claim_justificatory_paths_preserved',
              'decision_dependency_accounting_exact_context_binding_required','decision_dependency_accounting_resolution_type',
              'decision_level_relation_discovery_required','decision_level_relation_resolution_exact_binding_required',
              'unresolved_relation_fail_closed','allowed_authorizers','valid_from','valid_to'}
    return (set(SUPPORT_UNIVERSE_POLICY)==required
            and SUPPORT_UNIVERSE_POLICY['closure_class']==CLOSURE_CLASS
            and SUPPORT_UNIVERSE_POLICY['algorithm']=='MATCHING_SUPPORT_UNIVERSE_SELECTION_DECISION_GRAPH_RELATION_CLOSURE_V6'
            and SUPPORT_UNIVERSE_POLICY['universe_before_selection'] is True
            and SUPPORT_UNIVERSE_POLICY['selection_does_not_delete_evidence_relations'] is True
            and SUPPORT_UNIVERSE_POLICY['selected_classification']=='SELECTED_JUSTIFICATORY'
            and tuple(SUPPORT_UNIVERSE_POLICY['allowed_exclusion_classes'])==tuple(SUPPORT_EXCLUSION_CLASSES)
            and tuple(SUPPORT_UNIVERSE_POLICY['blocking_exclusion_classes'])==('EXCLUDED_UNRESOLVED',)
            and set(SUPPORT_UNIVERSE_POLICY['allowed_relation_resolutions'])==set(SUPPORT_RELATION_RESOLUTIONS)
            and SUPPORT_UNIVERSE_POLICY['proper_subset_requires_explicit_selection'] is True
            and SUPPORT_UNIVERSE_POLICY['exact_universe_binding_required'] is True
            and SUPPORT_UNIVERSE_POLICY['claim_context_scope_snapshot_binding_required'] is True
            and SUPPORT_UNIVERSE_POLICY['permutation_invariant_selection_required'] is True
            and SUPPORT_UNIVERSE_POLICY['decision_relevant_excluded_excluded_relation_coverage_required'] is True
            and SUPPORT_UNIVERSE_POLICY['excluded_excluded_relation_relevance_rule']=='EFFECT_SOURCE_AND_GENERIC_DEPENDENCY_PATH_CLOSURE'
            and SUPPORT_UNIVERSE_POLICY['generic_dependency_selected_support_path_closure_required'] is True
            and SUPPORT_UNIVERSE_POLICY['generic_dependency_path_through_excluded_supports_preserved'] is True
            and SUPPORT_UNIVERSE_POLICY['source_failure_domain_dependency_graph_required'] is True
            and SUPPORT_UNIVERSE_POLICY['source_dependency_path_through_excluded_supports_preserved'] is True
            and SUPPORT_UNIVERSE_POLICY['pair_summary_not_complete_semantic_state'] is True
            and SUPPORT_UNIVERSE_POLICY['orthogonal_dependency_channels_preserved'] is True
            and SUPPORT_UNIVERSE_POLICY['source_dependency_relevance_uses_source_state_independently'] is True
            and SUPPORT_UNIVERSE_POLICY['excluded_redundant_disposition_closed_under_source_dependency_paths'] is True
            and SUPPORT_UNIVERSE_POLICY['source_dependency_resolution_type']=='DEPENDENCY_ACCOUNTED_NOT_COUNTED'
            and SUPPORT_UNIVERSE_POLICY['decision_level_dependency_graph_required'] is True
            and SUPPORT_UNIVERSE_POLICY['cross_claim_justificatory_paths_preserved'] is True
            and SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_exact_context_binding_required'] is True
            and SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_resolution_type']=='DEPENDENCY_ACCOUNTED_NOT_COUNTED'
            and SUPPORT_UNIVERSE_POLICY['decision_level_relation_discovery_required'] is True
            and SUPPORT_UNIVERSE_POLICY['decision_level_relation_resolution_exact_binding_required'] is True
            and SUPPORT_UNIVERSE_POLICY['unresolved_relation_fail_closed'] is True
            and canonical_hash(SUPPORT_UNIVERSE_POLICY)==PINNED_META_AUTHORITY['support_universe_policy_hash']
            and vf<=t<=vt)

def relation_discovery_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(RELATION_DISCOVERY_POLICY['valid_from']);vt=strict_date(RELATION_DISCOVERY_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','matching_support_universe_is_not_relation_neighborhood',
              'discovery_precedes_decision_relevance_filtering','one_selected_endpoint_can_trigger_discovery',
              'preserve_legacy_multi_matching_endpoint_discovery','all_endpoints_must_be_in_retrieval_snapshot',
              'out_of_snapshot_relation_fail_closed','exact_relation_id_set_binding_required',
              'exact_relation_instance_records_binding_required','decision_level_discovery_over_composed_nodes',
              'decision_level_pair_and_nway_preserved','decision_level_cross_claim_scope_supported',
              'decision_node_membership_is_not_complete_endpoint_ownership',
              'decision_endpoint_ownership_from_all_modeled_matching_universes',
              'local_scope_sufficiency_uses_complete_endpoint_ownership','snapshot_only_endpoint_status_explicit',
              'complete_endpoint_ownership_before_graph_anchor_filtering',
              'cross_claim_modeled_endpoints_without_graph_anchor_require_decision_scope',
              'excluded_not_needed_preserves_cross_claim_relations',
              'relation_effect_and_ownership_precede_graph_membership',
              'decision_relation_universe_binds_evaluated_relation_rows',
              'allowed_relation_types','valid_from','valid_to'}
    return (set(RELATION_DISCOVERY_POLICY)==required
            and RELATION_DISCOVERY_POLICY['closure_class']==CLOSURE_CLASS
            and RELATION_DISCOVERY_POLICY['algorithm']=='OWNERSHIP_EFFECT_FIRST_DECISION_RELATION_DISCOVERY_V4'
            and RELATION_DISCOVERY_POLICY['matching_support_universe_is_not_relation_neighborhood'] is True
            and RELATION_DISCOVERY_POLICY['discovery_precedes_decision_relevance_filtering'] is True
            and RELATION_DISCOVERY_POLICY['one_selected_endpoint_can_trigger_discovery'] is True
            and RELATION_DISCOVERY_POLICY['preserve_legacy_multi_matching_endpoint_discovery'] is True
            and RELATION_DISCOVERY_POLICY['all_endpoints_must_be_in_retrieval_snapshot'] is True
            and RELATION_DISCOVERY_POLICY['out_of_snapshot_relation_fail_closed'] is True
            and RELATION_DISCOVERY_POLICY['exact_relation_id_set_binding_required'] is True
            and RELATION_DISCOVERY_POLICY['exact_relation_instance_records_binding_required'] is True
            and RELATION_DISCOVERY_POLICY['decision_level_discovery_over_composed_nodes'] is True
            and RELATION_DISCOVERY_POLICY['decision_level_pair_and_nway_preserved'] is True
            and RELATION_DISCOVERY_POLICY['decision_level_cross_claim_scope_supported'] is True
            and RELATION_DISCOVERY_POLICY['decision_node_membership_is_not_complete_endpoint_ownership'] is True
            and RELATION_DISCOVERY_POLICY['decision_endpoint_ownership_from_all_modeled_matching_universes'] is True
            and RELATION_DISCOVERY_POLICY['local_scope_sufficiency_uses_complete_endpoint_ownership'] is True
            and RELATION_DISCOVERY_POLICY['snapshot_only_endpoint_status_explicit'] is True
            and RELATION_DISCOVERY_POLICY['complete_endpoint_ownership_before_graph_anchor_filtering'] is True
            and RELATION_DISCOVERY_POLICY['cross_claim_modeled_endpoints_without_graph_anchor_require_decision_scope'] is True
            and RELATION_DISCOVERY_POLICY['excluded_not_needed_preserves_cross_claim_relations'] is True
            and RELATION_DISCOVERY_POLICY['relation_effect_and_ownership_precede_graph_membership'] is True
            and RELATION_DISCOVERY_POLICY['decision_relation_universe_binds_evaluated_relation_rows'] is True
            and tuple(RELATION_DISCOVERY_POLICY['allowed_relation_types'])==('COMMON_MODE','UNKNOWN')
            and canonical_hash(RELATION_DISCOVERY_POLICY)==PINNED_META_AUTHORITY['relation_discovery_policy_hash']
            and vf<=t<=vt)

def relation_resolution_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(RELATION_RESOLUTION_POLICY['valid_from']);vt=strict_date(RELATION_RESOLUTION_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','relation_identity','resolution_is_relation_specific_not_pair_generic',
              'one_resolution_per_relation_instance','exact_endpoint_set_binding_required',
              'claim_context_scope_snapshot_binding_required','exact_universe_binding_required',
              'exact_selected_subset_binding_required','authorization_declaration_scope_must_cover_certificate_scope',
              'certificate_binding_cannot_repair_underbound_authorization_source',
              'non_decision_relevant_authorization_is_audit_context_specific',
              'issuance_must_not_add_unauthorized_epistemic_scope',
              'explicit_context_binding_step_required_for_pre_context_declarations',
              'registry_key_identity_binding_required',
              'support_selection_registry_typed_key_identity_binding_required',
              'registry_incoherence_fails_closed_globally',
              'relation_effects','allowed_resolution_types',
              'effect_resolution_compatibility','unknown_fail_closed','selected_support_invalidating_fail_closed',
              'redundant_exclusion_requires_disposition_certificate','free_text_is_not_semantic_authority',
              'allowed_resolution_authorizers','allowed_disposition_authorizers','valid_from','valid_to'}
    compat=RELATION_RESOLUTION_POLICY.get('effect_resolution_compatibility')
    return (set(RELATION_RESOLUTION_POLICY)==required
            and RELATION_RESOLUTION_POLICY['closure_class']==CLOSURE_CLASS
            and RELATION_RESOLUTION_POLICY['relation_identity']=='STABLE_RELATION_ID'
            and RELATION_RESOLUTION_POLICY['resolution_is_relation_specific_not_pair_generic'] is True
            and RELATION_RESOLUTION_POLICY['one_resolution_per_relation_instance'] is True
            and RELATION_RESOLUTION_POLICY['exact_endpoint_set_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['claim_context_scope_snapshot_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['exact_universe_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['exact_selected_subset_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['authorization_declaration_scope_must_cover_certificate_scope'] is True
            and RELATION_RESOLUTION_POLICY['certificate_binding_cannot_repair_underbound_authorization_source'] is True
            and RELATION_RESOLUTION_POLICY['non_decision_relevant_authorization_is_audit_context_specific'] is True
            and RELATION_RESOLUTION_POLICY['issuance_must_not_add_unauthorized_epistemic_scope'] is True
            and RELATION_RESOLUTION_POLICY['explicit_context_binding_step_required_for_pre_context_declarations'] is True
            and RELATION_RESOLUTION_POLICY['registry_key_identity_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['support_selection_registry_typed_key_identity_binding_required'] is True
            and RELATION_RESOLUTION_POLICY['registry_incoherence_fails_closed_globally'] is True
            and tuple(RELATION_RESOLUTION_POLICY['relation_effects'])==tuple(RELATION_EFFECTS)
            and tuple(RELATION_RESOLUTION_POLICY['allowed_resolution_types'])==tuple(RELATION_RESOLUTION_TYPES)
            and compat==RELATION_EFFECT_RESOLUTION_COMPATIBILITY
            and RELATION_RESOLUTION_POLICY['unknown_fail_closed'] is True
            and RELATION_RESOLUTION_POLICY['selected_support_invalidating_fail_closed'] is True
            and RELATION_RESOLUTION_POLICY['redundant_exclusion_requires_disposition_certificate'] is True
            and RELATION_RESOLUTION_POLICY['free_text_is_not_semantic_authority'] is True
            and canonical_hash(RELATION_RESOLUTION_POLICY)==PINNED_META_AUTHORITY['relation_resolution_policy_hash']
            and vf<=t<=vt)

def relation_decision_relevance_policy_adequate(asof):
    try:t=strict_date(asof);vf=strict_date(RELATION_DECISION_RELEVANCE_POLICY['valid_from']);vt=strict_date(RELATION_DECISION_RELEVANCE_POLICY['valid_to'])
    except Exception:return False
    required={'policy_id','closure_class','algorithm','discovery_precedes_relevance_filtering',
              'relation_effect_precedes_endpoint_disposition','excluded_support_not_epistemically_irrelevant',
              'endpoint_scope_cannot_erase_typed_blocking_effect','authorization_precedes_nonblocking_status',
              'endpoint_disposition_cannot_bypass_required_handling','relevance_classification_distinct_from_resolution_requirement',
              'implemented_handling_must_match_pinned_effect_policy','always_decision_relevant_effects',
              'endpoint_scope_dependent_effects','effect_required_handling','non_decision_relevant_requires_authorization',
              'non_decision_relevant_required_resolution_type','reliability_degrading_requires_resolution_all_endpoint_scopes',
              'selected_support_invalidating_fail_closed_all_endpoint_scopes','unknown_fail_closed_all_endpoint_scopes',
              'contradictory_requires_resolution_all_endpoint_scopes','redundancy_only_all_excluded_can_be_nonblocking',
              'valid_from','valid_to'}
    always=tuple(RELATION_DECISION_RELEVANCE_POLICY.get('always_decision_relevant_effects',()))
    conditional=tuple(RELATION_DECISION_RELEVANCE_POLICY.get('endpoint_scope_dependent_effects',()))
    handling=RELATION_DECISION_RELEVANCE_POLICY.get('effect_required_handling')
    expected_handling={
        'REDUNDANCY_ONLY':'ENDPOINT_SCOPE',
        'RELIABILITY_DEGRADING':'RESOLUTION_REQUIRED',
        'SELECTED_SUPPORT_INVALIDATING':'FAIL_CLOSED',
        'CONTRADICTORY':'RESOLUTION_REQUIRED',
        'NON_DECISION_RELEVANT':'AUTHORIZATION_REQUIRED',
        'UNKNOWN':'FAIL_CLOSED',
    }
    return (set(RELATION_DECISION_RELEVANCE_POLICY)==required
            and RELATION_DECISION_RELEVANCE_POLICY['closure_class']==CLOSURE_CLASS
            and RELATION_DECISION_RELEVANCE_POLICY['algorithm']=='EFFECT_FIRST_REQUIRED_HANDLING_V2'
            and RELATION_DECISION_RELEVANCE_POLICY['discovery_precedes_relevance_filtering'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['relation_effect_precedes_endpoint_disposition'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['excluded_support_not_epistemically_irrelevant'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['endpoint_scope_cannot_erase_typed_blocking_effect'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['authorization_precedes_nonblocking_status'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['endpoint_disposition_cannot_bypass_required_handling'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['relevance_classification_distinct_from_resolution_requirement'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['implemented_handling_must_match_pinned_effect_policy'] is True
            and always==('RELIABILITY_DEGRADING','SELECTED_SUPPORT_INVALIDATING','CONTRADICTORY','UNKNOWN')
            and conditional==('REDUNDANCY_ONLY','NON_DECISION_RELEVANT')
            and handling==expected_handling
            and RELATION_DECISION_RELEVANCE_POLICY['non_decision_relevant_requires_authorization'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['non_decision_relevant_required_resolution_type']=='NON_DECISION_RELEVANT_AUTHORIZED'
            and RELATION_DECISION_RELEVANCE_POLICY['reliability_degrading_requires_resolution_all_endpoint_scopes'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['selected_support_invalidating_fail_closed_all_endpoint_scopes'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['unknown_fail_closed_all_endpoint_scopes'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['contradictory_requires_resolution_all_endpoint_scopes'] is True
            and RELATION_DECISION_RELEVANCE_POLICY['redundancy_only_all_excluded_can_be_nonblocking'] is True
            and canonical_hash(RELATION_DECISION_RELEVANCE_POLICY)==PINNED_META_AUTHORITY['relation_decision_relevance_policy_hash']
            and vf<=t<=vt)

def make_gate_meta(asof='2026-08-10'):
    obligations=set(CLOSURE_CLASS_SPEC['obligations']); mapped=set(OBLIGATION_GATE_MAP)
    schema_complete=obligations==mapped
    live_spec_matches=canonical_hash(CLOSURE_CLASS_SPEC)==PINNED_META_AUTHORITY['closure_class_spec_hash']
    live_map_matches=canonical_hash(OBLIGATION_GATE_MAP)==PINNED_META_AUTHORITY['obligation_gate_map_hash']
    live_gates_match=canonical_hash(MANDATORY_GATES)==PINNED_META_AUTHORITY['mandatory_gates_hash']
    meta_app=meta_baseline_version_applicable(asof)
    ontology_ok=dependency_ontology_adequate(asof) and canonical_hash(PINNED_DEPENDENCY_ONTOLOGY_SPEC)==PINNED_META_AUTHORITY['dependency_ontology_hash']
    source_policy_ok=source_independence_policy_adequate(asof)
    source_semantics_policy_ok=source_semantics_policy_adequate(asof)
    support_universe_policy_ok=support_universe_policy_adequate(asof)
    relation_discovery_policy_ok=relation_discovery_policy_adequate(asof)
    relation_resolution_policy_ok=relation_resolution_policy_adequate(asof)
    relation_decision_relevance_policy_ok=relation_decision_relevance_policy_adequate(asof)
    adequate=(schema_complete and live_spec_matches and live_map_matches and live_gates_match and meta_app and ontology_ok
              and source_policy_ok and source_semantics_policy_ok and support_universe_policy_ok
              and relation_discovery_policy_ok and relation_resolution_policy_ok and relation_decision_relevance_policy_ok
              and all(OBLIGATION_GATE_MAP[o] in MANDATORY_GATES for o in obligations))
    payload={'closure_class':CLOSURE_CLASS,'closure_class_spec_hash':closure_class_spec_hash(),
             'gate_registry_hash':gate_registry_hash(),'obligation_gate_map_hash':canonical_hash(OBLIGATION_GATE_MAP),
             'pinned_meta_authority_hash':pinned_meta_authority_hash(),'meta_baseline_version':PINNED_META_AUTHORITY['meta_baseline_version'],
             'as_of_date':asof,'schema_complete':schema_complete,'adequate_for_closure_class':adequate,
             'live_spec_matches_pinned':live_spec_matches,'live_gate_map_matches_pinned':live_map_matches,
             'live_gate_registry_matches_pinned':live_gates_match,'meta_baseline_version_applicable':meta_app,
             'dependency_ontology_adequate':ontology_ok,'source_independence_policy_adequate':source_policy_ok,
             'source_semantics_policy_adequate':source_semantics_policy_ok,
             'support_universe_policy_adequate':support_universe_policy_ok,
             'relation_discovery_policy_adequate':relation_discovery_policy_ok,
             'relation_resolution_policy_adequate':relation_resolution_policy_ok,
             'relation_decision_relevance_policy_adequate':relation_decision_relevance_policy_ok}
    return GateMetaAdequacyCertificate(sha(payload),**payload)
def validate_gate_meta(cert,asof='2026-08-10'):
    fresh=make_gate_meta(asof);return cert is not None and asdict(fresh)==asdict(cert)


# ============================================================
# Context / control adequacy
# ============================================================

def make_context(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,coverage,content_integrity,policy,authorization):
    try:strict_date(asof)
    except:return None
    if not all([policy,authorization,coverage,content_integrity,nonblank(scope_spec),nonblank(extract_spec),nonblank(retrieval_scope)]):return None
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,
                            policy.per_claim_requirements_hash)
    if aid is None or policy.support_artifact_context_id!=aid:return None
    competition=make_snapshot_competition(text,claim_identity_map,scope_spec,retrieval_scope,asof)
    applicability=make_snapshot_applicability(text,claim_identity_map,scope_spec,retrieval_scope,asof)
    if competition is None or applicability is None:return None
    claims=parse_claims(text)
    core={'input_hash':sha(text),'raw_evidence_hash':sha(evidence),'claim_set_hash':claim_set_hash(claims),
          'claim_identity_map_hash':sha(claim_identity_map or {}),'as_of_date':asof,'scope_spec_hash':sha(scope_spec),
          'extraction_spec_hash':sha(extract_spec),'retrieval_scope_id':retrieval_scope,
          'retrieval_universe_id':competition.retrieval_universe_id,
          'evidence_set_coverage_certificate_id':coverage.certificate_id,
          'snapshot_content_integrity_certificate_id':content_integrity.certificate_id,
          'snapshot_competition_certificate_id':competition.certificate_id,
          'snapshot_applicability_certificate_id':applicability.certificate_id,
          'closure_policy_certificate_id':policy.certificate_id,
          'policy_authorization_certificate_id':authorization.certificate_id,'gate_registry_hash':authorization.gate_registry_hash,
          'decision_runtime_authorization_state_hash':_decision_runtime_authorization_state_hash()}
    payload={'audit_context_id':aid,**core};return AuditContextCertificate(sha(payload),**payload)

def validate_context(cert,text,evidence,claim_identity_map,asof,scope,extract,retrieval,coverage,content_integrity,policy,authorization):
    if cert is None:return False
    fresh=make_context(text,evidence,claim_identity_map,asof,scope,extract,retrieval,coverage,content_integrity,policy,authorization)
    return fresh is not None and asdict(fresh)==asdict(cert)
def make_binding(kind,cid,ctx,policy,result=True):
    if kind not in {'SCOPE','EXTRACTION'} or result is not True or not nonblank(cid):return None
    spec=ctx.scope_spec_hash if kind=='SCOPE' else ctx.extraction_spec_hash
    payload={'condition_type':kind,'condition_id':cid,'audit_context_id':ctx.audit_context_id,'input_hash':ctx.input_hash,'raw_evidence_hash':ctx.raw_evidence_hash,'claim_set_hash':ctx.claim_set_hash,'condition_spec_hash':spec,'closure_policy_certificate_id':policy.certificate_id,'result':True}
    return ControlBindingCertificate(sha(payload),**payload)
def validate_binding(cert,kind,ctx,policy):
    if cert is None:return False
    fresh=make_binding(kind,cert.condition_id,ctx,policy,cert.result);return fresh is not None and asdict(fresh)==asdict(cert)
def scope_adequate(text,spec,claims):return spec==CANONICAL_SCOPE and bool(claims) and all(c.predicate!='unmodelled' for c in claims)
def extraction_adequate(text,spec,claims):
    sentences=[x.strip() for x in re.split(r'(?<=[.!?])\s+',text.strip()) if x.strip()]
    return spec==CANONICAL_EXTRACTION and len(sentences)==len(claims) and all(c.predicate!='unmodelled' for c in claims)
def make_adequacy(kind,text,spec,claims,ctx):
    result=scope_adequate(text,spec,claims) if kind=='SCOPE' else extraction_adequate(text,spec,claims) if kind=='EXTRACTION' else False
    if result is not True:return None
    payload={'adequacy_type':kind,'audit_context_id':ctx.audit_context_id,'profile_hash':control_profile_hash(),'result':True,'validator_id':f'{kind}_ADEQUACY_V2'}
    return AdequacyCertificate(sha(payload),**payload)
def validate_adequacy(cert,kind,text,spec,claims,ctx):
    if cert is None:return False
    fresh=make_adequacy(kind,text,spec,claims,ctx);return fresh is not None and asdict(fresh)==asdict(cert)


# ============================================================
# Evidence normalization / claim identities
# ============================================================

EVIDENCE_KEYS={'evidence_id','subject','predicate','value','source','polarity','identity_registry_entry_id','authority_id','authority_record_entity_id','authority_record_event_id','authority_record_version_id','valid_from','valid_to','observed_at','available_at','provenance','source_semantics_id','epistemic_role_record_id'}


def evidence_source_field_valid(source):
    if not nonblank(source):return False
    if EVIDENCE_SOURCE_FIELD_POLICY!=PINNED_EVIDENCE_SOURCE_FIELD_POLICY:return False
    prefix=EVIDENCE_SOURCE_FIELD_POLICY.get('required_prefix')
    return isinstance(prefix,str) and bool(prefix) and source.startswith(prefix) and len(source)>len(prefix)

def _base_fact_components(raw,index):
    e=[];r=dict(raw);unknown=set(r)-EVIDENCE_KEYS
    if unknown:e.append(f'unknown evidence fields: {sorted(unknown)}')
    eid=r.get('evidence_id') or f'E{index}'
    for k in ['subject','predicate','value','source']:
        if not nonblank(r.get(k)):e.append(f'missing {k}')
    if nonblank(r.get('source')) and not evidence_source_field_valid(r.get('source')):e.append('evidence source field semantic role invalid')
    if nonblank(r.get('subject')) and not subject_shape_ok(r['subject']):e.append('subject admission failed')
    if nonblank(r.get('value')) and nonblank(r.get('predicate')) and not value_shape_ok(r['value'],r['predicate']):e.append('value admission failed')
    ident=make_identity('EVIDENCE',eid,r.get('subject',''),r.get('identity_registry_entry_id'))
    if ident is None:e.append('evidence identity unresolved')
    temp=make_temporal(r.get('valid_from'),r.get('valid_to'),r.get('observed_at'),r.get('available_at'))
    if temp is None:e.append('invalid temporal semantics')
    prov=make_provenance(eid,r.get('provenance'))
    if prov is None:e.append('invalid provenance')
    if ident is not None and prov is not None and (prov.referent_entity_id,prov.referent_event_id,prov.referent_version_id)!=identity_tuple(ident):
        e.append('provenance referent does not match evidence identity')
    pc=make_prov_complete(eid,prov) if prov else None
    if pc is None:e.append('provenance completeness failed')
    ont=make_dependency_ontology_conformance_certificate(eid,prov) if prov else None
    if ont is None:e.append('dependency instance ontology conformance failed')
    if prov is not None and not dependency_resolution_valid(prov):e.append('provenance dependency UNKNOWN/UNRESOLVED')
    if prov is not None and not dependency_state_justification_valid(prov):e.append('dependency state justification invalid')
    auth=None
    if ident and prov:
        auth=make_authority(eid,r.get('authority_id',''),r.get('predicate',''),ident,prov,r.get('authority_record_entity_id'),r.get('authority_record_event_id'),r.get('authority_record_version_id'))
    if auth is None:e.append('authority/referent record binding failed')
    semantics_id=r.get('source_semantics_id')
    resolution=_resolution_cert_for_semantics(semantics_id) if nonblank(semantics_id) else None
    sourcefd=make_source_failure_domain_certificate(eid,prov,auth,semantics_id) if prov and auth else None
    if sourcefd is None:e.append('source failure-domain semantics unresolved')
    return ({
        'raw':r,'evidence_id':eid,'identity':ident,'temporal':temp,'provenance':prov,
        'provenance_completeness':pc,'dependency_ontology_conformance':ont,'authority':auth,
        'source_semantics_id':semantics_id,'source_semantics_resolution':resolution,
        'source_failure_domain':sourcefd,
    },e)

def _evidence_assertion_commitment_from_components(comp):
    r=comp['raw']
    fields={
        'evidence_id':comp['evidence_id'],'subject':r.get('subject'),'predicate':pkey(r.get('predicate','')),
        'value':r.get('value'),'source':r.get('source'),'polarity':r.get('polarity','POSITIVE'),
        'identity_certificate_id':None if comp['identity'] is None else comp['identity'].certificate_id,
        'temporal_certificate_id':None if comp['temporal'] is None else comp['temporal'].certificate_id,
        'provenance_certificate_id':None if comp['provenance'] is None else comp['provenance'].certificate_id,
        'provenance_completeness_certificate_id':None if comp['provenance_completeness'] is None else comp['provenance_completeness'].certificate_id,
        'dependency_ontology_conformance_certificate_id':None if comp['dependency_ontology_conformance'] is None else comp['dependency_ontology_conformance'].certificate_id,
        'source_failure_domain_certificate_id':None if comp['source_failure_domain'] is None else comp['source_failure_domain'].certificate_id,
        'source_semantics_resolution_certificate_id':None if comp['source_semantics_resolution'] is None else comp['source_semantics_resolution'].certificate_id,
        'authority_certificate_id':None if comp['authority'] is None else comp['authority'].certificate_id,
    }
    return canonical_hash(fields)

def _trusted_fact_assertion_commitment(f):
    return canonical_hash({
        'evidence_id':f.evidence_id,'subject':f.subject,'predicate':f.predicate,'value':f.value,
        'source':f.source,'polarity':f.polarity,'identity_certificate_id':f.identity.certificate_id,
        'temporal_certificate_id':f.temporal.certificate_id,'provenance_certificate_id':f.provenance.certificate_id,
        'provenance_completeness_certificate_id':f.provenance_completeness.certificate_id,
        'dependency_ontology_conformance_certificate_id':f.dependency_ontology_conformance.certificate_id,
        'source_failure_domain_certificate_id':f.source_failure_domain.certificate_id,
        'source_semantics_resolution_certificate_id':None if f.source_semantics_resolution is None else f.source_semantics_resolution.certificate_id,
        'authority_certificate_id':f.authority.certificate_id,
    })

def _evidence_role_policies_pinned():
    return (EVIDENCE_EPISTEMIC_ROLE_POLICY==PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY
            and EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY==PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY)

def _role_issuer_grant(grant_id):
    for gid,authority,roles in PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY['grants']:
        if gid==grant_id:
            return {'grant_id':gid,'issuer_authority_id':authority,'allowed_roles':tuple(roles),
                    'grant_scope':PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY['grant_scope']}
    return None

def _default_role_issuer_grant_id(epistemic_role):
    for gid,_authority,roles in PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY['grants']:
        if epistemic_role in roles:return gid
    return None

def _evidence_semantic_assertion_identity_from_components(comp):
    r=comp['raw'];ident=comp.get('identity');prov=comp.get('provenance')
    if ident is None or prov is None:return None
    return canonical_hash({
        'referent_identity':identity_tuple(ident),
        'provenance_referent':(prov.referent_entity_id,prov.referent_event_id,prov.referent_version_id),
        'predicate':pkey(r.get('predicate','')),'value':r.get('value'),'polarity':r.get('polarity','POSITIVE'),
    })

def _canonical_content_origin_from_components(comp):
    prov=comp.get('provenance');semantic_id=_evidence_semantic_assertion_identity_from_components(comp)
    if prov is None or semantic_id is None:return None
    return 'content-origin:'+canonical_hash({
        'root_origin_id':prov.root_origin_id,
        'referent_entity_id':prov.referent_entity_id,
        'referent_event_id':prov.referent_event_id,
        'referent_version_id':prov.referent_version_id,
        'semantic_assertion_identity':semantic_id,
    })

def _canonical_content_origin_from_role_row(row):
    if not isinstance(row,dict):return None
    needed=('root_origin_id','referent_entity_id','referent_event_id','referent_version_id','semantic_assertion_identity')
    if not all(nonblank(row.get(k)) for k in needed):return None
    return 'content-origin:'+canonical_hash({k:row.get(k) for k in needed})

def _rooted_provenance_identity_from_components(comp):
    prov=comp.get('provenance')
    if prov is None:return None
    return canonical_hash({
        'root_origin_id':prov.root_origin_id,
        'referent_entity_id':prov.referent_entity_id,
        'referent_event_id':prov.referent_event_id,
        'referent_version_id':prov.referent_version_id,
    })

def _rooted_provenance_identity_from_role_row(row):
    if not isinstance(row,dict):return None
    needed=('root_origin_id','referent_entity_id','referent_event_id','referent_version_id')
    if not all(nonblank(row.get(k)) for k in needed):return None
    return canonical_hash({k:row.get(k) for k in needed})

def _stable_temporal_identity_from_components(comp):
    r=comp.get('raw') or {}
    vals={k:r.get(k) for k in ('valid_from','valid_to','observed_at','available_at')}
    if not all(nonblank(v) for v in vals.values()):return None
    return canonical_hash(vals)

def _stable_temporal_identity_from_role_row(row):
    if not isinstance(row,dict):return None
    vals={k:row.get(k) for k in ('valid_from','valid_to','observed_at','available_at')}
    if not all(nonblank(v) for v in vals.values()):return None
    return canonical_hash(vals)

def _evidence_identity_payload_from_components(comp):
    semantic=_evidence_semantic_assertion_identity_from_components(comp)
    origin=_canonical_content_origin_from_components(comp)
    rooted=_rooted_provenance_identity_from_components(comp)
    temporal=_stable_temporal_identity_from_components(comp)
    if not all(nonblank(x) for x in (semantic,origin,rooted,temporal)):return None
    return {
        'semantic_assertion_identity':semantic,
        'canonical_content_origin_id':origin,
        'rooted_provenance_identity':rooted,
        'stable_temporal_identity':temporal,
    }

def _evidence_identity_payload_from_role_row(row):
    if not isinstance(row,dict):return None
    semantic=row.get('semantic_assertion_identity')
    origin=_canonical_content_origin_from_role_row(row)
    rooted=_rooted_provenance_identity_from_role_row(row)
    temporal=_stable_temporal_identity_from_role_row(row)
    if not all(nonblank(x) for x in (semantic,origin,rooted,temporal)):return None
    return {
        'semantic_assertion_identity':semantic,
        'canonical_content_origin_id':origin,
        'rooted_provenance_identity':rooted,
        'stable_temporal_identity':temporal,
    }

def _evidence_identity_commitment_from_payload(payload):
    return None if not isinstance(payload,dict) else canonical_hash(payload)

def _evidence_identity_record_payload(record):
    if not isinstance(record,EvidenceIdentityRecord):return None
    return {
        'evidence_id':record.evidence_id,
        'evidence_identity_commitment':record.evidence_identity_commitment,
        'semantic_assertion_identity':record.semantic_assertion_identity,
        'assertion_commitment':record.assertion_commitment,
        'canonical_content_origin_id':record.canonical_content_origin_id,
        'rooted_provenance_identity':record.rooted_provenance_identity,
        'stable_temporal_identity':record.stable_temporal_identity,
        'first_authorization_artifact_id':record.first_authorization_artifact_id,
        'first_history_commitment':record.first_history_commitment,
    }

def _evidence_identity_record_fingerprint(record):
    payload=_evidence_identity_record_payload(record)
    return None if payload is None else canonical_hash(payload)

def _make_evidence_identity_record(evidence_id,comp,assertion_commitment,first_authorization_artifact_id,first_history_commitment):
    ident=_evidence_identity_payload_from_components(comp)
    if ident is None:return None
    payload={
        'evidence_id':evidence_id,
        'evidence_identity_commitment':_evidence_identity_commitment_from_payload(ident),
        'semantic_assertion_identity':ident['semantic_assertion_identity'],
        'assertion_commitment':assertion_commitment,
        'canonical_content_origin_id':ident['canonical_content_origin_id'],
        'rooted_provenance_identity':ident['rooted_provenance_identity'],
        'stable_temporal_identity':ident['stable_temporal_identity'],
        'first_authorization_artifact_id':first_authorization_artifact_id,
        'first_history_commitment':first_history_commitment,
    }
    return EvidenceIdentityRecord(**payload,record_fingerprint=canonical_hash(payload))

def _evidence_identity_record_structurally_valid(record,registry=None,authorization_registry=None,role_registry=None):
    registry=EVIDENCE_ID_IDENTITY_REGISTRY if registry is None else registry
    authorization_registry=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY if authorization_registry is None else authorization_registry
    role_registry=EVIDENCE_EPISTEMIC_ROLE_REGISTRY if role_registry is None else role_registry
    if not isinstance(record,EvidenceIdentityRecord):return False
    if registry.get(record.evidence_id)!=record:return False
    if record.record_fingerprint!=_evidence_identity_record_fingerprint(record):return False
    if not _valid_history_commitment_value(record.first_history_commitment):return False
    first=authorization_registry.get(record.first_authorization_artifact_id)
    if not isinstance(first,EvidenceEpistemicRoleAuthorizationArtifact) or first.evidence_id!=record.evidence_id:return False
    if (first.assertion_commitment!=record.assertion_commitment
        or first.semantic_assertion_identity!=record.semantic_assertion_identity
        or first.canonical_content_origin_id!=record.canonical_content_origin_id):return False
    row=role_registry.get(first.role_record_id)
    ident=_evidence_identity_payload_from_role_row(row)
    if ident is None:return False
    if _evidence_identity_commitment_from_payload(ident)!=record.evidence_identity_commitment:return False
    return (record.semantic_assertion_identity==ident['semantic_assertion_identity']
            and record.canonical_content_origin_id==ident['canonical_content_origin_id']
            and record.rooted_provenance_identity==ident['rooted_provenance_identity']
            and record.stable_temporal_identity==ident['stable_temporal_identity'])

def _evidence_identity_matches_components(record,comp):
    if not isinstance(record,EvidenceIdentityRecord):return False
    ident=_evidence_identity_payload_from_components(comp)
    if ident is None:return False
    return (record.evidence_identity_commitment==_evidence_identity_commitment_from_payload(ident)
            and record.semantic_assertion_identity==ident['semantic_assertion_identity']
            and record.canonical_content_origin_id==ident['canonical_content_origin_id']
            and record.rooted_provenance_identity==ident['rooted_provenance_identity']
            and record.stable_temporal_identity==ident['stable_temporal_identity'])

def _role_row_for_components(role_record_id,comp,epistemic_role,claimed_content_origin_id,role_authority_id,resolution_state):
    r=comp['raw'];prov=comp['provenance']
    return {
        'role_record_id':role_record_id,'evidence_id':comp['evidence_id'],
        'assertion_commitment':_evidence_assertion_commitment_from_components(comp),
        'semantic_assertion_identity':_evidence_semantic_assertion_identity_from_components(comp),
        'source_semantics_resolution_certificate_id':None if comp['source_semantics_resolution'] is None else comp['source_semantics_resolution'].certificate_id,
        'provenance_certificate_id':prov.certificate_id,'authority_certificate_id':comp['authority'].certificate_id,
        'root_origin_id':prov.root_origin_id,'referent_entity_id':prov.referent_entity_id,
        'referent_event_id':prov.referent_event_id,'referent_version_id':prov.referent_version_id,
        'valid_from':r.get('valid_from'),'valid_to':r.get('valid_to'),'observed_at':r.get('observed_at'),'available_at':r.get('available_at'),
        'predicate':pkey(r.get('predicate','')),'value':r.get('value'),'polarity':r.get('polarity','POSITIVE'),
        'content_origin_id':_canonical_content_origin_from_components(comp),
        'claimed_content_origin_id':claimed_content_origin_id,
        'epistemic_role':epistemic_role,'role_authority_id':role_authority_id,
        'resolution_state':resolution_state,
    }

TRUSTED_ROLE_RECORD_ID_PREFIX='role:auth:'

def _trusted_role_record_id_reserved(role_record_id):
    return nonblank(role_record_id) and str(role_record_id).startswith(TRUSTED_ROLE_RECORD_ID_PREFIX)

def register_evidence_epistemic_role(role_record_id,raw_evidence,epistemic_role,content_origin_id,
                                      role_authority_id='LOCAL_EPISTEMIC_ROLE_AUTHORITY',resolution_state='RESOLVED',
                                      issue_certificate=True):
    """Register an auditable caller declaration only; this function does not mint role authority."""
    if not _evidence_role_policies_pinned():raise ValueError('epistemic role policy is not pinned')
    if not all(nonblank(x) for x in (role_record_id,epistemic_role,content_origin_id,role_authority_id,resolution_state)):
        raise ValueError('invalid epistemic role registration')
    if epistemic_role not in set(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['allowed_roles']):raise ValueError('invalid epistemic role')
    if resolution_state!=PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['resolved_state']:raise ValueError('unresolved epistemic role cannot be registered as authoritative')
    if _trusted_role_record_id_reserved(role_record_id):
        raise ValueError('role_record_id is reserved for trusted controller role authority')
    if _fixture_role_record_id_owned(role_record_id):
        raise ValueError('role_record_id is owned by active self-test fixture namespace')
    comp,errs=_base_fact_components(raw_evidence,1)
    if errs:raise ValueError('cannot bind epistemic role to inadmissible evidence: '+repr(errs))
    row=_role_row_for_components(role_record_id,comp,epistemic_role,content_origin_id,role_authority_id,resolution_state)
    current=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(role_record_id)
    if current is not None and current!=row:raise ValueError('epistemic role record is append-only')
    EVIDENCE_EPISTEMIC_ROLE_REGISTRY[role_record_id]=row
    # Caller declarations remain intentionally uncertified/unauthorized.
    return None

def bind_evidence_epistemic_role(raw_evidence,epistemic_role,content_origin_id,role_record_id=None,
                                  role_authority_id='LOCAL_EPISTEMIC_ROLE_AUTHORITY'):
    eid=raw_evidence.get('evidence_id') or 'UNBOUND'
    rid=role_record_id or ('role:decl:'+sha((eid,content_origin_id,epistemic_role))[:24])
    cert=register_evidence_epistemic_role(rid,raw_evidence,epistemic_role,content_origin_id,role_authority_id)
    raw_evidence['epistemic_role_record_id']=rid
    return cert

def _evidence_role_authorization_artifact_fingerprint(artifact):
    return canonical_hash(asdict(artifact)) if isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact) else None

def _exact_evidence_role_authorization_key(evidence_id,assertion_commitment,canonical_content_origin_id):
    if not all(nonblank(x) for x in (evidence_id,assertion_commitment,canonical_content_origin_id)):return None
    return 'role-auth-key:'+canonical_hash({
        'evidence_id':evidence_id,
        'assertion_commitment':assertion_commitment,
        'canonical_content_origin_id':canonical_content_origin_id,
    })

def _exact_evidence_role_authorization_key_from_artifact(artifact):
    if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact):return None
    return _exact_evidence_role_authorization_key(artifact.evidence_id,artifact.assertion_commitment,artifact.canonical_content_origin_id)

def _origin_history_firstness_anchor_valid(origin,hist):
    if not isinstance(hist,dict) or hist.get('canonical_content_origin_id')!=origin:return False
    first=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(hist.get('first_authorization_artifact_id'))
    if not isinstance(first,EvidenceEpistemicRoleAuthorizationArtifact) or first.canonical_content_origin_id!=origin:return False
    ident=EVIDENCE_ID_IDENTITY_REGISTRY.get(first.evidence_id)
    if not isinstance(ident,EvidenceIdentityRecord):return False
    return (ident.first_authorization_artifact_id==first.authorization_artifact_id
            and _valid_history_commitment_value(hist.get('first_history_commitment'))
            and hist.get('first_history_commitment')==ident.first_history_commitment)

def _evidence_role_runtime_authority_commitment(artifact):
    if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact):return None
    if not _evidence_role_authorization_artifact_structurally_valid(artifact):return None
    if artifact.authority_scope!='PRODUCTION':return None
    row=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(artifact.role_record_id)
    cert=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(artifact.role_record_id)
    hist=EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(artifact.canonical_content_origin_id)
    grant=_role_issuer_grant(artifact.issuer_grant_id)
    key=_exact_evidence_role_authorization_key_from_artifact(artifact)
    ident=EVIDENCE_ID_IDENTITY_REGISTRY.get(artifact.evidence_id)
    if not isinstance(row,dict) or cert is None or not isinstance(hist,dict) or grant is None or key is None:return None
    if not _evidence_identity_record_structurally_valid(ident):return None
    if EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(key)!=artifact.authorization_artifact_id:return None
    if hist.get('canonical_content_origin_id')!=artifact.canonical_content_origin_id:return None
    if not _origin_history_firstness_anchor_valid(artifact.canonical_content_origin_id,hist):return None
    if hist.get('semantic_assertion_identity')!=artifact.semantic_assertion_identity:return None
    if hist.get('epistemic_role')!=artifact.epistemic_role:return None
    first=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(hist.get('first_authorization_artifact_id'))
    if first is None or first.canonical_content_origin_id!=artifact.canonical_content_origin_id:return None
    if first.semantic_assertion_identity!=artifact.semantic_assertion_identity or first.epistemic_role!=artifact.epistemic_role:return None
    row_ident=_evidence_identity_payload_from_role_row(row)
    if row_ident is None or ident.evidence_identity_commitment!=_evidence_identity_commitment_from_payload(row_ident):return None
    return canonical_hash({
        'authorization_artifact_fingerprint':_evidence_role_authorization_artifact_fingerprint(artifact),
        'role_record_fingerprint':canonical_hash(row),
        'role_certificate_fingerprint':canonical_hash(asdict(cert)),
        'origin_history_fingerprint':canonical_hash(hist),
        'evidence_identity_record_fingerprint':_evidence_identity_record_fingerprint(ident),
        'issuer_grant_fingerprint':canonical_hash(grant),
        'pinned_role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),
        'pinned_role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),
        'exact_role_authorization_key':key,
        'authority_scope':'PRODUCTION',
    })

def _authorization_artifacts_for_role_record(role_record_id):
    return [a for a in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.values()
            if isinstance(a,EvidenceEpistemicRoleAuthorizationArtifact) and a.role_record_id==role_record_id]

def _production_role_record_id_owned(role_record_id):
    if not nonblank(role_record_id):return False
    if role_record_id in EVIDENCE_EPISTEMIC_ROLE_REGISTRY or role_record_id in EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY:return True
    return any(isinstance(a,EvidenceEpistemicRoleAuthorizationArtifact) and a.role_record_id==role_record_id
               for a in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.values())

def _declaration_only_role_record_id_owned(role_record_id):
    if not nonblank(role_record_id) or not isinstance(EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(role_record_id),dict):return False
    if role_record_id in EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY:return False
    return len(_authorization_artifacts_for_role_record(role_record_id))==0

def _trusted_default_role_record_id(evidence_id,origin,epistemic_role,assertion):
    return TRUSTED_ROLE_RECORD_ID_PREFIX+sha((evidence_id,origin,epistemic_role,assertion))[:24]

def _trusted_default_role_record_id_with_legacy_bypass(evidence_id,origin,epistemic_role,assertion):
    primary=_trusted_default_role_record_id(evidence_id,origin,epistemic_role,assertion)
    if not _production_role_record_id_owned(primary):return primary
    if not _declaration_only_role_record_id_owned(primary):return primary
    # Older checkpoints could contain public declaration-only rows in role:auth:.
    # Preserve those rows as nonauthoritative, but do not let them deny future trusted default issuance.
    limit=len(EVIDENCE_EPISTEMIC_ROLE_REGISTRY)+2
    for ordinal in range(1,limit+1):
        candidate=TRUSTED_ROLE_RECORD_ID_PREFIX+sha((evidence_id,origin,epistemic_role,assertion,'legacy-declaration-squat',ordinal))[:24]
        if not _production_role_record_id_owned(candidate):return candidate
        if not _declaration_only_role_record_id_owned(candidate):return candidate
    raise ValueError('trusted role_record_id namespace exhausted by legacy declarations')

def _fixture_role_record_id_owned(role_record_id):
    generation=_ensure_self_test_scope_generation()
    if generation is None or not nonblank(role_record_id):return False
    if (_SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS.get(role_record_id)==generation
        and (role_record_id in _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY
             or role_record_id in _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY)):
        return True
    return any(isinstance(a,EvidenceEpistemicRoleAuthorizationArtifact)
               and a.role_record_id==role_record_id
               and _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(a.authorization_artifact_id)==generation
               for a in _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.values())

def _trusted_role_issuance_entry_resulting_head(sequence,authorization_artifact_id,evidence_id,role_record_id,canonical_content_origin_id,predecessor_chain_head):
    if type(sequence) is not int or sequence<1:return None
    if not all(nonblank(x) for x in (authorization_artifact_id,evidence_id,role_record_id,canonical_content_origin_id,predecessor_chain_head)):return None
    if not _valid_history_commitment_value(predecessor_chain_head):return None
    return canonical_hash({
        'ancestry_version':TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION,
        'sequence':sequence,
        'authorization_artifact_id':authorization_artifact_id,
        'evidence_id':evidence_id,
        'role_record_id':role_record_id,
        'canonical_content_origin_id':canonical_content_origin_id,
        'predecessor_chain_head':predecessor_chain_head,
    })

def _trusted_role_issuance_artifact_binding_valid(artifact):
    if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact) or artifact.authority_scope!='PRODUCTION':return False
    if artifact.trusted_ancestry_version!=TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION:return False
    seq=artifact.trusted_ancestry_sequence;pred=artifact.trusted_ancestry_predecessor_head
    if type(seq) is not int or seq<1 or not _valid_history_commitment_value(pred):return False
    entry=TRUSTED_ROLE_ISSUANCE_CHAIN.get(seq)
    if not isinstance(entry,TrustedRoleIssuanceAncestryEntry) or type(entry.sequence) is not int or entry.sequence!=seq:return False
    if (entry.authorization_artifact_id!=artifact.authorization_artifact_id
        or entry.evidence_id!=artifact.evidence_id
        or entry.role_record_id!=artifact.role_record_id
        or entry.canonical_content_origin_id!=artifact.canonical_content_origin_id
        or entry.predecessor_chain_head!=pred):return False
    expected=_trusted_role_issuance_entry_resulting_head(seq,entry.authorization_artifact_id,entry.evidence_id,entry.role_record_id,entry.canonical_content_origin_id,pred)
    return expected is not None and entry.resulting_chain_head==expected

def _trusted_role_issuance_chain_valid():
    head=TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD
    if not _valid_history_commitment_value(head):return False
    n=len(TRUSTED_ROLE_ISSUANCE_CHAIN)
    if n==0:
        return head==TRUSTED_ROLE_ISSUANCE_GENESIS_HEAD and len(EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY)==0
    # R239: registry positions have one canonical Python representation. Numeric-equivalent
    # non-int keys (True, 1.0, IntEnum(1), etc.) must not alias controller-derived int positions.
    if any(type(k) is not int for k in TRUSTED_ROLE_ISSUANCE_CHAIN):return False
    if set(TRUSTED_ROLE_ISSUANCE_CHAIN)!=set(range(1,n+1)):return False
    artifact_ids=set(EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY)
    entry_artifact_ids=[];prev=TRUSTED_ROLE_ISSUANCE_GENESIS_HEAD
    for seq in range(1,n+1):
        entry=TRUSTED_ROLE_ISSUANCE_CHAIN.get(seq)
        if not isinstance(entry,TrustedRoleIssuanceAncestryEntry) or type(entry.sequence) is not int or entry.sequence!=seq:return False
        if entry.predecessor_chain_head!=prev:return False
        artifact=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(entry.authorization_artifact_id)
        if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact) or artifact.authority_scope!='PRODUCTION':return False
        if not _trusted_role_issuance_artifact_binding_valid(artifact):return False
        expected=_trusted_role_issuance_entry_resulting_head(seq,entry.authorization_artifact_id,entry.evidence_id,entry.role_record_id,entry.canonical_content_origin_id,prev)
        if expected is None or entry.resulting_chain_head!=expected:return False
        entry_artifact_ids.append(entry.authorization_artifact_id);prev=expected
    if len(entry_artifact_ids)!=len(set(entry_artifact_ids)):return False
    if set(entry_artifact_ids)!=artifact_ids:return False
    return head==prev

def _reset_trusted_role_issuance_ancestry_for_tests():
    global TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD
    TRUSTED_ROLE_ISSUANCE_CHAIN.clear()
    TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD=TRUSTED_ROLE_ISSUANCE_GENESIS_HEAD

def _evidence_role_authorization_artifact_structurally_valid(artifact):
    if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact):return False
    if not _evidence_role_policies_pinned():return False
    if artifact.authority_scope!='PRODUCTION':return False
    if not _trusted_role_issuance_artifact_binding_valid(artifact):return False
    if EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(artifact.authorization_artifact_id)!=artifact:return False
    row=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(artifact.role_record_id)
    if not isinstance(row,dict) or row.get('role_record_id')!=artifact.role_record_id:return False
    if artifact.role_record_fingerprint!=canonical_hash(row):return False
    if row.get('evidence_id')!=artifact.evidence_id or row.get('assertion_commitment')!=artifact.assertion_commitment:return False
    if row.get('semantic_assertion_identity')!=artifact.semantic_assertion_identity:return False
    if row.get('content_origin_id')!=artifact.canonical_content_origin_id:return False
    if _canonical_content_origin_from_role_row(row)!=artifact.canonical_content_origin_id:return False
    if row.get('epistemic_role')!=artifact.epistemic_role:return False
    if row.get('resolution_state')!=PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['resolved_state']:return False
    if artifact.pinned_role_policy_hash!=pinned_evidence_epistemic_role_policy_hash():return False
    if artifact.pinned_role_issuer_policy_hash!=pinned_evidence_epistemic_role_issuer_policy_hash():return False
    grant=_role_issuer_grant(artifact.issuer_grant_id)
    if grant is None or artifact.epistemic_role not in set(grant['allowed_roles']):return False
    if artifact.issuer_authority_id!=grant['issuer_authority_id'] or artifact.issuer_grant_fingerprint!=canonical_hash(grant):return False
    if row.get('role_authority_id')!=artifact.issuer_authority_id:return False
    if artifact.source_semantics_resolution_certificate_id!=row.get('source_semantics_resolution_certificate_id'):return False
    if artifact.provenance_certificate_id!=row.get('provenance_certificate_id') or artifact.authority_certificate_id!=row.get('authority_certificate_id'):return False
    key=_exact_evidence_role_authorization_key_from_artifact(artifact)
    if key is None or EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(key)!=artifact.authorization_artifact_id:return False
    ident=EVIDENCE_ID_IDENTITY_REGISTRY.get(artifact.evidence_id)
    if not _evidence_identity_record_structurally_valid(ident):return False
    row_ident=_evidence_identity_payload_from_role_row(row)
    if row_ident is None or ident.evidence_identity_commitment!=_evidence_identity_commitment_from_payload(row_ident):return False
    payload={
        'role_record_id':artifact.role_record_id,'evidence_id':artifact.evidence_id,
        'assertion_commitment':artifact.assertion_commitment,'semantic_assertion_identity':artifact.semantic_assertion_identity,
        'canonical_content_origin_id':artifact.canonical_content_origin_id,'epistemic_role':artifact.epistemic_role,
        'issuer_grant_id':artifact.issuer_grant_id,'issuer_authority_id':artifact.issuer_authority_id,
        'issuer_grant_fingerprint':artifact.issuer_grant_fingerprint,'pinned_role_policy_hash':artifact.pinned_role_policy_hash,
        'pinned_role_issuer_policy_hash':artifact.pinned_role_issuer_policy_hash,
        'source_semantics_resolution_certificate_id':artifact.source_semantics_resolution_certificate_id,
        'provenance_certificate_id':artifact.provenance_certificate_id,'authority_certificate_id':artifact.authority_certificate_id,
        'role_record_fingerprint':artifact.role_record_fingerprint,'issuance_history_commitment':artifact.issuance_history_commitment,
        'authority_scope':artifact.authority_scope,
        'trusted_ancestry_version':artifact.trusted_ancestry_version,
        'trusted_ancestry_sequence':artifact.trusted_ancestry_sequence,
        'trusted_ancestry_predecessor_head':artifact.trusted_ancestry_predecessor_head,
    }
    expected=sha(payload)
    return (artifact.authorization_artifact_id==expected and artifact.authorization_artifact_fingerprint==expected
            and _valid_history_commitment_value(artifact.issuance_history_commitment))

def _evidence_role_artifact_runtime_authorized(artifact):
    if (not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact)
        or _DECISION_REHYDRATION_ACTIVE
        or not _trusted_role_issuance_chain_valid()
        or not _evidence_role_authorization_artifact_structurally_valid(artifact)):
        return False
    if artifact.authority_scope!='PRODUCTION':return False
    aid=artifact.authorization_artifact_id
    live=_evidence_role_runtime_authority_commitment(artifact)
    return (live is not None
            and _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.get(aid)==_evidence_role_authorization_artifact_fingerprint(artifact)
            and _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.get(aid)==live)

def _authorize_fresh_evidence_role_artifact(artifact):
    if isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact) and not _DECISION_REHYDRATION_ACTIVE:
        if artifact.authority_scope!='PRODUCTION':return
        if not _trusted_role_issuance_chain_valid():return
        if _evidence_role_authorization_artifact_structurally_valid(artifact):
            commitment=_evidence_role_runtime_authority_commitment(artifact)
            if commitment is not None:
                _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS[artifact.authorization_artifact_id]=_evidence_role_authorization_artifact_fingerprint(artifact)
                _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS[artifact.authorization_artifact_id]=commitment

def _controller_issue_evidence_epistemic_role(raw_evidence,epistemic_role,issuer_grant_id=None,role_record_id=None,_capability=None):
    """Controller-owned production issuance path. Fixture authority uses an isolated overlay."""
    global TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD
    if _capability is _SELF_TEST_ROLE_ISSUER_CAPABILITY:
        return _fixture_issue_evidence_epistemic_role(raw_evidence,epistemic_role,role_record_id,issuer_grant_id)
    if _capability is not _EVIDENCE_ROLE_ISSUER_CAPABILITY:
        raise ValueError('missing controller role-issuer capability')
    if _DECISION_REHYDRATION_ACTIVE:raise ValueError('cannot issue role authority during rehydration')
    if not _evidence_role_policies_pinned():raise ValueError('epistemic role policy is not pinned')
    if epistemic_role not in set(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['allowed_roles']):raise ValueError('invalid epistemic role')
    gid=issuer_grant_id or _default_role_issuer_grant_id(epistemic_role);grant=_role_issuer_grant(gid)
    if grant is None or epistemic_role not in set(grant['allowed_roles']):raise ValueError('issuer grant does not authorize role')
    comp,errs=_base_fact_components(raw_evidence,1)
    if errs:raise ValueError('cannot authorize epistemic role for inadmissible evidence: '+repr(errs))
    origin=_canonical_content_origin_from_components(comp);semantic_id=_evidence_semantic_assertion_identity_from_components(comp)
    if not nonblank(origin) or not nonblank(semantic_id):raise ValueError('canonical content origin unresolved')
    eid=comp['evidence_id'];assertion=_evidence_assertion_commitment_from_components(comp)
    identity_payload=_evidence_identity_payload_from_components(comp)
    if identity_payload is None:raise ValueError('global evidence identity unresolved')
    identity_commitment=_evidence_identity_commitment_from_payload(identity_payload)
    if not _trusted_role_issuance_chain_valid():
        raise ValueError('trusted role issuance ancestry chain is invalid')
    existing_identity=EVIDENCE_ID_IDENTITY_REGISTRY.get(eid)
    if existing_identity is not None:
        if not _evidence_identity_record_structurally_valid(existing_identity):
            raise ValueError('existing global evidence identity is invalid')
        if existing_identity.evidence_identity_commitment!=identity_commitment:
            raise ValueError('evidence_id is already bound to a different immutable evidence identity')
    history=EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(origin)
    if history is not None and (history.get('semantic_assertion_identity')!=semantic_id or history.get('epistemic_role')!=epistemic_role):
        raise ValueError('conflicting epistemic role for existing content origin')
    exact_key=_exact_evidence_role_authorization_key(eid,assertion,origin)
    existing_aid=EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(exact_key)
    if existing_aid is not None:
        artifact=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(existing_aid)
        if (artifact is None or artifact.evidence_id!=eid or artifact.assertion_commitment!=assertion
            or artifact.canonical_content_origin_id!=origin or artifact.epistemic_role!=epistemic_role
            or artifact.authority_scope!='PRODUCTION'):
            raise ValueError('conflicting exact evidence role authorization')
        if existing_identity is None:
            raise ValueError('existing production authorization is missing global evidence identity')
        cert=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(artifact.role_record_id)
        if cert is None or not validate_evidence_epistemic_role_certificate(cert,assertion,require_runtime_authority=False):
            raise ValueError('existing exact role authorization is not valid')
        _authorize_fresh_evidence_role_artifact(artifact)
        raw_evidence['epistemic_role_record_id']=artifact.role_record_id
        return cert
    pre_issuance_history=decision_persistence_history_commitment()
    rid=(role_record_id if role_record_id is not None
         else _trusted_default_role_record_id_with_legacy_bypass(eid,origin,epistemic_role,assertion))
    if _fixture_role_record_id_owned(rid):
        raise ValueError('role_record_id is owned by active self-test fixture namespace')
    row=_role_row_for_components(rid,comp,epistemic_role,origin,grant['issuer_authority_id'],PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['resolved_state'])
    current=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(rid)
    arts=_authorization_artifacts_for_role_record(rid)
    if current is not None and current!=row:raise ValueError('epistemic role record is append-only')
    if arts:raise ValueError('role record already has authorization artifact')
    EVIDENCE_EPISTEMIC_ROLE_REGISTRY[rid]=row
    issuance=decision_persistence_history_commitment()
    ancestry_sequence=len(TRUSTED_ROLE_ISSUANCE_CHAIN)+1
    ancestry_predecessor=TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD
    payload={
        'role_record_id':rid,'evidence_id':eid,'assertion_commitment':row['assertion_commitment'],
        'semantic_assertion_identity':semantic_id,'canonical_content_origin_id':origin,'epistemic_role':epistemic_role,
        'issuer_grant_id':gid,'issuer_authority_id':grant['issuer_authority_id'],'issuer_grant_fingerprint':canonical_hash(grant),
        'pinned_role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),
        'pinned_role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),
        'source_semantics_resolution_certificate_id':row['source_semantics_resolution_certificate_id'],
        'provenance_certificate_id':row['provenance_certificate_id'],'authority_certificate_id':row['authority_certificate_id'],
        'role_record_fingerprint':canonical_hash(row),'issuance_history_commitment':issuance,
        'authority_scope':'PRODUCTION',
        'trusted_ancestry_version':TRUSTED_ROLE_ISSUANCE_ANCESTRY_VERSION,
        'trusted_ancestry_sequence':ancestry_sequence,
        'trusted_ancestry_predecessor_head':ancestry_predecessor,
    }
    aid=sha(payload)
    artifact=EvidenceEpistemicRoleAuthorizationArtifact(aid,**payload,authorization_artifact_fingerprint=aid)
    ancestry_resulting=_trusted_role_issuance_entry_resulting_head(
        ancestry_sequence,aid,eid,rid,origin,ancestry_predecessor)
    if ancestry_resulting is None:
        EVIDENCE_EPISTEMIC_ROLE_REGISTRY.pop(rid,None)
        raise ValueError('cannot derive trusted role issuance ancestry entry')
    ancestry_entry=TrustedRoleIssuanceAncestryEntry(
        ancestry_sequence,aid,eid,rid,origin,ancestry_predecessor,ancestry_resulting)
    if exact_key in EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX:
        EVIDENCE_EPISTEMIC_ROLE_REGISTRY.pop(rid,None)
        raise ValueError('exact evidence role authorization already exists')
    if existing_identity is None:
        identity_record=_make_evidence_identity_record(eid,comp,assertion,aid,pre_issuance_history)
        if identity_record is None:
            EVIDENCE_EPISTEMIC_ROLE_REGISTRY.pop(rid,None)
            raise ValueError('cannot establish global evidence identity')
        EVIDENCE_ID_IDENTITY_REGISTRY[eid]=identity_record
    else:
        identity_record=existing_identity
    EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY[aid]=artifact
    EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX[exact_key]=aid
    if history is None:
        EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY[origin]={
            'canonical_content_origin_id':origin,'semantic_assertion_identity':semantic_id,'epistemic_role':epistemic_role,
            'first_authorization_artifact_id':aid,'first_history_commitment':pre_issuance_history,
        }
    TRUSTED_ROLE_ISSUANCE_CHAIN[ancestry_sequence]=ancestry_entry
    TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD=ancestry_resulting
    if not _evidence_identity_record_structurally_valid(identity_record):
        # The first artifact was not present when a new record was constructed; it must validate now.
        EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.pop(aid,None);EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.pop(exact_key,None)
        TRUSTED_ROLE_ISSUANCE_CHAIN.pop(ancestry_sequence,None);TRUSTED_ROLE_ISSUANCE_CHAIN_HEAD=ancestry_predecessor
        if history is None:EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.pop(origin,None)
        if existing_identity is None:EVIDENCE_ID_IDENTITY_REGISTRY.pop(eid,None)
        EVIDENCE_EPISTEMIC_ROLE_REGISTRY.pop(rid,None)
        raise ValueError('global evidence identity could not be validated after issuance')
    cert=issue_evidence_epistemic_role_certificate(rid)
    _authorize_fresh_evidence_role_artifact(artifact)
    raw_evidence['epistemic_role_record_id']=rid
    return cert

def _clear_self_test_evidence_role_state():
    for reg in (_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY,
                _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY,
                _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY,
                _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY,
                _SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX,
                _SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY,
                _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS,
                _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS,
                _SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS,
                _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS):
        reg.clear()

def _mint_self_test_scope_generation_id():
    global _SELF_TEST_SCOPE_GENERATION_COUNTER
    _SELF_TEST_SCOPE_GENERATION_COUNTER+=1
    return 'self-test-scope:'+sha((_SELF_TEST_SCOPE_GENERATION_COUNTER,decision_persistence_history_commitment()))[:32]

def enter_self_test_role_scope():
    """Start one fresh fixture-authority generation. Old fixture authority is never inherited."""
    global _SELF_TEST_ROLE_AUTHORITY_ACTIVE,_SELF_TEST_SCOPE_GENERATION_ID
    if _SELF_TEST_ROLE_AUTHORITY_ACTIVE or _SELF_TEST_SCOPE_GENERATION_ID is not None:
        return None
    _clear_self_test_evidence_role_state()
    _SELF_TEST_SCOPE_GENERATION_ID=_mint_self_test_scope_generation_id()
    _SELF_TEST_ROLE_AUTHORITY_ACTIVE=True
    return _SELF_TEST_SCOPE_GENERATION_ID

def exit_self_test_role_scope():
    """End the active fixture generation irreversibly and clear all live fixture authority."""
    global _SELF_TEST_ROLE_AUTHORITY_ACTIVE,_SELF_TEST_SCOPE_GENERATION_ID
    was_active=_SELF_TEST_ROLE_AUTHORITY_ACTIVE or _SELF_TEST_SCOPE_GENERATION_ID is not None
    _SELF_TEST_ROLE_AUTHORITY_ACTIVE=False
    _SELF_TEST_SCOPE_GENERATION_ID=None
    _clear_self_test_evidence_role_state()
    return bool(was_active)

def _ensure_self_test_scope_generation():
    """Return the explicit active generation; the compatibility boolean never mints authority."""
    if not _SELF_TEST_ROLE_AUTHORITY_ACTIVE or not nonblank(_SELF_TEST_SCOPE_GENERATION_ID):
        return None
    return _SELF_TEST_SCOPE_GENERATION_ID

def _rotate_self_test_scope_generation_if_active():
    global _SELF_TEST_SCOPE_GENERATION_ID
    _clear_self_test_evidence_role_state()
    if _SELF_TEST_ROLE_AUTHORITY_ACTIVE:
        _SELF_TEST_SCOPE_GENERATION_ID=_mint_self_test_scope_generation_id()
    else:
        _SELF_TEST_SCOPE_GENERATION_ID=None
    return _SELF_TEST_SCOPE_GENERATION_ID

def _fixture_scope_generation_matches(value):
    return (nonblank(value) and _SELF_TEST_ROLE_AUTHORITY_ACTIVE
            and nonblank(_SELF_TEST_SCOPE_GENERATION_ID)
            and value==_SELF_TEST_SCOPE_GENERATION_ID)

def _fixture_authorization_artifacts_for_role_record(role_record_id):
    return [a for a in _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.values()
            if isinstance(a,EvidenceEpistemicRoleAuthorizationArtifact) and a.role_record_id==role_record_id]

def _fixture_remove_evidence_role_state(evidence_id):
    aids=[aid for aid,a in _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.items()
          if isinstance(a,EvidenceEpistemicRoleAuthorizationArtifact) and a.evidence_id==evidence_id]
    rids=set();origins=set()
    for aid in aids:
        a=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(aid)
        if a is not None:rids.add(a.role_record_id);origins.add(a.canonical_content_origin_id)
        _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.pop(aid,None)
        _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.pop(aid,None)
        _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.pop(aid,None)
        _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.pop(aid,None)
    for key,aid in list(_SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.items()):
        if aid in aids:_SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.pop(key,None)
    for rid in rids:
        _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY.pop(rid,None)
        _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.pop(rid,None)
        _SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS.pop(rid,None)
    for origin in origins:
        hist=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(origin)
        if isinstance(hist,dict) and hist.get('first_authorization_artifact_id') in aids:
            _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.pop(origin,None)
    for ikey,ident in list(_SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY.items()):
        if isinstance(ident,dict) and ident.get('evidence_id')==evidence_id:
            _SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY.pop(ikey,None)

def _fixture_evidence_role_artifact_structurally_valid(artifact):
    generation=_ensure_self_test_scope_generation()
    if generation is None or not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact):return False
    if _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(artifact.authorization_artifact_id)!=generation:return False
    if artifact.authority_scope!='SELF_TEST_ONLY' or not _evidence_role_policies_pinned():return False
    if _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(artifact.authorization_artifact_id)!=artifact:return False
    row=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(artifact.role_record_id)
    if not isinstance(row,dict) or canonical_hash(row)!=artifact.role_record_fingerprint:return False
    if row.get('evidence_id')!=artifact.evidence_id or row.get('assertion_commitment')!=artifact.assertion_commitment:return False
    if row.get('semantic_assertion_identity')!=artifact.semantic_assertion_identity or row.get('content_origin_id')!=artifact.canonical_content_origin_id:return False
    if row.get('epistemic_role')!=artifact.epistemic_role:return False
    key=_exact_evidence_role_authorization_key_from_artifact(artifact)
    if _SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(key)!=artifact.authorization_artifact_id:return False
    grant=_role_issuer_grant(artifact.issuer_grant_id)
    if grant is None or artifact.epistemic_role not in set(grant['allowed_roles']):return False
    payload={
        'role_record_id':artifact.role_record_id,'evidence_id':artifact.evidence_id,
        'assertion_commitment':artifact.assertion_commitment,'semantic_assertion_identity':artifact.semantic_assertion_identity,
        'canonical_content_origin_id':artifact.canonical_content_origin_id,'epistemic_role':artifact.epistemic_role,
        'issuer_grant_id':artifact.issuer_grant_id,'issuer_authority_id':artifact.issuer_authority_id,
        'issuer_grant_fingerprint':artifact.issuer_grant_fingerprint,'pinned_role_policy_hash':artifact.pinned_role_policy_hash,
        'pinned_role_issuer_policy_hash':artifact.pinned_role_issuer_policy_hash,
        'source_semantics_resolution_certificate_id':artifact.source_semantics_resolution_certificate_id,
        'provenance_certificate_id':artifact.provenance_certificate_id,'authority_certificate_id':artifact.authority_certificate_id,
        'role_record_fingerprint':artifact.role_record_fingerprint,'issuance_history_commitment':artifact.issuance_history_commitment,
        'authority_scope':artifact.authority_scope,
    }
    expected=sha({**payload,'scope_generation_id':generation})
    return artifact.authorization_artifact_id==expected and artifact.authorization_artifact_fingerprint==expected

def _fixture_evidence_role_runtime_commitment(artifact):
    if not _fixture_evidence_role_artifact_structurally_valid(artifact):return None
    row=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(artifact.role_record_id)
    cert=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(artifact.role_record_id)
    hist=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(artifact.canonical_content_origin_id)
    key=_exact_evidence_role_authorization_key_from_artifact(artifact)
    generation=_SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(artifact.authorization_artifact_id)
    ident=_SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY.get('fixture-evidence-id:'+sha((generation,artifact.evidence_id))) if nonblank(generation) else None
    grant=_role_issuer_grant(artifact.issuer_grant_id)
    if cert is None or not isinstance(hist,dict) or not isinstance(ident,dict) or grant is None:return None
    return canonical_hash({
        'authorization_artifact_fingerprint':_evidence_role_authorization_artifact_fingerprint(artifact),
        'role_record_fingerprint':canonical_hash(row),'role_certificate_fingerprint':canonical_hash(asdict(cert)),
        'origin_history_fingerprint':canonical_hash(hist),'evidence_identity_record_fingerprint':canonical_hash(ident),
        'issuer_grant_fingerprint':canonical_hash(grant),'authority_scope':'SELF_TEST_ONLY',
        'scope_generation_id':_SELF_TEST_SCOPE_GENERATION_ID,
    })

def _make_fixture_evidence_epistemic_role_certificate(role_record_id):
    generation=_ensure_self_test_scope_generation()
    if generation is None:return None
    if _SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS.get(role_record_id)!=generation:return None
    row=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(role_record_id)
    arts=_fixture_authorization_artifacts_for_role_record(role_record_id)
    if not isinstance(row,dict) or len(arts)!=1:return None
    artifact=arts[0]
    if not _fixture_evidence_role_artifact_structurally_valid(artifact):return None
    payload={
        'role_record_id':role_record_id,'evidence_id':row.get('evidence_id'),'assertion_commitment':row.get('assertion_commitment'),
        'source_semantics_resolution_certificate_id':row.get('source_semantics_resolution_certificate_id'),
        'provenance_certificate_id':row.get('provenance_certificate_id'),'authority_certificate_id':row.get('authority_certificate_id'),
        'content_origin_id':row.get('content_origin_id'),'epistemic_role':row.get('epistemic_role'),
        'role_authority_id':row.get('role_authority_id'),'resolution_state':row.get('resolution_state'),
        'role_record_fingerprint':canonical_hash(row),'role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),
        'authorization_artifact_id':artifact.authorization_artifact_id,
        'authorization_artifact_fingerprint':_evidence_role_authorization_artifact_fingerprint(artifact),
        'role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),'result':'PASS',
    }
    return EvidenceEpistemicRoleCertificate(sha({**payload,'scope_generation_id':generation}),**payload)

def _fixture_issue_evidence_epistemic_role(raw_evidence,epistemic_role,role_record_id=None,issuer_grant_id=None):
    generation=_ensure_self_test_scope_generation()
    if generation is None:raise ValueError('self-test role issuer is not active')
    if _DECISION_REHYDRATION_ACTIVE:raise ValueError('cannot issue fixture role during rehydration')
    if not _evidence_role_policies_pinned():raise ValueError('epistemic role policy is not pinned')
    gid=issuer_grant_id or _default_role_issuer_grant_id(epistemic_role);grant=_role_issuer_grant(gid)
    if grant is None or epistemic_role not in set(grant['allowed_roles']):raise ValueError('issuer grant does not authorize role')
    comp,errs=_base_fact_components(raw_evidence,1)
    if errs:raise ValueError('cannot authorize fixture role for inadmissible evidence: '+repr(errs))
    eid=comp['evidence_id'];assertion=_evidence_assertion_commitment_from_components(comp)
    origin=_canonical_content_origin_from_components(comp);semantic=_evidence_semantic_assertion_identity_from_components(comp)
    identity_payload=_evidence_identity_payload_from_components(comp)
    if identity_payload is None:raise ValueError('fixture evidence identity unresolved')
    ident_commit=_evidence_identity_commitment_from_payload(identity_payload)
    fixture_identity_key='fixture-evidence-id:'+sha((generation,eid))
    existing_fixture_identity=_SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY.get(fixture_identity_key)
    if existing_fixture_identity is not None:
        identity_conflict=(not isinstance(existing_fixture_identity,dict)
            or existing_fixture_identity.get('scope_generation_id')!=generation
            or existing_fixture_identity.get('evidence_id')!=eid
            or existing_fixture_identity.get('evidence_identity_commitment')!=ident_commit)
        if identity_conflict:
            # Legacy self-test mutation compatibility is replacement, never coexistence: the exact prior
            # fixture identity/role authority for this evidence_id is removed before the new one is issued.
            # This path exists only under the explicit SELF_TEST_ONLY autorebind capability.
            if (_SELF_TEST_FIXTURE_ROLE_AUTOREBIND and isinstance(role_record_id,str)
                and role_record_id.startswith('role:auto:')):
                _fixture_remove_evidence_role_state(eid)
                existing_fixture_identity=None
            else:
                raise ValueError('fixture evidence_id is already bound to a different identity in this scope generation')
    # Existing production authority may be consumed by fixture code without mutation.
    prod_key=_exact_evidence_role_authorization_key(eid,assertion,origin)
    prod_aid=EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(prod_key)
    if prod_aid is not None:
        prod_art=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(prod_aid)
        if prod_art is not None and prod_art.epistemic_role==epistemic_role:
            cert=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(prod_art.role_record_id)
            if cert is not None and validate_evidence_epistemic_role_certificate(cert,assertion):
                raw_evidence['epistemic_role_record_id']=prod_art.role_record_id
                return cert
    exact_key=prod_key
    existing_aid=_SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(exact_key)
    if existing_aid is not None:
        art=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(existing_aid)
        if (art is None or art.epistemic_role!=epistemic_role
            or _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(existing_aid)!=generation):
            raise ValueError('conflicting fixture exact role authorization')
        cert=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(art.role_record_id)
        if cert is None:raise ValueError('fixture certificate missing')
        raw_evidence['epistemic_role_record_id']=art.role_record_id
        return cert
    history=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(origin)
    if history is not None and (history.get('semantic_assertion_identity')!=semantic or history.get('epistemic_role')!=epistemic_role):
        raise ValueError('conflicting fixture role for content origin')
    rid=role_record_id or ('role:auto:'+sha((eid,origin,epistemic_role,assertion))[:24])
    if _production_role_record_id_owned(rid):
        raise ValueError('role_record_id is owned by production namespace')
    row=_role_row_for_components(rid,comp,epistemic_role,origin,grant['issuer_authority_id'],PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['resolved_state'])
    current=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(rid)
    if current is not None and current!=row:raise ValueError('fixture role record is append-only')
    _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_REGISTRY[rid]=row
    _SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS[rid]=generation
    issuance=decision_persistence_history_commitment()
    payload={
        'role_record_id':rid,'evidence_id':eid,'assertion_commitment':row['assertion_commitment'],
        'semantic_assertion_identity':semantic,'canonical_content_origin_id':origin,'epistemic_role':epistemic_role,
        'issuer_grant_id':gid,'issuer_authority_id':grant['issuer_authority_id'],'issuer_grant_fingerprint':canonical_hash(grant),
        'pinned_role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),'pinned_role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),
        'source_semantics_resolution_certificate_id':row['source_semantics_resolution_certificate_id'],
        'provenance_certificate_id':row['provenance_certificate_id'],'authority_certificate_id':row['authority_certificate_id'],
        'role_record_fingerprint':canonical_hash(row),'issuance_history_commitment':issuance,'authority_scope':'SELF_TEST_ONLY',
    }
    aid=sha({**payload,'scope_generation_id':generation});art=EvidenceEpistemicRoleAuthorizationArtifact(aid,**payload,authorization_artifact_fingerprint=aid)
    if existing_fixture_identity is None:
        _SELF_TEST_EVIDENCE_ID_IDENTITY_REGISTRY[fixture_identity_key]={
            'scope_generation_id':generation,'evidence_id':eid,'evidence_identity_commitment':ident_commit,
            'assertion_commitment':assertion,'canonical_content_origin_id':origin,
            'first_authorization_artifact_id':aid,
        }
    _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY[aid]=art
    _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS[aid]=generation
    _SELF_TEST_EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX[exact_key]=aid
    if history is None:
        _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY[origin]={
            'canonical_content_origin_id':origin,'semantic_assertion_identity':semantic,'epistemic_role':epistemic_role,
            'first_authorization_artifact_id':aid,
        }
    cert=_make_fixture_evidence_epistemic_role_certificate(rid)
    if cert is None:raise ValueError('fixture role certificate cannot be issued')
    _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY[rid]=cert
    com=_fixture_evidence_role_runtime_commitment(art)
    _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS[aid]=_evidence_role_authorization_artifact_fingerprint(art)
    _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS[aid]=com
    raw_evidence['epistemic_role_record_id']=rid
    return cert

def _make_production_evidence_epistemic_role_certificate(role_record_id):
    if not _evidence_role_policies_pinned():return None
    row=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(role_record_id)
    if not isinstance(row,dict) or row.get('role_record_id')!=role_record_id:return None
    if row.get('epistemic_role') not in set(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['allowed_roles']):return None
    if row.get('resolution_state')!=PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['resolved_state']:return None
    arts=_authorization_artifacts_for_role_record(role_record_id)
    if len(arts)!=1:return None
    artifact=arts[0]
    if not _evidence_role_authorization_artifact_structurally_valid(artifact):return None
    payload={
        'role_record_id':role_record_id,'evidence_id':row.get('evidence_id'),'assertion_commitment':row.get('assertion_commitment'),
        'source_semantics_resolution_certificate_id':row.get('source_semantics_resolution_certificate_id'),
        'provenance_certificate_id':row.get('provenance_certificate_id'),'authority_certificate_id':row.get('authority_certificate_id'),
        'content_origin_id':row.get('content_origin_id'),'epistemic_role':row.get('epistemic_role'),
        'role_authority_id':row.get('role_authority_id'),'resolution_state':row.get('resolution_state'),
        'role_record_fingerprint':canonical_hash(row),'role_policy_hash':pinned_evidence_epistemic_role_policy_hash(),
        'authorization_artifact_id':artifact.authorization_artifact_id,
        'authorization_artifact_fingerprint':_evidence_role_authorization_artifact_fingerprint(artifact),
        'role_issuer_policy_hash':pinned_evidence_epistemic_role_issuer_policy_hash(),'result':'PASS',
    }
    if not all(nonblank(payload[k]) for k in ('evidence_id','assertion_commitment','provenance_certificate_id','authority_certificate_id','content_origin_id')):return None
    return EvidenceEpistemicRoleCertificate(sha(payload),**payload)

def make_evidence_epistemic_role_certificate(role_record_id):
    prod_owned=_production_role_record_id_owned(role_record_id)
    fixture_owned=_fixture_role_record_id_owned(role_record_id)
    if prod_owned and fixture_owned:return None
    if fixture_owned:return _make_fixture_evidence_epistemic_role_certificate(role_record_id)
    if prod_owned:return _make_production_evidence_epistemic_role_certificate(role_record_id)
    return None

def issue_evidence_epistemic_role_certificate(role_record_id):
    cert=make_evidence_epistemic_role_certificate(role_record_id)
    if cert is None:raise ValueError('epistemic role certificate cannot be issued')
    prod_art=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
    fixture_art=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
    if (prod_art is None)==(fixture_art is None):
        raise ValueError('authorization artifact namespace is unresolved or ambiguous')
    if prod_art is not None:
        if prod_art.authority_scope!='PRODUCTION':raise ValueError('invalid production authorization artifact scope')
        EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY[role_record_id]=cert
    else:
        generation=_ensure_self_test_scope_generation()
        if generation is None or fixture_art.authority_scope!='SELF_TEST_ONLY':raise ValueError('invalid fixture authorization artifact scope')
        if _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(fixture_art.authorization_artifact_id)!=generation:
            raise ValueError('fixture authorization artifact generation mismatch')
        _SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY[role_record_id]=cert
    return cert

def validate_evidence_epistemic_role_certificate(cert,assertion_commitment=None,require_runtime_authority=True):
    if cert is None or not _evidence_role_policies_pinned():return False
    prod_art=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
    fixture_art=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
    if prod_art is not None and fixture_art is not None:return False
    if fixture_art is not None:
        generation=_ensure_self_test_scope_generation()
        if generation is None or fixture_art.authority_scope!='SELF_TEST_ONLY':return False
        if _SELF_TEST_AUTH_ARTIFACT_GENERATION_BINDINGS.get(cert.authorization_artifact_id)!=generation:return False
        if _SELF_TEST_ROLE_RECORD_GENERATION_BINDINGS.get(cert.role_record_id)!=generation:return False
        current=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(cert.role_record_id)
        fresh=_make_fixture_evidence_epistemic_role_certificate(cert.role_record_id)
        if current is None or fresh is None or asdict(current)!=asdict(cert) or asdict(fresh)!=asdict(cert):return False
        if fixture_art.role_record_id!=cert.role_record_id:return False
        if cert.authorization_artifact_fingerprint!=_evidence_role_authorization_artifact_fingerprint(fixture_art):return False
        if require_runtime_authority:
            live=_fixture_evidence_role_runtime_commitment(fixture_art)
            aid=fixture_art.authorization_artifact_id
            if (live is None
                or _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.get(aid)!=_evidence_role_authorization_artifact_fingerprint(fixture_art)
                or _SELF_TEST_EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.get(aid)!=live):return False
        return assertion_commitment is None or cert.assertion_commitment==assertion_commitment
    if prod_art is not None:
        if prod_art.authority_scope!='PRODUCTION' or prod_art.role_record_id!=cert.role_record_id:return False
        current=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(cert.role_record_id)
        fresh=_make_production_evidence_epistemic_role_certificate(cert.role_record_id)
        if current is None or fresh is None or asdict(current)!=asdict(cert) or asdict(fresh)!=asdict(cert):return False
        if cert.authorization_artifact_fingerprint!=_evidence_role_authorization_artifact_fingerprint(prod_art):return False
        if require_runtime_authority and not _evidence_role_artifact_runtime_authorized(prod_art):return False
        return assertion_commitment is None or cert.assertion_commitment==assertion_commitment
    return False

def _evidence_role_authorization_registry_valid():
    if not _evidence_role_policies_pinned():return False
    if not _trusted_role_issuance_chain_valid():return False
    seen_keys={}; seen_evidence={}
    # Every production evidence identity row must be internally valid.
    for eid,ident in EVIDENCE_ID_IDENTITY_REGISTRY.items():
        if not isinstance(ident,EvidenceIdentityRecord) or eid!=ident.evidence_id:return False
        if not _evidence_identity_record_structurally_valid(ident):return False
    for aid,artifact in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.items():
        if not isinstance(artifact,EvidenceEpistemicRoleAuthorizationArtifact) or aid!=artifact.authorization_artifact_id:return False
        if artifact.authority_scope!='PRODUCTION':return False
        key=_exact_evidence_role_authorization_key_from_artifact(artifact)
        if key is None:return False
        if key in seen_keys and seen_keys[key]!=aid:return False
        seen_keys[key]=aid
        ident=EVIDENCE_ID_IDENTITY_REGISTRY.get(artifact.evidence_id)
        if not isinstance(ident,EvidenceIdentityRecord):return False
        row=EVIDENCE_EPISTEMIC_ROLE_REGISTRY.get(artifact.role_record_id)
        row_ident=_evidence_identity_payload_from_role_row(row)
        if row_ident is None:return False
        row_commit=_evidence_identity_commitment_from_payload(row_ident)
        prior=seen_evidence.get(artifact.evidence_id)
        if prior is not None and prior!=row_commit:return False
        seen_evidence[artifact.evidence_id]=row_commit
        if ident.evidence_identity_commitment!=row_commit:return False
        if EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.get(key)!=aid:return False
        if not _evidence_role_authorization_artifact_structurally_valid(artifact):return False
        cert=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(artifact.role_record_id)
        if cert is None or not validate_evidence_epistemic_role_certificate(cert,artifact.assertion_commitment,require_runtime_authority=False):return False
        hist=EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.get(artifact.canonical_content_origin_id)
        if not isinstance(hist,dict):return False
        if hist.get('semantic_assertion_identity')!=artifact.semantic_assertion_identity or hist.get('epistemic_role')!=artifact.epistemic_role:return False
        first=hist.get('first_authorization_artifact_id')
        if first not in EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY:return False
    if set(EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX)!=set(seen_keys):return False
    for key,aid in EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX.items():
        if seen_keys.get(key)!=aid:return False
    for origin,hist in EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY.items():
        if not isinstance(hist,dict) or hist.get('canonical_content_origin_id')!=origin:return False
        if not _origin_history_firstness_anchor_valid(origin,hist):return False
        first=EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(hist.get('first_authorization_artifact_id'))
        if first is None or first.canonical_content_origin_id!=origin:return False
        if first.semantic_assertion_identity!=hist.get('semantic_assertion_identity') or first.epistemic_role!=hist.get('epistemic_role'):return False
    for rid,cert in EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.items():
        if not isinstance(cert,EvidenceEpistemicRoleCertificate) or rid!=cert.role_record_id:return False
        if len(_authorization_artifacts_for_role_record(rid))!=1:return False
        if not validate_evidence_epistemic_role_certificate(cert,require_runtime_authority=False):return False
    return True

def _role_certificate_for_components(comp):
    rid=comp['raw'].get('epistemic_role_record_id')
    if not nonblank(rid):return None
    cert=EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(rid)
    if cert is None and _ensure_self_test_scope_generation() is not None:
        cert=_SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(rid)
    commitment=_evidence_assertion_commitment_from_components(comp)
    if not validate_evidence_epistemic_role_certificate(cert,commitment):
        # Self-test-only compatibility path: exact mutated legacy fixtures are reclassified through
        # the controller-owned fixture issuer, never through the public declaration API.
        if _ensure_self_test_scope_generation() is not None and _SELF_TEST_FIXTURE_ROLE_AUTOREBIND and isinstance(rid,str) and rid.startswith('role:auto:'):
            try:
                fresh_rid='role:auto:rebind:'+sha((comp['evidence_id'],commitment))[:20]
                cert=_fixture_issue_evidence_epistemic_role(comp['raw'],'DIRECT_WORLD_RECORD',role_record_id=fresh_rid)
            except ValueError:return None
            commitment=_evidence_assertion_commitment_from_components(comp)
            if not validate_evidence_epistemic_role_certificate(cert,commitment):return None
        else:return None
    if cert.evidence_id!=comp['evidence_id']:return None
    if cert.provenance_certificate_id!=comp['provenance'].certificate_id:return None
    if cert.authority_certificate_id!=comp['authority'].certificate_id:return None
    sid=None if comp['source_semantics_resolution'] is None else comp['source_semantics_resolution'].certificate_id
    if cert.source_semantics_resolution_certificate_id!=sid:return None
    origin=_canonical_content_origin_from_components(comp)
    if cert.content_origin_id!=origin:return None
    return cert

def evidence_epistemic_role_direct_eligible(f):
    if f is None or not _evidence_role_policies_pinned():return False
    if f.epistemic_role not in set(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY['direct_world_state_eligible_roles']):return False
    commitment=_trusted_fact_assertion_commitment(f);cert=f.epistemic_role_certificate
    return (validate_evidence_epistemic_role_certificate(cert,commitment)
            and cert.epistemic_role==f.epistemic_role and cert.content_origin_id==f.content_origin_id)

def normalize_fact(raw,index):
    comp,e=_base_fact_components(raw,index)
    if e:return None,e
    role_cert=_role_certificate_for_components(comp)
    if role_cert is None:return None,['evidence epistemic role unresolved or unauthorized']
    r=comp['raw']
    return TrustedFact(comp['evidence_id'],r['subject'],pkey(r['predicate']),r['value'],r['source'],r.get('polarity','POSITIVE'),
                       comp['identity'],comp['temporal'],comp['provenance'],comp['provenance_completeness'],
                       comp['dependency_ontology_conformance'],comp['source_failure_domain'],comp['source_semantics_resolution'],
                       comp['authority'],role_cert.epistemic_role,role_cert.content_origin_id,role_cert),[]

def attach_claim_identities(claims,claim_identity_map):
    errors=[];claim_identity_map=claim_identity_map or {}
    for c in claims:
        if c.predicate in {'hypothesis','unmodelled'}:continue
        rid=claim_identity_map.get(c.id)
        c.identity=make_identity('CLAIM',c.id,c.subject,rid) if rid else None
        if c.identity is None:errors.append({'claim_id':c.id,'error':'claim identity unresolved'})
    return errors

def identity_ambiguities(facts,claims):
    groups={}
    for f in facts:groups.setdefault(alias_skeleton(f.subject),[]).append(('fact',f.evidence_id,f.subject,f.identity.entity_id))
    for c in claims:
        if c.identity:groups.setdefault(alias_skeleton(c.subject),[]).append(('claim',c.id,c.subject,c.identity.entity_id))
    out=[]
    for sk,items in groups.items():
        reps={norm(x[2]) for x in items};entities={x[3] for x in items}
        if len(reps)>1 or len(entities)>1:out.append({'type':'SUBJECT_IDENTITY_AMBIGUITY','skeleton':sk,'representations':sorted(reps),'entity_ids':sorted(entities)})
    return out


# ============================================================
# Direct / support / consistency
# ============================================================

def evidence_fingerprint(f):return sha(asdict(f))
def support_matches(c,f,ctx):
    return evidence_epistemic_role_direct_eligible(f) and c.identity is not None and identity_tuple(c.identity)==identity_tuple(f.identity) and world_active(f.temporal,ctx.as_of_date) and epistemically_available(f.temporal,ctx.as_of_date) and pkey(c.predicate)==f.predicate and norm(c.value)==norm(f.value) and c.polarity==f.polarity
def matching_supports(c,facts,ctx):return [f for f in facts if support_matches(c,f,ctx)]


def _support_artifact_key(audit_context_id, claim_id):
    return f'{audit_context_id}:{claim_id}'

def _retrieval_snapshot_id(retrieval_scope_id):
    row=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    return None if row is None else row.get('snapshot_id')

def _audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,requirements_hash):
    """Stable pre-policy context identity used to bind support-universe artifacts.

    It deliberately excludes generated policy/certificate IDs so that universe certificates
    can bind the context without a hash cycle.  The final AuditContextCertificate still
    binds the generated policy and authorization certificates.
    """
    if (not relation_resolution_registry_key_identity_coherent()
        or not support_selection_registry_key_identity_coherent()):return None
    row=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope)
    if row is None:return None
    claims=parse_claims(text)
    payload={
        'context_seed_version':'AUDIT_CONTEXT_SEED_V2_CERTIFICATE_KEY_VALUE_BINDING',
        'input_hash':sha(text),'raw_evidence_hash':sha(evidence),'claim_set_hash':claim_set_hash(claims),
        'claim_identity_map_hash':sha(claim_identity_map or {}),'as_of_date':asof,
        'scope_spec_hash':sha(scope_spec),'extraction_spec_hash':sha(extract_spec),
        'retrieval_scope_id':retrieval_scope,'retrieval_snapshot_id':row.get('snapshot_id'),
        'retrieval_universe_id':row.get('retrieval_universe_id'),
        'per_claim_requirements_hash':requirements_hash,
        'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_resolution_registry_hash':relation_resolution_declaration_registry_hash(),
        'excluded_support_disposition_registry_hash':excluded_support_disposition_registry_hash(),
        'source_independence_policy_hash':source_independence_policy_hash(),
        'source_independence_certificate_registry_hash':source_independence_certificate_registry_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),
        'support_set_independence_certificate_registry_hash':support_set_independence_certificate_registry_hash(),
        'dependency_ontology_hash':dependency_ontology_hash(),
        'gate_registry_hash':gate_registry_hash(),
    }
    return sha(payload)

def _fact_universe_fingerprint(f):
    # Content-sensitive, not merely evidence-ID-sensitive.  This closes semantic reuse of
    # the same evidence IDs under a different snapshot payload.
    return sha(asdict(f))

def make_matching_support_universe(c,facts,ctx):
    if c is None or c.identity is None or ctx is None:return None
    snapshot_id=_retrieval_snapshot_id(ctx.retrieval_scope_id)
    if not nonblank(snapshot_id):return None
    sup=tuple(sorted(matching_supports(c,facts,ctx),key=lambda f:f.evidence_id))
    ids=tuple(f.evidence_id for f in sup)
    if len(ids)!=len(set(ids)):return None
    projection={
        'claim_id':c.id,'predicate':pkey(c.predicate),'value':norm(c.value),'polarity':c.polarity,
        'identity':None if c.identity is None else identity_tuple(c.identity),
    }
    ids_hash=sha(ids)
    records_hash=sha(tuple((f.evidence_id,_fact_universe_fingerprint(f)) for f in sup))
    projection_hash=sha(projection)
    up={
        'claim_id':c.id,'audit_context_id':ctx.audit_context_id,
        'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':snapshot_id,
        'matching_evidence_ids':ids,'matching_evidence_ids_hash':ids_hash,
        'matching_evidence_records_hash':records_hash,'claim_projection_hash':projection_hash,
    }
    universe_hash=sha(up); universe_id='support-universe:'+universe_hash[:24]
    return MatchingSupportUniverse(universe_id,universe_hash=universe_hash,**up)

def _find_matching_support_universe(c,facts,ctx):
    fresh=make_matching_support_universe(c,facts,ctx)
    if fresh is None:return None
    candidates=[u for u in MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()
                if isinstance(u,MatchingSupportUniverse) and u.audit_context_id==ctx.audit_context_id and u.claim_id==c.id]
    if len(candidates)!=1:return None
    return candidates[0] if asdict(candidates[0])==asdict(fresh) else None

def validate_matching_support_universe(universe,c,facts,ctx):
    if universe is None:return False
    fresh=make_matching_support_universe(c,facts,ctx)
    return fresh is not None and asdict(fresh)==asdict(universe)

def _canonical_relation_resolutions(value):
    rows=[]
    if value is None:return tuple()
    if isinstance(value,dict):
        items=value.items()
        for k,v in items:
            if isinstance(k,(tuple,list)) and len(k)==2:a,b=k
            elif isinstance(k,str) and '|' in k:a,b=k.split('|',1)
            else:raise ValueError('invalid relation resolution key')
            rows.append((min(str(a),str(b)),max(str(a),str(b)),str(v)))
    else:
        for row in value:
            if not isinstance(row,(tuple,list)) or len(row)!=3:raise ValueError('invalid relation resolution row')
            a,b,v=row;rows.append((min(str(a),str(b)),max(str(a),str(b)),str(v)))
    if len({(a,b) for a,b,_ in rows})!=len(rows):raise ValueError('duplicate relation resolution pair')
    return tuple(sorted(rows))

def register_support_selection(selection_id,claim_id,retrieval_scope_id,matching_evidence_ids,
                               selected_support_ids,required_supports,exclusion_classifications,
                               justification_reason,exclusion_reasons=None,relation_resolutions=None,
                               authorizer_id='LOCAL_SUPPORT_UNIVERSE_AUTHORITY'):
    if not support_selection_registry_key_identity_coherent():
        raise ValueError('support selection registry key identity mismatch')
    if selection_id in SUPPORT_SELECTION_REGISTRY:raise ValueError('duplicate support selection id')
    if not all(nonblank(x) for x in (selection_id,claim_id,retrieval_scope_id,justification_reason,authorizer_id)):
        raise ValueError('invalid support selection')
    if authorizer_id not in set(SUPPORT_UNIVERSE_POLICY['allowed_authorizers']):raise ValueError('unauthorized support selection authorizer')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if rr is None:raise ValueError('unknown retrieval scope')
    universe=tuple(sorted(set(matching_evidence_ids or ())))
    selected=tuple(sorted(set(selected_support_ids or ())))
    if len(universe)!=len(tuple(matching_evidence_ids or ())) or len(selected)!=len(tuple(selected_support_ids or ())):
        raise ValueError('duplicate evidence id in support selection')
    if type(required_supports) is not int or required_supports<1 or len(selected)!=required_supports:
        raise ValueError('selected support count must equal required_supports')
    if not set(selected).issubset(set(universe)):raise ValueError('selected support outside matching universe')
    excluded=tuple(sorted(set(universe)-set(selected)))
    classes=dict(exclusion_classifications or {})
    if set(classes)!=set(excluded):raise ValueError('every and only excluded support requires classification')
    if any(v not in set(SUPPORT_EXCLUSION_CLASSES) for v in classes.values()):raise ValueError('invalid exclusion classification')
    reasons=dict(exclusion_reasons or {})
    if set(reasons)!=set(excluded) or any(not nonblank(v) for v in reasons.values()):
        raise ValueError('every excluded support requires a nonblank reason')
    resolutions=_canonical_relation_resolutions(relation_resolutions)
    if any(v not in set(SUPPORT_RELATION_RESOLUTIONS) for _,_,v in resolutions):raise ValueError('invalid relation resolution')
    row={
        'selection_id':selection_id,'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,
        'retrieval_snapshot_id':rr['snapshot_id'],'matching_evidence_ids':universe,
        'matching_evidence_ids_hash':sha(universe),'selected_support_ids':selected,
        'selected_support_ids_hash':sha(selected),'excluded_support_ids':excluded,
        'required_supports':required_supports,'exclusion_classifications':tuple(sorted(classes.items())),
        'exclusion_reasons':tuple(sorted(reasons.items())),'relation_resolutions':resolutions,
        'justification_reason':justification_reason,'authorizer_id':authorizer_id,
        'support_universe_policy_hash':support_universe_policy_hash(),
    }
    SUPPORT_SELECTION_REGISTRY[selection_id]=row
    return copy.deepcopy(row)

def _automatic_full_universe_selection(c,universe,requirement):
    need=requirement['required_independent_supports']
    if len(universe.matching_evidence_ids)!=need:return None
    selected=universe.matching_evidence_ids
    return {
        'selection_id':'auto-full:'+sha((c.id,universe.universe_hash,need))[:24],
        'claim_id':c.id,'retrieval_scope_id':universe.retrieval_scope_id,
        'retrieval_snapshot_id':universe.retrieval_snapshot_id,'matching_evidence_ids':selected,
        'matching_evidence_ids_hash':universe.matching_evidence_ids_hash,'selected_support_ids':selected,
        'selected_support_ids_hash':sha(selected),'excluded_support_ids':tuple(),
        'required_supports':need,'exclusion_classifications':tuple(),'exclusion_reasons':tuple(),
        'relation_resolutions':tuple(),'justification_reason':'FULL_MATCHING_UNIVERSE_SELECTED',
        'authorizer_id':'LOCAL_SUPPORT_UNIVERSE_AUTHORITY','support_universe_policy_hash':support_universe_policy_hash(),
    }

def _selection_descriptor(c,universe,requirement):
    if universe is None:return None
    if not support_selection_registry_key_identity_coherent():return None
    auto=_automatic_full_universe_selection(c,universe,requirement)
    if auto is not None:return auto
    need=requirement['required_independent_supports']
    candidates=[]
    for registry_key,row in SUPPORT_SELECTION_REGISTRY.items():
        if (_support_selection_registry_entry_identity(row)!=registry_key
            or row.get('record_type') is not None):continue
        if (row.get('claim_id')==c.id and row.get('retrieval_scope_id')==universe.retrieval_scope_id
            and row.get('retrieval_snapshot_id')==universe.retrieval_snapshot_id
            and row.get('matching_evidence_ids_hash')==universe.matching_evidence_ids_hash
            and tuple(row.get('matching_evidence_ids',()))==universe.matching_evidence_ids
            and row.get('required_supports')==need
            and row.get('support_universe_policy_hash')==support_universe_policy_hash()):
            candidates.append(row)
    # Ambiguous multiple declarations fail closed; selection must be deterministic/certified.
    return candidates[0] if len(candidates)==1 else None

def _relation_row_effect(row):
    effect=row.get('relation_effect','UNKNOWN') if isinstance(row,dict) else 'UNKNOWN'
    return effect if effect in set(RELATION_EFFECTS) else 'UNKNOWN'

def _support_set_relations_for_pair(aid,bid,claim_id,retrieval_scope_id):
    out=[]
    for rid,row in sorted(SUPPORT_SET_COMMON_MODE_REGISTRY.items()):
        if not isinstance(row,dict):continue
        ids=set(row.get('evidence_ids',()))
        if aid not in ids or bid not in ids:continue
        rel=row.get('relation')
        if rel=='COMMON_MODE':
            if row.get('claim_id','*') not in {claim_id,'*'} or row.get('retrieval_scope_id','*') not in {retrieval_scope_id,'*'}:continue
        elif rel in {'UNKNOWN','INDEPENDENT'}:
            if row.get('claim_id') not in {claim_id,'*'} or row.get('retrieval_scope_id') not in {retrieval_scope_id,'*'}:continue
        else:continue
        out.append((rid,rel,_relation_row_effect(row),tuple(sorted(ids)),row.get('reason','')))
    return tuple(out)

def register_relation_resolution(resolution_id,relation_id,claim_id,retrieval_scope_id,selected_support_ids,
                                 resolution_type,justification_reason,
                                 authorizer_id='LOCAL_RELATION_RESOLUTION_AUTHORITY'):
    """Register a pre-context relation authorization declaration.

    v0.2.26 deliberately keeps this declaration PENDING until an explicit
    bind_relation_resolution_authorizations_for_prepare(...) call binds it to one exact
    audit context / support universe / relation neighborhood.  A pending declaration
    is never sufficient for certificate issuance.
    """
    if not relation_resolution_registry_key_identity_coherent():
        raise ValueError('relation resolution registry key identity mismatch')
    if resolution_id in RELATION_RESOLUTION_REGISTRY:raise ValueError('duplicate relation resolution id')
    if not all(nonblank(x) for x in (resolution_id,relation_id,claim_id,retrieval_scope_id,resolution_type,justification_reason,authorizer_id)):
        raise ValueError('invalid relation resolution declaration')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id); rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(relation_id)
    if rr is None:raise ValueError('unknown retrieval scope')
    if not isinstance(rel,dict) or rel.get('relation') not in {'COMMON_MODE','UNKNOWN'}:
        raise ValueError('unknown or non-resolvable relation id')
    if rel.get('claim_id','*') not in {claim_id,'*'} or rel.get('retrieval_scope_id','*') not in {retrieval_scope_id,'*'}:
        raise ValueError('relation scope mismatch')
    effect=_relation_row_effect(rel)
    if effect not in set(RELATION_EFFECTS):raise ValueError('invalid relation effect')
    allowed=set(RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,()))
    if resolution_type not in allowed:raise ValueError('resolution type incompatible with relation effect')
    if authorizer_id not in set(RELATION_RESOLUTION_POLICY['allowed_resolution_authorizers']):
        raise ValueError('unauthorized relation resolution')
    selected=tuple(sorted(set(selected_support_ids or ())))
    if not selected or len(selected)!=len(tuple(selected_support_ids or ())):raise ValueError('invalid selected support set')
    # At most one still-unbound authorization may exist for the same relation/snapshot.
    # Bound authorizations for other audit contexts do not prevent issuing a fresh,
    # separately identified authorization for a later context.
    for registry_key,row in RELATION_RESOLUTION_REGISTRY.items():
        if (isinstance(row,dict) and row.get('resolution_id')==registry_key
            and row.get('relation_id')==relation_id and row.get('claim_id')==claim_id
            and row.get('retrieval_scope_id')==retrieval_scope_id and row.get('retrieval_snapshot_id')==rr['snapshot_id']
            and row.get('authorization_binding_state')=='PENDING'):
            raise ValueError('duplicate pending relation resolution declaration')
    row={
        'resolution_id':resolution_id,'relation_id':relation_id,'relation_type':rel.get('relation'),
        'relation_effect':effect,'evidence_ids_hash':sha(tuple(sorted(rel.get('evidence_ids',())))),
        'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':rr['snapshot_id'],
        'selected_support_ids':selected,'selected_support_ids_hash':sha(selected),
        'authorizer_id':authorizer_id,'resolution_type':resolution_type,'justification_reason':justification_reason,
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'authorization_binding_state':'PENDING',
        'audit_context_id':None,'matching_support_universe_hash':None,
        'decision_relevant_relation_universe_hash':None,'decision_relevant_relation_ids_hash':None,
        'exclusion_classification_hash':None,'source_failure_domain_closure_hash':None,
        'relation_registry_hash':None,'support_universe_policy_hash':None,
        'relation_discovery_policy_hash':None,'authorization_scope_hash':None,
    }
    RELATION_RESOLUTION_REGISTRY[resolution_id]=row
    return copy.deepcopy(row)

def register_excluded_support_disposition(disposition_id,claim_id,retrieval_scope_id,excluded_evidence_id,
                                          selected_evidence_ids,supporting_relation_ids,justification_reason,
                                          disposition_class='EXCLUDED_REDUNDANT',
                                          authorizer_id='LOCAL_EXCLUSION_DISPOSITION_AUTHORITY'):
    if disposition_id in EXCLUDED_SUPPORT_DISPOSITION_REGISTRY:raise ValueError('duplicate excluded support disposition id')
    if not all(nonblank(x) for x in (disposition_id,claim_id,retrieval_scope_id,excluded_evidence_id,
                                     justification_reason,disposition_class,authorizer_id)):
        raise ValueError('invalid excluded support disposition')
    if disposition_class!='EXCLUDED_REDUNDANT':raise ValueError('only redundant disposition is certificate-authorized in v0.2.22')
    if authorizer_id not in set(RELATION_RESOLUTION_POLICY['allowed_disposition_authorizers']):
        raise ValueError('unauthorized excluded support disposition')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if rr is None:raise ValueError('unknown retrieval scope')
    selected=tuple(sorted(set(selected_evidence_ids or ())))
    relids=tuple(sorted(set(supporting_relation_ids or ())))
    if not selected or len(selected)!=len(tuple(selected_evidence_ids or ())):raise ValueError('invalid selected support ids')
    if not relids or len(relids)!=len(tuple(supporting_relation_ids or ())):raise ValueError('invalid supporting relation ids')
    for rid in relids:
        rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(rid)
        if not isinstance(rel,dict) or rel.get('relation')!='COMMON_MODE':raise ValueError('invalid redundancy relation id')
        if _relation_row_effect(rel)!='REDUNDANCY_ONLY':raise ValueError('redundant disposition requires REDUNDANCY_ONLY relation effect')
        eids=set(rel.get('evidence_ids',()))
        if excluded_evidence_id not in eids or not (set(selected)&eids):
            raise ValueError('redundancy relation endpoints do not support disposition')
        if rel.get('claim_id','*') not in {claim_id,'*'} or rel.get('retrieval_scope_id','*') not in {retrieval_scope_id,'*'}:
            raise ValueError('redundancy relation scope mismatch')
    row={
        'disposition_id':disposition_id,'claim_id':claim_id,'retrieval_scope_id':retrieval_scope_id,
        'retrieval_snapshot_id':rr['snapshot_id'],'excluded_evidence_id':excluded_evidence_id,
        'selected_evidence_ids':selected,'selected_evidence_ids_hash':sha(selected),
        'supporting_relation_ids':relids,'supporting_relation_ids_hash':sha(relids),
        'disposition_class':disposition_class,'required_relation_effect':'REDUNDANCY_ONLY',
        'authorizer_id':authorizer_id,'justification_reason':justification_reason,
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
    }
    EXCLUDED_SUPPORT_DISPOSITION_REGISTRY[disposition_id]=row
    return copy.deepcopy(row)

def _relation_discovery_candidates(c,ctx,universe,descriptor):
    """Canonical pre-relevance discovery neighborhood for v0.2.23.

    Preserve every v0.2.22 relation with >=2 matching-universe endpoints, and additionally
    discover any scoped COMMON_MODE/UNKNOWN relation touching at least one selected support.
    Endpoint snapshot binding is recorded but not used to erase the relation: invalid external
    endpoints are surfaced to the mandatory discovery-completeness gate and fail closed.
    """
    if universe is None or descriptor is None:return tuple()
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None:return tuple()
    snapshot_ids=set(rr.get('expected_evidence_ids',()))
    matching=set(universe.matching_evidence_ids)
    selected=set(descriptor.get('selected_support_ids',()))
    allowed=set(RELATION_DISCOVERY_POLICY.get('allowed_relation_types',()))
    rows=[]
    for rid,row in sorted(SUPPORT_SET_COMMON_MODE_REGISTRY.items()):
        if not isinstance(row,dict) or row.get('relation') not in allowed:continue
        if row.get('claim_id','*') not in {c.id,'*'} or row.get('retrieval_scope_id','*') not in {ctx.retrieval_scope_id,'*'}:continue
        eids=tuple(sorted(set(row.get('evidence_ids',()))))
        if len(eids)<2:continue
        eset=set(eids)
        selected_anchor=bool(eset&selected)
        legacy_multi_matching=len(eset&matching)>=2
        if not (selected_anchor or legacy_multi_matching):continue
        rows.append({
            'relation_id':rid,'relation_type':row.get('relation'),'relation_effect':_relation_row_effect(row),
            'evidence_ids':eids,'evidence_ids_hash':sha(eids),
            'selected_anchor':selected_anchor,'legacy_multi_matching':legacy_multi_matching,
            'endpoint_scope_valid':eset.issubset(snapshot_ids),
            'registry_entry_hash':sha(row),
        })
    return tuple(rows)

def make_decision_relevant_relation_universe(c,ctx,universe,descriptor):
    if universe is None or descriptor is None:return None
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None or rr.get('snapshot_id')!=universe.retrieval_snapshot_id:return None
    candidates=_relation_discovery_candidates(c,ctx,universe,descriptor)
    relation_ids=tuple(x['relation_id'] for x in candidates)
    if len(set(relation_ids))!=len(relation_ids):return None
    out_of_snapshot=tuple(x['relation_id'] for x in candidates if not x['endpoint_scope_valid'])
    records=tuple((x['relation_id'],x['relation_type'],x['relation_effect'],x['evidence_ids'],
                   x['endpoint_scope_valid'],x['registry_entry_hash']) for x in candidates)
    payload={
        'universe_id':'relation-neighborhood:'+sha((c.id,ctx.audit_context_id,universe.universe_hash,
                                                   sha(tuple(descriptor.get('selected_support_ids',()))),relation_ids))[:24],
        'claim_id':c.id,'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':universe.retrieval_snapshot_id,'matching_support_universe_hash':universe.universe_hash,
        'selected_support_ids_hash':sha(tuple(descriptor.get('selected_support_ids',()))),
        'relation_ids':relation_ids,'relation_ids_hash':sha(relation_ids),
        'relation_instance_records_hash':sha(records),
        'out_of_snapshot_relation_ids':out_of_snapshot,'out_of_snapshot_relation_ids_hash':sha(out_of_snapshot),
        'relation_registry_hash':support_set_common_mode_registry_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
    }
    payload['universe_hash']=sha(payload)
    return DecisionRelevantRelationUniverse(**payload)

def _find_decision_relevant_relation_universe(c,ctx,universe,descriptor):
    candidates=[x for x in DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY.values()
                if isinstance(x,DecisionRelevantRelationUniverse)
                and x.audit_context_id==ctx.audit_context_id and x.claim_id==c.id]
    if len(candidates)!=1:return None
    fresh=make_decision_relevant_relation_universe(c,ctx,universe,descriptor)
    return candidates[0] if fresh is not None and asdict(candidates[0])==asdict(fresh) else None

def _relation_instances_for_claim(c,ctx,universe,descriptor):
    if universe is None or descriptor is None:return tuple()
    neighborhood=_find_decision_relevant_relation_universe(c,ctx,universe,descriptor)
    if neighborhood is None:return tuple()
    rows={x['relation_id']:x for x in _relation_discovery_candidates(c,ctx,universe,descriptor)}
    instances=[]
    for rid in neighborhood.relation_ids:
        info=rows.get(rid)
        if info is None or not info['endpoint_scope_valid']:continue
        row=SUPPORT_SET_COMMON_MODE_REGISTRY.get(rid)
        if not isinstance(row,dict):return tuple()
        inst=RelationInstance(
            relation_id=rid,relation_type=info['relation_type'],relation_effect=info['relation_effect'],
            evidence_ids=info['evidence_ids'],evidence_ids_hash=info['evidence_ids_hash'],
            claim_id=c.id,retrieval_scope_id=ctx.retrieval_scope_id,retrieval_snapshot_id=universe.retrieval_snapshot_id,
            authority_id=row.get('authority_id',''),policy_id=row.get('policy_id',''),
            reason_hash=sha(row.get('reason','')),registry_entry_hash=sha(row),
        )
        instances.append(inst)
    if len({x.relation_id for x in instances})!=len(instances):return tuple()
    return tuple(instances)

def _relation_instance_decision_relevant(inst,descriptor):
    # Final epistemic-relevance classification is intentionally distinct from the
    # required-handling predicate introduced in v0.2.25.  A relation may ultimately
    # become nonblocking while still requiring an exact authorization first.
    selected=set(descriptor.get('selected_support_ids',()))
    eids=set(inst.evidence_ids)
    s=len(eids&selected)
    effect=inst.relation_effect if inst.relation_effect in set(RELATION_EFFECTS) else 'UNKNOWN'
    always=set(RELATION_DECISION_RELEVANCE_POLICY.get('always_decision_relevant_effects',()))
    if effect in always:return True
    if effect in {'REDUNDANCY_ONLY','NON_DECISION_RELEVANT'}:
        return s>=1
    return True

def _relation_instance_required_handling_mode(inst,descriptor):
    """Return policy-driven handling obligation before any nonblocking conclusion.

    This predicate is the v0.2.25 separation between epistemic relevance and the
    requirement to obtain a relation-specific resolution/authorization.  Endpoint
    disposition may refine REDUNDANCY_ONLY handling, but it cannot bypass a handling
    mode pinned for another typed effect.
    """
    effect=inst.relation_effect if inst.relation_effect in set(RELATION_EFFECTS) else 'UNKNOWN'
    handling=RELATION_DECISION_RELEVANCE_POLICY.get('effect_required_handling',{})
    mode=handling.get(effect,'FAIL_CLOSED') if isinstance(handling,dict) else 'FAIL_CLOSED'
    if mode=='ENDPOINT_SCOPE':
        return 'RESOLUTION_REQUIRED' if _relation_instance_decision_relevant(inst,descriptor) else 'NONE'
    if mode in {'RESOLUTION_REQUIRED','AUTHORIZATION_REQUIRED','FAIL_CLOSED','NONE'}:
        return mode
    return 'FAIL_CLOSED'

def _relation_instance_requires_handling(inst,descriptor):
    return _relation_instance_required_handling_mode(inst,descriptor)!='NONE'

def _relation_authorization_scope_payload(c,facts,ctx,universe,descriptor,neighborhood,inst):
    if universe is None or descriptor is None or neighborhood is None or inst is None:return None
    classes=tuple(descriptor.get('exclusion_classifications',()))
    return {
        'claim_id':c.id,'audit_context_id':ctx.audit_context_id,
        'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':universe.retrieval_snapshot_id,
        'matching_support_universe_hash':universe.universe_hash,
        'selected_support_ids_hash':sha(tuple(descriptor.get('selected_support_ids',()))),
        'decision_relevant_relation_universe_hash':neighborhood.universe_hash,
        'decision_relevant_relation_ids_hash':neighborhood.relation_ids_hash,
        'relation_id':inst.relation_id,'relation_type':inst.relation_type,
        'relation_effect':inst.relation_effect,'evidence_ids_hash':inst.evidence_ids_hash,
        'exclusion_classification_hash':sha(classes),
        'source_failure_domain_closure_hash':_source_fd_closure_hash_for_universe(universe,facts),
        'relation_registry_hash':support_set_common_mode_registry_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
    }

def bind_relation_resolution_authorizations_for_prepare(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,
                                                        retrieval_scope,req=None,resolution_ids=None):
    """Explicitly bind pending relation-resolution authorizations to one exact prepare scope.

    This is intentionally separate from prepare() and from certificate issuance.  The caller
    authorizes the exact deterministic audit context before prepare.  Issuance cannot fill in
    missing scope later.  Returns True only when every requested pending declaration is bound
    exactly (or was already bound to the same exact scope).

    Binding is transactional for both explicit and implicit selection: no pending declaration
    is changed until the whole selected set has been validated and all replacement rows have
    been prepared.  With ``resolution_ids is None``, the selected set is all rows belonging to
    the current retrieval scope; rows from other retrieval scopes remain ignored.
    """
    if (not relation_resolution_registry_key_identity_coherent()
        or not support_selection_registry_key_identity_coherent()):return False
    try:
        claims=parse_claims(text); reqs=normalize_requirements(claims,req)
    except Exception:
        return False
    requirements_hash=sha(reqs)
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,requirements_hash)
    if aid is None:return False
    facts=[]
    for i,r in enumerate(evidence,1):
        f,errs=normalize_fact(r,i)
        if errs:return False
        facts.append(f)
    if attach_claim_identities(claims,claim_identity_map):return False
    class _Ctx:pass
    ctx=_Ctx();ctx.audit_context_id=aid;ctx.as_of_date=asof;ctx.retrieval_scope_id=retrieval_scope
    requested=None if resolution_ids is None else tuple(resolution_ids)
    if requested is not None and (not requested or len(set(requested))!=len(requested)):return False
    requested_set=None if requested is None else set(requested)
    rows=[]
    for key,row in RELATION_RESOLUTION_REGISTRY.items():
        if not isinstance(row,dict) or row.get('resolution_id')!=key:return False
        if requested_set is not None and key not in requested_set:continue
        if row.get('retrieval_scope_id')!=retrieval_scope:continue
        rows.append((key,row))
    if requested_set is not None and set(k for k,_ in rows)!=requested_set:return False

    transactional=True
    staged={}
    ok=True
    for key,row in rows:
        c=next((x for x in claims if x.id==row.get('claim_id')),None)
        if c is None or c.id not in reqs:
            if transactional:return False
            ok=False;continue
        universe=make_matching_support_universe(c,facts,ctx)
        if universe is None:
            if transactional:return False
            ok=False;continue
        descriptor=_selection_descriptor(c,universe,reqs[c.id])
        if descriptor is None:
            if transactional:return False
            ok=False;continue
        neighborhood=make_decision_relevant_relation_universe(c,ctx,universe,descriptor)
        if neighborhood is None:
            if transactional:return False
            ok=False;continue
        info=next((x for x in _relation_discovery_candidates(c,ctx,universe,descriptor)
                   if x.get('relation_id')==row.get('relation_id')),None)
        rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(row.get('relation_id'))
        if info is None or not info.get('endpoint_scope_valid') or not isinstance(rel,dict):
            if transactional:return False
            ok=False;continue
        inst=RelationInstance(
            relation_id=info['relation_id'],relation_type=info['relation_type'],relation_effect=info['relation_effect'],
            evidence_ids=info['evidence_ids'],evidence_ids_hash=info['evidence_ids_hash'],
            claim_id=c.id,retrieval_scope_id=ctx.retrieval_scope_id,retrieval_snapshot_id=universe.retrieval_snapshot_id,
            authority_id=rel.get('authority_id',''),policy_id=rel.get('policy_id',''),
            reason_hash=sha(rel.get('reason','')),registry_entry_hash=sha(rel),
        )
        scope_payload=_relation_authorization_scope_payload(c,facts,ctx,universe,descriptor,neighborhood,inst)
        if scope_payload is None:
            if transactional:return False
            ok=False;continue
        if (row.get('relation_type')!=inst.relation_type or row.get('relation_effect')!=inst.relation_effect
            or row.get('evidence_ids_hash')!=inst.evidence_ids_hash
            or row.get('selected_support_ids_hash')!=scope_payload['selected_support_ids_hash']
            or row.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id
            or row.get('relation_resolution_policy_hash')!=relation_resolution_policy_hash()
            or row.get('relation_decision_relevance_policy_hash')!=relation_decision_relevance_policy_hash()):
            if transactional:return False
            ok=False;continue
        expected_scope_hash=sha(scope_payload)
        state=row.get('authorization_binding_state')
        if state=='BOUND':
            if (row.get('authorization_scope_hash')!=expected_scope_hash
                or any(row.get(k)!=v for k,v in scope_payload.items())):
                if transactional:return False
                ok=False
            continue
        if state!='PENDING':
            if transactional:return False
            ok=False;continue
        bound=dict(row)
        bound.update(scope_payload)
        bound['authorization_binding_state']='BOUND'
        bound['authorization_scope_hash']=expected_scope_hash
        if transactional:staged[key]=bound
        else:RELATION_RESOLUTION_REGISTRY[key]=bound

    if transactional:
        for key,bound in staged.items():
            RELATION_RESOLUTION_REGISTRY[key]=bound
        return True
    return ok

def _matching_relation_resolution_declaration(c,facts,ctx,universe,descriptor,inst):
    if not relation_resolution_registry_key_identity_coherent():return None
    selected=tuple(descriptor.get('selected_support_ids',()))
    neighborhood=_find_decision_relevant_relation_universe(c,ctx,universe,descriptor)
    if neighborhood is None:return None
    scope_payload=_relation_authorization_scope_payload(c,facts,ctx,universe,descriptor,neighborhood,inst)
    if scope_payload is None:return None
    scope_hash=sha(scope_payload)
    candidates=[]
    for registry_key,row in RELATION_RESOLUTION_REGISTRY.items():
        if not isinstance(row,dict) or row.get('resolution_id')!=registry_key:return None
        if (row.get('authorization_binding_state')=='BOUND'
            and row.get('relation_id')==inst.relation_id and row.get('claim_id')==c.id
            and row.get('retrieval_scope_id')==ctx.retrieval_scope_id
            and row.get('retrieval_snapshot_id')==universe.retrieval_snapshot_id
            and row.get('selected_support_ids_hash')==sha(selected)
            and row.get('authorization_scope_hash')==scope_hash
            and all(row.get(k)==v for k,v in scope_payload.items())):
            candidates.append(row)
    return candidates[0] if len(candidates)==1 else None

def make_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst):
    if inst is None:return None
    handling_mode=_relation_instance_required_handling_mode(inst,descriptor)
    if handling_mode in {'NONE','FAIL_CLOSED'}:return None
    row=_matching_relation_resolution_declaration(c,facts,ctx,universe,descriptor,inst)
    if row is None:return None
    rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(inst.relation_id)
    if not isinstance(rel,dict):return None
    effect=_relation_row_effect(rel)
    if (row.get('relation_type')!=inst.relation_type or row.get('relation_effect')!=effect
        or row.get('evidence_ids_hash')!=inst.evidence_ids_hash):return None
    resolution_type=row.get('resolution_type')
    if resolution_type not in set(RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,())):return None
    if effect in {'UNKNOWN','SELECTED_SUPPORT_INVALIDATING'}:return None
    if row.get('authorizer_id') not in set(RELATION_RESOLUTION_POLICY['allowed_resolution_authorizers']):return None
    if row.get('relation_resolution_policy_hash')!=relation_resolution_policy_hash():return None
    if row.get('relation_decision_relevance_policy_hash')!=relation_decision_relevance_policy_hash():return None
    classes=tuple(descriptor.get('exclusion_classifications',()))
    payload={
        'resolution_id':row['resolution_id'],'relation_id':inst.relation_id,
        'relation_type':inst.relation_type,'relation_effect':effect,'evidence_ids_hash':inst.evidence_ids_hash,
        'claim_id':c.id,'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':universe.retrieval_snapshot_id,'matching_support_universe_hash':universe.universe_hash,
        'selected_support_ids_hash':sha(tuple(descriptor.get('selected_support_ids',()))),
        'exclusion_classification_hash':sha(classes),
        'source_failure_domain_closure_hash':_source_fd_closure_hash_for_universe(universe,facts),
        'relation_registry_hash':support_set_common_mode_registry_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'authorization_scope_hash':row.get('authorization_scope_hash'),
        'authorizer_id':row['authorizer_id'],'resolution_type':resolution_type,
        'justification_hash':sha(row.get('justification_reason','')),'result':'PASS',
    }
    return RelationResolutionCertificate(sha(payload),**payload)

def _find_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst):
    candidates=[x for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()
                if isinstance(x,RelationResolutionCertificate) and x.audit_context_id==ctx.audit_context_id
                and x.claim_id==c.id and x.relation_id==inst.relation_id]
    if len(candidates)!=1:return None
    fresh=make_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
    return candidates[0] if fresh is not None and asdict(candidates[0])==asdict(fresh) else None

def validate_relation_resolution_certificate(cert,c,facts,ctx,universe,descriptor,inst):
    if cert is None:return False
    fresh=make_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
    return fresh is not None and asdict(cert)==asdict(fresh)

def _matching_disposition_declaration(c,ctx,universe,descriptor,excluded_evidence_id):
    selected=tuple(descriptor.get('selected_support_ids',()))
    candidates=[]
    for row in EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.values():
        if not isinstance(row,dict):continue
        if (row.get('claim_id')==c.id and row.get('retrieval_scope_id')==ctx.retrieval_scope_id
            and row.get('retrieval_snapshot_id')==universe.retrieval_snapshot_id
            and row.get('excluded_evidence_id')==excluded_evidence_id
            and row.get('selected_evidence_ids_hash')==sha(selected)):
            candidates.append(row)
    return candidates[0] if len(candidates)==1 else None

def make_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,excluded_evidence_id):
    classes=dict(descriptor.get('exclusion_classifications',()))
    if classes.get(excluded_evidence_id)!='EXCLUDED_REDUNDANT':return None
    row=_matching_disposition_declaration(c,ctx,universe,descriptor,excluded_evidence_id)
    if row is None or row.get('disposition_class')!='EXCLUDED_REDUNDANT':return None
    if row.get('required_relation_effect')!='REDUNDANCY_ONLY':return None
    if row.get('authorizer_id') not in set(RELATION_RESOLUTION_POLICY['allowed_disposition_authorizers']):return None
    if row.get('relation_resolution_policy_hash')!=relation_resolution_policy_hash():return None
    if row.get('relation_decision_relevance_policy_hash')!=relation_decision_relevance_policy_hash():return None
    instances={x.relation_id:x for x in _relation_instances_for_claim(c,ctx,universe,descriptor)}
    supporting=tuple(row.get('supporting_relation_ids',()))
    if not supporting:return None
    for rid in supporting:
        inst=instances.get(rid)
        if inst is None or inst.relation_effect!='REDUNDANCY_ONLY':return None
        eids=set(inst.evidence_ids)
        if excluded_evidence_id not in eids or not (set(descriptor.get('selected_support_ids',()))&eids):return None
        cert=_find_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
        if cert is None or cert.resolution_type!='REDUNDANT_RELATION_ACCOUNTED':return None
    # A redundant disposition is closed under every decision-relevant relation touching
    # the excluded evidence.  A separate degrading/unknown/contradictory relation cannot
    # be hidden behind the redundancy label.
    relevant_touching=tuple(sorted(
        inst.relation_id for inst in instances.values()
        if excluded_evidence_id in set(inst.evidence_ids) and _relation_instance_requires_handling(inst,descriptor)
    ))
    for rid in relevant_touching:
        inst=instances[rid]
        mode=_relation_instance_required_handling_mode(inst,descriptor)
        if mode=='FAIL_CLOSED':return None
        cert=_find_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
        if cert is None:return None
    # v0.2.27: a redundancy disposition is also closed under source/failure-domain
    # dependency paths.  Explicit relation IDs are not the whole dependency graph.
    ledger=_support_relation_ledger(c,facts,ctx,universe,descriptor)
    if ledger is None:return None
    for aid,bid,scope,state,diag,source_state,source_cert,set_rows,exclass,relevant,resolution in ledger:
        if excluded_evidence_id not in {aid,bid}:continue
        if relevant and source_state=='SOURCE_SHARED_DEPENDENCY':
            if resolution!=SUPPORT_UNIVERSE_POLICY.get('source_dependency_resolution_type'):return None
    neighborhood=_find_decision_relevant_relation_universe(c,ctx,universe,descriptor)
    if neighborhood is None:return None
    payload={
        'disposition_id':row['disposition_id'],'claim_id':c.id,'audit_context_id':ctx.audit_context_id,
        'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':universe.retrieval_snapshot_id,
        'excluded_evidence_id':excluded_evidence_id,
        'selected_evidence_ids_hash':sha(tuple(descriptor.get('selected_support_ids',()))),
        'supporting_relation_ids_hash':sha(supporting),'required_relation_effect':'REDUNDANCY_ONLY',
        'matching_support_universe_hash':universe.universe_hash,
        'selected_support_ids_hash':sha(tuple(descriptor.get('selected_support_ids',()))),
        'decision_relevant_relation_ids_hash':sha(relevant_touching),
        'decision_relevant_relation_universe_hash':neighborhood.universe_hash,
        'authority_id':row['authorizer_id'],'support_universe_policy_hash':support_universe_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'justification_hash':sha(row.get('justification_reason','')),'result':'PASS',
    }
    return ExcludedSupportDispositionCertificate(sha(payload),**payload)

def _find_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,excluded_evidence_id):
    candidates=[x for x in EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY.values()
                if isinstance(x,ExcludedSupportDispositionCertificate) and x.audit_context_id==ctx.audit_context_id
                and x.claim_id==c.id and x.excluded_evidence_id==excluded_evidence_id]
    if len(candidates)!=1:return None
    fresh=make_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,excluded_evidence_id)
    return candidates[0] if fresh is not None and asdict(candidates[0])==asdict(fresh) else None

def validate_excluded_support_disposition_certificate(cert,c,facts,ctx,universe,descriptor,excluded_evidence_id):
    if cert is None:return False
    fresh=make_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,excluded_evidence_id)
    return fresh is not None and asdict(cert)==asdict(fresh)

def _relation_resolution_certificate_ids(c,ctx):
    return tuple(sorted(x.certificate_id for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()
                        if isinstance(x,RelationResolutionCertificate)
                        and x.audit_context_id==ctx.audit_context_id and x.claim_id==c.id))

def _relation_resolution_coverage_artifact_hash(c,ctx):
    rids=_relation_resolution_certificate_ids(c,ctx)
    dids=tuple(sorted(x.certificate_id for x in EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY.values()
                      if isinstance(x,ExcludedSupportDispositionCertificate)
                      and x.audit_context_id==ctx.audit_context_id and x.claim_id==c.id))
    return sha((rids,dids))

def _decision_relevant_relation_discovery_complete_for_claim(c,facts,ctx,requirement,universe=None,descriptor=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None:return False
    descriptor=descriptor or _selection_descriptor(c,universe,requirement)
    if descriptor is None:return False
    if not relation_discovery_policy_adequate(ctx.as_of_date):return False
    neighborhood=_find_decision_relevant_relation_universe(c,ctx,universe,descriptor)
    if neighborhood is None:return False
    if neighborhood.matching_support_universe_hash!=universe.universe_hash:return False
    if neighborhood.selected_support_ids_hash!=sha(tuple(descriptor.get('selected_support_ids',()))):return False
    if neighborhood.retrieval_snapshot_id!=universe.retrieval_snapshot_id:return False
    if neighborhood.relation_registry_hash!=support_set_common_mode_registry_hash():return False
    if neighborhood.relation_discovery_policy_hash!=relation_discovery_policy_hash():return False
    # Relations touching selected support are never erased merely because another endpoint
    # is outside the matching support universe.  If that endpoint is not in the current
    # retrieval snapshot, v0.2.23 has no legal external binding mechanism and fails closed.
    if neighborhood.out_of_snapshot_relation_ids:return False
    candidates=_relation_discovery_candidates(c,ctx,universe,descriptor)
    relation_ids=tuple(x['relation_id'] for x in candidates)
    if relation_ids!=neighborhood.relation_ids or sha(relation_ids)!=neighborhood.relation_ids_hash:return False
    records=tuple((x['relation_id'],x['relation_type'],x['relation_effect'],x['evidence_ids'],
                   x['endpoint_scope_valid'],x['registry_entry_hash']) for x in candidates)
    if sha(records)!=neighborhood.relation_instance_records_hash:return False
    # Every selected-anchored candidate must be present even if only one endpoint is a
    # matching support.  This is the central R24 -> v0.2.23 discovery-closure invariant.
    selected=set(descriptor.get('selected_support_ids',()))
    for x in candidates:
        if set(x['evidence_ids'])&selected and x['relation_id'] not in set(neighborhood.relation_ids):return False
    return True

def decision_relevant_relation_discovery_complete_valid(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return False
    for c in modeled:
        requirement=reqs.get(c.id)
        if requirement is None:return False
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:return False
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:return False
        if not _decision_relevant_relation_discovery_complete_for_claim(c,facts,ctx,requirement,universe,descriptor):return False
    return True

def _relation_instance_coverage_valid_for_claim(c,facts,ctx,requirement,universe=None,descriptor=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None:return False
    descriptor=descriptor or _selection_descriptor(c,universe,requirement)
    if descriptor is None:return False
    if not _decision_relevant_relation_discovery_complete_for_claim(c,facts,ctx,requirement,universe,descriptor):return False
    instances=_relation_instances_for_claim(c,ctx,universe,descriptor)
    # Registry identity is one-to-one: one stable relation_id, one payload.
    if len({x.relation_id for x in instances})!=len(instances):return False
    for inst in instances:
        mode=_relation_instance_required_handling_mode(inst,descriptor)
        if mode=='NONE':continue
        if mode=='FAIL_CLOSED':return False
        cert=_find_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
        if cert is None:return False
        if cert.relation_id!=inst.relation_id:return False
        if cert.relation_effect!=inst.relation_effect or cert.evidence_ids_hash!=inst.evidence_ids_hash:return False
        if mode=='AUTHORIZATION_REQUIRED':
            expected=RELATION_DECISION_RELEVANCE_POLICY.get('non_decision_relevant_required_resolution_type')
            if inst.relation_effect!='NON_DECISION_RELEVANT' or cert.resolution_type!=expected:return False
    classes=dict(descriptor.get('exclusion_classifications',()))
    for eid,cls in classes.items():
        if cls=='EXCLUDED_REDUNDANT':
            if _find_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,eid) is None:return False
    return True

def support_relation_instance_resolution_coverage_valid(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return False
    for c in modeled:
        requirement=reqs.get(c.id)
        if requirement is None:return False
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:return False
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:return False
        if not _relation_instance_coverage_valid_for_claim(c,facts,ctx,requirement,universe,descriptor):return False
        ledger=_support_relation_ledger(c,facts,ctx,universe,descriptor)
        if not _source_dependency_universe_coverage_valid(descriptor,ledger):return False
    return True

def _source_dependency_path_relevant_pair_keys(selected,rows):
    """Return source/failure-domain dependency edges that lie on a support-justification path.

    v0.2.28 preserves source/failure-domain dependency as an orthogonal channel without declaring every EXCLUDED<->EXCLUDED edge relevant.
    The graph contains (a) source/failure-domain dependency edges and (b) explicit
    selected<->excluded justificatory bridges (principally certified redundancy paths).
    A source dependency edge is decision-relevant when it can participate in a path between
    two distinct selected supports.  This preserves legal isolated excluded redundancy while
    preventing a dependency from disappearing merely because both endpoints are excluded.
    """
    selected=set(selected or ())
    graph={}
    source_edges=set()
    for r in rows:
        aid=r['aid'];bid=r['bid'];key=(min(aid,bid),max(aid,bid))
        # Do not consult aggregated pair state here: COMMON_MODE may coexist with
        # a source/failure-domain dependency on the same endpoints.
        is_source_dep=(r['source_state']=='SOURCE_SHARED_DEPENDENCY')
        has_redundancy=any(x[1]=='COMMON_MODE' and x[2]=='REDUNDANCY_ONLY' for x in r['set_rows'])
        is_justificatory_bridge=(
            r['scope']=='SELECTED_EXCLUDED' and (
                (r['exclass']=='EXCLUDED_REDUNDANT' and has_redundancy)
                or (r['exclass']=='EXCLUDED_DEPENDENT' and r['state']=='DEPENDENT'
                    and r['resolution']=='DEPENDENCY_ACCOUNTED_NOT_COUNTED')
            )
        )
        if not (is_source_dep or is_justificatory_bridge):continue
        graph.setdefault(aid,set()).add(bid);graph.setdefault(bid,set()).add(aid)
        if is_source_dep:source_edges.add(key)

    def reachable(start,skip):
        seen={start};stack=[start]
        while stack:
            cur=stack.pop()
            for nxt in graph.get(cur,()):
                if (min(cur,nxt),max(cur,nxt))==skip:continue
                if nxt not in seen:seen.add(nxt);stack.append(nxt)
        return seen

    relevant=set()
    for key in source_edges:
        a,b=key
        ra=reachable(a,key);rb=reachable(b,key)
        sa=selected & ra; sb=selected & rb
        if b not in ra:
            # Bridge edge: it is on a selected-to-selected path iff each side reaches
            # at least one different selected support.
            if sa and sb and any(x!=y for x in sa for y in sb):relevant.add(key)
        else:
            # Cycle edge: conservative only inside a component containing >=2 selected
            # supports; dangling source dependencies remain non-relevant.
            if len(selected & ra)>=2:relevant.add(key)
    return relevant


def _support_relation_ledger(c,facts,ctx,universe,descriptor):
    fmap={f.evidence_id:f for f in facts}
    selected=set(descriptor['selected_support_ids']); excluded=set(descriptor['excluded_support_ids'])
    if selected|excluded!=set(universe.matching_evidence_ids) or selected&excluded:return None
    classes=dict(descriptor.get('exclusion_classifications',()))
    # Legacy pair-level resolutions remain explicit accounting for source/failure-domain
    # dependencies; relation-instance resolution remains separately certificate-bound.
    resolution_map={(a,b):v for a,b,v in descriptor.get('relation_resolutions',())}
    raw=[]
    for aid,bid in combinations(universe.matching_evidence_ids,2):
        a=fmap.get(aid); b=fmap.get(bid)
        if a is None or b is None:return None
        if aid in selected and bid in selected:pair_scope='SELECTED_SELECTED'
        elif aid in excluded and bid in excluded:pair_scope='EXCLUDED_EXCLUDED'
        else:pair_scope='SELECTED_EXCLUDED'
        pair_ok,diag,source_state,source_cert=pair_independence(a,b,ctx.as_of_date,ctx.retrieval_scope_id)
        set_rows=_support_set_relations_for_pair(aid,bid,c.id,ctx.retrieval_scope_id)
        set_blockers=[r for r in set_rows if r[1] in {'COMMON_MODE','UNKNOWN'}]
        has_unknown=any(r[1]=='UNKNOWN' or r[2]=='UNKNOWN' for r in set_blockers) or source_state=='SOURCE_RELATION_UNRESOLVED'
        has_common=any(r[1]=='COMMON_MODE' for r in set_blockers)
        contradiction=(identity_tuple(a.identity)==identity_tuple(b.identity) and a.predicate==b.predicate and
                       (norm(a.value)!=norm(b.value) or a.polarity!=b.polarity))
        if contradiction:state='CONTRADICTION'
        elif has_unknown:state='UNRESOLVED'
        elif has_common:state='COMMON_MODE'
        elif not pair_ok:state='DEPENDENT'
        else:state='INDEPENDENT'
        exid=bid if aid in selected else aid if bid in selected else None
        exclass=classes.get(exid) if exid is not None else None
        typed_effects={r[2] for r in set_rows}
        always_effects=set(RELATION_DECISION_RELEVANCE_POLICY.get('always_decision_relevant_effects',()))
        typed_relevant=bool(typed_effects & always_effects)
        resolution=resolution_map.get((min(aid,bid),max(aid,bid)))
        raw.append({'aid':aid,'bid':bid,'scope':pair_scope,'state':state,'diag':tuple(diag),
                    'source_state':source_state,'source_cert':None if source_cert is None else source_cert.certificate_id,
                    'set_rows':set_rows,'exclass':exclass,'typed_relevant':typed_relevant,'resolution':resolution})

    path_relevant=_source_dependency_path_relevant_pair_keys(selected,raw)
    rows=[]
    for r in raw:
        key=(min(r['aid'],r['bid']),max(r['aid'],r['bid']))
        source_path_relevant=(r['source_state']=='SOURCE_SHARED_DEPENDENCY' and key in path_relevant)
        decision_relevant=(r['scope']!='EXCLUDED_EXCLUDED' or r['typed_relevant']
                           or r['state'] in {'UNRESOLVED','CONTRADICTION'}
                           or r['exclass']=='EXCLUDED_CONTRADICTORY' or source_path_relevant)
        rows.append((r['aid'],r['bid'],r['scope'],r['state'],r['diag'],r['source_state'],r['source_cert'],r['set_rows'],
                     r['exclass'],decision_relevant,r['resolution']))
    return tuple(rows)


def _source_dependency_universe_coverage_valid(descriptor,ledger):
    """Mandatory-equivalent source/failure-domain closure over the full support universe."""
    if ledger is None:return False
    required=SUPPORT_UNIVERSE_POLICY.get('source_dependency_resolution_type')
    if required not in set(SUPPORT_RELATION_RESOLUTIONS):return False
    for aid,bid,scope,state,diag,source_state,source_cert,set_rows,exclass,relevant,resolution in ledger:
        if source_state=='SOURCE_SHARED_DEPENDENCY' and relevant:
            # Source/failure-domain dependency is an orthogonal semantic channel.
            # It remains an obligation even when the pair summary is COMMON_MODE,
            # CONTRADICTION, or another aggregate state.
            if scope=='SELECTED_SELECTED':return False
            # Selected-excluded and path-relevant excluded-excluded dependencies require
            # explicit typed accounting in the exact support selection. A selected-excluded
            # support may remain EXCLUDED_REDUNDANT when a separate redundancy relation is
            # independently certified; the dependency channel is accounted here.
            if resolution!=required:return False
            if scope=='SELECTED_EXCLUDED' and exclass not in {'EXCLUDED_DEPENDENT','EXCLUDED_REDUNDANT'}:return False
    return True


def _relation_ledger_coverage_valid(descriptor,ledger):
    if ledger is None:return False
    classes=dict(descriptor.get('exclusion_classifications',()))
    if any(v not in set(SUPPORT_EXCLUSION_CLASSES) for v in classes.values()):return False
    if any(v=='EXCLUDED_UNRESOLVED' for v in classes.values()):return False
    allowed=set(SUPPORT_RELATION_RESOLUTIONS)
    for aid,bid,scope,state,diag,source_state,source_cert,set_rows,exclass,relevant,resolution in ledger:
        if resolution is not None and resolution not in allowed:return False
        if scope=='SELECTED_SELECTED':
            if state!='INDEPENDENT':return False
        elif scope=='SELECTED_EXCLUDED':
            if state=='UNRESOLVED':return False
            if state=='INDEPENDENT':
                if exclass not in {'EXCLUDED_NOT_NEEDED','EXCLUDED_REDUNDANT','EXCLUDED_DEPENDENT'}:return False
            elif state=='COMMON_MODE':
                # Exact per-relation certificates + disposition authorization are checked separately.
                if exclass not in {'EXCLUDED_REDUNDANT','EXCLUDED_DEPENDENT'}:return False
            elif state=='DEPENDENT':
                if exclass!='EXCLUDED_DEPENDENT' or resolution!='DEPENDENCY_ACCOUNTED_NOT_COUNTED':return False
            elif state=='CONTRADICTION':
                if exclass!='EXCLUDED_CONTRADICTORY' or resolution!='CONTRADICTION_RESOLVED':return False
        else:
            if relevant and state in {'UNRESOLVED','CONTRADICTION'}:return False
            if relevant and source_state=='SOURCE_SHARED_DEPENDENCY':
                if resolution!='DEPENDENCY_ACCOUNTED_NOT_COUNTED':return False
    return _source_dependency_universe_coverage_valid(descriptor,ledger)

def _source_fd_closure_hash_for_universe(universe,facts):
    fmap={f.evidence_id:f for f in facts};rows=[]
    for eid in universe.matching_evidence_ids:
        f=fmap.get(eid)
        if f is None:return sha(('MISSING',eid))
        fd=f.source_failure_domain.failure_domain_id
        cl=failure_domain_closure(fd)
        rows.append((eid,fd,None if cl is None else tuple(sorted(cl)),tuple(sorted(source_common_mode_ids(f)))))
    return sha(tuple(rows))

def make_support_selection_certificate(c,facts,ctx,requirement,universe=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None or not validate_matching_support_universe(universe,c,facts,ctx):return None
    d=_selection_descriptor(c,universe,requirement)
    if d is None:return None
    selected=tuple(d.get('selected_support_ids',())); excluded=tuple(d.get('excluded_support_ids',()))
    need=requirement['required_independent_supports']
    if len(selected)!=need or set(selected)|set(excluded)!=set(universe.matching_evidence_ids) or set(selected)&set(excluded):return None
    if tuple(sorted(selected))!=selected or tuple(sorted(excluded))!=excluded:return None
    classes=tuple(d.get('exclusion_classifications',()))
    reasons=tuple(d.get('exclusion_reasons',()))
    if set(x for x,_ in classes)!=set(excluded) or set(x for x,_ in reasons)!=set(excluded):return None
    if any(cls not in set(SUPPORT_EXCLUSION_CLASSES) for _,cls in classes):return None
    if any(not nonblank(reason) for _,reason in reasons) or not nonblank(d.get('justification_reason')):return None
    if d.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id:return None
    ledger=_support_relation_ledger(c,facts,ctx,universe,d)
    if not _relation_ledger_coverage_valid(d,ledger):return None
    if not _relation_instance_coverage_valid_for_claim(c,facts,ctx,requirement,universe,d):return None
    payload={
        'selection_id':d['selection_id'],'claim_id':c.id,'audit_context_id':ctx.audit_context_id,
        'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':universe.retrieval_snapshot_id,
        'matching_support_universe_hash':universe.universe_hash,'selected_support_ids':selected,
        'excluded_support_ids':excluded,'selected_support_ids_hash':sha(selected),'excluded_support_ids_hash':sha(excluded),
        'exclusion_classifications':classes,'exclusion_classification_hash':sha(classes),
        'exclusion_reason_hash':sha(reasons),'relation_ledger_hash':sha(ledger),
        'relation_resolution_hash':_relation_resolution_coverage_artifact_hash(c,ctx),
        'source_failure_domain_closure_hash':_source_fd_closure_hash_for_universe(universe,facts),
        'common_mode_registry_hash':support_set_common_mode_registry_hash(),
        'support_requirement_hash':sha(requirement),'justification_reason_hash':sha(d['justification_reason']),
        'support_universe_policy_hash':support_universe_policy_hash(),'source_policy_hash':source_independence_policy_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),'ontology_hash':dependency_ontology_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),'result':'PASS',
    }
    return SupportSelectionCertificate(sha(payload),**payload)

def _find_support_selection_certificate(c,facts,ctx,requirement,universe=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None:return None
    candidates=[x for x in SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values()
                if isinstance(x,SupportSelectionCertificate) and x.audit_context_id==ctx.audit_context_id and x.claim_id==c.id]
    if len(candidates)!=1:return None
    cert=candidates[0];fresh=make_support_selection_certificate(c,facts,ctx,requirement,universe)
    return cert if fresh is not None and asdict(cert)==asdict(fresh) else None

def validate_support_selection_certificate(cert,c,facts,ctx,requirement,universe=None):
    if cert is None:return False
    fresh=make_support_selection_certificate(c,facts,ctx,requirement,universe)
    return fresh is not None and asdict(cert)==asdict(fresh)

def make_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe=None,selection_cert=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None:return None
    selection_cert=selection_cert or _find_support_selection_certificate(c,facts,ctx,requirement,universe)
    if selection_cert is None or not validate_support_selection_certificate(selection_cert,c,facts,ctx,requirement,universe):return None
    d=_selection_descriptor(c,universe,requirement)
    if d is None:return None
    ledger=_support_relation_ledger(c,facts,ctx,universe,d)
    if not _relation_ledger_coverage_valid(d,ledger):return None
    if not _decision_relevant_relation_discovery_complete_for_claim(c,facts,ctx,requirement,universe,d):return None
    neighborhood=_find_decision_relevant_relation_universe(c,ctx,universe,d)
    if neighborhood is None:return None
    if not _relation_instance_coverage_valid_for_claim(c,facts,ctx,requirement,universe,d):return None
    # Universe-level COMMON_MODE/UNKNOWN rows are represented in the matching-support ledger,
    # while the v0.2.23 relation neighborhood separately binds selected->non-matching relations.
    # they touch; unresolved rows therefore cannot disappear just because one endpoint was excluded.
    payload={
        'coverage_id':'coverage:'+sha((c.id,ctx.audit_context_id,universe.universe_hash,selection_cert.certificate_id))[:24],
        'claim_id':c.id,'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':universe.retrieval_snapshot_id,'matching_support_universe_hash':universe.universe_hash,
        'selected_support_ids_hash':selection_cert.selected_support_ids_hash,
        'excluded_support_ids_hash':selection_cert.excluded_support_ids_hash,
        'support_selection_certificate_id':selection_cert.certificate_id,
        'relation_ledger_hash':sha(ledger),'relation_resolution_hash':selection_cert.relation_resolution_hash,
        'decision_relevant_relation_universe_hash':neighborhood.universe_hash,
        'decision_relevant_relation_ids_hash':neighborhood.relation_ids_hash,
        'source_failure_domain_closure_hash':_source_fd_closure_hash_for_universe(universe,facts),
        'common_mode_registry_hash':support_set_common_mode_registry_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),'source_policy_hash':source_independence_policy_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),'ontology_hash':dependency_ontology_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'coverage_result':'PASS',
    }
    return ClaimSupportUniverseCoverageCertificate(sha(payload),**payload)

def _find_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe=None,selection_cert=None):
    universe=universe or _find_matching_support_universe(c,facts,ctx)
    if universe is None:return None
    candidates=[x for x in CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values()
                if isinstance(x,ClaimSupportUniverseCoverageCertificate) and x.audit_context_id==ctx.audit_context_id and x.claim_id==c.id]
    if len(candidates)!=1:return None
    cert=candidates[0]
    fresh=make_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,selection_cert)
    return cert if fresh is not None and asdict(cert)==asdict(fresh) else None

def validate_claim_support_universe_coverage_certificate(cert,c,facts,ctx,requirement,universe=None,selection_cert=None):
    if cert is None:return False
    fresh=make_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,selection_cert)
    return fresh is not None and asdict(cert)==asdict(fresh)

def _clear_support_artifacts_for_context(audit_context_id):
    for registry in (MATCHING_SUPPORT_UNIVERSE_REGISTRY,DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY,
                     SUPPORT_SELECTION_CERTIFICATE_REGISTRY,CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY,
                     RELATION_RESOLUTION_CERTIFICATE_REGISTRY,EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY):
        for key,val in list(registry.items()):
            if getattr(val,'audit_context_id',None)==audit_context_id:del registry[key]

def _prepare_support_universe_artifacts(text,evidence,claim_identity_map,asof,retrieval_scope,reqs,audit_context_id):
    facts=[]
    for i,r in enumerate(evidence,1):
        f,errs=normalize_fact(r,i)
        if errs:return False
        facts.append(f)
    claims=parse_claims(text)
    if attach_claim_identities(claims,claim_identity_map):return False
    class _Ctx:pass
    ctx=_Ctx();ctx.audit_context_id=audit_context_id;ctx.as_of_date=asof;ctx.retrieval_scope_id=retrieval_scope
    _clear_support_artifacts_for_context(audit_context_id)
    for c in claims:
        if c.predicate in {'hypothesis','unmodelled'}:continue
        requirement=reqs.get(c.id)
        if requirement is None:continue
        universe=make_matching_support_universe(c,facts,ctx)
        if universe is None:continue
        MATCHING_SUPPORT_UNIVERSE_REGISTRY[universe.universe_id]=universe
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:continue
        neighborhood=make_decision_relevant_relation_universe(c,ctx,universe,descriptor)
        if neighborhood is None:continue
        DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY[neighborhood.universe_id]=neighborhood
        # Relation-specific artifacts are derived only after the selected-support relation
        # neighborhood has been canonically discovered and bound to the retrieval snapshot.
        for inst in _relation_instances_for_claim(c,ctx,universe,descriptor):
            if not _relation_instance_requires_handling(inst,descriptor):continue
            rcert=make_relation_resolution_certificate(c,facts,ctx,universe,descriptor,inst)
            if rcert is not None:RELATION_RESOLUTION_CERTIFICATE_REGISTRY[rcert.certificate_id]=rcert
        for eid,cls in dict(descriptor.get('exclusion_classifications',())).items():
            if cls!='EXCLUDED_REDUNDANT':continue
            dcert=make_excluded_support_disposition_certificate(c,facts,ctx,universe,descriptor,eid)
            if dcert is not None:EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY[dcert.certificate_id]=dcert
        sel=make_support_selection_certificate(c,facts,ctx,requirement,universe)
        if sel is None:continue
        SUPPORT_SELECTION_CERTIFICATE_REGISTRY[sel.certificate_id]=sel
        cov=make_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,sel)
        if cov is not None:CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY[cov.certificate_id]=cov
    return True

def support_selection_justification_valid(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return False
    for c in modeled:
        requirement=reqs.get(c.id)
        if requirement is None:return False
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:return False
        cert=_find_support_selection_certificate(c,facts,ctx,requirement,universe)
        if cert is None:return False
    return True

def claim_support_universe_common_mode_coverage_valid(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return False
    for c in modeled:
        requirement=reqs.get(c.id)
        if requirement is None:return False
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:return False
        sel=_find_support_selection_certificate(c,facts,ctx,requirement,universe)
        if sel is None:return False
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None or not _relation_instance_coverage_valid_for_claim(c,facts,ctx,requirement,universe,descriptor):return False
        cov=_find_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,sel)
        if cov is None:return False
    return True
def make_direct(c,f,ctx):
    if not evidence_epistemic_role_direct_eligible(f):return None
    rc=make_referent_consistency(c,f)
    if rc is None:return None
    payload={'claim_id':c.id,'evidence_id':f.evidence_id,'audit_context_id':ctx.audit_context_id,'claim_identity_certificate_id':c.identity.certificate_id,'evidence_identity_certificate_id':f.identity.certificate_id,'authority_certificate_id':f.authority.certificate_id,'provenance_certificate_id':f.provenance.certificate_id,'provenance_completeness_certificate_id':f.provenance_completeness.certificate_id,'dependency_ontology_conformance_certificate_id':f.dependency_ontology_conformance.certificate_id,'source_failure_domain_certificate_id':f.source_failure_domain.certificate_id,'epistemic_role_certificate_id':f.epistemic_role_certificate.certificate_id,'referent_consistency_certificate_id':rc.certificate_id,'temporal_certificate_id':f.temporal.certificate_id,'evidence_fingerprint':evidence_fingerprint(f)}
    return DirectCertificate(sha(payload),**payload)
def validate_direct(c,cert,facts,ctx):
    if cert is None or cert.audit_context_id!=ctx.audit_context_id:return False
    f=next((x for x in facts if x.evidence_id==cert.evidence_id),None)
    if f is None or not support_matches(c,f,ctx) or not evidence_epistemic_role_direct_eligible(f):return False
    if cert.epistemic_role_certificate_id!=f.epistemic_role_certificate.certificate_id:return False
    rc=make_referent_consistency(c,f)
    if rc is None or cert.referent_consistency_certificate_id!=rc.certificate_id:return False
    if not validate_identity(c.identity,'CLAIM',c.id,c.subject,c.identity.registry_entry_id):return False
    if not validate_identity(f.identity,'EVIDENCE',f.evidence_id,f.subject,f.identity.registry_entry_id):return False
    if not validate_temporal(f.temporal) or not validate_provenance(f.provenance,f.evidence_id) or not validate_prov_complete(f.provenance_completeness,f.provenance,f.evidence_id) or not validate_dependency_ontology_conformance_certificate(f.dependency_ontology_conformance,f.provenance,f.evidence_id) or not validate_source_failure_domain_certificate(f.source_failure_domain,f.provenance,f.authority,f.evidence_id) or not dependency_resolution_valid(f.provenance) or not dependency_state_justification_valid(f.provenance) or not validate_authority(f.authority,f):return False
    fresh=make_direct(c,f,ctx);return fresh is not None and asdict(fresh)==asdict(cert)
def audit_claims(claims,facts,ctx):
    usable=[f for f in facts if world_active(f.temporal,ctx.as_of_date) and epistemically_available(f.temporal,ctx.as_of_date)]
    for c in claims:
        if c.status==ClaimStatus.HYPOTHETICAL:continue
        if c.predicate=='unmodelled' or c.identity is None:c.status=ClaimStatus.UNRESOLVED;c.reason='unmodelled or unresolved identity';continue
        opp=[f for f in usable if evidence_epistemic_role_direct_eligible(f) and identity_tuple(f.identity)==identity_tuple(c.identity) and f.predicate==pkey(c.predicate) and norm(f.value)==norm(c.value) and f.polarity!=c.polarity]
        if opp:c.status=ClaimStatus.QUARANTINED;c.reason='direct contradiction';continue
        sup=matching_supports(c,usable,ctx)
        if not sup:c.status=ClaimStatus.UNRESOLVED;c.reason='no referent-consistent epistemically available support';continue
        cert=make_direct(c,sup[0],ctx)
        if cert is None:c.status=ClaimStatus.UNRESOLVED;c.reason='referent consistency failed';continue
        c.status=ClaimStatus.SUPPORTED;c.reason=f'direct referent-consistent support {sup[0].evidence_id}; support policy pending';c.certificate=cert

def active_facts(facts,ctx):return [f for f in facts if world_active(f.temporal,ctx.as_of_date) and epistemically_available(f.temporal,ctx.as_of_date)]
def constraint_coverage(c):
    sch=PREDICATE_SCHEMA.get(pkey(c.predicate))
    if sch is None:return False,'UNMODELLED_PREDICATE_CONSTRAINT'
    if sch['coverage']=='COMPLETE':return True,'COMPLETE'
    known=set();[known.update(pair) for pair in STATE_RELATIONS]
    return (pkey(c.value) in known,'KNOWN_RELATION_CLASS' if pkey(c.value) in known else 'UNMODELLED_STATE_CONSTRAINT')
def relation_coverage_violations(facts,ctx):
    out=[];usable=active_facts(facts,ctx)
    for a,b in combinations(usable,2):
        if identity_tuple(a.identity)!=identity_tuple(b.identity) or a.predicate!=b.predicate or not temporal_overlap(a.temporal,b.temporal) or a.polarity!='POSITIVE' or b.polarity!='POSITIVE' or norm(a.value)==norm(b.value):continue
        if a.predicate in {'date','location'}:continue
        if a.predicate=='state' and frozenset((pkey(a.value),pkey(b.value))) not in STATE_RELATIONS:out.append({'type':'UNMODELLED_STATE_RELATION','evidence_ids':[a.evidence_id,b.evidence_id],'values':[a.value,b.value]})
    return out
def global_consistency(facts,ctx):
    out=[];usable=[f for f in active_facts(facts,ctx) if evidence_epistemic_role_direct_eligible(f)]
    for a,b in combinations(usable,2):
        if identity_tuple(a.identity)!=identity_tuple(b.identity) or a.predicate!=b.predicate or not temporal_overlap(a.temporal,b.temporal):continue
        same=norm(a.value)==norm(b.value)
        if same and a.polarity!=b.polarity:out.append({'type':'POLARITY_CONFLICT','evidence_ids':[a.evidence_id,b.evidence_id]});continue
        sch=PREDICATE_SCHEMA.get(a.predicate)
        if sch and sch['cardinality']=='ONE' and a.polarity==b.polarity=='POSITIVE' and not same:out.append({'type':'CARDINALITY_ONE_CONFLICT','evidence_ids':[a.evidence_id,b.evidence_id]});continue
        if a.predicate=='state' and a.polarity==b.polarity=='POSITIVE' and STATE_RELATIONS.get(frozenset((pkey(a.value),pkey(b.value))))=='CONFLICT':out.append({'type':'MUTUALLY_EXCLUSIVE_STATE_CONFLICT','evidence_ids':[a.evidence_id,b.evidence_id]})
    return out
def make_support_set_certificate(c,facts,ctx,requirement):
    need=requirement['required_independent_supports']
    universe=_find_matching_support_universe(c,facts,ctx)
    if universe is None or len(universe.matching_evidence_ids)<need:return None
    sel=_find_support_selection_certificate(c,facts,ctx,requirement,universe)
    if sel is None:return None
    cov=_find_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,sel)
    if cov is None:return None
    fmap={f.evidence_id:f for f in facts}
    try:ss=tuple(fmap[eid] for eid in sel.selected_support_ids)
    except KeyError:return None
    if len(ss)!=need:return None
    if need==1:
        independence_id='SINGLE_SUPPORT';set_level_id='SINGLE_SUPPORT'
    else:
        set_cert=_valid_support_set_independence_certificate(c.id,ctx.retrieval_scope_id,ss,ctx.as_of_date)
        if set_cert is None:return None
        icert=make_justification_independence_certificate(c.id,ss,ctx.retrieval_scope_id,ctx.as_of_date)
        if icert is None or not validate_justification_independence_certificate(icert,c.id,ss,ctx.retrieval_scope_id,ctx.as_of_date):return None
        independence_id=icert.certificate_id;set_level_id=set_cert.certificate_id
    direct_ids=[]
    for f in ss:
        dc=make_direct(c,f,ctx)
        if dc is None:return None
        direct_ids.append(dc.certificate_id)
    payload={'claim_id':c.id,'audit_context_id':ctx.audit_context_id,'required_supports':need,
             'support_ids_hash':sha(tuple(sorted(f.evidence_id for f in ss))),
             'direct_certificate_ids_hash':sha(tuple(sorted(direct_ids))),
             'independence_certificate_id':independence_id,'set_level_independence_certificate_id':set_level_id,
             'matching_support_universe_hash':universe.universe_hash,
             'support_selection_certificate_id':sel.certificate_id,
             'support_universe_coverage_certificate_id':cov.certificate_id,
             'support_policy_hash':sha(requirement),'support_set_result':'PASS'}
    return SupportSetCertificate(sha(payload),**payload)

def validate_support_set_certificate(cert,c,facts,ctx,requirement):
    fresh=make_support_set_certificate(c,facts,ctx,requirement)
    return fresh is not None and asdict(fresh)==asdict(cert)

def selected_support_facts(c,facts,ctx,requirement):
    universe=_find_matching_support_universe(c,facts,ctx)
    if universe is None:return None
    sel=_find_support_selection_certificate(c,facts,ctx,requirement,universe)
    if sel is None:return None
    cov=_find_claim_support_universe_coverage_certificate(c,facts,ctx,requirement,universe,sel)
    if cov is None:return None
    fmap={f.evidence_id:f for f in facts}
    try:return tuple(fmap[eid] for eid in sel.selected_support_ids)
    except KeyError:return None


# ============================================================
# v0.2.29 — decision-level cross-claim dependency closure
# ============================================================

DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE='DECISION_SOURCE_DEPENDENCY_ACCOUNTING'
DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE='DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING'
GENERIC_DEPENDENCY_ACCOUNTING_CHANNEL='GENERIC_PROVENANCE'


def _canonical_selected_support_map(selected_map):
    if not isinstance(selected_map,dict):return None
    rows=[]
    for cid,eids in selected_map.items():
        if not nonblank(cid):return None
        vals=tuple(sorted(set(eids or ())))
        if len(vals)!=len(tuple(eids or ())):return None
        rows.append((cid,vals))
    return tuple(sorted(rows))


def register_decision_dependency_accounting(accounting_id,retrieval_scope_id,claim_ids,selected_support_map,
                                            evidence_ids,resolution_type,reason,
                                            authorizer_id='LOCAL_SUPPORT_UNIVERSE_AUTHORITY'):
    """Register an explicit decision-level source/failure-domain accounting declaration.

    The declaration starts PENDING.  It must be explicitly bound to the exact audit context,
    claim set, selected-support map and decision dependency graph before prepare().
    The row is stored in SUPPORT_SELECTION_REGISTRY so the already-pinned support-selection
    registry fingerprint also protects it across prepare -> audit.
    """
    if not support_selection_registry_key_identity_coherent():
        raise ValueError('support selection registry key identity mismatch')
    if accounting_id in SUPPORT_SELECTION_REGISTRY:raise ValueError('duplicate decision dependency accounting id')
    if not all(nonblank(x) for x in (accounting_id,retrieval_scope_id,resolution_type,reason,authorizer_id)):
        raise ValueError('invalid decision dependency accounting')
    if authorizer_id not in set(SUPPORT_UNIVERSE_POLICY['allowed_authorizers']):
        raise ValueError('unauthorized decision dependency accounting authorizer')
    required=SUPPORT_UNIVERSE_POLICY.get('decision_dependency_accounting_resolution_type')
    if resolution_type!=required or resolution_type not in set(SUPPORT_RELATION_RESOLUTIONS):
        raise ValueError('invalid decision dependency accounting resolution')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if rr is None:raise ValueError('unknown retrieval scope')
    cids=tuple(sorted(set(claim_ids or ())))
    if not cids or len(cids)!=len(tuple(claim_ids or ())) or any(not nonblank(x) for x in cids):
        raise ValueError('invalid decision claim ids')
    smap=_canonical_selected_support_map(selected_support_map)
    if smap is None or tuple(cid for cid,_ in smap)!=cids:
        raise ValueError('selected support map must exactly cover decision claims')
    eids=tuple(sorted(set(evidence_ids or ())))
    if len(eids)!=2 or len(eids)!=len(tuple(evidence_ids or ())):
        raise ValueError('decision dependency accounting requires exactly two evidence ids')
    row={
        'record_type':DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE,
        'accounting_id':accounting_id,'binding_state':'PENDING',
        'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':rr.get('snapshot_id'),
        'claim_ids':cids,'claim_ids_hash':sha(cids),
        'selected_support_map':smap,'selected_support_map_hash':sha(smap),
        'evidence_ids':eids,'evidence_ids_hash':sha(eids),
        'resolution_type':resolution_type,'reason':reason,'authorizer_id':authorizer_id,
        'support_universe_policy_hash':support_universe_policy_hash(),
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':decision_persistence_history_commitment(),
        'audit_context_id':None,'matching_support_universe_map_hash':None,
        'decision_dependency_graph_hash':None,'path_relevant_source_edges_hash':None,
        'decision_evidence_ownership_map_hash':None,'decision_source_relation_universe_hash':None,
        'decision_source_relation_records_hash':None,'decision_source_obligation_pairs_hash':None,
        'source_semantics_registry_hash':None,'source_semantics_resolution_certificate_registry_hash':None,
        'failure_domain_relation_registry_hash':None,'source_independence_policy_hash':None,'source_semantics_policy_hash':None,
        'source_edge_hash':None,'source_relation_record_hash':None,'accounting_scope_hash':None,
    }
    SUPPORT_SELECTION_REGISTRY[accounting_id]=row
    _authorize_fresh_decision_row(accounting_id)
    return copy.deepcopy(row)


def register_decision_generic_dependency_accounting(accounting_id,retrieval_scope_id,claim_ids,selected_support_map,
                                                    generic_dependency_node,evidence_ids,resolution_type,reason,
                                                    authorizer_id='LOCAL_SUPPORT_UNIVERSE_AUTHORITY'):
    """Register a PENDING exact generic-provenance dependency accounting declaration."""
    if not support_selection_registry_key_identity_coherent():
        raise ValueError('support selection registry key identity mismatch')
    if accounting_id in SUPPORT_SELECTION_REGISTRY:raise ValueError('duplicate generic dependency accounting id')
    if not all(nonblank(x) for x in (accounting_id,retrieval_scope_id,resolution_type,reason,authorizer_id)):
        raise ValueError('invalid generic dependency accounting')
    if authorizer_id not in set(SUPPORT_UNIVERSE_POLICY['allowed_authorizers']):raise ValueError('unauthorized generic accounting authorizer')
    required=SUPPORT_UNIVERSE_POLICY.get('decision_dependency_accounting_resolution_type')
    if resolution_type!=required:raise ValueError('invalid generic dependency accounting resolution')
    node=tuple(generic_dependency_node or ())
    if len(node)!=3 or any(not isinstance(x,str) or not x for x in node):raise ValueError('invalid generic dependency node')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
    if rr is None:raise ValueError('unknown retrieval scope')
    cids=tuple(sorted(set(claim_ids or ())))
    if not cids or len(cids)!=len(tuple(claim_ids or ())):raise ValueError('invalid decision claim ids')
    smap=_canonical_selected_support_map(selected_support_map)
    if smap is None or tuple(cid for cid,_ in smap)!=cids:raise ValueError('selected support map must exactly cover decision claims')
    eids=tuple(sorted(set(evidence_ids or ())))
    if len(eids)<2 or len(eids)!=len(tuple(evidence_ids or ())):raise ValueError('generic accounting needs exact endpoint set')
    row={
        'record_type':DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE,'dependency_channel':GENERIC_DEPENDENCY_ACCOUNTING_CHANNEL,
        'accounting_id':accounting_id,'binding_state':'PENDING','retrieval_scope_id':retrieval_scope_id,
        'retrieval_snapshot_id':rr.get('snapshot_id'),'claim_ids':cids,'claim_ids_hash':sha(cids),
        'selected_support_map':smap,'selected_support_map_hash':sha(smap),
        'generic_dependency_node':node,'generic_dependency_node_hash':sha(node),
        'evidence_ids':eids,'evidence_ids_hash':sha(eids),'resolution_type':resolution_type,'reason':reason,
        'authorizer_id':authorizer_id,'support_universe_policy_hash':support_universe_policy_hash(),
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':decision_persistence_history_commitment(),
        'audit_context_id':None,'matching_support_universe_map_hash':None,'decision_dependency_graph_hash':None,
        'decision_evidence_ownership_map_hash':None,'decision_generic_dependency_universe_hash':None,
        'decision_generic_dependency_records_hash':None,'decision_generic_dependency_obligations_hash':None,
        'provenance_policy_hash':None,'dependency_ontology_hash':None,'dependency_justification_registry_hash':None,
        'representation_equivalence_policy_hash':generic_relation_source_identity_policy_hash(),
        'representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),
        'representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),
        'active_equivalence_ids_hash':None,'inactive_equivalence_records_hash':None,
        'equivalence_applicability_records_hash':None,'contextual_equivalence_resolution_hash':None,
        'complete_raw_representation_inventory_hash':None,'representation_classes_present_hash':None,
        'candidate_semantic_descriptor_records_hash':None,'cross_representation_pair_coverage_records_hash':None,
        'proven_non_candidate_records_hash':None,
        'candidate_representation_pair_universe_hash':None,'candidate_disposition_records_hash':None,
        'ontology_prefix_map_hash':None,'source_discovery_signal_hash':None,'typed_discovery_signal_hash':None,
        'representation_distinctness_registry_hash':generic_representation_distinctness_registry_hash(),
        'representation_distinctness_certificate_registry_hash':generic_representation_distinctness_certificate_registry_hash(),
        'representation_completeness_certificate_hash':None,
        'generic_dependency_record_hash':None,'accounting_scope_hash':None,
    }
    SUPPORT_SELECTION_REGISTRY[accounting_id]=row
    _authorize_fresh_decision_row(accounting_id)
    return copy.deepcopy(row)


def _decision_support_dependency_graph(claims,facts,ctx,reqs,registered_universes=True):
    """Build the deterministic decision-level graph over selected + justificatory excluded supports.

    Claim-local ledgers remain authoritative for local coverage.  This graph composes those local
    justifications across all modeled claims and independently evaluates source/failure-domain
    channels between every included evidence node.  Pair summaries are not used as semantic truth.
    """
    modeled=tuple(sorted((c for c in claims if c.predicate not in {'hypothesis','unmodelled'}),key=lambda c:c.id))
    if not modeled:return None
    fmap={f.evidence_id:f for f in facts}
    selected_map={};universe_map={};node_owners={};selected_claims={};bridges=[];local_source_accounting={}
    for c in modeled:
        requirement=reqs.get(c.id)
        if requirement is None:return None
        universe=(_find_matching_support_universe(c,facts,ctx) if registered_universes
                  else make_matching_support_universe(c,facts,ctx))
        if universe is None:return None
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:return None
        selected=tuple(descriptor.get('selected_support_ids',()))
        if not selected:return None
        selected_map[c.id]=selected;universe_map[c.id]=universe.universe_hash
        for eid in selected:
            if eid not in fmap:return None
            node_owners.setdefault(eid,set()).add(c.id);selected_claims.setdefault(eid,set()).add(c.id)
        ledger=_support_relation_ledger(c,facts,ctx,universe,descriptor)
        if ledger is None:return None
        csel=set(selected)
        for row in ledger:
            aid,bid,scope,state,diag,source_state,source_cert,set_rows,exclass,relevant,resolution=row
            key=(min(aid,bid),max(aid,bid))
            if source_state=='SOURCE_SHARED_DEPENDENCY' and resolution==SUPPORT_UNIVERSE_POLICY.get('source_dependency_resolution_type'):
                local_source_accounting.setdefault(key,set()).add((c.id,resolution))
            if scope!='SELECTED_EXCLUDED':continue
            has_redundancy=any(x[1]=='COMMON_MODE' and x[2]=='REDUNDANCY_ONLY' for x in set_rows)
            bridge_type=None
            if exclass=='EXCLUDED_REDUNDANT' and has_redundancy:
                bridge_type='REDUNDANCY_JUSTIFICATION'
            elif (exclass=='EXCLUDED_DEPENDENT' and source_state=='SOURCE_SHARED_DEPENDENCY'
                  and resolution==SUPPORT_UNIVERSE_POLICY.get('source_dependency_resolution_type')):
                bridge_type='DEPENDENCY_JUSTIFICATION'
            if bridge_type is None:continue
            if aid in csel and bid not in csel:selid,exid=aid,bid
            elif bid in csel and aid not in csel:selid,exid=bid,aid
            else:continue
            if exid not in fmap:return None
            node_owners.setdefault(exid,set()).add(c.id)
            bridges.append((min(selid,exid),max(selid,exid),c.id,bridge_type,exid))

    decision_nodes=tuple(sorted(node_owners))
    selected_ids=set(eid for _,eids in selected_map.items() for eid in eids)
    if not selected_ids:return None
    source_rows=[]
    for aid,bid in combinations(decision_nodes,2):
        a=fmap.get(aid);b=fmap.get(bid)
        if a is None or b is None:return None
        ok,state,diag,source_cert=evaluate_source_relation(a,b)
        source_rows.append((aid,bid,state,tuple(sorted(diag)),None if source_cert is None else source_cert.certificate_id))

    # The path graph contains justificatory bridges plus dependency/unresolved source channels.
    graph={}
    for aid,bid,cid,btype,exid in bridges:
        graph.setdefault(aid,set()).add(bid);graph.setdefault(bid,set()).add(aid)
    candidate_source={}
    for row in source_rows:
        aid,bid,state,diag,cert=row
        if state not in {'SOURCE_SHARED_DEPENDENCY','SOURCE_RELATION_UNRESOLVED'}:continue
        key=(aid,bid)
        candidate_source[key]=row
        graph.setdefault(aid,set()).add(bid);graph.setdefault(bid,set()).add(aid)

    def reachable(start,skip):
        seen={start};stack=[start]
        while stack:
            cur=stack.pop()
            for nxt in graph.get(cur,()):
                if (min(cur,nxt),max(cur,nxt))==skip:continue
                if nxt not in seen:seen.add(nxt);stack.append(nxt)
        return seen

    relevant=[]
    for key,row in sorted(candidate_source.items()):
        a,b=key;ra=reachable(a,key);rb=reachable(b,key)
        sa=selected_ids & ra;sb=selected_ids & rb
        if b not in ra:
            if sa and sb and any(x!=y for x in sa for y in sb):relevant.append(row)
        else:
            if len(selected_ids & ra)>=2:relevant.append(row)

    selected_rows=_canonical_selected_support_map(selected_map)
    owner_rows=tuple(sorted((eid,tuple(sorted(owners)),tuple(sorted(selected_claims.get(eid,set()))))
                            for eid,owners in node_owners.items()))
    bridge_rows=tuple(sorted(set(bridges)))
    source_rows=tuple(sorted(source_rows))
    relevant_rows=tuple(sorted(relevant))
    local_rows=tuple(sorted((a,b,tuple(sorted(vals))) for (a,b),vals in local_source_accounting.items()))
    graph_payload={
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),
        'claim_ids_hash':sha(tuple(c.id for c in modeled)),
        'selected_support_map_hash':sha(selected_rows),
        'matching_support_universe_map_hash':sha(tuple(sorted(universe_map.items()))),
        'node_ownership':owner_rows,'justificatory_bridges':bridge_rows,
        'source_relation_rows':source_rows,
        'path_relevant_source_edges':relevant_rows,
        'support_universe_policy_hash':support_universe_policy_hash(),
    }
    graph_hash=sha(graph_payload)
    return {
        'claim_ids':tuple(c.id for c in modeled),'claim_ids_hash':graph_payload['claim_ids_hash'],
        'selected_support_map':selected_rows,'selected_support_map_hash':graph_payload['selected_support_map_hash'],
        'matching_support_universe_map':tuple(sorted(universe_map.items())),
        'matching_support_universe_map_hash':graph_payload['matching_support_universe_map_hash'],
        'node_ownership':owner_rows,'justificatory_bridges':bridge_rows,'source_relation_rows':source_rows,
        'path_relevant_source_edges':relevant_rows,'path_relevant_source_edges_hash':sha(relevant_rows),
        'local_source_accounting':local_rows,'graph_hash':graph_hash,
    }



# ============================================================
# v0.2.32 — decision-level exact scope coverage over complete matching-universe ownership
# ============================================================

DECISION_RELATION_RESOLUTION_RECORD_TYPE='DECISION_TYPED_RELATION_RESOLUTION'


def _decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Build complete endpoint->claim ownership from all modeled MatchingSupportUniverses.

    v0.2.32: decision-node membership is diagnostic only.  Ownership is derived from the
    full modeled matching universes, so EXCLUDED_NOT_NEEDED and other non-graph evidence
    cannot become ownerless merely because it is absent from the decision dependency graph.
    """
    if dgraph is None:return None
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None:return None
    snapshot_ids=tuple(sorted(set(rr.get('expected_evidence_ids',()))))
    participating=tuple(sorted(dgraph.get('claim_ids',())))
    if not participating:return None
    modeled={c.id:c for c in claims if c.predicate not in {'hypothesis','unmodelled'}}
    node_ids=set(eid for eid,_,_ in dgraph.get('node_ownership',()))
    owner_map={eid:set() for eid in snapshot_ids}
    class_map={eid:[] for eid in snapshot_ids}
    universe_rows=[]
    selected_rows=[]
    for cid in participating:
        c=modeled.get(cid); requirement=reqs.get(cid)
        if c is None or requirement is None:return None
        universe=(_find_matching_support_universe(c,facts,ctx) if registered_universes
                  else make_matching_support_universe(c,facts,ctx))
        if universe is None:return None
        if not set(universe.matching_evidence_ids).issubset(set(snapshot_ids)):return None
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:return None
        selected=set(descriptor.get('selected_support_ids',()))
        classes=dict(descriptor.get('exclusion_classifications',()))
        if selected | set(classes) != set(universe.matching_evidence_ids):return None
        if selected & set(classes):return None
        universe_rows.append((cid,universe.universe_hash))
        selected_rows.append((cid,tuple(sorted(selected))))
        for eid in universe.matching_evidence_ids:
            owner_map.setdefault(eid,set()).add(cid)
            cls='SELECTED_JUSTIFICATORY' if eid in selected else classes.get(eid,'MATCHING_UNCLASSIFIED')
            class_map.setdefault(eid,[]).append((cid,cls))
    universe_rows=tuple(sorted(universe_rows));selected_rows=tuple(sorted(selected_rows))
    if sha(universe_rows)!=dgraph.get('matching_support_universe_map_hash'):return None
    if sha(selected_rows)!=dgraph.get('selected_support_map_hash'):return None
    records=[]
    for eid in snapshot_ids:
        owners=tuple(sorted(owner_map.get(eid,set())))
        classifications=tuple(sorted(class_map.get(eid,())))
        status='MODELED_CLAIM_OWNED' if owners else 'SNAPSHOT_ONLY'
        records.append((eid,owners,classifications,eid in node_ids,status))
    records=tuple(records)
    payload={
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),
        'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
        'decision_node_ids_hash':sha(tuple(sorted(node_ids))),'ownership_records_hash':sha(records),
    }
    map_hash=sha(payload)
    return DecisionEvidenceOwnershipMap(
        'decision-evidence-ownership:'+map_hash[:24],ctx.audit_context_id,ctx.retrieval_scope_id,
        payload['retrieval_snapshot_id'],dgraph['claim_ids_hash'],dgraph['selected_support_map_hash'],
        dgraph['matching_support_universe_map_hash'],payload['decision_node_ids_hash'],records,sha(records),map_hash
    )


def _decision_level_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Evaluate every in-scope typed relation before graph-anchor filtering.

    v0.2.34 derives endpoint ownership first.  Graph membership remains diagnostic/path
    information; it cannot erase a cross-claim modeled relation obligation.  Rows that are
    explicitly non-decision-level are still bound into DecisionLevelRelationUniverse so
    absence from relation_ids is itself auditable rather than an implicit relevance claim.
    """
    if dgraph is None:return tuple()
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None:return tuple()
    snapshot_ids=set(rr.get('expected_evidence_ids',()))
    node_ids=set(eid for eid,_,_ in dgraph.get('node_ownership',()))
    selected_ids=set(eid for _,eids in dgraph.get('selected_support_map',()) for eid in eids)
    participating=set(dgraph.get('claim_ids',()))
    if not participating:return tuple()
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return tuple()
    ownership_records={eid:(tuple(owners),tuple(classes),bool(in_graph),status)
                       for eid,owners,classes,in_graph,status in ownership_map.ownership_records}

    local_claims_by_relation={}
    modeled={c.id:c for c in claims if c.predicate not in {'hypothesis','unmodelled'}}
    for cid in sorted(participating):
        c=modeled.get(cid); requirement=reqs.get(cid)
        if c is None or requirement is None:return tuple()
        universe=(_find_matching_support_universe(c,facts,ctx) if registered_universes
                  else make_matching_support_universe(c,facts,ctx))
        if universe is None:return tuple()
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:return tuple()
        neighborhood=(_find_decision_relevant_relation_universe(c,ctx,universe,descriptor) if registered_universes
                      else make_decision_relevant_relation_universe(c,ctx,universe,descriptor))
        if neighborhood is None:return tuple()
        for rid in neighborhood.relation_ids:
            local_claims_by_relation.setdefault(rid,set()).add(cid)

    allowed=set(RELATION_DISCOVERY_POLICY.get('allowed_relation_types',()))
    rows=[]
    for rid,row in sorted(SUPPORT_SET_COMMON_MODE_REGISTRY.items()):
        if not isinstance(row,dict) or row.get('relation') not in allowed:continue
        if row.get('retrieval_scope_id','*') not in {ctx.retrieval_scope_id,'*'}:continue
        claim_scope=row.get('claim_id','*')
        if claim_scope!='*' and claim_scope not in participating:continue
        eids=tuple(sorted(set(row.get('evidence_ids',()))))
        if len(eids)<2:continue
        eset=set(eids)
        local_claims=tuple(sorted(local_claims_by_relation.get(rid,set())))
        endpoint_ownership=tuple((eid,ownership_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[0]) for eid in eids)
        endpoint_ownership_status=tuple((eid,ownership_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[3],
                                         ownership_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[2],
                                         ownership_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[1])
                                        for eid in eids)
        endpoint_claims=tuple(sorted({cid for _,owners in endpoint_ownership for cid in owners}))
        effect=_relation_row_effect(row)
        decision_count=len(eset & node_ids)
        selected_anchor=bool(eset & selected_ids)
        endpoint_scope_valid=eset.issubset(snapshot_ids)
        cross_claim_modeled=len(endpoint_claims)>=2
        local_scope_sufficient=(len(endpoint_claims)==1 and endpoint_claims[0] in set(local_claims))
        legacy_graph_relevant=(decision_count>=2 or selected_anchor)

        # v0.2.50 / R62: effect-first relevance is authoritative.  Endpoint ownership or
        # graph disposition cannot erase a typed effect whose pinned policy is always decision
        # relevant.  Endpoint-scope-dependent effects continue to use the legacy ownership path.
        always_effects=set(RELATION_DECISION_RELEVANCE_POLICY.get('always_decision_relevant_effects',()))
        if effect in always_effects:
            decision_level_required=True
            relevance_classification='DECISION_LEVEL_EFFECT_ALWAYS_RELEVANT'
        elif cross_claim_modeled:
            decision_level_required=True
            relevance_classification='DECISION_LEVEL_CROSS_CLAIM_MODELED'
        elif legacy_graph_relevant:
            decision_level_required=True
            relevance_classification='DECISION_LEVEL_GRAPH_ANCHORED'
        elif local_scope_sufficient:
            decision_level_required=False
            relevance_classification='CLAIM_LOCAL_SCOPE_SUFFICIENT_NON_GRAPH'
        elif len(endpoint_claims)==0:
            decision_level_required=False
            relevance_classification='SNAPSHOT_ONLY_NON_DECISION_LEVEL'
        else:
            # A modeled endpoint relation that is neither safely local-covered nor graph-anchored
            # must not disappear.  Fall back to decision-level handling rather than infer irrelevance.
            decision_level_required=True
            relevance_classification='DECISION_LEVEL_MODELED_SCOPE_UNCOVERED'

        rows.append({
            'relation_id':rid,'relation_type':row.get('relation'),'relation_effect':effect,
            'evidence_ids':eids,'evidence_ids_hash':sha(eids),'claim_scope':claim_scope,
            'decision_node_endpoint_count':decision_count,'selected_anchor':selected_anchor,
            'endpoint_scope_valid':endpoint_scope_valid,
            'claim_local_covered':bool(local_claims),'local_covering_claim_ids':local_claims,
            'endpoint_claim_ownership':endpoint_ownership,'endpoint_claim_ids':endpoint_claims,
            'endpoint_claim_ownership_status':endpoint_ownership_status,
            'endpoint_claim_ownership_hash':sha((endpoint_ownership,endpoint_ownership_status)),
            'decision_evidence_ownership_map_hash':ownership_map.map_hash,
            'claim_local_scope_sufficient':local_scope_sufficient,
            'cross_claim_modeled_endpoints':cross_claim_modeled,
            'decision_level_required':decision_level_required,
            'relevance_classification':relevance_classification,
            'registry_entry_hash':sha(row),
        })
    return tuple(rows)


def _decision_level_relation_discovery_candidates(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Return exact relation instances requiring decision-level coverage after ownership-first assessment."""
    return tuple(x for x in _decision_level_relation_assessments(
        claims,facts,ctx,reqs,dgraph,registered_universes) if x['decision_level_required'])


def make_decision_level_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    if dgraph is None:return None
    assessments=_decision_level_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes)
    assessed_ids=tuple(x['relation_id'] for x in assessments)
    if len(set(assessed_ids))!=len(assessed_ids):return None
    candidates=tuple(x for x in assessments if x['decision_level_required'])
    relation_ids=tuple(x['relation_id'] for x in candidates)
    out_of_snapshot=tuple(x['relation_id'] for x in candidates if not x['endpoint_scope_valid'])
    local_covered=tuple(x['relation_id'] for x in candidates if x['claim_local_covered'])
    local_scope_sufficient=tuple(x['relation_id'] for x in candidates if x['claim_local_scope_sufficient'])
    non_decision=tuple(x['relation_id'] for x in assessments if not x['decision_level_required'])
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return None
    endpoint_ownership_records=tuple((x['relation_id'],x['endpoint_claim_ownership'],x['endpoint_claim_ownership_status']) for x in assessments)
    records=tuple((x['relation_id'],x['relation_type'],x['relation_effect'],x['evidence_ids'],x['claim_scope'],
                   x['decision_node_endpoint_count'],x['selected_anchor'],x['endpoint_scope_valid'],
                   x['claim_local_covered'],x['local_covering_claim_ids'],x['endpoint_claim_ownership'],
                   x['endpoint_claim_ids'],x['endpoint_claim_ownership_status'],x['claim_local_scope_sufficient'],
                   x['cross_claim_modeled_endpoints'],x['relevance_classification'],x['registry_entry_hash']) for x in candidates)
    evaluated_records=tuple((x['relation_id'],x['relation_type'],x['relation_effect'],x['evidence_ids'],x['claim_scope'],
                             x['endpoint_scope_valid'],x['endpoint_claim_ownership'],x['endpoint_claim_ownership_status'],
                             x['local_covering_claim_ids'],x['claim_local_scope_sufficient'],
                             x['cross_claim_modeled_endpoints'],x['decision_level_required'],
                             x['relevance_classification'],x['registry_entry_hash']) for x in assessments)
    node_ids=tuple(sorted(eid for eid,_,_ in dgraph.get('node_ownership',())))
    payload={
        'universe_id':'decision-relation-universe:'+sha((ctx.audit_context_id,dgraph['graph_hash'],relation_ids,assessed_ids))[:24],
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),
        'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
        'decision_dependency_graph_hash':dgraph['graph_hash'],'decision_node_ids_hash':sha(node_ids),
        'decision_evidence_ownership_map_hash':ownership_map.map_hash,
        'endpoint_claim_ownership_hash':sha(endpoint_ownership_records),
        'relation_ids':relation_ids,'relation_ids_hash':sha(relation_ids),
        'relation_instance_records_hash':sha(records),
        'evaluated_relation_ids_hash':sha(assessed_ids),'evaluated_relation_records_hash':sha(evaluated_records),
        'non_decision_level_relation_ids_hash':sha(non_decision),
        'claim_local_covered_relation_ids_hash':sha(local_covered),
        'claim_local_scope_sufficient_relation_ids_hash':sha(local_scope_sufficient),
        'out_of_snapshot_relation_ids':out_of_snapshot,'out_of_snapshot_relation_ids_hash':sha(out_of_snapshot),
        'relation_registry_hash':support_set_common_mode_registry_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
    }
    payload['universe_hash']=sha(payload)
    return DecisionLevelRelationUniverse(**payload)

def _decision_relation_candidate_map(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    return {x['relation_id']:x for x in _decision_level_relation_discovery_candidates(
        claims,facts,ctx,reqs,dgraph,registered_universes)}


def _decision_generic_representation_completeness_state(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Complete raw inventory + descriptor-derived cross-representation pair coverage.

    Every exact cross-endpoint, cross-representation raw pair receives one ledger row.  A pair can
    become a candidate only from exact controller descriptors; otherwise the ledger preserves a
    typed PROVEN_NON_CANDIDATE basis.  Therefore an empty candidate list is never accepted merely
    via all([]): coverage cardinality and exact raw-pair membership are independently checked.
    """
    if dgraph is None:return None
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return None
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None:return None
    snapshot_ids=tuple(sorted(set(rr.get('expected_evidence_ids',()))))
    fmap={f.evidence_id:f for f in facts}
    owner_records={eid:(tuple(owners),tuple(classes),bool(in_graph),status) for eid,owners,classes,in_graph,status in ownership_map.ownership_records}
    raw_inventory=[];classes=set();raw_by_endpoint={};descriptor_records=[]
    for eid in snapshot_ids:
        f=fmap.get(eid)
        if f is None:return None
        raws=tuple(sorted(raw_generic_dependency_nodes(f)));raw_by_endpoint[eid]=raws
        owners,clss,in_graph,status=owner_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))
        raw_inventory.append((eid,owners,clss,in_graph,status,raws));classes.update((r[0],r[1]) for r in raws)
        for raw in raws:descriptor_records.append((eid,raw,_raw_candidate_semantic_descriptors(raw)))
    raw_inventory=tuple(raw_inventory);classes=tuple(sorted(classes));descriptor_records=tuple(sorted(descriptor_records,key=str))

    source_universe=make_decision_level_source_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes)
    relation_universe=make_decision_level_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes)
    if source_universe is None or relation_universe is None:return None
    ontology_prefix_map_hash=canonical_hash({'dimensions':DEPENDENCY_DIMENSIONS,'prefixes':DEPENDENCY_PREFIX,'ontology_id':PINNED_DEPENDENCY_ONTOLOGY_SPEC.get('ontology_id')})
    eq_state=generic_equivalence_contextual_resolution_state(ctx.as_of_date,ctx.retrieval_scope_id)
    cache_key=sha((ctx.audit_context_id,ctx.retrieval_scope_id,ctx.as_of_date,dgraph.get('graph_hash'),registered_universes,
                   sha(raw_inventory),ownership_map.map_hash,source_universe.universe_hash,relation_universe.universe_hash,
                   ontology_prefix_map_hash,eq_state['contextual_resolution_hash'],generic_representation_distinctness_registry_hash(),
                   generic_representation_distinctness_certificate_registry_hash()))
    cached=_DECISION_GENERIC_REPRESENTATION_COMPLETENESS_STATE_CACHE.get(cache_key)
    if cached is not None:return dict(cached)
    source_pairs=set(tuple(x) for x in source_universe.assessed_pair_ids)
    typed_assessments=_decision_level_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes)
    typed_endpoint_sets=[set(rec.get('evidence_ids',())) for rec in typed_assessments]
    source_signal_records=[];typed_signal_records=[]
    desc_lookup={(eid,raw):desc for eid,raw,desc in descriptor_records}

    expected_cross_pairs=[];coverage=[];noncandidates=[];candidates=[];dispositions=[]
    for ea,eb in combinations(snapshot_ids,2):
        for ra in raw_by_endpoint.get(ea,()):
            for rb in raw_by_endpoint.get(eb,()):
                # Pair-coverage is cross-*representation* coverage. Different dimensions of the same
                # typed DEPENDENCY representation are not alternate representations of one node.
                if ra[0]==rb[0]:continue
                endpoints=tuple(sorted((ea,eb)));rawpair=_canonical_raw_node_pair(ra,rb)
                pair_payload=(endpoints,rawpair);pair_id='generic-raw-pair:'+sha(pair_payload)[:24]
                expected_cross_pairs.append((pair_id,endpoints,rawpair))
                source_signal=(ea,eb) in source_pairs or (eb,ea) in source_pairs
                typed_signal=any(ea in e and eb in e for e in typed_endpoint_sets)
                source_signal_records.append((pair_id,source_signal));typed_signal_records.append((pair_id,typed_signal))
                da=desc_lookup.get((ea,ra),tuple());db=desc_lookup.get((eb,rb),tuple())
                common=sorted({(x[0],x[1],x[2]) for x in da}&{(x[0],x[1],x[2]) for x in db})
                spec=None
                if len(common)==1:
                    st0,sd0,ident0=common[0];isem0='CANONICAL_DEPENDENCY_LOCAL_ID';key0=_equivalence_pair_key(ra[0],ra[1],rb[0],rb[1])
                    pinned0=_candidate_equivalence_specs().get(key0)
                    basis0='PINNED_AUTHORITY_PAIR_DESCRIPTOR' if pinned0 is not None and tuple(pinned0)==(st0,sd0,isem0) else 'CONTROLLER_EXACT_DESCRIPTOR_MATCH'
                    spec=(st0,sd0,isem0,ident0,basis0)
                if spec is None:
                    if not da and not db:reason=('NO_CONTROLLER_DESCRIPTOR_EITHER_SIDE',da,db)
                    elif not da:reason=('NO_CONTROLLER_DESCRIPTOR_LEFT',da,db)
                    elif not db:reason=('NO_CONTROLLER_DESCRIPTOR_RIGHT',da,db)
                    elif {x[1] for x in da}.isdisjoint({x[1] for x in db}):reason=('EXACT_DIFFERENT_DEPENDENCY_DIMENSION',da,db)
                    elif {(x[1],x[2]) for x in da}.isdisjoint({(x[1],x[2]) for x in db}):reason=('EXACT_DIFFERENT_LOCAL_IDENTIFIER',da,db)
                    else:reason=('NO_EXACT_SHARED_DESCRIPTOR',da,db)
                    proof=('PROVEN_NON_CANDIDATE',reason)
                    coverage.append((pair_id,endpoints,rawpair,'PROVEN_NON_CANDIDATE',proof))
                    noncandidates.append((pair_id,endpoints,rawpair,proof))
                    continue
                st,sd,isem,ident,basis=spec;semantic=(st,sd,ident)
                discovery=(basis,'SOURCE_CHANNEL_SIGNAL' if source_signal else 'NO_SOURCE_CHANNEL_SIGNAL','TYPED_RELATION_SIGNAL' if typed_signal else 'NO_TYPED_RELATION_SIGNAL')
                candidate_payload=(endpoints,rawpair,semantic,isem,discovery)
                cid='generic-representation-candidate:'+sha(candidate_payload)[:24]
                coverage.append((pair_id,endpoints,rawpair,'CANDIDATE_REQUIRES_DISPOSITION',(cid,semantic,isem,discovery)))
                candidates.append((cid,endpoints,rawpair,semantic,isem,discovery,pair_id))
                state,node,recs=_candidate_alias_state(ra,rb,ctx.as_of_date,ctx.retrieval_scope_id)
                if state=='RESOLVED':disp='RESOLVED_EQUIVALENT'
                elif state=='CONFLICT':disp='CONFLICT'
                elif state=='PROVEN_DISTINCT':disp='PROVEN_DISTINCT'
                elif state=='UNRESOLVED' and recs:disp='INACTIVE_AUTHORITY'
                else:disp='UNRESOLVED'
                dispositions.append((cid,disp,node,tuple(recs),endpoints,rawpair,discovery,pair_id))
    expected_cross_pairs=tuple(sorted(expected_cross_pairs,key=str));coverage=tuple(sorted(coverage,key=str))
    noncandidates=tuple(sorted(noncandidates,key=str));candidates=tuple(sorted(candidates,key=str));dispositions=tuple(sorted(dispositions,key=str))
    source_signal_records=tuple(sorted(source_signal_records));typed_signal_records=tuple(sorted(typed_signal_records))

    expected_ids=[x[0] for x in expected_cross_pairs];coverage_ids=[x[0] for x in coverage]
    coverage_complete=(len(expected_ids)==len(set(expected_ids))==len(coverage_ids)==len(set(coverage_ids)) and set(expected_ids)==set(coverage_ids))
    candidate_ids=[x[0] for x in candidates];disp_ids=[x[0] for x in dispositions]
    candidate_complete=(len(candidate_ids)==len(set(candidate_ids))==len(disp_ids)==len(set(disp_ids)) and set(candidate_ids)==set(disp_ids))
    coverage_class_valid=all(x[3] in {'CANDIDATE_REQUIRES_DISPOSITION','PROVEN_NON_CANDIDATE'} for x in coverage)
    noncandidate_ids={x[0] for x in noncandidates};ledger_noncandidate_ids={x[0] for x in coverage if x[3]=='PROVEN_NON_CANDIDATE'}
    noncandidate_complete=(noncandidate_ids==ledger_noncandidate_ids and len(noncandidate_ids)==len(noncandidates))
    candidate_ledger_ids={x[4][0] for x in coverage if x[3]=='CANDIDATE_REQUIRES_DISPOSITION'}
    candidate_ledger_complete=(candidate_ledger_ids==set(candidate_ids))
    dispositions_closed=all(x[1] in {'RESOLVED_EQUIVALENT','PROVEN_DISTINCT'} for x in dispositions)
    result='PASS' if (coverage_complete and coverage_class_valid and noncandidate_complete and candidate_complete and candidate_ledger_complete and dispositions_closed) else 'BLOCK'
    state={
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),'as_of_date':ctx.as_of_date,
        'decision_evidence_ownership_map_hash':ownership_map.map_hash,'decision_level_source_relation_universe_hash':source_universe.universe_hash,'decision_level_relation_universe_hash':relation_universe.universe_hash,
        'complete_raw_representation_inventory':raw_inventory,'complete_raw_representation_inventory_hash':sha(raw_inventory),
        'representation_classes_present':classes,'representation_classes_present_hash':sha(classes),
        'candidate_semantic_descriptor_records':descriptor_records,'candidate_semantic_descriptor_records_hash':sha(descriptor_records),
        'cross_representation_pair_coverage_records':coverage,'cross_representation_pair_coverage_records_hash':sha(coverage),
        'proven_non_candidate_records':noncandidates,'proven_non_candidate_records_hash':sha(noncandidates),
        'candidate_representation_pair_universe':candidates,'candidate_representation_pair_universe_hash':sha(candidates),
        'candidate_disposition_records':dispositions,'candidate_disposition_records_hash':sha(dispositions),
        'ontology_prefix_map_hash':ontology_prefix_map_hash,'source_discovery_signal_hash':sha(source_signal_records),'typed_discovery_signal_hash':sha(typed_signal_records),
        'active_equivalence_ids_hash':sha(eq_state['active_ids']),'inactive_equivalence_records_hash':sha(eq_state['inactive_records']),
        'equivalence_applicability_records_hash':sha(eq_state['applicability_records']),'contextual_equivalence_resolution_hash':eq_state['contextual_resolution_hash'],
        'distinctness_registry_hash':generic_representation_distinctness_registry_hash(),'distinctness_certificate_registry_hash':generic_representation_distinctness_certificate_registry_hash(),
        'completeness_result':result,
    }
    # Performance-only memoization must remain bounded. Self-tests and long-running local
    # processes can create many exact audit contexts; retaining every large pair-coverage state
    # indefinitely causes pathological memory/GC growth without adding semantic authority.
    if len(_DECISION_GENERIC_REPRESENTATION_COMPLETENESS_STATE_CACHE) >= 64:
        _DECISION_GENERIC_REPRESENTATION_COMPLETENESS_STATE_CACHE.clear()
    _DECISION_GENERIC_REPRESENTATION_COMPLETENESS_STATE_CACHE[cache_key]=state
    return dict(state)

def _decision_generic_representation_completeness_certificate_from_state(state):
    if state is None:return None
    payload={k:v for k,v in state.items() if k not in {'complete_raw_representation_inventory','representation_classes_present',
                                                        'candidate_semantic_descriptor_records','cross_representation_pair_coverage_records','proven_non_candidate_records',
                                                        'candidate_representation_pair_universe','candidate_disposition_records'}}
    return DecisionGenericRepresentationCompletenessCertificate(sha(payload),**payload)

def make_decision_generic_representation_completeness_certificate(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    state=_decision_generic_representation_completeness_state(claims,facts,ctx,reqs,dgraph,registered_universes)
    return _decision_generic_representation_completeness_certificate_from_state(state)

def issue_decision_generic_representation_completeness_certificate(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    cert=make_decision_generic_representation_completeness_certificate(claims,facts,ctx,reqs,dgraph,registered_universes)
    if cert is None:return None
    GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY[ctx.audit_context_id]=cert
    return cert

def validate_decision_generic_representation_completeness_certificate(cert,claims,facts,ctx,reqs,dgraph,registered_universes=True):
    if cert is None:return False
    fresh=make_decision_generic_representation_completeness_certificate(claims,facts,ctx,reqs,dgraph,registered_universes)
    return fresh is not None and asdict(fresh)==asdict(cert)



_MIXED_CHANNEL_PATH_RELEVANCE_CACHE={}

def _mixed_channel_selected_support_path_relevance(facts,ctx,dgraph,owner_records):
    """Shared traversal for decision relevance without shared semantics/accounting.

    v0.2.54 invariant:
        SNAPSHOT-COMPLETE CONNECTIVITY != SHARED SEMANTICS != SHARED ACCOUNTING

    Connectivity for path relevance is composed from exact justificatory bridges,
    canonical generic hyperedges, blocking source/failure-domain edges
    (SOURCE_SHARED_DEPENDENCY / SOURCE_RELATION_UNRESOLVED), and in-scope typed
    relation edges, including NON_DECISION_RELEVANT labels. A typed effect label
    does not erase structural connectivity; authorization governs the typed relation
    obligation, not whether other blocking channels are connected through its endpoints.
    Generic, source, and typed semantics remain separately accounted. Masking removes only
    the exact generic/source candidate under evaluation, while every other legal
    channel may remain traversal-only connectivity.
    """
    if dgraph is None:return {'generic':{},'source':{},'source_relation_results':{}}
    owner_hash=sha(tuple(sorted((eid,tuple(v[0]),tuple(v[1]),bool(v[2]),v[3]) for eid,v in owner_records.items())))
    fmap={f.evidence_id:f for f in facts}
    modeled_ids=tuple(sorted(eid for eid,(owners,_,_,_) in owner_records.items() if owners and eid in fmap))
    # v0.2.46 / R54: mixed-channel connectivity is snapshot-complete.  A SNAPSHOT_ONLY
    # endpoint may be traversal-relevant even though it owns no modeled claim.  Keep
    # decision accounting separate: discovery/traversal sees the complete retrieval
    # snapshot, while source assessment rows are still emitted only for legacy
    # cross-claim modeled pairs or source edges proven selected-support-path relevant.
    traversal_ids=tuple(sorted(eid for eid in owner_records if eid in fmap))
    traversal_id_set=set(traversal_ids)
    snapshot_only_ids=tuple(sorted(set(traversal_ids)-set(modeled_ids)))
    snapshot_only_id_set=set(snapshot_only_ids)
    # Cached source_relation_results are outputs of evaluate_source_relation(...).
    # Bind the cache to every mutable source-independence input that can affect any
    # traversal pair, including SNAPSHOT_ONLY endpoints that may bridge channels.
    relevant_si_auth={
        k:v for k,v in SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.items()
        if set(v.get('evidence_ids',())) and set(v.get('evidence_ids',())).issubset(traversal_id_set)
    }
    relevant_si_certs={
        registry_key:asdict(cert)
        for registry_key,cert in SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.items()
        if getattr(cert,'independence_id',None) in relevant_si_auth
    }
    source_independence_state_hash=canonical_hash({
        'authorizations':relevant_si_auth,
        'certificates':relevant_si_certs,
    })
    # v0.2.48 / R58: typed relations can be traversal-only bridges even when their
    # own endpoint ownership keeps them outside decision-level typed accounting.
    # Bind the mixed-path cache to the exact in-scope typed inventory that can
    # connect endpoints in this retrieval snapshot. Effect labels do not erase
    # structural connectivity; typed accounting/authorization remains separate.
    participating_claims=set(dgraph.get('claim_ids',()))
    selected_ids=set(eid for _,eids in dgraph.get('selected_support_map',()) for eid in eids)
    allowed_typed_relation_types=set(RELATION_DISCOVERY_POLICY.get('allowed_relation_types',()))
    # v0.2.53 / R68: selected<->modeled-nonselected typed connectivity is not
    # automatically redundant with local/justificatory connectivity.  R67 shows
    # an exact A-C NON_DECISION_RELEVANT relation with no A-C justificatory bridge,
    # where dropping the typed pair hides a composed selected-support path through
    # a separately-accounted B-C SOURCE dependency.  Track exact bridge endpoint
    # pairs so only genuinely duplicated selected<->nonselected typed pairs remain
    # suppressed.  This preserves the R29/R30 double-accounting guard.
    justificatory_pair_set=set()
    for bridge in dgraph.get('justificatory_bridges',()):
        if len(bridge)>=2:
            a,b=bridge[0],bridge[1]
            if a in traversal_id_set and b in traversal_id_set and a!=b:
                justificatory_pair_set.add((min(a,b),max(a,b)))
    typed_traversal_records=[]
    for rid,row in sorted(SUPPORT_SET_COMMON_MODE_REGISTRY.items()):
        if not isinstance(row,dict) or row.get('relation') not in allowed_typed_relation_types:continue
        if row.get('retrieval_scope_id','*') not in {ctx.retrieval_scope_id,'*'}:continue
        claim_scope=row.get('claim_id','*')
        if claim_scope!='*' and claim_scope not in participating_claims:continue
        eids=tuple(sorted(set(row.get('evidence_ids',()))))
        if len(eids)<2 or not set(eids).issubset(traversal_id_set):continue
        # v0.2.53 / R68: filter modeled-only typed connectivity per induced pair.
        # SNAPSHOT_ONLY relations remain snapshot-complete.  For modeled-only
        # relations always retain nonselected<->nonselected pairs (R63/R65), and
        # additionally retain selected<->nonselected pairs only when the exact pair
        # has no justificatory bridge already present in the decision graph (R67).
        # Thus typed connectivity fills a real structural gap without duplicating
        # selected<->excluded local semantics that R29/R30 already account exactly.
        endpoint_set=set(eids)
        touches_snapshot=bool(endpoint_set & snapshot_only_id_set)
        if touches_snapshot:
            traversal_pair_records=tuple((a,b,'STANDARD') for a,b in combinations(eids,2))
        else:
            projected=[]
            for a,b in combinations(eids,2):
                a_selected=a in selected_ids; b_selected=b in selected_ids
                if not a_selected and not b_selected:
                    projected.append((a,b,'STANDARD'))
                    continue
                if a_selected != b_selected:
                    pair=(min(a,b),max(a,b))
                    if pair not in justificatory_pair_set:
                        # This exact class is the R67 structural gap: a modeled
                        # selected<->nonselected typed pair with no substituting
                        # justificatory bridge.  Track it separately so legacy exact
                        # SOURCE pair accounting is not allowed to launder a path that
                        # becomes global only because this missing connector exists.
                        projected.append((a,b,'MODELED_SELECTED_NONSEL_NO_BRIDGE'))
            traversal_pair_records=tuple(projected)
        if not traversal_pair_records:continue
        effect=_relation_row_effect(row)
        # Effect/handling labels remain orthogonal to structural connectivity.
        # The typed relation keeps separate discovery/relevance/resolution/accounting;
        # these pairs are traversal-only edges for other channel path relevance.
        typed_traversal_records.append((rid,row.get('relation'),effect,eids,traversal_pair_records,sha(row)))
    typed_traversal_records=tuple(typed_traversal_records)
    typed_traversal_state_hash=canonical_hash(typed_traversal_records)
    cache_key=(getattr(ctx,'audit_context_id',None),dgraph.get('graph_hash'),owner_hash,
               provenance_policy_hash(),source_semantics_policy_hash(),source_independence_policy_hash(),
               source_semantics_registry_hash(),source_semantics_resolution_certificate_registry_hash(),
               failure_domain_relation_registry_hash(),source_independence_state_hash,
               relation_discovery_policy_hash(),relation_decision_relevance_policy_hash(),typed_traversal_state_hash,
               generic_representation_equivalence_registry_hash(),
               generic_representation_equivalence_certificate_registry_hash(),generic_representation_distinctness_registry_hash(),
               generic_representation_distinctness_certificate_registry_hash())
    cached=_MIXED_CHANNEL_PATH_RELEVANCE_CACHE.get(cache_key)
    if cached is not None:return cached

    generic_hyperedges={}
    for eid in traversal_ids:
        for semantic,_raw in generic_dependency_representation_records(fmap[eid],ctx.as_of_date,ctx.retrieval_scope_id):
            generic_hyperedges.setdefault(semantic,set()).add(eid)
    generic_hyperedges={node:tuple(sorted(endpoints)) for node,endpoints in generic_hyperedges.items() if len(endpoints)>=2}
    allowed=canonical_allowed_shared_generic_nodes(ctx.as_of_date,ctx.retrieval_scope_id)
    # v0.2.57 / R77: do not take the no-GENERIC fast path while a legal
    # justificatory bridge exists.  R76 shows that all-modeled evidence can form a
    # pure-SOURCE composed selected-support path using only justificatory bridges +
    # blocking SOURCE edges.  In that topology generic_hyperedges, typed traversal,
    # and SNAPSHOT_ONLY endpoints are all absent, so the earlier fast path returned
    # before SOURCE scanning.  Preserve the fast path only when there is no other
    # structural bridge capable of composing SOURCE segments.
    if len(selected_ids)<2 or (not generic_hyperedges and not typed_traversal_records
                               and not snapshot_only_ids and not justificatory_pair_set):
        result={'generic':{},'source':{},'source_relation_results':{}}
        if len(_MIXED_CHANNEL_PATH_RELEVANCE_CACHE)>=64:_MIXED_CHANNEL_PATH_RELEVANCE_CACHE.clear()
        _MIXED_CHANNEL_PATH_RELEVANCE_CACHE[cache_key]=result
        return result

    source_relation_results={}
    source_edges={}
    for aid,bid in combinations(traversal_ids,2):
        ok,state,diag,cert=evaluate_source_relation(fmap[aid],fmap[bid])
        pair=(aid,bid)
        source_relation_results[pair]=(bool(ok),state,tuple(sorted(diag)),cert)
        if state in {'SOURCE_SHARED_DEPENDENCY','SOURCE_RELATION_UNRESOLVED'}:
            source_edges[pair]=(aid,bid)

    # Edge tags are exact typed traversal identities.  This is connectivity only;
    # no tag can satisfy another channel's accounting obligation.
    adjacency={}
    def add_edge(a,b,tag):
        if a==b:return
        adjacency.setdefault(a,{}).setdefault(b,set()).add(tag)
        adjacency.setdefault(b,{}).setdefault(a,set()).add(tag)
    for i,row in enumerate(dgraph.get('justificatory_bridges',())):
        if len(row)>=2:add_edge(row[0],row[1],('BRIDGE',i))
    for node,endpoints in generic_hyperedges.items():
        tag=('GENERIC',node)
        for a,b in combinations(endpoints,2):add_edge(a,b,tag)
    # v0.2.48 / R58: an in-scope typed relation may bridge otherwise isolated
    # generic/source segments through SNAPSHOT_ONLY endpoints. This is traversal
    # connectivity only: the typed relation keeps its independent discovery,
    # relevance, resolution, and accounting semantics.
    for rid,rtype,effect,endpoints,traversal_pair_records,_row_hash in typed_traversal_records:
        for a,b,pair_class in traversal_pair_records:
            tag=('TYPED_GAP' if pair_class=='MODELED_SELECTED_NONSEL_NO_BRIDGE' else 'TYPED',rid,rtype,effect,a,b)
            add_edge(a,b,tag)
    for pair in source_edges:
        add_edge(pair[0],pair[1],('SOURCE',pair))

    has_allowed_shared_generic_connectivity=any(node in allowed for node in generic_hyperedges)

    def evaluate(endpoints,mask_tag,diagnose_connector_assistance=False):
        endpoint_set=set(endpoints)
        def traverse(mask_gap_typed=False,mask_all_typed=False,mask_allowed_shared_generic=False):
            unassigned=set(endpoints);component_records=[]
            while unassigned:
                start=min(unassigned);seen={start};stack=[start]
                while stack:
                    cur=stack.pop()
                    for nxt,tags in adjacency.get(cur,{}).items():
                        # Parallel representations stay distinct. The edge remains
                        # traversable whenever any exact tag other than the candidate
                        # under test remains. Diagnostic passes may additionally mask
                        # the R67 selected<->nonselected typed-gap class or every typed
                        # traversal connector. R70 uses all-typed masking. R72 adds a
                        # narrower diagnostic for ALLOWED_SHARED GENERIC connectors: their
                        # own channel is explicitly nonblocking, but they may still globalize
                        # a previously local SOURCE dependency. Blocking GENERIC nodes retain
                        # their own decision obligation and are not folded into this compatibility
                        # exception.
                        usable=[tag for tag in tags if tag!=mask_tag
                                and not (mask_gap_typed and isinstance(tag,tuple) and tag and tag[0]=='TYPED_GAP')
                                and not (mask_all_typed and isinstance(tag,tuple) and tag and tag[0] in {'TYPED','TYPED_GAP'})
                                and not (mask_allowed_shared_generic and isinstance(tag,tuple) and len(tag)>=2
                                         and tag[0]=='GENERIC' and tag[1] in allowed)]
                        if nxt not in seen and usable:
                            seen.add(nxt);stack.append(nxt)
                member_endpoints=endpoint_set & seen
                unassigned-=member_endpoints
                anchors=tuple(sorted(selected_ids & seen))
                component_records.append((tuple(sorted(seen)),anchors))
            component_records=tuple(sorted(component_records,key=str))
            union_anchors=tuple(sorted({x for _,anchors in component_records for x in anchors}))
            selected_bearing=sum(bool(anchors) for _,anchors in component_records)
            cut_relevant=selected_bearing>=2 and len(union_anchors)>=2
            cyclic_relevant=any(len(endpoint_set & set(members))>=2 and len(anchors)>=2
                                for members,anchors in component_records)
            return bool(cut_relevant or cyclic_relevant),union_anchors,component_records
        relevant,union_anchors,component_records=traverse(False,False,False)
        relevant_without_gap,_,_=traverse(True,False,False)
        relevant_without_any_typed,_,_=traverse(False,True,False)
        if diagnose_connector_assistance and relevant and has_allowed_shared_generic_connectivity:
            relevant_without_allowed_shared_generic,_,_=traverse(False,False,True)
        else:
            relevant_without_allowed_shared_generic=relevant
        # v0.2.56 / R74: individual necessity diagnostics are insufficient when
        # typed and ALLOWED_SHARED GENERIC connectors are parallel alternatives.
        # Each class can mask the necessity of the other.  Diagnose the composed
        # path once more with *all* nonblocking connector classes removed together.
        # This is still traversal-only evidence: it does not change either channel's
        # own accounting semantics; it only decides whether stale local SOURCE pair
        # accounting may discharge a path that exists because of connector assistance.
        if diagnose_connector_assistance and relevant:
            relevant_without_nonblocking_connectors,_,_=traverse(False,True,True)
        else:
            relevant_without_nonblocking_connectors=relevant
        return {
            'selected_support_path_relevant':relevant,
            'selected_support_path_anchor_ids':union_anchors,
            'selected_support_path_component_records':component_records,
            'selected_support_path_requires_modeled_selected_nonselected_typed_gap':bool(relevant and not relevant_without_gap),
            'selected_support_path_requires_typed_connector':bool(relevant and not relevant_without_any_typed),
            'selected_support_path_requires_allowed_shared_generic_connector':bool(relevant and not relevant_without_allowed_shared_generic),
            'selected_support_path_requires_nonblocking_connector_assistance':bool(relevant and not relevant_without_nonblocking_connectors),
        }

    generic_out={}
    for node,endpoints in sorted(generic_hyperedges.items(),key=str):
        if node in allowed:continue
        generic_out[node]=evaluate(endpoints,('GENERIC',node),False)
    source_out={}
    for pair,endpoints in sorted(source_edges.items()):
        source_out[pair]=evaluate(endpoints,('SOURCE',pair),True)
    result={'generic':generic_out,'source':source_out,'source_relation_results':source_relation_results}
    if len(_MIXED_CHANNEL_PATH_RELEVANCE_CACHE)>=64:_MIXED_CHANNEL_PATH_RELEVANCE_CACHE.clear()
    _MIXED_CHANNEL_PATH_RELEVANCE_CACHE[cache_key]=result
    return result


def _generic_dependency_selected_support_path_relevance(dgraph,node_endpoints,allowed_nodes=()):
    """Return exact generic-node path relevance between distinct selected supports.

    v0.2.43 legacy generic-only traversal retained for compatibility diagnostics. Evaluation candidates
    and traversal hyperedges are distinct: allowed_shared nodes are exempt from their own
    decision obligation but remain traversal-only connectivity for evaluating other nodes.
    Generic hyperedges are composed only with justificatory bridges, never with source or typed
    dependency truth. A generic node is decision-relevant when removing that node shows
    that it either connects two or more selected-bearing endpoint components, or is a
    redundant/cyclic dependency inside one endpoint component already containing at least
    two distinct selected supports. Side branches with no selected anchor remain local.

    The graph is materialized once with per-edge generic-node tags. Per-node evaluation
    masks only edges that are supported exclusively by the node under test, avoiding the
    quadratic graph rebuilding cost of the initial v0.2.41 implementation.
    """
    if dgraph is None:return {}
    selected_ids=set(eid for _,eids in dgraph.get('selected_support_map',()) for eid in eids)
    allowed=set(tuple(x) for x in allowed_nodes)
    # Evaluation and traversal are deliberately distinct. A resolved allowed_shared
    # node is exempt from its own decision obligation, but it remains a structural
    # traversal hyperedge when deciding whether a different blocking generic node
    # lies on a selected-support path. Only the node currently under evaluation is masked.
    traversal_hyperedges={tuple(node):tuple(sorted(set(endpoints))) for node,endpoints in node_endpoints.items()
                          if len(set(endpoints))>=2}
    candidates={node:endpoints for node,endpoints in traversal_hyperedges.items() if node not in allowed}

    # adjacency[a][b] is the set of generic semantic nodes supporting that edge;
    # None denotes an unmasked justificatory bridge.
    adjacency={}
    def add_edge(a,b,tag):
        if a==b:return
        adjacency.setdefault(a,{}).setdefault(b,set()).add(tag)
        adjacency.setdefault(b,{}).setdefault(a,set()).add(tag)
    for row in dgraph.get('justificatory_bridges',()):
        if len(row)>=2:add_edge(row[0],row[1],None)
    for node,endpoints in traversal_hyperedges.items():
        # A generic shared node is a hyperedge. Clique projection preserves exact
        # endpoint connectivity and remains deterministic/permutation invariant.
        for a,b in combinations(endpoints,2):add_edge(a,b,node)

    def traversable(tags,masked):
        if None in tags:return True
        return any(tag!=masked for tag in tags)

    out={}
    for node,endpoints in sorted(candidates.items(),key=str):
        endpoint_set=set(endpoints);unassigned=set(endpoints);component_records=[]
        while unassigned:
            start=min(unassigned);seen={start};stack=[start]
            while stack:
                cur=stack.pop()
                for nxt,tags in adjacency.get(cur,{}).items():
                    if nxt not in seen and traversable(tags,node):seen.add(nxt);stack.append(nxt)
            member_endpoints=endpoint_set & seen
            unassigned-=member_endpoints
            anchors=tuple(sorted(selected_ids & seen))
            component_records.append((tuple(sorted(seen)),anchors))
        component_records=tuple(sorted(component_records,key=str))
        union_anchors=tuple(sorted({x for _,anchors in component_records for x in anchors}))
        # Decision relevance has two distinct forms after masking only the node
        # currently under evaluation.
        #
        # CUT relevance: removing the node separates at least two endpoint
        # components that each carry selected support, with at least two distinct
        # selected anchors overall.
        selected_bearing=sum(bool(anchors) for _,anchors in component_records)
        cut_relevant=selected_bearing>=2 and len(union_anchors)>=2
        #
        # CYCLIC relevance: at least two endpoints of the node under evaluation
        # remain together through alternate connectivity inside one component
        # that already carries at least two distinct selected anchors.  Requiring
        # two endpoints in that anchor-rich component prevents an unrelated side
        # branch (only one endpoint) from becoming decision-level merely because
        # it touches a component containing two selected supports.  Conversely,
        # an extra unanchored endpoint cannot dilute a real cyclic obligation.
        cyclic_relevant=any(
            len(endpoint_set & set(members))>=2 and len(anchors)>=2
            for members,anchors in component_records
        )
        relevant=cut_relevant or cyclic_relevant
        out[node]={
            'selected_support_path_relevant':bool(relevant),
            'selected_support_path_anchor_ids':union_anchors,
            'selected_support_path_component_records':component_records,
        }
    return out


def _decision_level_generic_dependency_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Evaluate generic dependency identity over complete modeled ownership in one exact audit context."""
    if dgraph is None:return tuple()
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return tuple()
    rr=RETRIEVAL_SCOPE_REGISTRY.get(ctx.retrieval_scope_id)
    if rr is None:return tuple()
    eq_state=generic_equivalence_contextual_resolution_state(ctx.as_of_date,ctx.retrieval_scope_id)
    snapshot_ids=set(rr.get('expected_evidence_ids',()))
    fmap={f.evidence_id:f for f in facts}
    owner_records={eid:(tuple(owners),tuple(classes),bool(in_graph),status)
                   for eid,owners,classes,in_graph,status in ownership_map.ownership_records}
    node_endpoints={};raw_by_node_endpoint={};raw_by_endpoint={}
    for eid in sorted(snapshot_ids):
        f=fmap.get(eid)
        if f is None:return tuple()
        raw_by_endpoint[eid]=tuple(sorted(raw_generic_dependency_nodes(f)))
        for semantic,raw in generic_dependency_representation_records(f,ctx.as_of_date,ctx.retrieval_scope_id):
            node_endpoints.setdefault(semantic,set()).add(eid)
            raw_by_node_endpoint.setdefault((semantic,eid),set()).add(raw)
    allowed=canonical_allowed_shared_generic_nodes(ctx.as_of_date,ctx.retrieval_scope_id)
    mixed_path_state=_mixed_channel_selected_support_path_relevance(facts,ctx,dgraph,owner_records)
    path_relevance=mixed_path_state['generic']
    rows=[]
    def add_row(node,endpoints,raw_representation_records,resolution_state='RESOLVED',resolution_records=tuple(),classification_override=None):
        endpoint_ownership=tuple((eid,owner_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[0]) for eid in endpoints)
        endpoint_classifications=tuple((eid,owner_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[1]) for eid in endpoints)
        endpoint_graph_membership=tuple((eid,owner_records.get(eid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[2]) for eid in endpoints)
        participating_claims=tuple(sorted({cid for _,owners in endpoint_ownership for cid in owners}))
        modeled_endpoints=tuple(eid for eid,owners in endpoint_ownership if owners)
        snapshot_only_endpoints=tuple(eid for eid,owners in endpoint_ownership if not owners)
        path_info=path_relevance.get(node,{}) if resolution_state=='RESOLVED' else {}
        path_relevant=bool(path_info.get('selected_support_path_relevant',False))
        path_anchors=tuple(path_info.get('selected_support_path_anchor_ids',()))
        path_components=tuple(path_info.get('selected_support_path_component_records',()))
        is_allowed=(node in allowed and resolution_state=='RESOLVED')
        if resolution_state!='RESOLVED':
            required=bool(modeled_endpoints);classification=classification_override or 'DECISION_GENERIC_EQUIVALENCE_'+resolution_state
        elif is_allowed:
            required=False;classification='ALLOWED_SHARED_GENERIC_DEPENDENCY'
        elif path_relevant:
            required=True;classification='DECISION_GENERIC_SELECTED_SUPPORT_PATH'
        elif len(participating_claims)>=2:
            required=True;classification='DECISION_GENERIC_CROSS_CLAIM_MODELED'
        elif modeled_endpoints and snapshot_only_endpoints:
            required=True;classification='DECISION_GENERIC_MODELED_SNAPSHOT_MIXED_UNCOVERED'
        elif len(participating_claims)==1:
            required=False;classification='CLAIM_LOCAL_GENERIC_DEPENDENCY'
        else:
            required=False;classification='SNAPSHOT_ONLY_GENERIC_DEPENDENCY'
        rows.append({
            'generic_dependency_node':node,'generic_dependency_node_hash':sha(node),
            'evidence_ids':endpoints,'evidence_ids_hash':sha(endpoints),
            'endpoint_claim_ownership':endpoint_ownership,'endpoint_claim_ownership_hash':sha(endpoint_ownership),
            'endpoint_classifications':endpoint_classifications,'endpoint_classifications_hash':sha(endpoint_classifications),
            'endpoint_graph_membership':endpoint_graph_membership,
            'participating_claims':participating_claims,'participating_claims_hash':sha(participating_claims),
            'modeled_endpoint_ids':modeled_endpoints,'snapshot_only_endpoint_ids':snapshot_only_endpoints,
            'raw_representation_records':raw_representation_records,'raw_representation_records_hash':sha(raw_representation_records),
            'representation_equivalence_policy_hash':generic_relation_source_identity_policy_hash(),
            'representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),
            'representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),
            'equivalence_resolution_state':resolution_state,'equivalence_resolution_records':tuple(resolution_records),
            'equivalence_resolution_records_hash':sha(tuple(resolution_records)),
            'contextual_equivalence_resolution_hash':eq_state['contextual_resolution_hash'],
            'allowed_shared':is_allowed,
            'selected_support_path_relevant':path_relevant,
            'selected_support_path_anchor_ids':path_anchors,
            'selected_support_path_component_records':path_components,
            'decision_level_required':required,
            'relevance_classification':classification,'decision_evidence_ownership_map_hash':ownership_map.map_hash,
        })
    mapping,_,_=_resolved_equivalence_class_map(ctx.as_of_date,ctx.retrieval_scope_id)
    for node,endpoints_set in sorted(node_endpoints.items()):
        endpoints=tuple(sorted(endpoints_set))
        if len(endpoints)<2:continue
        raw_records=tuple((eid,tuple(sorted(raw_by_node_endpoint.get((node,eid),set())))) for eid in endpoints)
        support=set()
        for eid,rrs in raw_records:
            for raw in rrs:
                for m in mapping.get((raw[0],raw[1]),tuple()):
                    sid=_semantic_identifier(raw,m[0],m[1],m[2])
                    if sid is not None and (m[0],m[1],sid)==node:support.update(m[3])
        add_row(node,endpoints,raw_records,'RESOLVED',tuple(sorted(support)))
    # Inactive records never canonicalize. If their representation pair is relevant, the alias remains explicit UNRESOLVED.
    unresolved={}
    for ea,eb in combinations(sorted(snapshot_ids),2):
        for ra in raw_by_endpoint.get(ea,()):
            for rb in raw_by_endpoint.get(eb,()):
                state,node,recs=_candidate_alias_state(ra,rb,ctx.as_of_date,ctx.retrieval_scope_id)
                if state not in {'UNRESOLVED','CONFLICT'} or node is None:continue
                key=(state,node)
                rec=unresolved.setdefault(key,{'endpoints':set(),'raw':{},'resolution_records':set()})
                rec['endpoints'].update((ea,eb));rec['raw'].setdefault(ea,set()).add(ra);rec['raw'].setdefault(eb,set()).add(rb)
                rec['resolution_records'].update(recs)
    for (state,node),rec in sorted(unresolved.items(),key=str):
        endpoints=tuple(sorted(rec['endpoints']))
        raw_records=tuple((eid,tuple(sorted(rec['raw'].get(eid,set())))) for eid in endpoints)
        special=('EQUIVALENCE_'+state,node[1],node[2])
        add_row(special,endpoints,raw_records,state,tuple(sorted(rec['resolution_records'])), 'DECISION_GENERIC_EQUIVALENCE_'+state)
    return tuple(sorted(rows,key=lambda x:(x['generic_dependency_node'],x['evidence_ids'],x['equivalence_resolution_state'])))

def make_decision_level_generic_dependency_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    if dgraph is None:return None
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return None
    completeness=_decision_generic_representation_completeness_state(claims,facts,ctx,reqs,dgraph,registered_universes)
    if completeness is None:return None
    fresh_comp=_decision_generic_representation_completeness_certificate_from_state(completeness)
    if fresh_comp is None:return None
    if registered_universes:
        cert=GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY.get(ctx.audit_context_id)
        if cert is None or asdict(cert)!=asdict(fresh_comp):return None
    else:
        cert=fresh_comp
    rows=_decision_level_generic_dependency_assessments(claims,facts,ctx,reqs,dgraph,registered_universes)
    nodes=tuple(x['generic_dependency_node'] for x in rows)
    if len(nodes)!=len(set(nodes)):return None
    obligations=tuple(x['generic_dependency_node'] for x in rows if x['decision_level_required'])
    allowed=tuple(x['generic_dependency_node'] for x in rows if x['allowed_shared'])
    nondecision=tuple(x['generic_dependency_node'] for x in rows if not x['decision_level_required'])
    records=tuple((x['generic_dependency_node'],x['evidence_ids'],x['endpoint_claim_ownership'],x['endpoint_classifications'],
                   x['endpoint_graph_membership'],x['participating_claims'],x['modeled_endpoint_ids'],
                   x['snapshot_only_endpoint_ids'],x['raw_representation_records'],x['equivalence_resolution_state'],
                   x['equivalence_resolution_records'],x['contextual_equivalence_resolution_hash'],x['allowed_shared'],
                   x['selected_support_path_relevant'],x['selected_support_path_anchor_ids'],x['selected_support_path_component_records'],
                   x['decision_level_required'],x['relevance_classification']) for x in rows)
    resolution_records=tuple((x['generic_dependency_node'],x['equivalence_resolution_state'],x['equivalence_resolution_records'],
                              x['contextual_equivalence_resolution_hash']) for x in rows)
    eq_state=generic_equivalence_contextual_resolution_state(ctx.as_of_date,ctx.retrieval_scope_id)
    payload={
        'universe_id':'decision-generic-dependency-universe:'+sha((ctx.audit_context_id,dgraph['graph_hash'],nodes,records,eq_state['contextual_resolution_hash'],completeness['candidate_disposition_records_hash']))[:24],
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),
        'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
        'decision_dependency_graph_hash':dgraph['graph_hash'],
        'decision_evidence_ownership_map_hash':ownership_map.map_hash,
        'assessed_dependency_nodes':nodes,'assessed_dependency_nodes_hash':sha(nodes),
        'generic_dependency_records_hash':sha(records),
        # v0.2.40: this hash covers the complete decision snapshot raw inventory, not only assessment rows.
        'raw_representation_records_hash':completeness['complete_raw_representation_inventory_hash'],
        'decision_obligation_nodes':obligations,'decision_obligation_nodes_hash':sha(obligations),
        'allowed_shared_nodes_hash':sha(allowed),'nondecision_nodes_hash':sha(nondecision),
        'provenance_policy_hash':provenance_policy_hash(),'dependency_ontology_hash':dependency_ontology_hash(),
        'dependency_justification_registry_hash':dependency_justification_registry_hash(),
        'representation_equivalence_policy_hash':generic_relation_source_identity_policy_hash(),
        'representation_equivalence_registry_hash':generic_representation_equivalence_registry_hash(),
        'representation_equivalence_certificate_registry_hash':generic_representation_equivalence_certificate_registry_hash(),
        'equivalence_resolution_records_hash':sha(resolution_records),
        'active_equivalence_ids':eq_state['active_ids'],'active_equivalence_ids_hash':sha(eq_state['active_ids']),
        'inactive_equivalence_records':eq_state['inactive_records'],'inactive_equivalence_records_hash':sha(eq_state['inactive_records']),
        'equivalence_applicability_records':eq_state['applicability_records'],'equivalence_applicability_records_hash':sha(eq_state['applicability_records']),
        'contextual_equivalence_resolution_hash':eq_state['contextual_resolution_hash'],
        'complete_raw_representation_inventory':completeness['complete_raw_representation_inventory'],
        'complete_raw_representation_inventory_hash':completeness['complete_raw_representation_inventory_hash'],
        'representation_classes_present':completeness['representation_classes_present'],
        'representation_classes_present_hash':completeness['representation_classes_present_hash'],
        'candidate_semantic_descriptor_records':completeness['candidate_semantic_descriptor_records'],
        'candidate_semantic_descriptor_records_hash':completeness['candidate_semantic_descriptor_records_hash'],
        'cross_representation_pair_coverage_records':completeness['cross_representation_pair_coverage_records'],
        'cross_representation_pair_coverage_records_hash':completeness['cross_representation_pair_coverage_records_hash'],
        'proven_non_candidate_records':completeness['proven_non_candidate_records'],
        'proven_non_candidate_records_hash':completeness['proven_non_candidate_records_hash'],
        'candidate_representation_pair_universe':completeness['candidate_representation_pair_universe'],
        'candidate_representation_pair_universe_hash':completeness['candidate_representation_pair_universe_hash'],
        'candidate_disposition_records':completeness['candidate_disposition_records'],
        'candidate_disposition_records_hash':completeness['candidate_disposition_records_hash'],
        'ontology_prefix_map_hash':completeness['ontology_prefix_map_hash'],
        'source_discovery_signal_hash':completeness['source_discovery_signal_hash'],
        'typed_discovery_signal_hash':completeness['typed_discovery_signal_hash'],
        'representation_distinctness_registry_hash':completeness['distinctness_registry_hash'],
        'representation_distinctness_certificate_registry_hash':completeness['distinctness_certificate_registry_hash'],
        'representation_completeness_certificate_id':cert.certificate_id,
        'representation_completeness_certificate_hash':sha(asdict(cert)),
    }
    payload['universe_hash']=sha(payload)
    return DecisionLevelGenericDependencyUniverse(**payload)


def _decision_generic_dependency_candidate_map(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    return {x['generic_dependency_node']:x for x in _decision_level_generic_dependency_assessments(
        claims,facts,ctx,reqs,dgraph,registered_universes) if x['decision_level_required']}


def _decision_level_source_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    """Evaluate source semantics over complete modeled ownership with shared path connectivity.

    v0.2.46 keeps source semantics orthogonal, but decision relevance uses snapshot-complete
    mixed traversal composed from justificatory bridges + generic hyperedges + blocking source
    edges. SNAPSHOT_ONLY endpoints may provide connectivity, but source rows become decision-level
    only when the shared traversal proves relevance to at least two distinct selected supports.
    """
    if dgraph is None:return tuple()
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return tuple()
    fmap={f.evidence_id:f for f in facts}
    owner_records={eid:(tuple(owners),tuple(classes),bool(in_graph),status)
                   for eid,owners,classes,in_graph,status in ownership_map.ownership_records}
    modeled_ids=tuple(sorted(eid for eid,(owners,_,_,_) in owner_records.items() if owners))
    mixed_path_state=_mixed_channel_selected_support_path_relevance(facts,ctx,dgraph,owner_records)
    source_path=mixed_path_state['source']; relation_results=mixed_path_state['source_relation_results']
    # v0.2.51 / R64 compatibility guard: legacy exact pair accounting remains
    # sufficient for a *single* path-relevant SOURCE_SHARED_DEPENDENCY.  The new
    # modeled excluded<->excluded typed bridge must not make that already-accounted
    # single dependency fail again (R29/R30).  But two or more distinct blocking
    # SOURCE segments sharing the same selected anchor set are a composed-path
    # obligation: independent local pair accounting cannot launder the combination
    # exposed by R63.
    exact_accounted_pairs=set()
    required_accounting=SUPPORT_UNIVERSE_POLICY.get('decision_dependency_accounting_resolution_type')
    for c in claims:
        requirement=reqs.get(c.id)
        if requirement is None:continue
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:continue
        descriptor=_selection_descriptor(c,universe,requirement)
        if descriptor is None:continue
        for x,y,resolution in descriptor.get('relation_resolutions',()):
            if resolution==required_accounting:
                exact_accounted_pairs.add((min(x,y),max(x,y)))
    relevant_blocking_by_anchors={}
    for source_pair,path_info in source_path.items():
        relation=relation_results.get(source_pair)
        if relation is None or relation[1]!='SOURCE_SHARED_DEPENDENCY':continue
        if not path_info.get('selected_support_path_relevant',False):continue
        anchors=tuple(path_info.get('selected_support_path_anchor_ids',()))
        relevant_blocking_by_anchors.setdefault(anchors,set()).add(source_pair)
    # v0.2.46 / R54: preserve every legacy modeled cross-claim pair and add only
    # blocking source pairs that the snapshot-complete mixed traversal proves are
    # relevant to a path carrying at least two selected supports.  This avoids
    # globally promoting isolated SNAPSHOT_ONLY source relations into decision scope.
    candidate_pairs=set(combinations(modeled_ids,2)) | set(source_path)
    rows=[]
    for aid,bid in sorted(candidate_pairs):
        aowners=owner_records.get(aid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[0]
        bowners=owner_records.get(bid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))[0]
        cross_claim=any(ca!=cb for ca in aowners for cb in bowners)
        pair=(aid,bid); path_info=source_path.get(pair,{})
        path_relevant=bool(path_info.get('selected_support_path_relevant',False))
        # Preserve the previous complete cross-claim domain, and add only proven
        # same-claim mixed-path blockers. Isolated local source edges remain local.
        if not cross_claim and not path_relevant:continue
        a=fmap.get(aid);b=fmap.get(bid)
        if a is None or b is None:return tuple()
        res=relation_results.get(pair)
        if res is None:
            ok,state,diag,cert=evaluate_source_relation(a,b);diag=tuple(sorted(diag))
        else:
            ok,state,diag,cert=res
        arec=owner_records.get(aid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))
        brec=owner_records.get(bid,(tuple(),tuple(),False,'SNAPSHOT_ONLY'))
        classifications=(arec[1],brec[1])
        graph_count=int(arec[2])+int(brec[2])
        required=state in {'SOURCE_SHARED_DEPENDENCY','SOURCE_RELATION_UNRESOLVED'} and (cross_claim or path_relevant)
        anchors=tuple(path_info.get('selected_support_path_anchor_ids',()))
        locally_accounted=(pair in exact_accounted_pairs)
        composed_blocker_count=len(relevant_blocking_by_anchors.get(anchors,set()))
        requires_typed_gap=bool(path_info.get('selected_support_path_requires_modeled_selected_nonselected_typed_gap',False))
        requires_typed_connector=bool(path_info.get('selected_support_path_requires_typed_connector',False))
        requires_allowed_shared_generic=bool(path_info.get('selected_support_path_requires_allowed_shared_generic_connector',False))
        requires_nonblocking_connector_assistance=bool(path_info.get('selected_support_path_requires_nonblocking_connector_assistance',False))
        # v0.2.56 / R74: local SOURCE pair accounting remains sufficient only when
        # the path survives removal of all nonblocking connector classes together.
        # R73 showed that checking typed and ALLOWED_SHARED GENERIC necessity one at
        # a time is not enough: parallel alternatives can mask each other.
        connector_assisted=requires_nonblocking_connector_assistance
        if (required and not cross_claim and path_relevant and state=='SOURCE_SHARED_DEPENDENCY'
                and locally_accounted and composed_blocker_count==1 and not connector_assisted):
            required=False
        if (path_relevant and state=='SOURCE_SHARED_DEPENDENCY' and locally_accounted
                and composed_blocker_count==1 and not connector_assisted):
            relevance='DECISION_SOURCE_SELECTED_SUPPORT_PATH_EXACTLY_ACCOUNTED'
        elif path_relevant and state=='SOURCE_SHARED_DEPENDENCY':relevance='DECISION_SOURCE_SELECTED_SUPPORT_PATH'
        elif path_relevant and state=='SOURCE_RELATION_UNRESOLVED':relevance='DECISION_SOURCE_UNRESOLVED_SELECTED_SUPPORT_PATH'
        elif state=='SOURCE_SHARED_DEPENDENCY':relevance='DECISION_SOURCE_SHARED_DEPENDENCY'
        elif state=='SOURCE_RELATION_UNRESOLVED':relevance='DECISION_SOURCE_UNRESOLVED'
        elif state in {'SOURCE_INDEPENDENCE_DISTINCT','SOURCE_INDEPENDENCE_JUSTIFIED'}:relevance='DECISION_SOURCE_NONBLOCKING_INDEPENDENT'
        else:relevance='DECISION_SOURCE_UNKNOWN'
        fd_rows=[]
        for f in (a,b):
            sf=f.source_failure_domain
            fd_rows.append((f.evidence_id,sf.certificate_id,sf.source_id,sf.failure_domain_id,
                            sf.canonical_failure_domain_id,sf.ancestor_failure_domain_ids_hash,
                            sf.source_common_mode_ids_hash,sf.source_semantics_resolution_certificate_id))
        rows.append({
            'evidence_ids':pair,'evidence_ids_hash':sha(pair),
            'endpoint_claim_ownership':((aid,aowners),(bid,bowners)),
            'endpoint_claim_ownership_hash':sha(((aid,aowners),(bid,bowners))),
            'endpoint_classifications':classifications,'decision_node_endpoint_count':graph_count,
            'source_state':state,'source_ok':bool(ok),'diagnostics':tuple(sorted(diag)),
            'source_independence_certificate_id':None if cert is None else cert.certificate_id,
            'source_failure_domain_bindings':tuple(fd_rows),'source_failure_domain_bindings_hash':sha(tuple(fd_rows)),
            'selected_support_path_relevant':path_relevant,
            'selected_support_path_anchor_ids':tuple(path_info.get('selected_support_path_anchor_ids',())),
            'selected_support_path_component_records':tuple(path_info.get('selected_support_path_component_records',())),
            'selected_support_path_requires_modeled_selected_nonselected_typed_gap':requires_typed_gap,
            'selected_support_path_requires_typed_connector':requires_typed_connector,
            'selected_support_path_requires_allowed_shared_generic_connector':requires_allowed_shared_generic,
            'selected_support_path_requires_nonblocking_connector_assistance':requires_nonblocking_connector_assistance,
            'decision_level_required':required,
            'relevance_classification':relevance,
            'decision_evidence_ownership_map_hash':ownership_map.map_hash,
        })
    return tuple(rows)


def make_decision_level_source_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    if dgraph is None:return None
    ownership_map=_decision_evidence_ownership_map(claims,facts,ctx,reqs,dgraph,registered_universes)
    if ownership_map is None:return None
    rows=_decision_level_source_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes)
    pair_ids=tuple(x['evidence_ids'] for x in rows)
    if len(pair_ids)!=len(set(pair_ids)):return None
    obligations=tuple(x['evidence_ids'] for x in rows if x['decision_level_required'])
    unresolved=tuple(x['evidence_ids'] for x in rows if x['source_state']=='SOURCE_RELATION_UNRESOLVED')
    nonblocking=tuple(x['evidence_ids'] for x in rows if x['source_state'] in {'SOURCE_INDEPENDENCE_DISTINCT','SOURCE_INDEPENDENCE_JUSTIFIED'})
    records=tuple((x['evidence_ids'],x['endpoint_claim_ownership'],x['endpoint_classifications'],
                   x['decision_node_endpoint_count'],x['source_state'],x['diagnostics'],
                   x['source_independence_certificate_id'],x['source_failure_domain_bindings'],
                   x.get('selected_support_path_relevant',False),x.get('selected_support_path_anchor_ids',()),
                   x.get('selected_support_path_component_records',()),
                   x.get('selected_support_path_requires_modeled_selected_nonselected_typed_gap',False),
                   x.get('selected_support_path_requires_typed_connector',False),
                   x.get('selected_support_path_requires_allowed_shared_generic_connector',False),
                   x.get('selected_support_path_requires_nonblocking_connector_assistance',False),
                   x['decision_level_required'],x['relevance_classification']) for x in rows)
    payload={
        'universe_id':'decision-source-relation-universe:'+sha((ctx.audit_context_id,dgraph['graph_hash'],pair_ids,records))[:24],
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':_retrieval_snapshot_id(ctx.retrieval_scope_id),
        'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
        'decision_dependency_graph_hash':dgraph['graph_hash'],
        'decision_evidence_ownership_map_hash':ownership_map.map_hash,
        'assessed_pair_ids':pair_ids,'assessed_pair_ids_hash':sha(pair_ids),'source_relation_records_hash':sha(records),
        'decision_obligation_pair_ids':obligations,'decision_obligation_pair_ids_hash':sha(obligations),
        'unresolved_pair_ids_hash':sha(unresolved),'nonblocking_pair_ids_hash':sha(nonblocking),
        'source_semantics_registry_hash':source_semantics_registry_hash(),
        'source_semantics_resolution_certificate_registry_hash':source_semantics_resolution_certificate_registry_hash(),
        'failure_domain_relation_registry_hash':failure_domain_relation_registry_hash(),
        'source_independence_policy_hash':source_independence_policy_hash(),
        'source_semantics_policy_hash':source_semantics_policy_hash(),
    }
    payload['universe_hash']=sha(payload)
    return DecisionLevelSourceRelationUniverse(**payload)


def _decision_source_relation_candidate_map(claims,facts,ctx,reqs,dgraph,registered_universes=True):
    return {x['evidence_ids']:x for x in _decision_level_source_relation_assessments(
        claims,facts,ctx,reqs,dgraph,registered_universes) if x['decision_level_required']}


def _cross_channel_coverage_hash(source_rows,typed_rows):
    """Bind source/typed overlap without allowing either representation to authorize the other.

    Pairwise source semantics can overlap either an exact typed pair or an n-way typed relation.
    The overlap binding therefore uses endpoint-set containment rather than pair-only equality.
    """
    typed_inventory=[]
    for x in typed_rows:
        eids=tuple(x.get('evidence_ids',()))
        typed_inventory.append((x.get('relation_id'),eids,x.get('relation_type'),x.get('relation_effect'),x.get('decision_level_required')))
    rows=[]
    for x in source_rows:
        pair=tuple(x['evidence_ids']);pset=set(pair)
        overlaps=tuple(sorted((rid,eids,rtype,effect,required) for rid,eids,rtype,effect,required in typed_inventory
                              if pset.issubset(set(eids))))
        rows.append((pair,x['source_state'],x['decision_level_required'],overlaps))
    return sha((tuple(sorted(rows)),tuple(sorted(typed_inventory))))


def _three_channel_composition_hash(generic_rows,source_rows,typed_rows):
    generic_inventory=tuple(sorted((x['generic_dependency_node'],x['evidence_ids'],x.get('raw_representation_records',()),
                                    x.get('representation_equivalence_policy_hash'),x['decision_level_required'],x['relevance_classification'])
                                   for x in generic_rows))
    source_inventory=tuple(sorted((x['evidence_ids'],x['source_state'],x['decision_level_required'],x['relevance_classification'])
                                  for x in source_rows))
    typed_inventory=tuple(sorted((x.get('relation_id'),tuple(x.get('evidence_ids',())),x.get('relation_type'),
                                  x.get('relation_effect'),x.get('decision_level_required')) for x in typed_rows))
    overlap=[]
    for gnode,geids,graw,gpolicy,grequired,gclass in generic_inventory:
        gset=set(geids)
        so=tuple(sorted((pair,state,required,cls) for pair,state,required,cls in source_inventory if set(pair).issubset(gset)))
        to=tuple(sorted((rid,eids,rtype,effect,required) for rid,eids,rtype,effect,required in typed_inventory if set(eids)&gset))
        overlap.append((gnode,geids,graw,gpolicy,grequired,gclass,so,to))
    return sha((generic_inventory,source_inventory,typed_inventory,tuple(overlap)))


def register_decision_relation_resolution(resolution_id,retrieval_scope_id,claim_ids,selected_support_map,
                                          relation_id,resolution_type,reason,
                                          authorizer_id='LOCAL_RELATION_RESOLUTION_AUTHORITY'):
    """Register a PENDING exact decision-level typed-relation handling declaration."""
    if not support_selection_registry_key_identity_coherent():
        raise ValueError('support selection registry key identity mismatch')
    if resolution_id in SUPPORT_SELECTION_REGISTRY:raise ValueError('duplicate decision relation resolution id')
    if not all(nonblank(x) for x in (resolution_id,retrieval_scope_id,relation_id,resolution_type,reason,authorizer_id)):
        raise ValueError('invalid decision relation resolution')
    rr=RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id); rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(relation_id)
    if rr is None or not isinstance(rel,dict):raise ValueError('unknown decision relation scope')
    effect=_relation_row_effect(rel); allowed=set(RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,()))
    if resolution_type not in allowed:raise ValueError('resolution incompatible with relation effect')
    if authorizer_id not in set(RELATION_RESOLUTION_POLICY['allowed_resolution_authorizers']):
        raise ValueError('unauthorized decision relation resolution')
    cids=tuple(sorted(set(claim_ids or ())))
    if not cids or len(cids)!=len(tuple(claim_ids or ())):raise ValueError('invalid decision claim ids')
    smap=_canonical_selected_support_map(selected_support_map)
    if smap is None or tuple(cid for cid,_ in smap)!=cids:raise ValueError('selected support map mismatch')
    eids=tuple(sorted(set(rel.get('evidence_ids',()))))
    row={
        'record_type':DECISION_RELATION_RESOLUTION_RECORD_TYPE,'resolution_id':resolution_id,'binding_state':'PENDING',
        'retrieval_scope_id':retrieval_scope_id,'retrieval_snapshot_id':rr.get('snapshot_id'),
        'claim_ids':cids,'claim_ids_hash':sha(cids),'selected_support_map':smap,'selected_support_map_hash':sha(smap),
        'relation_id':relation_id,'relation_type':rel.get('relation'),'relation_effect':effect,
        'evidence_ids':eids,'evidence_ids_hash':sha(eids),'relation_claim_scope':rel.get('claim_id','*'),
        'resolution_type':resolution_type,'reason':reason,'authorizer_id':authorizer_id,
        'relation_registry_hash':support_set_common_mode_registry_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'support_universe_policy_hash':support_universe_policy_hash(),
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':decision_persistence_history_commitment(),
        'audit_context_id':None,'matching_support_universe_map_hash':None,'decision_dependency_graph_hash':None,
        'decision_evidence_ownership_map_hash':None,
        'decision_relation_universe_hash':None,'decision_relation_ids_hash':None,'relation_entry_hash':sha(rel),
        'resolution_scope_hash':None,
    }
    SUPPORT_SELECTION_REGISTRY[resolution_id]=row
    _authorize_fresh_decision_row(resolution_id)
    return copy.deepcopy(row)


def bind_decision_relation_resolutions_for_prepare(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,
                                                   retrieval_scope,req=None,resolution_ids=None):
    """Bind PENDING decision-level relation handling to the exact pre-prepare decision relation universe."""
    if (not relation_resolution_registry_key_identity_coherent()
        or not support_selection_registry_key_identity_coherent()):return 0
    claims=parse_claims(text)
    try:reqs=normalize_requirements(claims,req)
    except Exception:return 0
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,sha(reqs))
    if aid is None:return 0
    facts=[]
    for i,r in enumerate(evidence,1):
        f,errs=normalize_fact(r,i)
        if errs:return 0
        facts.append(f)
    if attach_claim_identities(claims,claim_identity_map):return 0
    class _Ctx:pass
    ctx=_Ctx();ctx.audit_context_id=aid;ctx.as_of_date=asof;ctx.retrieval_scope_id=retrieval_scope
    dgraph=_decision_support_dependency_graph(claims,tuple(facts),ctx,reqs,registered_universes=False)
    if dgraph is None:return 0
    universe=make_decision_level_relation_universe(claims,tuple(facts),ctx,reqs,dgraph,registered_universes=False)
    if universe is None or universe.out_of_snapshot_relation_ids:return 0
    cmap=_decision_relation_candidate_map(claims,tuple(facts),ctx,reqs,dgraph,registered_universes=False)
    requested=None if resolution_ids is None else set(resolution_ids)
    if requested is not None and (not requested or len(requested)!=len(tuple(resolution_ids))):return 0
    count=0
    for key,row in list(SUPPORT_SELECTION_REGISTRY.items()):
        if not isinstance(row,dict):return 0
        if row.get('record_type')!=DECISION_RELATION_RESOLUTION_RECORD_TYPE:continue
        if row.get('resolution_id')!=key:return 0
        if requested is not None and key not in requested:continue
        if row.get('binding_state')!='PENDING' or row.get('retrieval_scope_id')!=retrieval_scope:continue
        if not _pending_decision_row_history_current(key,row):continue
        info=cmap.get(row.get('relation_id'))
        if info is None or info.get('claim_local_scope_sufficient') or not info.get('endpoint_scope_valid'):continue
        if (row.get('claim_ids_hash')!=dgraph['claim_ids_hash'] or row.get('selected_support_map_hash')!=dgraph['selected_support_map_hash']
            or row.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id or row.get('relation_type')!=info['relation_type']
            or row.get('relation_effect')!=info['relation_effect'] or row.get('evidence_ids_hash')!=info['evidence_ids_hash']):continue
        rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(info['relation_id'])
        if not isinstance(rel,dict) or row.get('relation_entry_hash')!=sha(rel):continue
        if (row.get('relation_registry_hash')!=support_set_common_mode_registry_hash()
            or row.get('relation_discovery_policy_hash')!=relation_discovery_policy_hash()
            or row.get('relation_resolution_policy_hash')!=relation_resolution_policy_hash()
            or row.get('relation_decision_relevance_policy_hash')!=relation_decision_relevance_policy_hash()
            or row.get('support_universe_policy_hash')!=support_universe_policy_hash()):continue
        payload={
            'resolution_id':row['resolution_id'],'audit_context_id':aid,'retrieval_scope_id':retrieval_scope,
            'retrieval_snapshot_id':universe.retrieval_snapshot_id,'claim_ids_hash':dgraph['claim_ids_hash'],
            'selected_support_map_hash':dgraph['selected_support_map_hash'],
            'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':dgraph['graph_hash'],
            'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_relation_universe_hash':universe.universe_hash,
            'decision_relation_ids_hash':universe.relation_ids_hash,'relation_id':info['relation_id'],
            'relation_type':info['relation_type'],'relation_effect':info['relation_effect'],
            'evidence_ids_hash':info['evidence_ids_hash'],'relation_claim_scope':info['claim_scope'],
            'relation_entry_hash':sha(rel),'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],
            'reason_hash':sha(row['reason']),'relation_registry_hash':support_set_common_mode_registry_hash(),
            'relation_discovery_policy_hash':relation_discovery_policy_hash(),
            'relation_resolution_policy_hash':relation_resolution_policy_hash(),
            'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
            'support_universe_policy_hash':support_universe_policy_hash(),
        }
        bound=dict(row);bound.update({
            'binding_state':'BOUND','audit_context_id':aid,
            'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':dgraph['graph_hash'],
            'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_relation_universe_hash':universe.universe_hash,
            'decision_relation_ids_hash':universe.relation_ids_hash,'resolution_scope_hash':sha(payload),
        })
        SUPPORT_SELECTION_REGISTRY[key]=bound
        _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[key]=canonical_hash(bound)
        count+=1
    return count


def _find_bound_decision_relation_resolution(dgraph,universe,ctx,info):
    if not support_selection_registry_key_identity_coherent():return None
    rel=SUPPORT_SET_COMMON_MODE_REGISTRY.get(info['relation_id'])
    if not isinstance(rel,dict):return None
    effect=info['relation_effect']; allowed=set(RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,()))
    matches=[]
    for registry_key,row in SUPPORT_SELECTION_REGISTRY.items():
        if not isinstance(row,dict):return None
        if row.get('record_type')!=DECISION_RELATION_RESOLUTION_RECORD_TYPE:continue
        if row.get('resolution_id')!=registry_key:return None
        if not _decision_row_runtime_authorized(registry_key,row):continue
        if (row.get('binding_state')!='BOUND' or row.get('audit_context_id')!=ctx.audit_context_id
            or row.get('retrieval_scope_id')!=ctx.retrieval_scope_id or row.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id
            or row.get('claim_ids_hash')!=dgraph['claim_ids_hash'] or row.get('selected_support_map_hash')!=dgraph['selected_support_map_hash']
            or row.get('matching_support_universe_map_hash')!=dgraph['matching_support_universe_map_hash']
            or row.get('decision_dependency_graph_hash')!=dgraph['graph_hash']
            or row.get('decision_evidence_ownership_map_hash')!=universe.decision_evidence_ownership_map_hash
            or row.get('decision_relation_universe_hash')!=universe.universe_hash
            or row.get('decision_relation_ids_hash')!=universe.relation_ids_hash or row.get('relation_id')!=info['relation_id']
            or row.get('relation_type')!=info['relation_type'] or row.get('relation_effect')!=effect
            or row.get('evidence_ids_hash')!=info['evidence_ids_hash'] or row.get('relation_claim_scope')!=info['claim_scope']
            or row.get('relation_entry_hash')!=sha(rel) or row.get('resolution_type') not in allowed
            or row.get('authorizer_id') not in set(RELATION_RESOLUTION_POLICY['allowed_resolution_authorizers'])
            or row.get('relation_registry_hash')!=support_set_common_mode_registry_hash()
            or row.get('relation_discovery_policy_hash')!=relation_discovery_policy_hash()
            or row.get('relation_resolution_policy_hash')!=relation_resolution_policy_hash()
            or row.get('relation_decision_relevance_policy_hash')!=relation_decision_relevance_policy_hash()
            or row.get('support_universe_policy_hash')!=support_universe_policy_hash()):continue
        payload={
            'resolution_id':row['resolution_id'],'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
            'retrieval_snapshot_id':universe.retrieval_snapshot_id,'claim_ids_hash':dgraph['claim_ids_hash'],
            'selected_support_map_hash':dgraph['selected_support_map_hash'],
            'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':dgraph['graph_hash'],
            'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_relation_universe_hash':universe.universe_hash,
            'decision_relation_ids_hash':universe.relation_ids_hash,'relation_id':info['relation_id'],
            'relation_type':info['relation_type'],'relation_effect':effect,'evidence_ids_hash':info['evidence_ids_hash'],
            'relation_claim_scope':info['claim_scope'],'relation_entry_hash':sha(rel),'resolution_type':row['resolution_type'],
            'authorizer_id':row['authorizer_id'],'reason_hash':sha(row['reason']),
            'relation_registry_hash':support_set_common_mode_registry_hash(),'relation_discovery_policy_hash':relation_discovery_policy_hash(),
            'relation_resolution_policy_hash':relation_resolution_policy_hash(),
            'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
            'support_universe_policy_hash':support_universe_policy_hash(),
        }
        if row.get('resolution_scope_hash')!=sha(payload):continue
        matches.append(row)
    return matches[0] if len(matches)==1 else None


def _decision_level_relation_coverage(claims,facts,ctx,reqs,dgraph):
    universe=make_decision_level_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    if universe is None or universe.out_of_snapshot_relation_ids:return None
    if not relation_discovery_policy_adequate(ctx.as_of_date) or not relation_resolution_policy_adequate(ctx.as_of_date):return None
    candidates=_decision_relation_candidate_map(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    if tuple(candidates)!=universe.relation_ids:return None
    artifacts=[]
    for rid in universe.relation_ids:
        info=candidates.get(rid)
        if info is None:return None
        if info['claim_local_scope_sufficient']:
            artifacts.append(('CLAIM_LOCAL_SCOPE_SUFFICIENT',rid,info['local_covering_claim_ids'],
                              info['endpoint_claim_ownership_hash']))
            continue
        effect=info['relation_effect'] if info['relation_effect'] in set(RELATION_EFFECTS) else 'UNKNOWN'
        if effect in {'UNKNOWN','SELECTED_SUPPORT_INVALIDATING'}:return None
        # Every cross-claim typed effect has an explicit decision-level obligation.  This
        # includes redundancy-only and NDR: labels alone are not nonblocking authorization.
        if effect not in {'REDUNDANCY_ONLY','RELIABILITY_DEGRADING','CONTRADICTORY','NON_DECISION_RELEVANT'}:return None
        row=_find_bound_decision_relation_resolution(dgraph,universe,ctx,info)
        if row is None:return None
        artifacts.append(('DECISION_RELATION_RESOLUTION',rid,row['resolution_id'],row['resolution_scope_hash']))
    return universe,tuple(sorted(artifacts))


def _generic_dependency_record_hash(info):
    return sha((info['generic_dependency_node'],info['evidence_ids'],info['endpoint_claim_ownership'],
                info['endpoint_classifications'],info['endpoint_graph_membership'],info['participating_claims'],
                info['modeled_endpoint_ids'],info['snapshot_only_endpoint_ids'],info.get('raw_representation_records',()),
                info.get('representation_equivalence_policy_hash'),info.get('contextual_equivalence_resolution_hash'),
                info['allowed_shared'],info.get('selected_support_path_relevant',False),
                info.get('selected_support_path_anchor_ids',()),info.get('selected_support_path_component_records',()),
                info['decision_level_required'],info['relevance_classification']))


def bind_decision_generic_dependency_accountings_for_prepare(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,
                                                              retrieval_scope,req=None,accounting_ids=None):
    if not support_selection_registry_key_identity_coherent():return 0
    claims=parse_claims(text)
    try:reqs=normalize_requirements(claims,req)
    except Exception:return 0
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,sha(reqs))
    if aid is None:return 0
    facts=[]
    for i,r in enumerate(evidence,1):
        f,errs=normalize_fact(r,i)
        if errs:return 0
        facts.append(f)
    if attach_claim_identities(claims,claim_identity_map):return 0
    class _Ctx:pass
    ctx=_Ctx();ctx.audit_context_id=aid;ctx.as_of_date=asof;ctx.retrieval_scope_id=retrieval_scope
    graph=_decision_support_dependency_graph(claims,tuple(facts),ctx,reqs,registered_universes=False)
    if graph is None:return 0
    universe=make_decision_level_generic_dependency_universe(claims,tuple(facts),ctx,reqs,graph,registered_universes=False)
    if universe is None:return 0
    candidates=_decision_generic_dependency_candidate_map(claims,tuple(facts),ctx,reqs,graph,registered_universes=False)
    wanted=None if accounting_ids is None else set(accounting_ids)
    count=0
    for key,row in list(SUPPORT_SELECTION_REGISTRY.items()):
        if not isinstance(row,dict):return 0
        if row.get('record_type')!=DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE:continue
        if row.get('accounting_id')!=key:return 0
        if wanted is not None and row.get('accounting_id') not in wanted:continue
        if row.get('binding_state')!='PENDING' or row.get('retrieval_scope_id')!=retrieval_scope:continue
        if not _pending_decision_row_history_current(key,row):continue
        node=tuple(row.get('generic_dependency_node',()))
        info=candidates.get(node)
        if info is None or tuple(row.get('evidence_ids',()))!=tuple(info['evidence_ids']):continue
        if row.get('claim_ids_hash')!=graph['claim_ids_hash'] or row.get('selected_support_map_hash')!=graph['selected_support_map_hash']:continue
        if row.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id or row.get('support_universe_policy_hash')!=support_universe_policy_hash():continue
        if row.get('representation_equivalence_policy_hash')!=universe.representation_equivalence_policy_hash:continue
        if row.get('representation_equivalence_registry_hash')!=universe.representation_equivalence_registry_hash:continue
        if row.get('representation_equivalence_certificate_registry_hash')!=universe.representation_equivalence_certificate_registry_hash:continue
        record_hash=_generic_dependency_record_hash(info)
        scope_payload={
            'accounting_id':row['accounting_id'],'dependency_channel':GENERIC_DEPENDENCY_ACCOUNTING_CHANNEL,
            'audit_context_id':aid,'retrieval_scope_id':retrieval_scope,'retrieval_snapshot_id':row['retrieval_snapshot_id'],
            'claim_ids_hash':graph['claim_ids_hash'],'selected_support_map_hash':graph['selected_support_map_hash'],
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_generic_dependency_universe_hash':universe.universe_hash,
            'decision_generic_dependency_records_hash':universe.generic_dependency_records_hash,
            'decision_generic_dependency_obligations_hash':universe.decision_obligation_nodes_hash,
            'provenance_policy_hash':universe.provenance_policy_hash,'dependency_ontology_hash':universe.dependency_ontology_hash,
            'dependency_justification_registry_hash':universe.dependency_justification_registry_hash,
            'representation_equivalence_policy_hash':universe.representation_equivalence_policy_hash,
            'representation_equivalence_registry_hash':universe.representation_equivalence_registry_hash,
            'representation_equivalence_certificate_registry_hash':universe.representation_equivalence_certificate_registry_hash,
            'active_equivalence_ids_hash':universe.active_equivalence_ids_hash,
            'inactive_equivalence_records_hash':universe.inactive_equivalence_records_hash,
            'equivalence_applicability_records_hash':universe.equivalence_applicability_records_hash,
            'contextual_equivalence_resolution_hash':universe.contextual_equivalence_resolution_hash,
            'complete_raw_representation_inventory_hash':universe.complete_raw_representation_inventory_hash,
            'representation_classes_present_hash':universe.representation_classes_present_hash,
            'candidate_semantic_descriptor_records_hash':universe.candidate_semantic_descriptor_records_hash,
            'cross_representation_pair_coverage_records_hash':universe.cross_representation_pair_coverage_records_hash,
            'proven_non_candidate_records_hash':universe.proven_non_candidate_records_hash,
            'candidate_representation_pair_universe_hash':universe.candidate_representation_pair_universe_hash,
            'candidate_disposition_records_hash':universe.candidate_disposition_records_hash,
            'ontology_prefix_map_hash':universe.ontology_prefix_map_hash,
            'source_discovery_signal_hash':universe.source_discovery_signal_hash,
            'typed_discovery_signal_hash':universe.typed_discovery_signal_hash,
            'representation_distinctness_registry_hash':universe.representation_distinctness_registry_hash,
            'representation_distinctness_certificate_registry_hash':universe.representation_distinctness_certificate_registry_hash,
            'representation_completeness_certificate_hash':universe.representation_completeness_certificate_hash,
            'generic_dependency_node_hash':row['generic_dependency_node_hash'],'evidence_ids_hash':row['evidence_ids_hash'],
            'generic_dependency_record_hash':record_hash,'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],
            'reason_hash':sha(row['reason']),'support_universe_policy_hash':support_universe_policy_hash(),
        }
        bound=dict(row);bound.update({
            'binding_state':'BOUND','audit_context_id':aid,
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],
            'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_generic_dependency_universe_hash':universe.universe_hash,
            'decision_generic_dependency_records_hash':universe.generic_dependency_records_hash,
            'decision_generic_dependency_obligations_hash':universe.decision_obligation_nodes_hash,
            'provenance_policy_hash':universe.provenance_policy_hash,'dependency_ontology_hash':universe.dependency_ontology_hash,
            'dependency_justification_registry_hash':universe.dependency_justification_registry_hash,
            'representation_equivalence_policy_hash':universe.representation_equivalence_policy_hash,
            'representation_equivalence_registry_hash':universe.representation_equivalence_registry_hash,
            'representation_equivalence_certificate_registry_hash':universe.representation_equivalence_certificate_registry_hash,
            'active_equivalence_ids_hash':universe.active_equivalence_ids_hash,
            'inactive_equivalence_records_hash':universe.inactive_equivalence_records_hash,
            'equivalence_applicability_records_hash':universe.equivalence_applicability_records_hash,
            'contextual_equivalence_resolution_hash':universe.contextual_equivalence_resolution_hash,
            'complete_raw_representation_inventory_hash':universe.complete_raw_representation_inventory_hash,
            'representation_classes_present_hash':universe.representation_classes_present_hash,
            'candidate_semantic_descriptor_records_hash':universe.candidate_semantic_descriptor_records_hash,
            'cross_representation_pair_coverage_records_hash':universe.cross_representation_pair_coverage_records_hash,
            'proven_non_candidate_records_hash':universe.proven_non_candidate_records_hash,
            'candidate_representation_pair_universe_hash':universe.candidate_representation_pair_universe_hash,
            'candidate_disposition_records_hash':universe.candidate_disposition_records_hash,
            'ontology_prefix_map_hash':universe.ontology_prefix_map_hash,
            'source_discovery_signal_hash':universe.source_discovery_signal_hash,
            'typed_discovery_signal_hash':universe.typed_discovery_signal_hash,
            'representation_distinctness_registry_hash':universe.representation_distinctness_registry_hash,
            'representation_distinctness_certificate_registry_hash':universe.representation_distinctness_certificate_registry_hash,
            'representation_completeness_certificate_hash':universe.representation_completeness_certificate_hash,
            'generic_dependency_record_hash':record_hash,'accounting_scope_hash':sha(scope_payload),
        })
        SUPPORT_SELECTION_REGISTRY[key]=bound
        _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[key]=canonical_hash(bound)
        count+=1
    return count


def _find_bound_decision_generic_dependency_accounting(graph,universe,ctx,info):
    if not support_selection_registry_key_identity_coherent():return None
    required=SUPPORT_UNIVERSE_POLICY.get('decision_dependency_accounting_resolution_type')
    if not info.get('decision_level_required'):return None
    node=tuple(info['generic_dependency_node']);eids=tuple(info['evidence_ids']);record_hash=_generic_dependency_record_hash(info)
    matches=[]
    for registry_key,row in SUPPORT_SELECTION_REGISTRY.items():
        if not isinstance(row,dict):return None
        if row.get('record_type')!=DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE:continue
        if row.get('accounting_id')!=registry_key:return None
        if not _decision_row_runtime_authorized(registry_key,row):continue
        if (row.get('dependency_channel')!=GENERIC_DEPENDENCY_ACCOUNTING_CHANNEL
            or row.get('binding_state')!='BOUND' or row.get('audit_context_id')!=ctx.audit_context_id
            or row.get('retrieval_scope_id')!=ctx.retrieval_scope_id or row.get('retrieval_snapshot_id')!=universe.retrieval_snapshot_id
            or tuple(row.get('generic_dependency_node',()))!=node or tuple(row.get('evidence_ids',()))!=eids
            or row.get('resolution_type')!=required or row.get('claim_ids_hash')!=graph['claim_ids_hash']
            or row.get('selected_support_map_hash')!=graph['selected_support_map_hash']
            or row.get('matching_support_universe_map_hash')!=graph['matching_support_universe_map_hash']
            or row.get('decision_dependency_graph_hash')!=graph['graph_hash']
            or row.get('decision_evidence_ownership_map_hash')!=universe.decision_evidence_ownership_map_hash
            or row.get('decision_generic_dependency_universe_hash')!=universe.universe_hash
            or row.get('decision_generic_dependency_records_hash')!=universe.generic_dependency_records_hash
            or row.get('decision_generic_dependency_obligations_hash')!=universe.decision_obligation_nodes_hash
            or row.get('provenance_policy_hash')!=universe.provenance_policy_hash
            or row.get('dependency_ontology_hash')!=universe.dependency_ontology_hash
            or row.get('dependency_justification_registry_hash')!=universe.dependency_justification_registry_hash
            or row.get('representation_equivalence_policy_hash')!=universe.representation_equivalence_policy_hash
            or row.get('representation_equivalence_registry_hash')!=universe.representation_equivalence_registry_hash
            or row.get('representation_equivalence_certificate_registry_hash')!=universe.representation_equivalence_certificate_registry_hash
            or row.get('active_equivalence_ids_hash')!=universe.active_equivalence_ids_hash
            or row.get('inactive_equivalence_records_hash')!=universe.inactive_equivalence_records_hash
            or row.get('equivalence_applicability_records_hash')!=universe.equivalence_applicability_records_hash
            or row.get('contextual_equivalence_resolution_hash')!=universe.contextual_equivalence_resolution_hash
            or row.get('complete_raw_representation_inventory_hash')!=universe.complete_raw_representation_inventory_hash
            or row.get('representation_classes_present_hash')!=universe.representation_classes_present_hash
            or row.get('candidate_semantic_descriptor_records_hash')!=universe.candidate_semantic_descriptor_records_hash
            or row.get('cross_representation_pair_coverage_records_hash')!=universe.cross_representation_pair_coverage_records_hash
            or row.get('proven_non_candidate_records_hash')!=universe.proven_non_candidate_records_hash
            or row.get('candidate_representation_pair_universe_hash')!=universe.candidate_representation_pair_universe_hash
            or row.get('candidate_disposition_records_hash')!=universe.candidate_disposition_records_hash
            or row.get('ontology_prefix_map_hash')!=universe.ontology_prefix_map_hash
            or row.get('source_discovery_signal_hash')!=universe.source_discovery_signal_hash
            or row.get('typed_discovery_signal_hash')!=universe.typed_discovery_signal_hash
            or row.get('representation_distinctness_registry_hash')!=universe.representation_distinctness_registry_hash
            or row.get('representation_distinctness_certificate_registry_hash')!=universe.representation_distinctness_certificate_registry_hash
            or row.get('representation_completeness_certificate_hash')!=universe.representation_completeness_certificate_hash
            or row.get('generic_dependency_node_hash')!=sha(node) or row.get('evidence_ids_hash')!=sha(eids)
            or row.get('generic_dependency_record_hash')!=record_hash
            or row.get('support_universe_policy_hash')!=support_universe_policy_hash()
            or row.get('authorizer_id') not in set(SUPPORT_UNIVERSE_POLICY['allowed_authorizers']) or not nonblank(row.get('reason'))):
            continue
        scope_payload={
            'accounting_id':row['accounting_id'],'dependency_channel':GENERIC_DEPENDENCY_ACCOUNTING_CHANNEL,
            'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':row['retrieval_snapshot_id'],
            'claim_ids_hash':graph['claim_ids_hash'],'selected_support_map_hash':graph['selected_support_map_hash'],
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,
            'decision_generic_dependency_universe_hash':universe.universe_hash,
            'decision_generic_dependency_records_hash':universe.generic_dependency_records_hash,
            'decision_generic_dependency_obligations_hash':universe.decision_obligation_nodes_hash,
            'provenance_policy_hash':universe.provenance_policy_hash,'dependency_ontology_hash':universe.dependency_ontology_hash,
            'dependency_justification_registry_hash':universe.dependency_justification_registry_hash,
            'representation_equivalence_policy_hash':universe.representation_equivalence_policy_hash,
            'representation_equivalence_registry_hash':universe.representation_equivalence_registry_hash,
            'representation_equivalence_certificate_registry_hash':universe.representation_equivalence_certificate_registry_hash,
            'active_equivalence_ids_hash':universe.active_equivalence_ids_hash,
            'inactive_equivalence_records_hash':universe.inactive_equivalence_records_hash,
            'equivalence_applicability_records_hash':universe.equivalence_applicability_records_hash,
            'contextual_equivalence_resolution_hash':universe.contextual_equivalence_resolution_hash,
            'complete_raw_representation_inventory_hash':universe.complete_raw_representation_inventory_hash,
            'representation_classes_present_hash':universe.representation_classes_present_hash,
            'candidate_semantic_descriptor_records_hash':universe.candidate_semantic_descriptor_records_hash,
            'cross_representation_pair_coverage_records_hash':universe.cross_representation_pair_coverage_records_hash,
            'proven_non_candidate_records_hash':universe.proven_non_candidate_records_hash,
            'candidate_representation_pair_universe_hash':universe.candidate_representation_pair_universe_hash,
            'candidate_disposition_records_hash':universe.candidate_disposition_records_hash,
            'ontology_prefix_map_hash':universe.ontology_prefix_map_hash,
            'source_discovery_signal_hash':universe.source_discovery_signal_hash,
            'typed_discovery_signal_hash':universe.typed_discovery_signal_hash,
            'representation_distinctness_registry_hash':universe.representation_distinctness_registry_hash,
            'representation_distinctness_certificate_registry_hash':universe.representation_distinctness_certificate_registry_hash,
            'representation_completeness_certificate_hash':universe.representation_completeness_certificate_hash,
            'generic_dependency_node_hash':row['generic_dependency_node_hash'],'evidence_ids_hash':row['evidence_ids_hash'],
            'generic_dependency_record_hash':record_hash,'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],
            'reason_hash':sha(row['reason']),'support_universe_policy_hash':support_universe_policy_hash(),
        }
        if row.get('accounting_scope_hash')!=sha(scope_payload):continue
        matches.append(row)
    return matches[0] if len(matches)==1 else None


def bind_decision_dependency_accountings_for_prepare(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,
                                                     retrieval_scope,req=None):
    """Bind PENDING decision source-dependency accounting to the complete cross-claim source universe."""
    if not support_selection_registry_key_identity_coherent():return 0
    claims=parse_claims(text)
    try:reqs=normalize_requirements(claims,req)
    except Exception:return 0
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope_spec,extract_spec,retrieval_scope,sha(reqs))
    if aid is None:return 0
    facts=[]
    for i,r in enumerate(evidence,1):
        f,errs=normalize_fact(r,i)
        if errs:return 0
        facts.append(f)
    if attach_claim_identities(claims,claim_identity_map):return 0
    class _Ctx:pass
    ctx=_Ctx();ctx.audit_context_id=aid;ctx.as_of_date=asof;ctx.retrieval_scope_id=retrieval_scope
    graph=_decision_support_dependency_graph(claims,tuple(facts),ctx,reqs,registered_universes=False)
    if graph is None:return 0
    source_universe=make_decision_level_source_relation_universe(claims,tuple(facts),ctx,reqs,graph,registered_universes=False)
    if source_universe is None:return 0
    candidates=_decision_source_relation_candidate_map(claims,tuple(facts),ctx,reqs,graph,registered_universes=False)
    shared={pair:row for pair,row in candidates.items() if row['source_state']=='SOURCE_SHARED_DEPENDENCY'}
    count=0
    for key,row in list(SUPPORT_SELECTION_REGISTRY.items()):
        if not isinstance(row,dict):return 0
        if row.get('record_type')!=DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE:continue
        if row.get('accounting_id')!=key:return 0
        if row.get('binding_state')!='PENDING' or row.get('retrieval_scope_id')!=retrieval_scope:continue
        if not _pending_decision_row_history_current(key,row):continue
        eids=tuple(row.get('evidence_ids',()))
        info=shared.get(eids)
        if info is None:continue
        edge=(eids[0],eids[1],info['source_state'],info['diagnostics'],info['source_independence_certificate_id'])
        if row.get('claim_ids_hash')!=graph['claim_ids_hash'] or row.get('selected_support_map_hash')!=graph['selected_support_map_hash']:continue
        if row.get('retrieval_snapshot_id')!=source_universe.retrieval_snapshot_id:continue
        if row.get('support_universe_policy_hash')!=support_universe_policy_hash():continue
        scope_payload={
            'accounting_id':row['accounting_id'],'audit_context_id':aid,
            'retrieval_scope_id':retrieval_scope,'retrieval_snapshot_id':row['retrieval_snapshot_id'],
            'claim_ids_hash':graph['claim_ids_hash'],'selected_support_map_hash':graph['selected_support_map_hash'],
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],
            'path_relevant_source_edges_hash':graph['path_relevant_source_edges_hash'],
            'decision_evidence_ownership_map_hash':source_universe.decision_evidence_ownership_map_hash,
            'decision_source_relation_universe_hash':source_universe.universe_hash,
            'decision_source_relation_records_hash':source_universe.source_relation_records_hash,
            'decision_source_obligation_pairs_hash':source_universe.decision_obligation_pair_ids_hash,
            'source_semantics_registry_hash':source_universe.source_semantics_registry_hash,
            'source_semantics_resolution_certificate_registry_hash':source_universe.source_semantics_resolution_certificate_registry_hash,
            'failure_domain_relation_registry_hash':source_universe.failure_domain_relation_registry_hash,
            'source_independence_policy_hash':source_universe.source_independence_policy_hash,
            'source_semantics_policy_hash':source_universe.source_semantics_policy_hash,
            'evidence_ids_hash':row['evidence_ids_hash'],'source_edge_hash':sha(edge),
            'source_relation_record_hash':sha((info['evidence_ids'],info['endpoint_claim_ownership'],info['endpoint_classifications'],
                                               info['decision_node_endpoint_count'],info['source_state'],info['diagnostics'],
                                               info['source_independence_certificate_id'],info['source_failure_domain_bindings'],
                                               info.get('selected_support_path_relevant',False),info.get('selected_support_path_anchor_ids',()),
                                               info.get('selected_support_path_component_records',()),
                                               info['decision_level_required'],info['relevance_classification'])),
            'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],
            'reason_hash':sha(row['reason']),'support_universe_policy_hash':support_universe_policy_hash(),
        }
        bound=dict(row)
        bound.update({
            'binding_state':'BOUND','audit_context_id':aid,
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],
            'path_relevant_source_edges_hash':graph['path_relevant_source_edges_hash'],
            'decision_evidence_ownership_map_hash':source_universe.decision_evidence_ownership_map_hash,
            'decision_source_relation_universe_hash':source_universe.universe_hash,
            'decision_source_relation_records_hash':source_universe.source_relation_records_hash,
            'decision_source_obligation_pairs_hash':source_universe.decision_obligation_pair_ids_hash,
            'source_semantics_registry_hash':source_universe.source_semantics_registry_hash,
            'source_semantics_resolution_certificate_registry_hash':source_universe.source_semantics_resolution_certificate_registry_hash,
            'failure_domain_relation_registry_hash':source_universe.failure_domain_relation_registry_hash,
            'source_independence_policy_hash':source_universe.source_independence_policy_hash,
            'source_semantics_policy_hash':source_universe.source_semantics_policy_hash,
            'source_edge_hash':sha(edge),'source_relation_record_hash':scope_payload['source_relation_record_hash'],
            'accounting_scope_hash':sha(scope_payload),
        })
        SUPPORT_SELECTION_REGISTRY[key]=bound
        _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[key]=canonical_hash(bound)
        count+=1
    return count


def _find_bound_decision_dependency_accounting(graph,source_universe,ctx,info):
    if not support_selection_registry_key_identity_coherent():return None
    required=SUPPORT_UNIVERSE_POLICY.get('decision_dependency_accounting_resolution_type')
    if info.get('source_state')!='SOURCE_SHARED_DEPENDENCY':return None
    eids=tuple(info['evidence_ids'])
    edge=(eids[0],eids[1],info['source_state'],info['diagnostics'],info['source_independence_certificate_id'])
    record_hash=sha((info['evidence_ids'],info['endpoint_claim_ownership'],info['endpoint_classifications'],
                     info['decision_node_endpoint_count'],info['source_state'],info['diagnostics'],
                     info['source_independence_certificate_id'],info['source_failure_domain_bindings'],
                     info.get('selected_support_path_relevant',False),info.get('selected_support_path_anchor_ids',()),
                     info.get('selected_support_path_component_records',()),
                     info['decision_level_required'],info['relevance_classification']))
    matches=[]
    for registry_key,row in SUPPORT_SELECTION_REGISTRY.items():
        if not isinstance(row,dict):return None
        if row.get('record_type')!=DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE:continue
        if row.get('accounting_id')!=registry_key:return None
        if not _decision_row_runtime_authorized(registry_key,row):continue
        if (row.get('binding_state')!='BOUND' or row.get('audit_context_id')!=ctx.audit_context_id
            or row.get('retrieval_scope_id')!=ctx.retrieval_scope_id
            or row.get('retrieval_snapshot_id')!=source_universe.retrieval_snapshot_id
            or tuple(row.get('evidence_ids',()))!=eids or row.get('resolution_type')!=required
            or row.get('claim_ids_hash')!=graph['claim_ids_hash']
            or row.get('selected_support_map_hash')!=graph['selected_support_map_hash']
            or row.get('matching_support_universe_map_hash')!=graph['matching_support_universe_map_hash']
            or row.get('decision_dependency_graph_hash')!=graph['graph_hash']
            or row.get('path_relevant_source_edges_hash')!=graph['path_relevant_source_edges_hash']
            or row.get('decision_evidence_ownership_map_hash')!=source_universe.decision_evidence_ownership_map_hash
            or row.get('decision_source_relation_universe_hash')!=source_universe.universe_hash
            or row.get('decision_source_relation_records_hash')!=source_universe.source_relation_records_hash
            or row.get('decision_source_obligation_pairs_hash')!=source_universe.decision_obligation_pair_ids_hash
            or row.get('source_semantics_registry_hash')!=source_universe.source_semantics_registry_hash
            or row.get('source_semantics_resolution_certificate_registry_hash')!=source_universe.source_semantics_resolution_certificate_registry_hash
            or row.get('failure_domain_relation_registry_hash')!=source_universe.failure_domain_relation_registry_hash
            or row.get('source_independence_policy_hash')!=source_universe.source_independence_policy_hash
            or row.get('source_semantics_policy_hash')!=source_universe.source_semantics_policy_hash
            or row.get('source_edge_hash')!=sha(edge) or row.get('source_relation_record_hash')!=record_hash
            or row.get('support_universe_policy_hash')!=support_universe_policy_hash()
            or row.get('authorizer_id') not in set(SUPPORT_UNIVERSE_POLICY['allowed_authorizers'])
            or not nonblank(row.get('reason'))):
            continue
        scope_payload={
            'accounting_id':row['accounting_id'],'audit_context_id':ctx.audit_context_id,
            'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':row['retrieval_snapshot_id'],
            'claim_ids_hash':graph['claim_ids_hash'],'selected_support_map_hash':graph['selected_support_map_hash'],
            'matching_support_universe_map_hash':graph['matching_support_universe_map_hash'],
            'decision_dependency_graph_hash':graph['graph_hash'],
            'path_relevant_source_edges_hash':graph['path_relevant_source_edges_hash'],
            'decision_evidence_ownership_map_hash':source_universe.decision_evidence_ownership_map_hash,
            'decision_source_relation_universe_hash':source_universe.universe_hash,
            'decision_source_relation_records_hash':source_universe.source_relation_records_hash,
            'decision_source_obligation_pairs_hash':source_universe.decision_obligation_pair_ids_hash,
            'source_semantics_registry_hash':source_universe.source_semantics_registry_hash,
            'source_semantics_resolution_certificate_registry_hash':source_universe.source_semantics_resolution_certificate_registry_hash,
            'failure_domain_relation_registry_hash':source_universe.failure_domain_relation_registry_hash,
            'source_independence_policy_hash':source_universe.source_independence_policy_hash,
            'source_semantics_policy_hash':source_universe.source_semantics_policy_hash,
            'evidence_ids_hash':row['evidence_ids_hash'],'source_edge_hash':sha(edge),
            'source_relation_record_hash':record_hash,
            'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],
            'reason_hash':sha(row['reason']),'support_universe_policy_hash':support_universe_policy_hash(),
        }
        if row.get('accounting_scope_hash')!=sha(scope_payload):continue
        matches.append(row)
    return matches[0] if len(matches)==1 else None


def _local_decision_dependency_accounting_for_edge(graph,edge):
    key=tuple(edge[:2]);required=SUPPORT_UNIVERSE_POLICY.get('source_dependency_resolution_type')
    for a,b,vals in graph.get('local_source_accounting',()):
        if (a,b)==key and any(res==required for _,res in vals):return ('LOCAL_CLAIM_ACCOUNTING',key,vals)
    return None

def _decision_selected_supports(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    selected={}
    for c in modeled:
        if c.id not in reqs:return None
        ss=selected_support_facts(c,facts,ctx,reqs[c.id])
        if ss is None:return None
        selected[c.id]=tuple(ss)
    return selected

def make_decision_support_closure_certificate(claims,facts,ctx,reqs):
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return None
    selected={}; support_cert_ids={};set_cert_ids=[]
    universe_map={};relation_universe_map={};selection_cert_ids={};coverage_cert_ids={}
    for c in modeled:
        if c.status!=ClaimStatus.VERIFIED or c.id not in reqs or c.support_set_certificate is None:return None
        if not validate_support_set_certificate(c.support_set_certificate,c,facts,ctx,reqs[c.id]):return None
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:return None
        sel=_find_support_selection_certificate(c,facts,ctx,reqs[c.id],universe)
        if sel is None:return None
        cov=_find_claim_support_universe_coverage_certificate(c,facts,ctx,reqs[c.id],universe,sel)
        if cov is None:return None
        descriptor=_selection_descriptor(c,universe,reqs[c.id])
        relation_universe=None if descriptor is None else _find_decision_relevant_relation_universe(c,ctx,universe,descriptor)
        if relation_universe is None:return None
        ss=selected_support_facts(c,facts,ctx,reqs[c.id])
        if ss is None:return None
        selected[c.id]=tuple(sorted(f.evidence_id for f in ss))
        support_cert_ids[c.id]=c.support_set_certificate.certificate_id
        universe_map[c.id]=universe.universe_hash
        relation_universe_map[c.id]=relation_universe.universe_hash
        selection_cert_ids[c.id]=sel.certificate_id
        coverage_cert_ids[c.id]=cov.certificate_id
        if len(ss)>1:
            sc=_valid_support_set_independence_certificate(c.id,ctx.retrieval_scope_id,ss,ctx.as_of_date)
            if sc is None:return None
            set_cert_ids.append(sc.certificate_id)

    fmap={f.evidence_id:f for f in facts}
    cross_shared=[];direct_source_ledger=[];source_cert_ids=[]
    for ca,cb in combinations(sorted(selected),2):
        for ea in selected[ca]:
            for eb in selected[cb]:
                ok,diag,state,source_cert=pair_independence(fmap[ea],fmap[eb],ctx.as_of_date,ctx.retrieval_scope_id)
                direct_source_ledger.append((ca,ea,cb,eb,state,tuple(diag),None if source_cert is None else source_cert.certificate_id))
                if source_cert is not None:source_cert_ids.append(source_cert.certificate_id)
                if not ok:cross_shared.append((ca,ea,cb,eb,tuple(sorted(diag))))
    # Direct selected-support dependency remains a hard block; decision accounting is for
    # indirect justification paths through excluded supports, not a way to certify selected
    # dependent supports as independent.
    if cross_shared:return None

    if len(modeled)>1:
        union=tuple(sorted({eid for eids in selected.values() for eid in eids}))
        if len(union)>1:
            ufacts=tuple(fmap[eid] for eid in union)
            dcert=_valid_support_set_independence_certificate('__DECISION__',ctx.retrieval_scope_id,ufacts,ctx.as_of_date)
            if dcert is None:return None
            set_cert_ids.append(dcert.certificate_id)

    # v0.2.29: compose claim-local universes into one decision-level dependency graph.
    dgraph=_decision_support_dependency_graph(claims,facts,ctx,reqs,registered_universes=True)
    if dgraph is None:return None
    if dgraph['selected_support_map_hash']!=sha(_canonical_selected_support_map(selected)):return None
    if dgraph['matching_support_universe_map_hash']!=sha(tuple(sorted(universe_map.items()))):return None

    decision_relation_coverage=_decision_level_relation_coverage(claims,facts,ctx,reqs,dgraph)
    if decision_relation_coverage is None:return None
    decision_relation_universe,decision_relation_artifacts=decision_relation_coverage
    candidates_info=_decision_relation_candidate_map(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    if tuple(candidates_info)!=decision_relation_universe.relation_ids:return None

    # v0.2.37: canonical generic provenance/dependency identity plus explicit equivalence resolution is an independent decision-level channel.
    decision_generic_universe=make_decision_level_generic_dependency_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    if decision_generic_universe is None:return None
    _comp_cert=GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY.get(ctx.audit_context_id)
    if (_comp_cert is None or _comp_cert.completeness_result!='PASS'
        or any(r[1] not in {'RESOLVED_EQUIVALENT','PROVEN_DISTINCT'} for r in decision_generic_universe.candidate_disposition_records)):
        return None
    _eq_state=generic_equivalence_contextual_resolution_state(ctx.as_of_date,ctx.retrieval_scope_id)
    if _eq_state['invalid_ids'] or _eq_state['conflicts']:return None
    generic_assessments=_decision_level_generic_dependency_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    generic_candidates={x['generic_dependency_node']:x for x in generic_assessments if x['decision_level_required']}
    if tuple(generic_candidates)!=decision_generic_universe.decision_obligation_nodes:return None
    generic_accounting=[]
    for node,info in generic_candidates.items():
        if info.get('equivalence_resolution_state')!='RESOLVED':return None
        acc=_find_bound_decision_generic_dependency_accounting(dgraph,decision_generic_universe,ctx,info)
        if acc is None:return None
        generic_accounting.append(('DECISION_BOUND_GENERIC_ACCOUNTING',node,tuple(info['evidence_ids']),acc['accounting_id'],acc['accounting_scope_hash']))

    # v0.2.34: source/failure-domain completeness is evaluated over complete modeled ownership,
    # independently of decision graph membership and independently of typed relation rows.
    decision_source_universe=make_decision_level_source_relation_universe(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    if decision_source_universe is None:return None
    source_assessments=_decision_level_source_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    source_candidates={x['evidence_ids']:x for x in source_assessments if x['decision_level_required']}
    if tuple(source_candidates)!=decision_source_universe.decision_obligation_pair_ids:return None

    decision_accounting=[]
    for pair,info in source_candidates.items():
        state=info['source_state']
        if state=='SOURCE_RELATION_UNRESOLVED':return None
        if state!='SOURCE_SHARED_DEPENDENCY':continue
        # Local claim accounting may still be retained diagnostically for graph-path semantics,
        # but cross-claim source obligations require exact decision-scope accounting.
        acc=_find_bound_decision_dependency_accounting(dgraph,decision_source_universe,ctx,info)
        if acc is None:return None
        decision_accounting.append(('DECISION_BOUND_SOURCE_ACCOUNTING',pair,acc['accounting_id'],acc['accounting_scope_hash']))

    typed_assessments=_decision_level_relation_assessments(claims,facts,ctx,reqs,dgraph,registered_universes=True)
    cross_channel_hash=_cross_channel_coverage_hash(source_assessments,typed_assessments)
    three_channel_hash=_three_channel_composition_hash(generic_assessments,source_assessments,typed_assessments)

    compatibility=[]
    for c in modeled:compatibility.append((c.id,identity_tuple(c.identity) if c.identity else None))
    source_relation_payload={
        'direct_selected_ledger':tuple(sorted(direct_source_ledger)),
        'decision_path_relevant_source_edges':dgraph['path_relevant_source_edges'],
        'decision_level_source_assessments':tuple((x['evidence_ids'],x['source_state'],x['diagnostics'],x['endpoint_claim_ownership'],
                                                   x['endpoint_classifications'],x.get('selected_support_path_relevant',False),
                                                   x.get('selected_support_path_anchor_ids',()),x.get('selected_support_path_component_records',()),
                                                   x['decision_level_required'],x['relevance_classification'])
                                                  for x in source_assessments),
        'decision_dependency_accounting':tuple(sorted(decision_accounting)),
        'decision_generic_dependency_accounting':tuple(sorted(generic_accounting)),
    }
    payload={
        'audit_context_id':ctx.audit_context_id,'claim_ids_hash':sha(tuple(sorted(c.id for c in modeled))),
        'support_set_certificate_ids_hash':sha(support_cert_ids),'selected_support_map_hash':sha(selected),
        'matching_support_universe_map_hash':sha(universe_map),
        'decision_relevant_relation_universe_map_hash':sha(relation_universe_map),
        'support_selection_certificate_ids_hash':sha(selection_cert_ids),
        'support_universe_coverage_certificate_ids_hash':sha(coverage_cert_ids),
        'union_dependency_graph_hash':dgraph['graph_hash'],
        'cross_claim_shared_nodes_hash':dgraph['path_relevant_source_edges_hash'],
        'decision_evidence_ownership_map_hash':decision_relation_universe.decision_evidence_ownership_map_hash,
        'decision_level_relation_universe_hash':decision_relation_universe.universe_hash,
        'decision_level_relation_ids_hash':decision_relation_universe.relation_ids_hash,
        'decision_level_relation_instance_records_hash':decision_relation_universe.relation_instance_records_hash,
        'decision_level_relation_scope_coverage_hash':sha(tuple((rid,
            candidates_info.get(rid,{}).get('endpoint_claim_ownership_hash'),
            candidates_info.get(rid,{}).get('claim_local_scope_sufficient'))
            for rid in decision_relation_universe.relation_ids)),
        'decision_level_relation_resolution_artifacts_hash':sha(decision_relation_artifacts),
        'decision_level_source_relation_universe_hash':decision_source_universe.universe_hash,
        'decision_level_source_relation_records_hash':decision_source_universe.source_relation_records_hash,
        'decision_level_source_obligation_pairs_hash':decision_source_universe.decision_obligation_pair_ids_hash,
        'cross_channel_coverage_hash':cross_channel_hash,
        'decision_level_generic_dependency_universe_hash':decision_generic_universe.universe_hash,
        'decision_level_generic_dependency_records_hash':decision_generic_universe.generic_dependency_records_hash,
        'decision_level_generic_dependency_raw_representation_records_hash':decision_generic_universe.raw_representation_records_hash,
        'decision_level_generic_dependency_obligations_hash':decision_generic_universe.decision_obligation_nodes_hash,
        'decision_level_generic_dependency_accounting_hash':sha(tuple(sorted(generic_accounting))),
        'generic_relation_source_identity_policy_hash':decision_generic_universe.representation_equivalence_policy_hash,
        'generic_representation_equivalence_registry_hash':decision_generic_universe.representation_equivalence_registry_hash,
        'generic_representation_equivalence_certificate_registry_hash':decision_generic_universe.representation_equivalence_certificate_registry_hash,
        'generic_equivalence_resolution_records_hash':decision_generic_universe.equivalence_resolution_records_hash,
        'generic_active_equivalence_ids_hash':decision_generic_universe.active_equivalence_ids_hash,
        'generic_inactive_equivalence_records_hash':decision_generic_universe.inactive_equivalence_records_hash,
        'generic_equivalence_applicability_records_hash':decision_generic_universe.equivalence_applicability_records_hash,
        'generic_contextual_equivalence_resolution_hash':decision_generic_universe.contextual_equivalence_resolution_hash,
        'generic_complete_raw_representation_inventory_hash':decision_generic_universe.complete_raw_representation_inventory_hash,
        'generic_representation_classes_present_hash':decision_generic_universe.representation_classes_present_hash,
        'generic_candidate_semantic_descriptor_records_hash':decision_generic_universe.candidate_semantic_descriptor_records_hash,
        'generic_cross_representation_pair_coverage_records_hash':decision_generic_universe.cross_representation_pair_coverage_records_hash,
        'generic_proven_non_candidate_records_hash':decision_generic_universe.proven_non_candidate_records_hash,
        'generic_candidate_representation_pair_universe_hash':decision_generic_universe.candidate_representation_pair_universe_hash,
        'generic_candidate_disposition_records_hash':decision_generic_universe.candidate_disposition_records_hash,
        'generic_ontology_prefix_map_hash':decision_generic_universe.ontology_prefix_map_hash,
        'generic_source_discovery_signal_hash':decision_generic_universe.source_discovery_signal_hash,
        'generic_typed_discovery_signal_hash':decision_generic_universe.typed_discovery_signal_hash,
        'generic_representation_distinctness_registry_hash':decision_generic_universe.representation_distinctness_registry_hash,
        'generic_representation_distinctness_certificate_registry_hash':decision_generic_universe.representation_distinctness_certificate_registry_hash,
        'generic_representation_completeness_certificate_hash':decision_generic_universe.representation_completeness_certificate_hash,
        'three_channel_composition_hash':three_channel_hash,
        'source_relation_ledger_hash':sha(source_relation_payload),
        'source_independence_certificate_ids_hash':sha(tuple(sorted(set(source_cert_ids)))),
        'support_set_independence_certificate_ids_hash':sha(tuple(sorted(set(set_cert_ids)))),
        'temporal_identity_compatibility_hash':sha(sorted(compatibility)),'closure_result':'PASS',
    }
    return DecisionSupportClosureCertificate(sha(payload),**payload)

def validate_decision_support_closure_certificate(cert,claims,facts,ctx,reqs):
    if cert is None:return False
    fresh=make_decision_support_closure_certificate(claims,facts,ctx,reqs)
    return fresh is not None and asdict(fresh)==asdict(cert)

def apply_support_policy_status(claims,facts,ctx,reqs):
    for c in claims:
        if c.status!=ClaimStatus.SUPPORTED or c.id not in reqs:continue
        cert=make_support_set_certificate(c,facts,ctx,reqs[c.id])
        if cert is not None:
            c.support_set_certificate=cert
            c.status=ClaimStatus.VERIFIED
            c.reason=f'policy-satisfied support set ({reqs[c.id]["required_independent_supports"]})'

def support_policy_violations(claims,facts,ctx,reqs):
    out=[]
    for c in claims:
        if c.id not in reqs:continue
        need=reqs[c.id]['required_independent_supports'];sup=matching_supports(c,facts,ctx)
        if len(sup)<need:
            out.append({'type':'INSUFFICIENT_SUPPORT_COUNT','claim_id':c.id,'required':need,'observed':len(sup)});continue
        universe=_find_matching_support_universe(c,facts,ctx)
        if universe is None:
            out.append({'type':'CERTIFIED_SUBSET_BUT_UNIVERSE_UNRESOLVED','claim_id':c.id,
                        'reason':'MATCHING_SUPPORT_UNIVERSE_MISSING_OR_INVALID'});continue
        sel=_find_support_selection_certificate(c,facts,ctx,reqs[c.id],universe)
        cov=None if sel is None else _find_claim_support_universe_coverage_certificate(c,facts,ctx,reqs[c.id],universe,sel)
        if sel is None or cov is None:
            # Diagnose whether the old existential condition is true.  It remains insufficient
            # for closure, but is useful to distinguish the R22 failure class.
            certified_subset=False;diag=[]
            candidates=[(x,) for x in sup] if need==1 else combinations(tuple(sorted(sup,key=lambda f:f.evidence_id)),need)
            for ss in candidates:
                ss=tuple(ss)
                if need==1:certified_subset=True;diag.append(tuple(f.evidence_id for f in ss));break
                ind,shared=independent_subset(ss,ctx.as_of_date,ctx.retrieval_scope_id)
                set_cert=_valid_support_set_independence_certificate(c.id,ctx.retrieval_scope_id,ss,ctx.as_of_date) if ind else None
                if set_cert is not None:
                    ic=make_justification_independence_certificate(c.id,ss,ctx.retrieval_scope_id,ctx.as_of_date)
                    if ic is not None and validate_justification_independence_certificate(ic,c.id,ss,ctx.retrieval_scope_id,ctx.as_of_date):
                        certified_subset=True;diag.append(tuple(f.evidence_id for f in ss));break
            out.append({'type':'CERTIFIED_SUBSET_BUT_UNIVERSE_UNRESOLVED' if certified_subset else 'NO_CERTIFIED_INDEPENDENT_SUBSET',
                        'claim_id':c.id,'required':need,'universe_evidence_ids':list(universe.matching_evidence_ids),
                        'candidate_subset':diag[0] if diag else None,
                        'selection_certificate_valid':sel is not None,'universe_coverage_certificate_valid':cov is not None})
            continue
        cert=make_support_set_certificate(c,facts,ctx,reqs[c.id])
        if cert is None:
            out.append({'type':'NO_CERTIFIED_INDEPENDENT_SUBSET','claim_id':c.id,'required':need,
                        'selected_support_ids':list(sel.selected_support_ids)})
    return out

def coverage_violations(claims,reqs):
    out=[]
    for c in claims:
        if c.id not in reqs or not reqs[c.id]['require_constraint_coverage']:continue
        ok,reason=constraint_coverage(c)
        if not ok:out.append({'type':reason,'claim_id':c.id,'value':c.value})
    return out

def justification_common_mode_coverage_valid(claims,facts,ctx,reqs):
    for c in claims:
        if c.id not in reqs or reqs[c.id]['required_independent_supports']<=1:continue
        sup=matching_supports(c,facts,ctx)
        for a,b in combinations(sup,2):
            ja={n for n in dependency_nodes(a) if n[0] in {'JUSTIFICATION','DEPENDENCY_STATE'}}
            jb={n for n in dependency_nodes(b) if n[0] in {'JUSTIFICATION','DEPENDENCY_STATE'}}
            shared=ja&jb
            ind,_=independent_subset((a,b),ctx.as_of_date,ctx.retrieval_scope_id)
            if shared and ind:return False
    return True


def _selected_support_map_for_gates(claims,facts,ctx,reqs):
    selected={}
    for c in claims:
        if c.predicate in {'hypothesis','unmodelled'}:continue
        if c.id not in reqs:return None
        ss=selected_support_facts(c,facts,ctx,reqs[c.id])
        if ss is None:return None
        selected[c.id]=tuple(ss)
    return selected

def source_failure_domain_resolution_complete_valid(claims,facts,ctx,reqs):
    if not facts or not source_semantics_policy_adequate(ctx.as_of_date):return False
    modeled=[c for c in claims if c.predicate not in {'hypothesis','unmodelled'}]
    if not modeled:return False
    # Keep this gate unary/semantic: it proves that enough candidate supports have KNOWN
    # source semantics when independence is required. Set-level certification is a separate gate.
    independence_required=(len(modeled)>1 or any(reqs.get(c.id,{}).get('required_independent_supports',1)>1 for c in modeled))
    if not independence_required:return True
    for c in modeled:
        if c.id not in reqs:return False
        need=reqs[c.id]['required_independent_supports']
        sup=matching_supports(c,facts,ctx)
        resolved=[f for f in sup if source_resolution_valid_for_independence(f)]
        if len(resolved)<need:return False
    return True

def support_set_common_mode_coverage_valid(claims,facts,ctx,reqs):
    if (not source_semantics_policy_adequate(ctx.as_of_date)
        or not support_set_independence_certificate_registry_coherent()):return False
    selected=_selected_support_map_for_gates(claims,facts,ctx,reqs)
    if selected is None:return False
    for cid,ss in selected.items():
        if len(ss)>1 and _valid_support_set_independence_certificate(cid,ctx.retrieval_scope_id,ss,ctx.as_of_date) is None:return False
    if len(selected)>1:
        union=tuple(sorted({f.evidence_id:f for ss in selected.values() for f in ss}.values(),key=lambda f:f.evidence_id))
        if len(union)>1 and _valid_support_set_independence_certificate('__DECISION__',ctx.retrieval_scope_id,union,ctx.as_of_date) is None:return False
    return True

def source_independence_semantics_valid(claims,facts,ctx,reqs):
    if (not facts or not source_independence_policy_adequate(ctx.as_of_date)
        or not source_semantics_policy_adequate(ctx.as_of_date)
        or not source_independence_certificate_registry_coherent()
        or not support_set_independence_certificate_registry_coherent()):return False
    if not all(validate_source_failure_domain_certificate(f.source_failure_domain,f.provenance,f.authority,f.evidence_id) for f in facts):return False
    selected=_selected_support_map_for_gates(claims,facts,ctx,reqs)
    if selected is None:return False
    for ss in selected.values():
        if len(ss)>1:
            ok,_,_,_=source_relation_assessment(ss)
            if not ok:return False
    for ca,cb in combinations(sorted(selected),2):
        for a in selected[ca]:
            for b in selected[cb]:
                ok,_,_,_=evaluate_source_relation(a,b)
                if not ok:return False
    return True

# ============================================================
# Prepare / audit
# ============================================================

def prepare(text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,req=None,waivers=None):
    claims=parse_claims(text)
    try:reqs=normalize_requirements(claims,req)
    except:return (None,)*10
    requirements_hash=sha(reqs)
    aid=_audit_context_seed(text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,requirements_hash)
    if aid is None:return (None,)*10
    cov=make_evidence_coverage(retrieval_scope,evidence)
    if cov is None:return None,None,None,None,None,None,None,None,None,None
    integrity=make_snapshot_content_integrity(retrieval_scope,evidence)
    if integrity is None:return None,None,cov,None,None,None,None,None,None,None
    _prepare_support_universe_artifacts(text,evidence,claim_identity_map,asof,retrieval_scope,reqs,aid)
    policy=make_policy(claims,req,artifact_context_id=aid)
    if policy is None:return (None,)*10
    auth=make_authorization(policy,claims,req,asof,waivers)
    if auth is None:return policy,None,cov,integrity,None,None,None,None,None,None
    ctx=make_context(text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,cov,integrity,policy,auth)
    if ctx is None:return policy,auth,cov,integrity,None,None,None,None,None,None
    # v0.2.39: prepare materializes the exact decision candidate-completeness certificate.
    _pfacts=[]
    for _i,_r in enumerate(evidence,1):
        _f,_errs=normalize_fact(_r,_i)
        if _errs:return policy,auth,cov,integrity,None,None,None,None,None,None
        _pfacts.append(_f)
    if attach_claim_identities(claims,claim_identity_map):return policy,auth,cov,integrity,None,None,None,None,None,None
    _dgraph=_decision_support_dependency_graph(claims,tuple(_pfacts),ctx,reqs,registered_universes=True) if reqs else None
    if reqs and _dgraph is not None:
        issue_decision_generic_representation_completeness_certificate(claims,tuple(_pfacts),ctx,reqs,_dgraph,registered_universes=True)
    sb=make_binding('SCOPE','scope:current',ctx,policy);eb=make_binding('EXTRACTION','extract:current',ctx,policy)
    sa=make_adequacy('SCOPE',text,scope,claims,ctx);ea=make_adequacy('EXTRACTION',text,extract,claims,ctx);gm=make_gate_meta(asof)
    return policy,auth,cov,integrity,ctx,sb,eb,sa,ea,gm

def audit_text(text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,req=None,waivers=None,
               policy=None,authorization=None,evidence_coverage=None,snapshot_integrity=None,context=None,
               scope_binding=None,extraction_binding=None,scope_adequacy=None,extraction_adequacy=None,
               gate_meta=None,resource_exhausted=False):
    claims=parse_claims(text);identity_errors=attach_claim_identities(claims,claim_identity_map)
    try:reqs=normalize_requirements(claims,req)
    except:reqs={}
    pol_ok=validate_policy(policy,claims,req)
    auth_ok=validate_authorization(authorization,policy,claims,req,asof,waivers)
    cov_ok=validate_evidence_coverage(evidence_coverage,retrieval_scope,evidence)
    integrity_ok=validate_snapshot_content_integrity(snapshot_integrity,retrieval_scope,evidence)
    overlap_cert=make_decision_relevant_overlap_certificate(text,claim_identity_map,scope,asof)
    overlap_ok=overlap_cert is not None
    relational_neighborhood_ok=relational_claim_neighborhood_complete(text,claim_identity_map)
    projection_ok=claim_projection_complete(text,claim_identity_map,retrieval_scope,asof)
    supersession_ok=snapshot_supersession_valid_for_audit(text,claim_identity_map,scope,retrieval_scope,asof)
    competition_cert=make_snapshot_competition(text,claim_identity_map,scope,retrieval_scope,asof)
    competition_ok=competition_cert is not None
    universe_membership_ok=retrieval_universe_membership_valid(retrieval_scope)
    partition_ok=retrieval_universe_partition_adequate(asof)
    applicability_cert=make_snapshot_applicability(text,claim_identity_map,scope,retrieval_scope,asof)
    applicability_ok=applicability_cert is not None
    freshness_ok=snapshot_freshness_valid(retrieval_scope,asof)
    current_ctx=(make_context(text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,
                              evidence_coverage,snapshot_integrity,policy,authorization)
                 if all([policy,authorization,evidence_coverage,snapshot_integrity]) else None)
    ctx_ok=(validate_context(context,text,evidence,claim_identity_map,asof,scope,extract,retrieval_scope,
                             evidence_coverage,snapshot_integrity,policy,authorization)
            if current_ctx else False)
    facts=[];evidence_errors=[]
    for i,r in enumerate(evidence,1):
        f,e=normalize_fact(r,i)
        if e:evidence_errors.append({'index':i,'evidence_id':r.get('evidence_id'),'errors':e})
        else:facts.append(f)
    ids=[f.evidence_id for f in facts];dups=sorted({x for x in ids if ids.count(x)>1})
    if dups:evidence_errors.append({'type':'DUPLICATE_EVIDENCE_ID','ids':dups})
    ambiguities=identity_ambiguities(facts,claims)
    if current_ctx is None:
        # A registry key/identity inconsistency is an evaluated global closure failure,
        # not merely an unavailable context.  Preserve explicit gate diagnostics for
        # post-prepare registry changes while still stopping before claim acceptance.
        registry_identity_ok=(relation_resolution_registry_key_identity_coherent()
                              and support_selection_registry_key_identity_coherent())
        return {'claims':[{'id':c.id,'status':c.status.value} for c in claims],
                'evidence_errors':evidence_errors,'identity_errors':identity_errors,
                'gates':({g:False for g in MANDATORY_GATES} if not registry_identity_ok else {}),
                'stop_type':'NONE','control_closure':False}
    audit_claims(claims,facts,current_ctx)
    cons=global_consistency(facts,current_ctx)
    rel=relation_coverage_violations(facts,current_ctx)
    sp=support_policy_violations(claims,facts,current_ctx,reqs) if reqs else [{'type':'INVALID_REQUIREMENTS'}]
    cv=coverage_violations(claims,reqs) if reqs else [{'type':'INVALID_REQUIREMENTS'}]
    if reqs:apply_support_policy_status(claims,facts,current_ctx,reqs)
    decision_dependency_graph=_decision_support_dependency_graph(claims,facts,current_ctx,reqs,registered_universes=True) if reqs else None
    decision_level_relation_universe=(make_decision_level_relation_universe(claims,facts,current_ctx,reqs,decision_dependency_graph,registered_universes=True)
                                      if reqs and decision_dependency_graph is not None else None)
    decision_level_source_relation_universe=(make_decision_level_source_relation_universe(claims,facts,current_ctx,reqs,decision_dependency_graph,registered_universes=True)
                                             if reqs and decision_dependency_graph is not None else None)
    decision_level_source_relation_assessments=(_decision_level_source_relation_assessments(claims,facts,current_ctx,reqs,decision_dependency_graph,registered_universes=True)
                                                if reqs and decision_dependency_graph is not None else tuple())
    decision_level_generic_dependency_universe=(make_decision_level_generic_dependency_universe(claims,facts,current_ctx,reqs,decision_dependency_graph,registered_universes=True)
                                                if reqs and decision_dependency_graph is not None else None)
    decision_level_generic_dependency_assessments=(_decision_level_generic_dependency_assessments(claims,facts,current_ctx,reqs,decision_dependency_graph,registered_universes=True)
                                                   if reqs and decision_dependency_graph is not None else tuple())
    decision_closure_cert=make_decision_support_closure_certificate(claims,facts,current_ctx,reqs) if reqs else None
    decision_closure_ok=decision_closure_cert is not None and validate_decision_support_closure_certificate(
        decision_closure_cert,claims,facts,current_ctx,reqs)
    certviol=[]
    for c in claims:
        if c.status==ClaimStatus.VERIFIED:
            if not validate_direct(c,c.certificate,facts,current_ctx):certviol.append(c.id);continue
            if c.id not in reqs or c.support_set_certificate is None or not validate_support_set_certificate(c.support_set_certificate,c,facts,current_ctx,reqs[c.id]):certviol.append(c.id)
    critical=[c.id for c in claims if c.status in {ClaimStatus.SUPPORTED,ClaimStatus.UNRESOLVED,ClaimStatus.QUARANTINED,ClaimStatus.HYPOTHETICAL}]
    sb=validate_binding(scope_binding,'SCOPE',current_ctx,policy)
    eb=validate_binding(extraction_binding,'EXTRACTION',current_ctx,policy)
    sa=validate_adequacy(scope_adequacy,'SCOPE',text,scope,claims,current_ctx)
    ea=validate_adequacy(extraction_adequacy,'EXTRACTION',text,extract,claims,current_ctx)
    gm=validate_gate_meta(gate_meta,asof)
    provcomp=all(validate_prov_complete(f.provenance_completeness,f.provenance,f.evidence_id) for f in facts) and len(facts)==len(evidence)
    provresolved=all(dependency_resolution_valid(f.provenance) for f in facts) and len(facts)==len(evidence)
    depjust=all(dependency_state_justification_valid(f.provenance) for f in facts) and len(facts)==len(evidence)
    dep_instance_ontology_ok=dependency_instance_ontology_conformance_valid(facts) and len(facts)==len(evidence)
    just_common_mode_ok=justification_common_mode_coverage_valid(claims,facts,current_ctx,reqs) if reqs else False
    source_semantics_ok=source_independence_semantics_valid(claims,facts,current_ctx,reqs) if reqs else False
    source_resolution_ok=source_failure_domain_resolution_complete_valid(claims,facts,current_ctx,reqs) if reqs else False
    set_common_mode_ok=support_set_common_mode_coverage_valid(claims,facts,current_ctx,reqs) if reqs else False
    relation_discovery_ok=decision_relevant_relation_discovery_complete_valid(claims,facts,current_ctx,reqs) if reqs else False
    relation_instance_coverage_ok=support_relation_instance_resolution_coverage_valid(claims,facts,current_ctx,reqs) if reqs else False
    support_selection_ok=support_selection_justification_valid(claims,facts,current_ctx,reqs) if reqs else False
    support_universe_coverage_ok=claim_support_universe_common_mode_coverage_valid(claims,facts,current_ctx,reqs) if reqs else False
    ontology_ok=dependency_ontology_adequate(asof,retrieval_scope)
    referent_ok=all(c.status!=ClaimStatus.VERIFIED or
                    (lambda f: f is not None and make_referent_consistency(c,f) is not None)
                    (next((f for f in facts if c.certificate and f.evidence_id==c.certificate.evidence_id),None))
                    for c in claims)
    meta=make_gate_meta(asof)
    gates={
        'claim_set_nonempty':bool(claims),'closure_policy_valid':pol_ok,
        'closure_policy_authorization_valid':auth_ok,'audit_context_valid':ctx_ok,
        'evidence_admission_valid':not evidence_errors,'unique_evidence_ids':not dups,
        'no_identity_ambiguity':not ambiguities,'identity_resolution_valid':not identity_errors,
        'provenance_completeness_valid':provcomp,'provenance_dependency_resolution_valid':provresolved,
        'dependency_state_justification_valid':depjust,'justification_common_mode_coverage_valid':just_common_mode_ok,
        'dependency_ontology_adequacy_valid':ontology_ok,'dependency_instance_ontology_conformance_valid':dep_instance_ontology_ok,
        'source_independence_semantics_valid':source_semantics_ok,
        'source_failure_domain_resolution_complete_valid':source_resolution_ok,
        'support_set_common_mode_coverage_valid':set_common_mode_ok,
        'decision_relevant_relation_discovery_complete_valid':relation_discovery_ok,
        'support_relation_instance_resolution_coverage_valid':relation_instance_coverage_ok,
        'claim_support_universe_common_mode_coverage_valid':support_universe_coverage_ok,
        'support_selection_justification_valid':support_selection_ok,
        'referent_consistency_valid':referent_ok,
        'evidence_id_universe_complete':cov_ok,'retrieval_snapshot_content_matches':integrity_ok,
        'retrieval_universe_membership_valid':universe_membership_ok,
        'claim_snapshot_projection_complete':projection_ok,
        'relational_claim_neighborhood_complete':relational_neighborhood_ok,
        'decision_relevant_snapshot_overlap_complete':overlap_ok,
        'cross_universe_evidence_closure_valid':overlap_ok and competition_ok,
        'snapshot_supersession_valid':supersession_ok,
        'decision_support_closure_valid':decision_closure_ok,
        'cross_group_snapshot_competition_resolved':competition_ok,
        'retrieval_universe_partition_adequate':partition_ok,
        'retrieval_snapshot_applicability_valid':applicability_ok,'snapshot_freshness_valid':freshness_ok,
        'global_consistency_valid':not cons,'constraint_relation_coverage_sufficient':not rel,
        'claim_specific_support_policy_valid':not sp,'constraint_coverage_sufficient':not cv,
        'no_critical_unresolved':not critical,'accepted_certificates_revalidate':not certviol,
        'scope_binding_valid':sb,'extraction_binding_valid':eb,'scope_adequacy_valid':sa,
        'extraction_adequacy_valid':ea,'meta_baseline_version_applicable':meta.meta_baseline_version_applicable,
        'gate_registry_binding_valid':gate_meta is not None and gate_meta.gate_registry_hash==gate_registry_hash(),
        'gate_registry_schema_complete':gm and meta.schema_complete and meta.live_spec_matches_pinned and meta.live_gate_map_matches_pinned,
        'gate_registry_adequate_for_closure_class':gm and meta.adequate_for_closure_class and meta.live_gate_registry_matches_pinned and meta.dependency_ontology_adequate and meta.source_independence_policy_adequate and meta.source_semantics_policy_adequate and meta.support_universe_policy_adequate and meta.relation_discovery_policy_adequate and meta.relation_resolution_policy_adequate,
    }
    # Backward-compatible diagnostic alias; not mandatory.
    gates['evidence_set_coverage_sufficient']=cov_ok
    closure_ready=all(gates.get(g) is True for g in MANDATORY_GATES)
    stop=StopType.RESOURCE_STOP if resource_exhausted is True else (StopType.EPISTEMIC_STOP if closure_ready else StopType.NONE)
    return {
        'claims':[{'id':c.id,'text':c.text,'status':c.status.value,'reason':c.reason,
                   'identity':None if c.identity is None else asdict(c.identity),
                   'certificate':None if c.certificate is None else asdict(c.certificate),
                   'support_set_certificate':None if c.support_set_certificate is None else asdict(c.support_set_certificate)} for c in claims],
        'accepted_evidence':[asdict(f) for f in facts],
        'evidence_errors':evidence_errors,'identity_errors':identity_errors,'identity_ambiguities':ambiguities,
        'global_consistency_violations':cons,'constraint_relation_coverage_violations':rel,
        'claim_support_policy_violations':sp,'constraint_coverage_violations':cv,
        'certificate_violations':certviol,'critical_unresolved':critical,
        'decision_support_closure_certificate':None if decision_closure_cert is None else asdict(decision_closure_cert),
        'decision_support_dependency_graph':None if decision_dependency_graph is None else {
            'graph_hash':decision_dependency_graph['graph_hash'],
            'claim_ids':decision_dependency_graph['claim_ids'],
            'selected_support_map':decision_dependency_graph['selected_support_map'],
            'matching_support_universe_map':decision_dependency_graph['matching_support_universe_map'],
            'node_ownership':decision_dependency_graph['node_ownership'],
            'justificatory_bridges':decision_dependency_graph['justificatory_bridges'],
            'source_relation_rows':decision_dependency_graph['source_relation_rows'],
            'path_relevant_source_edges':decision_dependency_graph['path_relevant_source_edges'],
            'path_relevant_source_edges_hash':decision_dependency_graph['path_relevant_source_edges_hash'],
        },
        'decision_level_relation_universe':None if decision_level_relation_universe is None else asdict(decision_level_relation_universe),
        'decision_level_source_relation_universe':None if decision_level_source_relation_universe is None else asdict(decision_level_source_relation_universe),
        'decision_level_source_relation_assessments':decision_level_source_relation_assessments,
        'decision_level_generic_dependency_universe':None if decision_level_generic_dependency_universe is None else asdict(decision_level_generic_dependency_universe),
        'decision_generic_representation_completeness_certificate':None if current_ctx is None else (None if GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY.get(current_ctx.audit_context_id) is None else asdict(GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY.get(current_ctx.audit_context_id))),
        'decision_level_generic_dependency_assessments':decision_level_generic_dependency_assessments,
        'matching_support_universes':[asdict(x) for x in MATCHING_SUPPORT_UNIVERSE_REGISTRY.values() if isinstance(x,MatchingSupportUniverse) and x.audit_context_id==current_ctx.audit_context_id],
        'decision_relevant_relation_universes':[asdict(x) for x in DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY.values() if isinstance(x,DecisionRelevantRelationUniverse) and x.audit_context_id==current_ctx.audit_context_id],
        'support_selection_certificates':[asdict(x) for x in SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values() if isinstance(x,SupportSelectionCertificate) and x.audit_context_id==current_ctx.audit_context_id],
        'claim_support_universe_coverage_certificates':[asdict(x) for x in CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values() if isinstance(x,ClaimSupportUniverseCoverageCertificate) and x.audit_context_id==current_ctx.audit_context_id],
        'relation_resolution_certificates':[asdict(x) for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values() if isinstance(x,RelationResolutionCertificate) and x.audit_context_id==current_ctx.audit_context_id],
        'excluded_support_disposition_certificates':[asdict(x) for x in EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY.values() if isinstance(x,ExcludedSupportDispositionCertificate) and x.audit_context_id==current_ctx.audit_context_id],
        'gates':gates,'stop_type':stop.value,'control_closure':stop==StopType.EPISTEMIC_STOP
    }


# ============================================================
# Self-tests
# ============================================================

def self_tests():
    global CLOSURE_CLASS_SPEC, OBLIGATION_GATE_MAP, MANDATORY_GATES, _SELF_TEST_FIXTURE_ROLE_AUTOREBIND, _SELF_TEST_ROLE_AUTHORITY_ACTIVE
    if _SELF_TEST_ROLE_AUTHORITY_ACTIVE or _SELF_TEST_SCOPE_GENERATION_ID is not None:
        exit_self_test_role_scope()
    enter_self_test_role_scope()
    _SELF_TEST_FIXTURE_ROLE_AUTOREBIND=True
    T=[]
    # R209: legacy self-tests reuse short fixture evidence labels across logically separate cases.
    # The first newly-created fixture evidence after a completed case starts a fresh generation,
    # while multiple evidence rows inside one case remain in the same generation.
    _fixture_case_boundary_pending=False
    def add(n,p):
        nonlocal _fixture_case_boundary_pending
        T.append({'name':n,'pass':bool(p)})
        _fixture_case_boundary_pending=True
    ASOF='2026-08-10';SCOPE=CANONICAL_SCOPE;EXTRACT=CANONICAL_EXTRACTION
    def dep(eid,override=None):
        d={dim:{'state':'KNOWN','id':f'{DEPENDENCY_PREFIX[dim]}:{eid}'} for dim in DEPENDENCY_DIMENSIONS}
        if override:d.update(override)
        return d
    def ev(eid,subject,predicate,value,ident,authority=None,ref_entity=None,ref_event=None,ref_version=None,record_entity=None,record_event=None,record_version=None,root=None,origin=None,group=None,lineage=None,extractor=None,source_id=None,source_semantics_id=None,vf='2026-01-01',vt='2026-12-31',obs=ASOF,avail=None,polarity='POSITIVE',dependencies=None,use_default_source_semantics=False,source_resolution_state='KNOWN'):
        nonlocal _fixture_case_boundary_pending
        if _fixture_case_boundary_pending:
            _rotate_self_test_scope_generation_if_active()
            _fixture_case_boundary_pending=False
        ir=IDENTITY_REGISTRY[ident];authority=authority or ('FLIGHT_RECORD_V5' if predicate=='date' else 'REGISTRY_RECORD_V5' if ir['domain_id']=='REGISTRY_ENTITY' else 'GENERAL_RECORD_V5')
        prefix={'FLIGHT_RECORD_V5':'flight-registry:','GENERAL_RECORD_V5':'general-record:','REGISTRY_RECORD_V5':'registry:'}[authority]
        root=root or f'{prefix}root:{eid}';origin=origin or f'{prefix}origin:{eid}';group=group or f'group:{eid}';extractor=extractor or f'extractor:{eid}';lineage=lineage or [root,origin];avail=avail or obs
        resolved_source_id=source_id or f'{prefix}{eid}'
        if source_semantics_id is None and not use_default_source_semantics:
            source_semantics_id='sem:auto:'+sha(resolved_source_id)[:20]
            if source_semantics_id not in SOURCE_SEMANTICS_REGISTRY:
                register_source_semantics(source_semantics_id,resolved_source_id,f'repo:auto:{sha(resolved_source_id)[:16]}',f'producer:auto:{sha(resolved_source_id)[:16]}',f'process:auto:{sha(resolved_source_id)[:16]}',f'fd:auto:{sha(resolved_source_id)[:16]}',resolution_state=source_resolution_state)
        rec={'evidence_id':eid,'subject':subject,'predicate':predicate,'value':value,'source':f'display:{eid}','polarity':polarity,'identity_registry_entry_id':ident,'authority_id':authority,'authority_record_entity_id':record_entity or ir['entity_id'],'authority_record_event_id':record_event or ir['event_id'],'authority_record_version_id':record_version or ir['version_id'],'valid_from':vf,'valid_to':vt,'observed_at':obs,'available_at':avail,'provenance':{'source_id':resolved_source_id,'root_origin_id':root,'origin_id':origin,'referent_entity_id':ref_entity or ir['entity_id'],'referent_event_id':ref_event or ir['event_id'],'referent_version_id':ref_version or ir['version_id'],'extractor_id':extractor,'common_mode_group':group,'lineage':lineage,'dependencies':dependencies or dep(eid)}}
        if source_semantics_id is not None:rec['source_semantics_id']=source_semantics_id
        try:_fixture_issue_evidence_epistemic_role(rec,'DIRECT_WORLD_RECORD',role_record_id=f'role:auto:{sha(rec)[:20]}')
        except ValueError:pass  # malformed negative fixtures must remain constructible so admission can reject them.
        return rec
    def _fixture_issue_set_certificates(text,e,cmap,req,retrieval,asof):
        facts=[]
        for i,r in enumerate(e,1):
            f,errs=normalize_fact(r,i)
            if errs:return
            facts.append(f)
        claims=parse_claims(text);attach_claim_identities(claims,cmap)
        try:reqs=normalize_requirements(claims,req)
        except:return
        class _Ctx: pass
        tmp=_Ctx();tmp.as_of_date=asof
        chosen=[]
        for c in claims:
            if c.predicate in {'hypothesis','unmodelled'} or c.id not in reqs:continue
            need=reqs[c.id]['required_independent_supports'];sup=matching_supports(c,facts,tmp)
            candidates=[(x,) for x in sup] if need==1 else list(combinations(sup,need))
            selected=None
            for ss in candidates:
                ss=tuple(ss)
                if need==1:
                    selected=ss;break
                ind,_=independent_subset(ss)
                if not ind:continue
                iid='fixture:set:'+sha((c.id,retrieval,sorted(f.evidence_id for f in ss)))[:24]
                try:
                    authorize_support_set_independence(iid,c.id,retrieval,ss,'legacy self-test fixture: explicit set-level independence')
                    issue_support_set_independence_certificate(iid,c.id,retrieval,ss)
                    selected=ss;break
                except ValueError:
                    continue
            if selected is not None:chosen.extend(selected)
        if len(claims)>1:
            union=tuple(sorted({f.evidence_id:f for f in chosen}.values(),key=lambda f:f.evidence_id))
            if len(union)>1:
                ind,_=independent_subset(union)
                if ind:
                    iid='fixture:decision:'+sha((retrieval,sorted(f.evidence_id for f in union)))[:24]
                    try:
                        authorize_support_set_independence(iid,'__DECISION__',retrieval,union,'legacy self-test fixture: explicit decision-level independence')
                        issue_support_set_independence_certificate(iid,'__DECISION__',retrieval,union)
                    except ValueError:
                        pass

    def run(text,e,cmap,req=None,waivers=None,asof=ASOF,scope=SCOPE,extract=EXTRACT,retrieval=None,auto_set_certificates=True):
        auto_scope=retrieval is None
        backup=dict(RETRIEVAL_SCOPE_REGISTRY) if auto_scope else None
        if auto_scope:
            RETRIEVAL_SCOPE_REGISTRY.clear()
            retrieval=f'fixture:{sha(e)[:12]}'
        try:
            if retrieval not in RETRIEVAL_SCOPE_REGISTRY:
                try:
                    _register_fixture_retrieval_scope(retrieval,e,f'snapshot:{retrieval}')
                except ValueError as exc:
                    return {'evidence_errors':[{'type':'RETRIEVAL_FIXTURE_ERROR','error':str(exc)}],
                            'identity_errors':[],'identity_ambiguities':[],'claims':[],
                            'global_consistency_violations':[],'constraint_relation_coverage_violations':[],
                            'claim_support_policy_violations':[],'constraint_coverage_violations':[],
                            'certificate_violations':[],'critical_unresolved':[],
                            'gates':{},'stop_type':'NONE','control_closure':False}
            if auto_set_certificates:
                _fixture_issue_set_certificates(text,e,cmap,req,retrieval,asof)
            bundle=prepare(text,e,cmap,asof,scope,extract,retrieval,req,waivers)
            return audit_text(text,e,cmap,asof,scope,extract,retrieval,req,waivers,*bundle)
        finally:
            if auto_scope:
                RETRIEVAL_SCOPE_REGISTRY.clear()
                RETRIEVAL_SCOPE_REGISTRY.update(backup)

    # 1 baseline
    add('baseline_referent_consistent_closes',run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1')],{'c1':'id:alice:v1'})['control_closure'])
    # R12 strongest
    bad=ev('E1','ID:ABC123','state','safe','id:registry:ABC123:v1',ref_entity='entity:XYZ999')
    out=run('ID:ABC123 is safe.',[bad],{'c1':'id:registry:ABC123:v1'})
    add('cross_certificate_provenance_referent_mismatch_blocks',bool(out['evidence_errors']) and out['stop_type']=='NONE')
    bad=ev('E1','ID:ABC123','state','safe','id:registry:ABC123:v1',record_entity='entity:XYZ999')
    out=run('ID:ABC123 is safe.',[bad],{'c1':'id:registry:ABC123:v1'})
    add('authority_record_referent_mismatch_blocks',bool(out['evidence_errors']))
    # claim/evidence identity mismatch
    bad=ev('E1','Bob','state','safe','id:bob:v1')
    out=run('Alice is safe.',[bad],{'c1':'id:alice:v1'})
    add('claim_evidence_entity_mismatch_not_verified',out['claims'][0]['status']=='UNRESOLVED')
    # general name requires explicit claim identity
    out=run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1')],{})
    add('missing_claim_identity_blocks',bool(out['identity_errors']) and out['stop_type']=='NONE')
    # exact same surface but different registry identity: add fixture alias
    IDENTITY_REGISTRY['id:alice:other']={'surface_subject':'Alice','domain_id':'GENERAL_ENTITY','entity_id':'entity:alice-other','event_id':'event:current','version_id':'v1'}
    bad=ev('E1','Alice','state','safe','id:alice:other')
    out=run('Alice is safe.',[bad],{'c1':'id:alice:v1'})
    add('same_surface_different_entity_not_support',out['claims'][0]['status']=='UNRESOLVED')
    del IDENTITY_REGISTRY['id:alice:other']

    # NONE/UNKNOWN semantics
    d=dep('E1');d['sensor_input']={'state':'UNKNOWN'}
    add('unknown_dependency_blocks_admission',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    d=dep('E1');d['sensor_input']={'state':'UNRESOLVED'}
    add('unresolved_dependency_blocks_admission',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    _register_fixture_dependency_justification('just:sensor:none','sensor_input','KNOWN_NONE','certified no sensor dependency')
    d=dep('E1');d['sensor_input']={'state':'KNOWN_NONE','justification_id':'just:sensor:none'}
    add('known_none_requires_and_accepts_justification',run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['control_closure'])
    _register_fixture_dependency_justification('just:sensor:na','sensor_input','NOT_APPLICABLE','sensor dimension not applicable for this source class')
    d=dep('E1');d['sensor_input']={'state':'NOT_APPLICABLE','justification_id':'just:sensor:na'}
    add('not_applicable_requires_and_accepts_justification',run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['control_closure'])
    d=dep('E1');d['sensor_input']={'state':'NOT_APPLICABLE'}
    add('unjustified_not_applicable_rejected',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    # legacy NONE string rejected
    d={dim:'NONE' for dim in DEPENDENCY_DIMENSIONS}
    add('legacy_none_strings_rejected',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    # canonical dependency identity sensor:S1 vs S1
    d1=dep('E1',{'sensor_input':{'state':'KNOWN','id':'sensor:S1'}});d2=dep('E2',{'sensor_input':{'state':'KNOWN','id':'S1'}})
    e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='A',extractor='XA',dependencies=d1),ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='B',extractor='XB',dependencies=d2)]
    out=run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('dependency_aliases_canonicalize_and_block_false_independence',bool(out['claim_support_policy_violations']))

    # evidence set coverage + snapshot content integrity
    RETRIEVAL_SCOPE_REGISTRY.clear()
    e_ref=[ev('E_SAFE','Alice','state','safe','id:alice:v1'),
           ev('E_NOT_SAFE','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')]
    scope='retrieval:alice:safety:full'
    _register_fixture_retrieval_scope(scope,e_ref,'snapshot:alice:safety')
    e=[e_ref[0]]
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,scope)
    add('missing_expected_evidence_blocks_id_coverage',bundle[2] is None)
    out=run('Alice is safe.',e_ref,{'c1':'id:alice:v1'},retrieval=scope)
    add('complete_authentic_snapshot_exposes_conflict',out['stop_type']=='NONE' and out['claims'][0]['status']=='QUARANTINED')
    e_sub=[e_ref[0],dict(e_ref[1])]
    e_sub[1]['polarity']='POSITIVE'
    bundle=prepare('Alice is safe.',e_sub,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,scope,{'c1':{'required_independent_supports':2}})
    add('same_ids_substituted_payload_blocks_snapshot_integrity',bundle[2] is not None and bundle[3] is None)
    # unregistered retrieval scope blocks
    e=[ev('E1','Alice','state','safe','id:alice:v1')]
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'retrieval:unregistered')
    add('unregistered_retrieval_scope_blocks',bundle[2] is None)

    # Gate meta adequacy
    gm=make_gate_meta();add('gate_meta_schema_complete',gm.schema_complete);add('gate_meta_adequate',gm.adequate_for_closure_class)
    add('referent_obligation_mapped',OBLIGATION_GATE_MAP['subject_provenance_referent_consistent']=='referent_consistency_valid')
    add('evidence_id_coverage_obligation_mapped',OBLIGATION_GATE_MAP['evidence_id_universe_coverage']=='evidence_id_universe_complete')
    add('snapshot_content_obligation_mapped',OBLIGATION_GATE_MAP['retrieval_snapshot_content_integrity']=='retrieval_snapshot_content_matches')
    add('dependency_justification_obligation_mapped',OBLIGATION_GATE_MAP['dependency_state_justification']=='dependency_state_justification_valid')

    # R11 temporal
    future=ev('E1','Alice','state','safe','id:alice:v1',vf='2026-01-01',vt='2026-12-31',obs='2026-12-01',avail='2026-12-01')
    out=run('Alice is safe.',[future],{'c1':'id:alice:v1'},asof='2026-01-15')
    add('future_observation_still_blocks',out['claims'][0]['status']=='UNRESOLVED')
    delayed=ev('E1','Alice','state','safe','id:alice:v1',obs='2026-01-10',avail='2026-02-01')
    add('delayed_availability_still_blocks',run('Alice is safe.',[delayed],{'c1':'id:alice:v1'},asof='2026-01-15')['stop_type']=='NONE')
    badtime=ev('E1','Alice','state','safe','id:alice:v1',obs='2026-02-01',avail='2026-01-01')
    add('available_before_observed_rejected',bool(run('Alice is safe.',[badtime],{'c1':'id:alice:v1'})['evidence_errors']))

    # constraint relation coverage
    e=[ev('E1','Alice','state','safe','id:alice:v1'),ev('E2','Alice','state','dangerous','id:alice:v1')]
    add('safe_dangerous_unknown_relation_blocks',bool(run('Alice is safe.',e,{'c1':'id:alice:v1'})['constraint_relation_coverage_violations']))
    e=[ev('E1','Alice','state','safe','id:alice:v1'),ev('E2','Alice','state','unsafe','id:alice:v1')]
    add('safe_unsafe_conflict_blocks',bool(run('Alice is safe. Alice is unsafe.',e,{'c1':'id:alice:v1','c2':'id:alice:v1'})['global_consistency_violations']))
    add('calm_unknown_constraint_blocks',bool(run('Alice is calm.',[ev('E1','Alice','state','calm','id:alice:v1')],{'c1':'id:alice:v1'})['constraint_coverage_violations']))

    # optout authorization
    out=run('Alice is calm.',[ev('E1','Alice','state','calm','id:alice:v1')],{'c1':'id:alice:v1'},{'c1':{'require_constraint_coverage':False}})
    add('coverage_optout_without_waiver_blocks',out['stop_type']=='NONE')
    out=run('Alice is calm.',[ev('E1','Alice','state','calm','id:alice:v1')],{'c1':'id:alice:v1'},{'c1':{'require_constraint_coverage':False}},{'c1':'waiver:calm-local-test'})
    add('authorized_waiver_can_close',out['control_closure'])

    # lineage/common-mode retained
    shared='upstream:shared';e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='A',lineage=['general-record:rA',shared,'general-record:oA'],extractor='XA'),ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='B',lineage=['general-record:rB',shared,'general-record:oB'],extractor='XB')]
    add('shared_lineage_blocks',bool(run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})['claim_support_policy_violations']))
    # claim-specific not pooled
    e=[ev('E1','Alice','state','safe','id:alice:v1'),ev('E2','Bob','state','safe','id:bob:v1')]
    out=run('Alice is safe. Bob is safe.',e,{'c1':'id:alice:v1','c2':'id:bob:v1'},{'c1':{'required_independent_supports':2},'c2':{'required_independent_supports':1}})
    add('support_not_pooled_across_claims',any(v.get('claim_id')=='c1' for v in out['claim_support_policy_violations']))

    # authority/domain regressions
    bad=ev('E1','flight','date','2025-09-19','id:flight:v1',authority='GENERAL_RECORD_V5',source_id='general-record:E1',root='general-record:r',origin='general-record:o')
    add('wrong_authority_domain_rejected',bool(run('The flight date is 2025-09-19.',[bad],{'c1':'id:flight:v1'})['evidence_errors']))
    good=ev('E1','flight','date','2025-09-19','id:flight:v1')
    add('flight_exact_identity_closes',run('The flight date is 2025-09-19.',[good],{'c1':'id:flight:v1'})['control_closure'])
    reg=ev('E1','ID:ABC123','state','safe','id:registry:ABC123:v1')
    add('registry_exact_identity_closes',run('ID:ABC123 is safe.',[reg],{'c1':'id:registry:ABC123:v1'})['control_closure'])

    # scope/extraction adequacy
    add('wrong_scope_blocks',run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1')],{'c1':'id:alice:v1'},scope='IGNORE')['stop_type']=='NONE')
    add('wrong_extraction_blocks',run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1')],{'c1':'id:alice:v1'},extract='IGNORE')['stop_type']=='NONE')
    add('unmodelled_parser_blocks',run('Free form unparsed sentence.',[],{})['stop_type']=='NONE')

    # semantic regressions
    bad=ev('E1','flight','date','2025-02-30','id:flight:v1')
    add('invalid_calendar_rejected',bool(run('The flight date is 2025-02-30.',[bad],{'c1':'id:flight:v1'})['evidence_errors']))
    add('unknown_value_rejected',bool(run('Alice is unknown.',[ev('E1','Alice','state','unknown','id:alice:v1')],{'c1':'id:alice:v1'})['evidence_errors']))
    # alias ambiguity
    e=[ev('E1',"O'Connor",'state','safe','id:oconnor:v1')]
    out=run("O'Connor is safe.",e,{'c1':'id:oconnor:v1'})
    add('unicode_alias_baseline_valid',out['control_closure'])

    # cardinality/history
    e=[ev('E1','Alice','location','London','id:alice:v1'),ev('E2','Alice','location','Paris','id:alice:v1')]
    add('location_conflict_blocks',bool(run('Alice is in London. Alice is in Paris.',e,{'c1':'id:alice:v1','c2':'id:alice:v1'})['global_consistency_violations']))
    e=[ev('E1','flight','date','2025-09-18','id:flight:v1',vf='2025-01-01',vt='2025-12-31',obs='2025-06-01',avail='2025-06-02'),ev('E2','flight','date','2025-09-19','id:flight:v1')]
    add('nonoverlap_history_no_false_conflict',not run('The flight date is 2025-09-19.',e,{'c1':'id:flight:v1'})['global_consistency_violations'])

    # context/policy changes
    RETRIEVAL_SCOPE_REGISTRY.clear()
    e=[ev('E1','Alice','state','safe','id:alice:v1')];ret='fixture:ctx';_register_fixture_retrieval_scope(ret,e,'snapshot:ctx')
    b1=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':1}})
    b2=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':2}})
    add('policy_change_changes_context',b1[4].audit_context_id!=b2[4].audit_context_id)
    # identity map changes context
    IDENTITY_REGISTRY['id:alice:other']={'surface_subject':'Alice','domain_id':'GENERAL_ENTITY','entity_id':'entity:alice-other','event_id':'event:current','version_id':'v1'}
    b3=prepare('Alice is safe.',e,{'c1':'id:alice:other'},ASOF,SCOPE,EXTRACT,ret)
    add('claim_identity_map_change_requires_applicable_snapshot',b3[4] is None)
    del IDENTITY_REGISTRY['id:alice:other']

    # tamper tests
    p,a,cov,integ,ctx,sb,eb,sa,ea,gm=b1
    badctx=AuditContextCertificate(**{**asdict(ctx),'certificate_id':'FAKE'})
    out=audit_text('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':1}},None,p,a,cov,integ,badctx,sb,eb,sa,ea,gm)
    add('context_tamper_blocks',out['stop_type']=='NONE')
    badcov=EvidenceSetCoverageCertificate(**{**asdict(cov),'certificate_id':'FAKE'})
    out=audit_text('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':1}},None,p,a,badcov,integ,ctx,sb,eb,sa,ea,gm)
    add('coverage_cert_tamper_blocks',out['stop_type']=='NONE')
    badinteg=SnapshotContentIntegrityCertificate(**{**asdict(integ),'certificate_id':'FAKE'})
    out=audit_text('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':1}},None,p,a,cov,badinteg,ctx,sb,eb,sa,ea,gm)
    add('snapshot_integrity_cert_tamper_blocks',out['stop_type']=='NONE')
    badgm=GateMetaAdequacyCertificate(**{**asdict(gm),'certificate_id':'FAKE'})
    out=audit_text('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,{'c1':{'required_independent_supports':1}},None,p,a,cov,integ,ctx,sb,eb,sa,ea,badgm)
    add('gate_meta_tamper_blocks',out['stop_type']=='NONE')

    # resource / empty / hypothesis / duplicates
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret)
    out=audit_text('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret,None,None,*bundle,resource_exhausted=True)
    add('resource_stop_distinct',out['stop_type']=='RESOURCE_STOP' and not out['control_closure'])
    add('empty_claim_set_blocks',run('',[],{})['stop_type']=='NONE')
    add('hypothesis_blocks',run('Maybe Alice is safe.',[],{})['stop_type']=='NONE')
    e2=[ev('E1','Alice','state','safe','id:alice:v1'),ev('E1','Alice','state','safe','id:alice:v1')]
    add('duplicate_ids_block',bool(run('Alice is safe.',e2,{'c1':'id:alice:v1'})['evidence_errors']))

    # registry fingerprints
    add('all_registry_hashes_present',all(len(x)==64 for x in [identity_registry_hash(),constraint_registry_hash(),authority_registry_hash(),provenance_policy_hash(),temporal_profile_hash(),control_profile_hash(),retrieval_registry_hash(),dependency_justification_registry_hash(),closure_class_spec_hash(),gate_registry_hash(),pinned_meta_authority_hash(),authorization_registry_hash()]))
    add('mandatory_gate_referent_present','referent_consistency_valid' in MANDATORY_GATES)
    add('mandatory_gate_evidence_id_coverage_present','evidence_id_universe_complete' in MANDATORY_GATES)
    add('mandatory_gate_snapshot_content_present','retrieval_snapshot_content_matches' in MANDATORY_GATES)
    add('mandatory_gate_dependency_justification_present','dependency_state_justification_valid' in MANDATORY_GATES)
    add('mandatory_gate_dependency_resolution_present','provenance_dependency_resolution_valid' in MANDATORY_GATES)

    # additional carried-forward regression checks
    bad=ev('E1','Alice','state','safe','id:alice:v1',source_id='banana')
    add('authority_source_namespace_still_enforced',bool(run('Alice is safe.',[bad],{'c1':'id:alice:v1'})['evidence_errors']))
    bad=ev('E1','Alice','state','safe','id:alice:v1',root='banana-root',origin='banana-origin',lineage=['banana-root','banana-origin'])
    add('authority_root_namespace_still_enforced',bool(run('Alice is safe.',[bad],{'c1':'id:alice:v1'})['evidence_errors']))
    bad=ev('E1','Alice','state','safe','id:alice:v1');bad['provenance']['lineage']=[bad['provenance']['root_origin_id'],'x','x',bad['provenance']['origin_id']]
    add('duplicate_lineage_node_rejected',bool(run('Alice is safe.',[bad],{'c1':'id:alice:v1'})['evidence_errors']))
    d=dep('E1');d.pop('sensor_input')
    add('missing_dependency_dimension_rejected',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    d=dep('E1');d['extra']={'state':'KNOWN','id':'extra:X'}
    add('extra_dependency_dimension_rejected',bool(run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1',dependencies=d)],{'c1':'id:alice:v1'})['evidence_errors']))
    e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='shared',extractor='XA'),ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='shared',extractor='XB')]
    add('same_common_mode_group_blocks',bool(run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})['claim_support_policy_violations']))
    e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='A',extractor='X'),ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='B',extractor='X')]
    add('same_extractor_blocks',bool(run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})['claim_support_policy_violations']))
    e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='A',extractor='XA'),ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='B',extractor='XB')]
    add('two_independent_supports_can_close',run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})['control_closure'])
    add('three_required_two_available_blocks',bool(run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':3}})['claim_support_policy_violations']))
    out=run('Alice is safe.',[ev('E1','Alice','state','safe','id:alice:v1')],{'c1':'id:alice:v1'},{'c1':{'require_constraint_coverage':False}},{'c1':'waiver:calm-local-test'})
    add('waiver_not_transferable_to_other_value',out['stop_type']=='NONE')
    out=run('Alice is calm.',[ev('E1','Alice','state','calm','id:alice:v1')],{'c1':'id:alice:v1'},{'c1':{'require_constraint_coverage':False}},{'c1':'waiver:calm-local-test'},asof='2027-01-01')
    add('expired_waiver_blocks',out['stop_type']=='NONE')
    add('blank_policy_id_rejected',make_policy(parse_claims('Alice is safe.'),policy_id='') is None)
    # clean bundle tamper checks
    RETRIEVAL_SCOPE_REGISTRY.clear()
    clean_e=[ev('E1','Alice','state','safe','id:alice:v1')];ret2='fixture:tamper';_register_fixture_retrieval_scope(ret2,clean_e,'snapshot:tamper')
    pp,aa,ccov,ci,cctx,ssb,eeb,ssa,eea,ggm=prepare('Alice is safe.',clean_e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,ret2)
    f,_=normalize_fact(clean_e[0],1);cl=parse_claims('Alice is safe.')[0];attach_claim_identities([cl],{'c1':'id:alice:v1'});dc=make_direct(cl,f,cctx)
    baddc=DirectCertificate(**{**asdict(dc),'audit_context_id':'FAKE'})
    add('direct_context_tamper_rejected',not validate_direct(cl,baddc,[f],cctx))
    badt=TemporalCertificate(**{**asdict(f.temporal),'certificate_id':'FAKE'})
    add('temporal_certificate_tamper_rejected',not validate_temporal(badt))
    badprov=ProvenanceCertificate(**{**asdict(f.provenance),'certificate_id':'FAKE'})
    add('provenance_certificate_tamper_rejected',not validate_provenance(badprov,f.evidence_id))
    badid=IdentityCertificate(**{**asdict(f.identity),'certificate_id':'FAKE'})
    add('identity_certificate_tamper_rejected',not validate_identity(badid,'EVIDENCE',f.evidence_id,f.subject,f.identity.registry_entry_id))
    e=[ev('E1','Door','state','locked','id:door:v1'),ev('E2','Door','state','unlocked','id:door:v1')]
    add('locked_unlocked_conflict_retained',bool(run('Door is locked. Door is unlocked.',e,{'c1':'id:door:v1','c2':'id:door:v1'})['global_consistency_violations']))
    e=[ev('E1','Alice','state','active','id:alice:v1'),ev('E2','Alice','state','inactive','id:alice:v1')]
    add('active_inactive_conflict_retained',bool(run('Alice is active. Alice is inactive.',e,{'c1':'id:alice:v1','c2':'id:alice:v1'})['global_consistency_violations']))
    e=[ev('E1','Alice','state','open','id:alice:v1'),ev('E2','Alice','state','closed','id:alice:v1')]
    add('open_closed_conflict_retained',bool(run('Alice is open. Alice is closed.',e,{'c1':'id:alice:v1','c2':'id:alice:v1'})['global_consistency_violations']))
    stale=ev('E1','Alice','state','safe','id:alice:v1',vf='2020-01-01',vt='2020-12-31',obs='2020-06-01',avail='2020-06-02')
    add('stale_evidence_still_blocks_current_claim',run('Alice is safe.',[stale],{'c1':'id:alice:v1'})['claims'][0]['status']=='UNRESOLVED')

    # R13 pinned meta-authority: coordinated runtime downgrade must fail meta-adequacy.
    saved_spec=CLOSURE_CLASS_SPEC; saved_map=OBLIGATION_GATE_MAP; saved_gates=MANDATORY_GATES
    try:
        CLOSURE_CLASS_SPEC={'closure_class':CLOSURE_CLASS,
                            'obligations':tuple(o for o in PINNED_CLOSURE_CLASS_SPEC['obligations']
                                                if o!='constraint_relation_coverage')}
        OBLIGATION_GATE_MAP={k:v for k,v in PINNED_OBLIGATION_GATE_MAP.items()
                             if k!='constraint_relation_coverage'}
        MANDATORY_GATES=tuple(g for g in PINNED_MANDATORY_GATES
                              if g!='constraint_relation_coverage_sufficient')
        downgraded=make_gate_meta()
        add('coordinated_meta_spec_downgrade_detected_by_pinned_authority',
            not downgraded.adequate_for_closure_class
            and not downgraded.live_spec_matches_pinned
            and not downgraded.live_gate_map_matches_pinned
            and not downgraded.live_gate_registry_matches_pinned)
    finally:
        CLOSURE_CLASS_SPEC=saved_spec; OBLIGATION_GATE_MAP=saved_map; MANDATORY_GATES=saved_gates

    # Same justification shared by two NOT_APPLICABLE supports is itself common-mode and blocks independence.
    _register_fixture_dependency_justification('just:all:na','sensor_input','NOT_APPLICABLE','same applicability ruling')
    d1=dep('E1',{'sensor_input':{'state':'NOT_APPLICABLE','justification_id':'just:all:na'}})
    d2=dep('E2',{'sensor_input':{'state':'NOT_APPLICABLE','justification_id':'just:all:na'}})
    e=[ev('E1','Alice','state','safe','id:alice:v1',root='general-record:rA',origin='general-record:oA',group='A',extractor='XA',dependencies=d1),
       ev('E2','Alice','state','safe','id:alice:v1',root='general-record:rB',origin='general-record:oB',group='B',extractor='XB',dependencies=d2)]
    out=run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('shared_not_applicable_justification_blocks_independence',bool(out['claim_support_policy_violations']))

    # Status semantics: direct support is not yet policy-satisfied verification.
    one=[ev('SS1','Alice','state','safe','id:alice:v1')]
    out=run('Alice is safe.',one,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('direct_support_below_requirement_is_supported_not_verified',out['claims'][0]['status']=='SUPPORTED' and out['stop_type']=='NONE')
    two=[ev('SS1','Alice','state','safe','id:alice:v1',root='general-record:ssr1',origin='general-record:sso1',group='SSG1',extractor='SSX1'),
         ev('SS2','Alice','state','safe','id:alice:v1',root='general-record:ssr2',origin='general-record:sso2',group='SSG2',extractor='SSX2')]
    out=run('Alice is safe.',two,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('verified_requires_policy_satisfied_support_set',out['claims'][0]['status']=='VERIFIED' and out['claims'][0]['support_set_certificate'] is not None and out['control_closure'])

    # R14: justification-ID splitting/common-mode laundering must be blocked.
    _register_fixture_dependency_justification('just:na:1','sensor_input','NOT_APPLICABLE','same applicability ruling',
                                               authority_id='LOCAL_DEPENDENCY_AUTHORITY',scope_id='dependency-policy:v0.2.18',
                                               rule_id='rule:shared-na',source_id='just-source:shared',validator_id='validator:shared')
    _register_fixture_dependency_justification('just:na:2','sensor_input','NOT_APPLICABLE','same applicability ruling',
                                               authority_id='LOCAL_DEPENDENCY_AUTHORITY',scope_id='dependency-policy:v0.2.18',
                                               rule_id='rule:shared-na',source_id='just-source:shared',validator_id='validator:shared')
    d1=dep('J1',{'sensor_input':{'state':'NOT_APPLICABLE','justification_id':'just:na:1'}})
    d2=dep('J2',{'sensor_input':{'state':'NOT_APPLICABLE','justification_id':'just:na:2'}})
    e=[ev('J1','Alice','state','safe','id:alice:v1',root='general-record:rJ1',origin='general-record:oJ1',group='JG1',extractor='JX1',dependencies=d1),
       ev('J2','Alice','state','safe','id:alice:v1',root='general-record:rJ2',origin='general-record:oJ2',group='JG2',extractor='JX2',dependencies=d2)]
    out=run('Alice is safe.',e,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('justification_id_splitting_common_mode_blocks',bool(out['claim_support_policy_violations']) and out['stop_type']=='NONE')
    f1,_=normalize_fact(e[0],1);f2,_=normalize_fact(e[1],2)
    ind,shared=independent_subset((f1,f2))
    add('different_justification_ids_same_failure_channel_not_independent',(not ind) and any(x[0] in {'JUSTIFICATION','DEPENDENCY_STATE'} for x in shared))

    # R14: snapshot/scope shopping must be blocked inside one controller-owned applicability group.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    partial=[ev('S_POS','Alice','state','safe','id:alice:v1')]
    full=[partial[0],ev('S_NEG','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')]
    group='retrieval-group:alice:safety'
    _register_fixture_retrieval_scope('scope:partial',partial,'snapshot:partial',applicability_group_id=group,snapshot_version=1)
    _register_fixture_retrieval_scope('scope:full',full,'snapshot:full',applicability_group_id=group,snapshot_version=2,supersedes='scope:partial')
    bpartial=prepare('Alice is safe.',partial,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:partial')
    add('older_partial_snapshot_shopping_blocked',bpartial[4] is None)
    bfull=prepare('Alice is safe.',full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:full')
    out=audit_text('Alice is safe.',full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:full',None,None,*bfull)
    add('latest_applicable_snapshot_selected_and_conflict_seen',bfull[4] is not None and out['stop_type']=='NONE' and out['claims'][0]['status']=='QUARANTINED')

    # R14: freshness/applicability metadata must be active for audit as_of.
    stale_snap=[ev('SF','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:stale-snapshot',stale_snap,'snapshot:stale',
                                       snapshot_created_at='2025-01-01',snapshot_available_at='2025-01-02',
                                       valid_from='2025-01-01',valid_to='2025-12-31',snapshot_version=1)
    bstale=prepare('Alice is safe.',stale_snap,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:stale-snapshot')
    add('stale_snapshot_not_applicable_to_current_asof',bstale[4] is None)

    future_snap=[ev('SFuture','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:future-snapshot',future_snap,'snapshot:future',
                                       snapshot_created_at='2026-09-01',snapshot_available_at='2026-09-02',
                                       valid_from='2026-01-01',valid_to='2027-12-31',snapshot_version=1)
    bfuture=prepare('Alice is safe.',future_snap,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:future-snapshot')
    add('future_snapshot_availability_blocks',bfuture[4] is None)

    # Meta baseline / dependency ontology version applicability.
    meta_expired=make_gate_meta('2100-01-01')
    add('expired_meta_baseline_blocks',not meta_expired.meta_baseline_version_applicable and not meta_expired.adequate_for_closure_class)
    saved_prefix=DEPENDENCY_PREFIX['sensor_input']
    try:
        DEPENDENCY_PREFIX['sensor_input']='sensor-mutated'
        add('dependency_ontology_runtime_mutation_detected',not dependency_ontology_adequate(ASOF))
    finally:
        DEPENDENCY_PREFIX['sensor_input']=saved_prefix

    add('mandatory_gate_justification_common_mode_present','justification_common_mode_coverage_valid' in MANDATORY_GATES)
    add('mandatory_gate_snapshot_applicability_present','retrieval_snapshot_applicability_valid' in MANDATORY_GATES)
    add('mandatory_gate_snapshot_freshness_present','snapshot_freshness_valid' in MANDATORY_GATES)
    add('mandatory_gate_dependency_ontology_present','dependency_ontology_adequacy_valid' in MANDATORY_GATES)
    add('mandatory_gate_meta_version_present','meta_baseline_version_applicable' in MANDATORY_GATES)

    # R15: cross-group snapshot shopping must be blocked by controller-derived retrieval universe.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    cg_partial=[ev('CGP1','Alice','state','safe','id:alice:v1',root='general-record:cg:r1',origin='general-record:cg:o1',group='CG1',extractor='CGX1'),
                ev('CGP2','Alice','state','safe','id:alice:v1',root='general-record:cg:r2',origin='general-record:cg:o2',group='CG2',extractor='CGX2')]
    cg_full=[cg_partial[0],cg_partial[1],ev('CGN1','Alice','state','safe','id:alice:v1',polarity='NEGATIVE',
                                           root='general-record:cg:r3',origin='general-record:cg:o3',group='CG3',extractor='CGX3')]
    _register_fixture_retrieval_scope('scope:cg:partial',cg_partial,'snapshot:cg:partial',
                                      applicability_group_id='group:A',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:cg:full',cg_full,'snapshot:cg:full',
                                      applicability_group_id='group:B',snapshot_version=2,
                                      supersedes='scope:cg:partial')
    bcgp=prepare('Alice is safe.',cg_partial,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:cg:partial',
                 {'c1':{'required_independent_supports':2}})
    add('cross_group_older_partial_snapshot_blocked',bcgp[4] is None)
    bcgf=prepare('Alice is safe.',cg_full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:cg:full',
                 {'c1':{'required_independent_supports':2}})
    out=audit_text('Alice is safe.',cg_full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:cg:full',
                   {'c1':{'required_independent_supports':2}},None,*bcgf)
    add('cross_group_latest_snapshot_selected_and_conflict_seen',
        bcgf[4] is not None and out['claims'][0]['status']=='QUARANTINED' and out['stop_type']=='NONE')

    # Equal highest version across groups is ambiguous -> fail closed.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    tie1=[ev('TIE1','Alice','state','safe','id:alice:v1')]
    tie2=[ev('TIE2','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:tie:A',tie1,'snapshot:tie:A',applicability_group_id='tie:A',snapshot_version=7)
    _register_fixture_retrieval_scope('scope:tie:B',tie2,'snapshot:tie:B',applicability_group_id='tie:B',snapshot_version=7)
    add('equal_highest_cross_group_snapshot_tie_blocks',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:tie:A',ASOF) is None
        and make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:tie:B',ASOF) is None)

    # Caller cannot invent a universe ID inconsistent with controller-derived scope identity.
    bogus=[ev('BG1','Bob','state','safe','id:bob:v1')]
    rejected=False
    try:
        _register_fixture_retrieval_scope('scope:bogus-universe',bogus,'snapshot:bogus',
                                          retrieval_universe_id='retrieval-universe:caller-picked')
    except ValueError:
        rejected=True
    add('caller_supplied_wrong_retrieval_universe_rejected',rejected)

    # Different real decision universes must not compete.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    alice=[ev('UA','Alice','state','safe','id:alice:v1')]
    bob=[ev('UB','Bob','state','safe','id:bob:v1')]
    _register_fixture_retrieval_scope('scope:universe:alice',alice,'snapshot:UA',applicability_group_id='cross:X',snapshot_version=3)
    _register_fixture_retrieval_scope('scope:universe:bob',bob,'snapshot:UB',applicability_group_id='cross:X',snapshot_version=99)
    add('different_entity_universes_do_not_compete',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:universe:alice',ASOF) is not None)

    # Registry mutation that tries to split one signature into another universe is detected.
    saved_universe=RETRIEVAL_SCOPE_REGISTRY['scope:universe:alice']['retrieval_universe_id']
    try:
        RETRIEVAL_SCOPE_REGISTRY['scope:universe:alice']['retrieval_universe_id']='retrieval-universe:tampered'
        add('retrieval_universe_membership_tamper_detected',
            not retrieval_universe_membership_valid('scope:universe:alice'))
        add('retrieval_universe_partition_tamper_detected',
            not retrieval_universe_partition_adequate(ASOF))
    finally:
        RETRIEVAL_SCOPE_REGISTRY['scope:universe:alice']['retrieval_universe_id']=saved_universe

    # Competition certificate is context-sensitive to registry state.
    comp_before=make_snapshot_competition('Bob is safe.',{'c1':'id:bob:v1'},SCOPE,'scope:universe:bob',ASOF)
    bob_new=[ev('UB2','Bob','state','safe','id:bob:v1')]
    _register_fixture_retrieval_scope('scope:universe:bob:new',bob_new,'snapshot:UB2',
                                      applicability_group_id='cross:Y',snapshot_version=100,
                                      supersedes='scope:universe:bob',retracted_evidence_ids=['UB'])
    comp_old=make_snapshot_competition('Bob is safe.',{'c1':'id:bob:v1'},SCOPE,'scope:universe:bob',ASOF)
    comp_new=make_snapshot_competition('Bob is safe.',{'c1':'id:bob:v1'},SCOPE,'scope:universe:bob:new',ASOF)
    add('newer_cross_group_snapshot_invalidates_old_competition',comp_before is not None and comp_old is None and comp_new is not None)

    # Stale competitor does not override a fresh applicable snapshot.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    sfresh=[ev('FR1','Door','state','open','id:door:v1')]
    sstale=[ev('ST1','Door','state','open','id:door:v1')]
    _register_fixture_retrieval_scope('scope:door:fresh',sfresh,'snapshot:door:fresh',
                                      applicability_group_id='door:A',snapshot_version=1,
                                      valid_from='2026-01-01',valid_to='2026-12-31')
    _register_fixture_retrieval_scope('scope:door:stale',sstale,'snapshot:door:stale',
                                      applicability_group_id='door:B',snapshot_version=99,
                                      valid_from='2025-01-01',valid_to='2025-12-31')
    add('stale_cross_group_competitor_does_not_win',
        make_snapshot_competition('Door is open.',{'c1':'id:door:v1'},SCOPE,'scope:door:fresh',ASOF) is not None)

    # AuditContext binds derived universe and competition certificate.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    cctx_records=[ev('CTXU1','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:ctx-universe',cctx_records,'snapshot:ctx-universe',snapshot_version=101)
    cctx_bundle=prepare('Alice is safe.',cctx_records,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:ctx-universe')
    cctx=cctx_bundle[4]
    add('audit_context_binds_retrieval_universe',cctx is not None and nonblank(cctx.retrieval_universe_id))
    add('audit_context_binds_snapshot_competition',cctx is not None and nonblank(cctx.snapshot_competition_certificate_id))

    # Pinned obligations include global competition/partition checks.
    add('mandatory_gate_cross_group_competition_present','cross_group_snapshot_competition_resolved' in MANDATORY_GATES)
    add('mandatory_gate_retrieval_partition_present','retrieval_universe_partition_adequate' in MANDATORY_GATES)
    add('mandatory_gate_retrieval_membership_present','retrieval_universe_membership_valid' in MANDATORY_GATES)
    add('pinned_obligation_cross_group_competition_present','cross_group_snapshot_competition' in PINNED_CLOSURE_CLASS_SPEC['obligations'])
    add('pinned_obligation_partition_adequacy_present','retrieval_universe_partition_adequacy' in PINNED_CLOSURE_CLASS_SPEC['obligations'])

    # R16: partial-overlap / superset snapshot must enter claim competition.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    po_partial=[
        ev('POP1','Alice','state','safe','id:alice:v1',root='general-record:po:r1',origin='general-record:po:o1',group='PO1',extractor='POX1'),
        ev('POP2','Alice','state','safe','id:alice:v1',root='general-record:po:r2',origin='general-record:po:o2',group='PO2',extractor='POX2')
    ]
    po_overlap=[
        ev('POQ1','Alice','state','safe','id:alice:v1',root='general-record:po:r3',origin='general-record:po:o3',group='PO3',extractor='POX3'),
        ev('POQ2','Alice','state','safe','id:alice:v1',root='general-record:po:r4',origin='general-record:po:o4',group='PO4',extractor='POX4'),
        ev('PON1','Alice','state','safe','id:alice:v1',polarity='NEGATIVE',root='general-record:po:r5',origin='general-record:po:o5',group='PO5',extractor='POX5'),
        ev('POL1','Alice','location','London','id:alice:v1',root='general-record:po:r6',origin='general-record:po:o6',group='PO6',extractor='POX6'),
    ]
    _register_fixture_retrieval_scope('scope:po:partial',po_partial,'snapshot:po:partial',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:po:overlap',po_overlap,'snapshot:po:overlap',snapshot_version=2)
    add('partial_overlap_snapshots_have_different_exact_universe_ids',
        RETRIEVAL_SCOPE_REGISTRY['scope:po:partial']['retrieval_universe_id'] !=
        RETRIEVAL_SCOPE_REGISTRY['scope:po:overlap']['retrieval_universe_id'])
    cmap,_=decision_relevant_candidate_map('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,ASOF)
    add('claim_projection_discovers_superset_snapshot_across_universe_ids',
        cmap is not None and set(cmap['c1'])=={'scope:po:partial','scope:po:overlap'})
    po_bundle=prepare('Alice is safe.',po_partial,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:po:partial',
                      {'c1':{'required_independent_supports':2}})
    add('partial_overlap_without_certified_supersession_blocks_context',po_bundle[4] is None)
    add('partial_overlap_without_certified_supersession_blocks_competition',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:po:partial',ASOF) is None)

    # A wider snapshot may explicitly supersede the old one only with a valid evidence-accounting chain.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    po_full=[po_partial[0],po_partial[1],
             ev('PON2','Alice','state','safe','id:alice:v1',polarity='NEGATIVE',root='general-record:po:r7',origin='general-record:po:o7',group='PO7',extractor='POX7'),
             ev('POL2','Alice','location','London','id:alice:v1',root='general-record:po:r8',origin='general-record:po:o8',group='PO8',extractor='POX8')]
    _register_fixture_retrieval_scope('scope:po:old',po_partial,'snapshot:po:old',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:po:new',po_full,'snapshot:po:new',snapshot_version=2,
                                      supersedes='scope:po:old')
    add('explicit_superset_supersession_certificate_created',
        make_snapshot_supersession_certificate(
            claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0],
            'scope:po:old','scope:po:new',ASOF) is not None)
    old_comp=make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:po:old',ASOF)
    new_comp=make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:po:new',ASOF)
    add('certified_superset_supersession_invalidates_old_and_selects_new',
        old_comp is None and new_comp is not None)
    new_bundle=prepare('Alice is safe.',po_full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:po:new',
                       {'c1':{'required_independent_supports':2}})
    out=audit_text('Alice is safe.',po_full,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:po:new',
                   {'c1':{'required_independent_supports':2}},None,*new_bundle)
    add('certified_superset_snapshot_exposes_counterevidence',
        new_bundle[4] is not None and out['claims'][0]['status']=='QUARANTINED' and out['stop_type']=='NONE')

    # R16: higher version alone is NOT valid supersession.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    vr1=[ev('VRP1','Alice','state','safe','id:alice:v1'),
         ev('VRP2','Alice','state','safe','id:alice:v1'),
         ev('VRN1','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')]
    vr2=[ev('VRP3','Alice','state','safe','id:alice:v1'),
         ev('VRP4','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:vr:v1',vr1,'snapshot:vr:v1',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:vr:v2',vr2,'snapshot:vr:v2',snapshot_version=2)
    add('higher_version_without_supersedes_does_not_win',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:vr:v2',ASOF) is None)
    add('higher_version_without_supersedes_blocks_context',
        prepare('Alice is safe.',vr2,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:vr:v2',
                {'c1':{'required_independent_supports':2}})[4] is None)

    # Explicit supersedes but silent dropping of predecessor evidence is still invalid.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    _register_fixture_retrieval_scope('scope:drop:v1',vr1,'snapshot:drop:v1',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:drop:v2',vr2,'snapshot:drop:v2',snapshot_version=2,
                                      supersedes='scope:drop:v1')
    ddesc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    add('supersedes_without_dropped_evidence_accounting_rejected',
        make_snapshot_supersession_certificate(ddesc,'scope:drop:v1','scope:drop:v2',ASOF) is None)

    # Explicit retractions make record removal visible to the supersession certificate.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    _register_fixture_retrieval_scope('scope:ret:v1',vr1,'snapshot:ret:v1',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:ret:v2',vr2,'snapshot:ret:v2',snapshot_version=2,
                                      supersedes='scope:ret:v1',
                                      retracted_evidence_ids=['VRP1','VRP2','VRN1'])
    rdesc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    add('explicit_retractions_allow_certified_supersession',
        make_snapshot_supersession_certificate(rdesc,'scope:ret:v1','scope:ret:v2',ASOF) is not None)

    # Retractions may not name arbitrary evidence outside the predecessor snapshot.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    _register_fixture_retrieval_scope('scope:badret:v1',vr1,'snapshot:badret:v1',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:badret:v2',vr2,'snapshot:badret:v2',snapshot_version=2,
                                      supersedes='scope:badret:v1',
                                      retracted_evidence_ids=['NOT-IN-PREDECESSOR'])
    brdesc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    add('arbitrary_retraction_id_rejected',
        make_snapshot_supersession_certificate(brdesc,'scope:badret:v1','scope:badret:v2',ASOF) is None)

    # Projection certificates are claim-specific: extra location does not erase state evidence.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    _register_fixture_retrieval_scope('scope:proj:wide',po_overlap,'snapshot:proj:wide',snapshot_version=1)
    pdesc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    pcert=make_claim_snapshot_projection_certificate('scope:proj:wide',pdesc,ASOF)
    prows=snapshot_projection_rows('scope:proj:wide',pdesc,ASOF)
    add('claim_projection_keeps_state_evidence_and_ignores_extra_location',
        pcert is not None and {x['evidence_id'] for x in prows}=={'POQ1','POQ2','PON1'})

    # Decision-relevant overlap certificate sees candidate scopes across exact-universe boundaries.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    _register_fixture_retrieval_scope('scope:ov:A',po_partial,'snapshot:ov:A',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:ov:B',po_overlap,'snapshot:ov:B',snapshot_version=2)
    ocert=make_decision_relevant_overlap_certificate('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,ASOF)
    add('decision_relevant_overlap_certificate_created_across_universe_ids',ocert is not None)

    # New pinned obligations/gates exist.
    add('mandatory_gate_claim_projection_present','claim_snapshot_projection_complete' in MANDATORY_GATES)
    add('mandatory_gate_decision_overlap_present','decision_relevant_snapshot_overlap_complete' in MANDATORY_GATES)
    add('mandatory_gate_cross_universe_closure_present','cross_universe_evidence_closure_valid' in MANDATORY_GATES)
    add('mandatory_gate_snapshot_supersession_present','snapshot_supersession_valid' in MANDATORY_GATES)
    add('pinned_obligation_partial_overlap_present','decision_relevant_snapshot_overlap_complete' in PINNED_CLOSURE_CLASS_SPEC['obligations'])
    add('pinned_obligation_snapshot_supersession_present','snapshot_supersession_valid' in PINNED_CLOSURE_CLASS_SPEC['obligations'])

    # R17: relational value-changing conflict must be candidate-relevant.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    rv_safe=[ev('RVS1','Alice','state','safe','id:alice:v1')]
    rv_unsafe=[ev('RVU1','Alice','state','unsafe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:rv:safe',rv_safe,'snapshot:rv:safe',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:rv:unsafe',rv_unsafe,'snapshot:rv:unsafe',snapshot_version=1)
    rv_cmap,_=decision_relevant_candidate_map('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,ASOF)
    add('relational_safe_unsafe_both_enter_candidate_map',
        rv_cmap is not None and set(rv_cmap['c1'])=={'scope:rv:safe','scope:rv:unsafe'})
    rdesc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    unsafe_rows=snapshot_projection_rows('scope:rv:unsafe',rdesc,ASOF)
    add('unsafe_is_relational_projection_for_safe_claim',
        len(unsafe_rows)==1 and unsafe_rows[0]['claim_relation']=='STATE_RELATION:CONFLICT')
    add('safe_unsafe_without_resolution_fail_closed',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:rv:safe',ASOF) is None)
    add('safe_unsafe_context_not_created',
        prepare('Alice is safe.',rv_safe,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:rv:safe')[4] is None)

    # R17: cardinality-ONE relational projection catches London/Paris.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    loc_l=[ev('LOC-L','Alice','location','London','id:alice:v1')]
    loc_p=[ev('LOC-P','Alice','location','Paris','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:loc:london',loc_l,'snapshot:loc:london',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:loc:paris',loc_p,'snapshot:loc:paris',snapshot_version=1)
    ldesc=claim_descriptors('Alice is in London.',{'c1':'id:alice:v1'})[0]
    paris_rows=snapshot_projection_rows('scope:loc:paris',ldesc,ASOF)
    add('cardinality_one_alternative_is_decision_relevant',
        len(paris_rows)==1 and paris_rows[0]['claim_relation']=='CARDINALITY_ONE_ALTERNATIVE')
    add('london_paris_without_resolution_blocks_competition',
        make_snapshot_competition('Alice is in London.',{'c1':'id:alice:v1'},SCOPE,'scope:loc:london',ASOF) is None)

    # R17 strongest: value-changing fork cannot hide the conflicting branch.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    pred=[ev('F-P1','Alice','state','safe','id:alice:v1')]
    branch_a=[pred[0],ev('F-A2','Alice','state','safe','id:alice:v1',
                         root='general-record:fork:a:r',origin='general-record:fork:a:o',
                         group='fork:A',extractor='fork:A')]
    branch_b=[ev('F-B1','Alice','state','unsafe','id:alice:v1',
                 root='general-record:fork:b:r',origin='general-record:fork:b:o',
                 group='fork:B',extractor='fork:B')]
    _register_fixture_retrieval_scope('scope:fork:pred',pred,'snapshot:fork:pred',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:fork:A',branch_a,'snapshot:fork:A',snapshot_version=2,
                                      supersedes='scope:fork:pred')
    _register_fixture_retrieval_scope('scope:fork:B',branch_b,'snapshot:fork:B',snapshot_version=2,
                                      supersedes='scope:fork:pred',retracted_evidence_ids=['F-P1'])
    fork_cmap,_=decision_relevant_candidate_map('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,ASOF)
    add('value_changing_fork_all_branches_discovered',
        fork_cmap is not None and set(fork_cmap['c1'])=={'scope:fork:pred','scope:fork:A','scope:fork:B'})
    add('value_changing_fork_has_no_unique_winner',
        make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'scope:fork:A',ASOF) is None)
    add('value_changing_fork_blocks_context',
        prepare('Alice is safe.',branch_a,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:fork:A',
                {'c1':{'required_independent_supports':2}})[4] is None)

    # Unrelated MANY-state value without a modeled relation does not become a candidate.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    calm=[ev('CALM1','Alice','state','calm','id:alice:v1')]
    safe=[ev('SAFE1','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('scope:rel:safe',safe,'snapshot:rel:safe')
    _register_fixture_retrieval_scope('scope:rel:calm',calm,'snapshot:rel:calm')
    safe_desc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
    add('unmodeled_state_value_not_silently_treated_as_known_relation',
        snapshot_projection_rows('scope:rel:calm',safe_desc,ASOF)==[])

    # R17: decision-level cross-claim common-mode must block closure.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    def dep_override(eid,dbid):
        d=dep(eid);d['upstream_db']={'state':'KNOWN','id':dbid};return d
    multi=[
        ev('A1','Alice','state','safe','id:alice:v1',dependencies=dep_override('A1','db:SHARED_X')),
        ev('A2','Alice','state','safe','id:alice:v1',dependencies=dep_override('A2','db:SHARED_Y')),
        ev('B1','Bob','state','safe','id:bob:v1',dependencies=dep_override('B1','db:SHARED_X')),
        ev('B2','Bob','state','safe','id:bob:v1',dependencies=dep_override('B2','db:SHARED_Y')),
    ]
    _register_fixture_retrieval_scope('scope:decision:shared',multi,'snapshot:decision:shared')
    txt='Alice is safe. Bob is safe.'
    cmap={'c1':'id:alice:v1','c2':'id:bob:v1'}
    req2={'c1':{'required_independent_supports':2},'c2':{'required_independent_supports':2}}
    _fixture_issue_set_certificates(txt,multi,cmap,req2,'scope:decision:shared',ASOF)
    b=prepare(txt,multi,cmap,ASOF,SCOPE,EXTRACT,'scope:decision:shared',req2)
    out=audit_text(txt,multi,cmap,ASOF,SCOPE,EXTRACT,'scope:decision:shared',req2,None,*b)
    add('both_claims_locally_verified_before_decision_gate',
        [x['status'] for x in out['claims']]==['VERIFIED','VERIFIED'])
    add('cross_claim_common_mode_blocks_decision_support_closure',
        out['gates'].get('decision_support_closure_valid') is False)
    add('cross_claim_common_mode_blocks_epistemic_stop',
        out['stop_type']=='NONE' and out['control_closure'] is False)

    # Clean multi-claim decision with no cross-claim dependency overlap can close.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    clean_multi=[
        ev('CA1','Alice','state','safe','id:alice:v1'),
        ev('CA2','Alice','state','safe','id:alice:v1'),
        ev('CB1','Bob','state','safe','id:bob:v1'),
        ev('CB2','Bob','state','safe','id:bob:v1'),
    ]
    _register_fixture_retrieval_scope('scope:decision:clean',clean_multi,'snapshot:decision:clean')
    _fixture_issue_set_certificates(txt,clean_multi,cmap,req2,'scope:decision:clean',ASOF)
    bc=prepare(txt,clean_multi,cmap,ASOF,SCOPE,EXTRACT,'scope:decision:clean',req2)
    outc=audit_text(txt,clean_multi,cmap,ASOF,SCOPE,EXTRACT,'scope:decision:clean',req2,None,*bc)
    add('clean_cross_claim_decision_closure_certificate_created',
        outc.get('decision_support_closure_certificate') is not None)
    add('clean_cross_claim_decision_can_close',
        outc['control_closure'] is True and outc['stop_type']=='EPISTEMIC_STOP')

    # Pinned architecture explicitly includes the new layer.
    add('mandatory_gate_relational_neighborhood_present',
        'relational_claim_neighborhood_complete' in MANDATORY_GATES)
    add('mandatory_gate_decision_support_closure_present',
        'decision_support_closure_valid' in MANDATORY_GATES)
    add('pinned_obligation_relational_neighborhood_present',
        'relational_claim_neighborhood_complete' in PINNED_CLOSURE_CLASS_SPEC['obligations'])
    add('pinned_obligation_decision_level_closure_present',
        'decision_level_support_closure' in PINNED_CLOSURE_CLASS_SPEC['obligations'])

    # R18 / v0.2.18: typed dependency identity and instance ontology conformance.
    # Raw local and correctly-prefixed aliases must canonicalize to the same typed sensor node.
    a=normalize_dependency_entry('sensor_input',{'state':'KNOWN','id':'S1'})
    b=normalize_dependency_entry('sensor_input',{'state':'KNOWN','id':'sensor:S1'})
    add('typed_dependency_raw_and_prefixed_alias_same_node',
        a is not None and b is not None and a[2]==b[2]=='sensor:S1'
        and typed_dependency_node('sensor_input',a[2])==('DEPENDENCY','sensor_input','S1'))

    # Direct namespace laundering must be rejected before independence certification.
    bad_dep=dep('NSBAD');bad_dep['sensor_input']={'state':'KNOWN','id':'runtime:trusted-shared-runtime'}
    bad_ev=ev('NSBAD','Alice','state','safe','id:alice:v1',dependencies=bad_dep)
    out=run('Alice is safe.',[bad_ev],{'c1':'id:alice:v1'})
    add('namespace_laundering_sensor_runtime_rejected',
        bool(out['evidence_errors']) and out['stop_type']=='NONE' and out['control_closure'] is False)

    # Typed node categories must prevent a lineage string from inheriting a runtime whitelist exception.
    collision='dep:runtime:trusted-shared-runtime'
    lc=[ev('LC1','Alice','state','safe','id:alice:v1',root='general-record:lc:r1',origin=collision,group='LCG1',extractor='LCX1'),
        ev('LC2','Alice','state','safe','id:alice:v1',root='general-record:lc:r2',origin=collision,group='LCG2',extractor='LCX2')]
    out=run('Alice is safe.',lc,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('lineage_collision_does_not_inherit_runtime_whitelist',
        out['control_closure'] is False and bool(out['claim_support_policy_violations']))

    # The same textual collision in common-mode must also remain a different typed category.
    cm=[ev('CM1','Alice','state','safe','id:alice:v1',root='general-record:cm:r1',origin='general-record:cm:o1',group=collision,extractor='CMX1'),
        ev('CM2','Alice','state','safe','id:alice:v1',root='general-record:cm:r2',origin='general-record:cm:o2',group=collision,extractor='CMX2')]
    out=run('Alice is safe.',cm,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('common_mode_collision_does_not_inherit_runtime_whitelist',
        out['control_closure'] is False and bool(out['claim_support_policy_violations']))

    # A real shared sensor is not independent.
    ds1=dep('SSN1',{'sensor_input':{'state':'KNOWN','id':'sensor:SHARED_SENSOR'}})
    ds2=dep('SSN2',{'sensor_input':{'state':'KNOWN','id':'SHARED_SENSOR'}})
    se=[ev('SSN1','Alice','state','safe','id:alice:v1',root='general-record:ssn:r1',origin='general-record:ssn:o1',group='SSNG1',extractor='SSNX1',dependencies=ds1),
        ev('SSN2','Alice','state','safe','id:alice:v1',root='general-record:ssn:r2',origin='general-record:ssn:o2',group='SSNG2',extractor='SSNX2',dependencies=ds2)]
    out=run('Alice is safe.',se,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('true_shared_sensor_blocks_independence',
        out['claims'][0]['status']=='SUPPORTED' and out['control_closure'] is False and bool(out['claim_support_policy_violations']))

    # The one legal shared runtime exception remains allowed within a claim.
    dr1=dep('LRT1',{'runtime':{'state':'KNOWN','id':'runtime:trusted-shared-runtime'}})
    dr2=dep('LRT2',{'runtime':{'state':'KNOWN','id':'trusted-shared-runtime'}})
    re=[ev('LRT1','Alice','state','safe','id:alice:v1',root='general-record:lrt:r1',origin='general-record:lrt:o1',group='LRTG1',extractor='LRTX1',dependencies=dr1),
        ev('LRT2','Alice','state','safe','id:alice:v1',root='general-record:lrt:r2',origin='general-record:lrt:o2',group='LRTG2',extractor='LRTX2',dependencies=dr2)]
    out=run('Alice is safe.',re,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('legal_shared_runtime_still_allowed_within_claim',
        out['claims'][0]['status']=='VERIFIED' and out['control_closure'] is True and out['stop_type']=='EPISTEMIC_STOP')

    # The same legal runtime node may also be shared across claims; all other dependencies remain distinct.
    ra=dep('CRA',{'runtime':{'state':'KNOWN','id':'runtime:trusted-shared-runtime'}})
    rb=dep('CRB',{'runtime':{'state':'KNOWN','id':'trusted-shared-runtime'}})
    cross=[ev('CRA','Alice','state','safe','id:alice:v1',dependencies=ra),
           ev('CRB','Bob','state','safe','id:bob:v1',dependencies=rb)]
    out=run('Alice is safe. Bob is safe.',cross,{'c1':'id:alice:v1','c2':'id:bob:v1'})
    add('legal_shared_runtime_still_allowed_cross_claim',
        [x['status'] for x in out['claims']]==['VERIFIED','VERIFIED'] and out['control_closure'] is True
        and out['decision_support_closure_certificate'] is not None)

    # Exhaustive cross-namespace matrix: each dimension rejects every other dimension's prefix and alias.
    for target in DEPENDENCY_DIMENSIONS:
        illegal=[]
        for foreign in DEPENDENCY_DIMENSIONS:
            if foreign==target:continue
            illegal.append(normalize_dependency_entry(target,{'state':'KNOWN','id':f'{DEPENDENCY_PREFIX[foreign]}:X'}) is None)
            illegal.append(normalize_dependency_entry(target,{'state':'KNOWN','id':f'{foreign}:X'}) is None)
        add(f'cross_namespace_matrix_{target}_rejects_all_foreign_namespaces',all(illegal))

    # Instance-level ontology certificate exists, validates, and is mandatory.
    cf,ce=normalize_fact(ev('ONT1','Alice','state','safe','id:alice:v1'),1)
    add('dependency_ontology_conformance_certificate_created',
        not ce and cf is not None and validate_dependency_ontology_conformance_certificate(
            cf.dependency_ontology_conformance,cf.provenance,cf.evidence_id))
    missing=replace(cf,dependency_ontology_conformance=None)
    add('missing_dependency_ontology_conformance_certificate_blocks',
        not dependency_instance_ontology_conformance_valid([missing]))
    good=cf.dependency_ontology_conformance
    tampered=DependencyOntologyConformanceCertificate(**{**asdict(good),'conformance_result':'FAIL'})
    tampered_fact=replace(cf,dependency_ontology_conformance=tampered)
    add('tampered_dependency_ontology_conformance_certificate_blocks',
        not dependency_instance_ontology_conformance_valid([tampered_fact]))
    add('mandatory_gate_dependency_instance_ontology_present',
        'dependency_instance_ontology_conformance_valid' in MANDATORY_GATES)
    add('pinned_obligation_dependency_instance_ontology_present',
        'dependency_instance_ontology_conformance' in PINNED_CLOSURE_CLASS_SPEC['obligations'])
    add('typed_allowed_shared_policy_is_pinned',
        tuple(PINNED_DEPENDENCY_ONTOLOGY_SPEC['allowed_shared_nodes'])==tuple(sorted(PROVENANCE_POLICY['allowed_shared_nodes']))
        and ('DEPENDENCY','runtime','trusted-shared-runtime') in PROVENANCE_POLICY['allowed_shared_nodes'])

    # Reproduce the strongest R18 namespace-laundering attack with certified supersession structure.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    def r18deps(tag):
        d=dep(tag);d['sensor_input']={'state':'KNOWN','id':'runtime:trusted-shared-runtime'};return d
    r18pa=ev('R18PA','Alice','state','safe','id:alice:v1',dependencies=r18deps('R18PA'))
    r18pb=ev('R18PB','Bob','state','safe','id:bob:v1',dependencies=r18deps('R18PB'))
    r18a2=ev('R18A2','Alice','state','safe','id:alice:v1',dependencies=r18deps('R18A2'))
    r18b2=ev('R18B2','Bob','state','safe','id:bob:v1',dependencies=r18deps('R18B2'))
    r18pred=[r18pa,r18pb];r18succ=[r18pa,r18pb,r18a2,r18b2]
    _register_fixture_retrieval_scope('scope:r18:pred',r18pred,'snapshot:r18:pred',snapshot_version=1)
    _register_fixture_retrieval_scope('scope:r18:succ',r18succ,'snapshot:r18:succ',snapshot_version=2,supersedes='scope:r18:pred')
    r18txt='Alice is safe. Bob is safe.';r18cmap={'c1':'id:alice:v1','c2':'id:bob:v1'}
    r18req={'c1':{'required_independent_supports':2},'c2':{'required_independent_supports':2}}
    rb=prepare(r18txt,r18succ,r18cmap,ASOF,SCOPE,EXTRACT,'scope:r18:succ',r18req)
    rout=audit_text(r18txt,r18succ,r18cmap,ASOF,SCOPE,EXTRACT,'scope:r18:succ',r18req,None,*rb)
    add('r18_strongest_namespace_laundering_attack_fail_closes',
        rout['control_closure'] is False and rout['stop_type']=='NONE' and bool(rout['evidence_errors'])
        and rout['gates'].get('dependency_instance_ontology_conformance_valid') is False)

    # Reproduce R18 lineage collision; it must now remain a LINEAGE node and block independence.
    RETRIEVAL_SCOPE_REGISTRY.clear()
    r18lc=[ev('R18LC1','Alice','state','safe','id:alice:v1',root='general-record:r18lc:r1',origin=collision,group='R18LCG1',extractor='R18LCX1'),
           ev('R18LC2','Alice','state','safe','id:alice:v1',root='general-record:r18lc:r2',origin=collision,group='R18LCG2',extractor='R18LCX2')]
    _register_fixture_retrieval_scope('scope:r18:lineage',r18lc,'snapshot:r18:lineage')
    lb=prepare('Alice is safe.',r18lc,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:r18:lineage',{'c1':{'required_independent_supports':2}})
    lout=audit_text('Alice is safe.',r18lc,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'scope:r18:lineage',{'c1':{'required_independent_supports':2}},None,*lb)
    lf1,_=normalize_fact(r18lc[0],1);lf2,_=normalize_fact(r18lc[1],2)
    lind,lshared=independent_subset((lf1,lf2))
    add('r18_lineage_collision_attack_fail_closes',
        lout['control_closure'] is False and (not lind) and ('LINEAGE','',collision) in lshared)

    # R19 / v0.2.19: source identity != failure domain != independence.
    # 1. same source, different lineage/extractor/dependencies: default conservative domain blocks.
    SOURCE_SEMANTICS_REGISTRY.clear();SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.clear();EVIDENCE_EPISTEMIC_ROLE_REGISTRY.clear();EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.clear();SUPPORT_SET_COMMON_MODE_REGISTRY.clear();SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.clear();SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.clear();SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.clear()
    shared_sid='general-record:R19-SHARED'
    r19same=[ev('R19S1','Alice','state','safe','id:alice:v1',source_id=shared_sid,root='general-record:r19:r1',origin='general-record:r19:o1',group='R19G1',extractor='R19X1'),
             ev('R19S2','Alice','state','safe','id:alice:v1',source_id=shared_sid,root='general-record:r19:r2',origin='general-record:r19:o2',group='R19G2',extractor='R19X2')]
    r19out=run('Alice is safe.',r19same,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('r19_same_source_single_claim_false_closure_blocked',r19out['control_closure'] is False and r19out['stop_type']=='NONE' and r19out['claims'][0]['status']=='SUPPORTED')

    # 2. cross-claim shared source must block decision-level closure even with one support per claim.
    r19cross=[ev('R19CA','Alice','state','safe','id:alice:v1',source_id=shared_sid,root='general-record:r19:ca:r',origin='general-record:r19:ca:o',group='R19CAG',extractor='R19CAX'),
              ev('R19CB','Bob','state','safe','id:bob:v1',source_id=shared_sid,root='general-record:r19:cb:r',origin='general-record:r19:cb:o',group='R19CBG',extractor='R19CBX')]
    r19co=run('Alice is safe. Bob is safe.',r19cross,{'c1':'id:alice:v1','c2':'id:bob:v1'})
    add('r19_same_source_cross_claim_false_closure_blocked',r19co['control_closure'] is False and r19co['gates'].get('decision_support_closure_valid') is False and r19co['gates'].get('source_independence_semantics_valid') is False)

    # Explicit source semantics fixtures.
    register_source_semantics('sem:r19:a',shared_sid,'repo:r19','producer:r19:a','process:r19:a','fd:r19:a')
    register_source_semantics('sem:r19:b',shared_sid,'repo:r19','producer:r19:b','process:r19:b','fd:r19:b')
    legal=[ev('R19L1','Alice','state','safe','id:alice:v1',source_id=shared_sid,source_semantics_id='sem:r19:a',root='general-record:r19:l1:r',origin='general-record:r19:l1:o',group='R19L1G',extractor='R19L1X'),
           ev('R19L2','Alice','state','safe','id:alice:v1',source_id=shared_sid,source_semantics_id='sem:r19:b',root='general-record:r19:l2:r',origin='general-record:r19:l2:o',group='R19L2G',extractor='R19L2X')]
    lf1,le1=normalize_fact(legal[0],1);lf2,le2=normalize_fact(legal[1],2)
    add('source_failure_domain_profiles_created',not le1 and not le2 and lf1.source_failure_domain.failure_domain_id!=lf2.source_failure_domain.failure_domain_id)
    missing=run('Alice is safe.',legal,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('missing_source_independence_certificate_blocks',missing['control_closure'] is False and missing['gates'].get('source_independence_semantics_valid') is False)
    authorize_source_independence('si:r19:legal',lf1,lf2,'independent producer/process partitions inside one repository')
    good_si=issue_source_independence_certificate('si:r19:legal',lf1,lf2)
    legalout=run('Alice is safe.',legal,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('same_source_certified_independent_failure_domains_pass',legalout['control_closure'] is True and legalout['gates'].get('source_independence_semantics_valid') is True)
    add('source_independence_certificate_validates',validate_source_independence_certificate(good_si,lf1,lf2))

    # Same explicit failure domain always blocks, even if source IDs differ.
    register_source_semantics('sem:r19:fd1','general-record:FD-A','repo:fd:a','producer:fd:shared','process:fd:a','fd:r19:shared')
    register_source_semantics('sem:r19:fd2','general-record:FD-B','repo:fd:b','producer:fd:shared','process:fd:b','fd:r19:shared')
    fdshared=[ev('R19FD1','Alice','state','safe','id:alice:v1',source_id='general-record:FD-A',source_semantics_id='sem:r19:fd1',root='general-record:r19:fd1:r',origin='general-record:r19:fd1:o',group='R19FD1G',extractor='R19FD1X'),
              ev('R19FD2','Alice','state','safe','id:alice:v1',source_id='general-record:FD-B',source_semantics_id='sem:r19:fd2',root='general-record:r19:fd2:r',origin='general-record:r19:fd2:o',group='R19FD2G',extractor='R19FD2X')]
    fdout=run('Alice is safe.',fdshared,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('different_source_ids_same_failure_domain_block',fdout['control_closure'] is False and fdout['gates'].get('source_independence_semantics_valid') is False)
    ff1,_=normalize_fact(fdshared[0],1);ff2,_=normalize_fact(fdshared[1],2)
    try:
        authorize_source_independence('si:r19:illegal-shared-fd',ff1,ff2,'should not authorize')
        shared_fd_authorized=True
    except ValueError:
        shared_fd_authorized=False
    add('same_failure_domain_cannot_be_certified_away',shared_fd_authorized is False)

    # Tampering a required pair certificate fails closed.
    SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY['si:r19:legal']=replace(good_si,result='FAIL')
    tampered=run('Alice is safe.',legal,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('tampered_source_independence_certificate_blocks',tampered['control_closure'] is False and tampered['gates'].get('source_independence_semantics_valid') is False)
    SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY['si:r19:legal']=good_si

    # Policy/meta pinning and typed ontology integration.
    add('source_node_type_present_in_pinned_ontology','SOURCE' in PINNED_DEPENDENCY_ONTOLOGY_SPEC['node_types'] and 'FAILURE_DOMAIN' in PINNED_DEPENDENCY_ONTOLOGY_SPEC['node_types'])
    add('source_independence_gate_present','source_independence_semantics_valid' in MANDATORY_GATES)
    add('source_independence_obligation_pinned',OBLIGATION_GATE_MAP.get('source_independence_semantics')=='source_independence_semantics_valid')
    add('source_policy_hash_pinned',PINNED_META_AUTHORITY.get('source_independence_policy_hash')==canonical_hash(PINNED_SOURCE_INDEPENDENCE_POLICY))
    saved_source_policy=dict(SOURCE_INDEPENDENCE_POLICY)
    SOURCE_INDEPENDENCE_POLICY['algorithm']='TAMPERED'
    badpolicy=run('Alice is safe.',[ev('R19P','Alice','state','safe','id:alice:v1')],{'c1':'id:alice:v1'})
    add('invalid_source_policy_hash_blocks',badpolicy['control_closure'] is False and badpolicy['gates'].get('gate_registry_adequate_for_closure_class') is False)
    SOURCE_INDEPENDENCE_POLICY.clear();SOURCE_INDEPENDENCE_POLICY.update(saved_source_policy)

    # Same repository, different source IDs and distinct domains is not auto-blocked when certified.
    register_source_semantics('sem:r19:repo1','general-record:REPO-A','repo:shared','producer:repo:a','process:repo:a','fd:repo:a')
    register_source_semantics('sem:r19:repo2','general-record:REPO-B','repo:shared','producer:repo:b','process:repo:b','fd:repo:b')
    repo=[ev('R19R1','Alice','state','safe','id:alice:v1',source_id='general-record:REPO-A',source_semantics_id='sem:r19:repo1',root='general-record:r19:rr1',origin='general-record:r19:ro1',group='R19RG1',extractor='R19RX1'),
          ev('R19R2','Alice','state','safe','id:alice:v1',source_id='general-record:REPO-B',source_semantics_id='sem:r19:repo2',root='general-record:r19:rr2',origin='general-record:r19:ro2',group='R19RG2',extractor='R19RX2')]
    rf1,_=normalize_fact(repo[0],1);rf2,_=normalize_fact(repo[1],2)
    repo_missing=run('Alice is safe.',repo,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('shared_repository_without_certificate_blocks',repo_missing['control_closure'] is False)
    authorize_source_independence('si:r19:repo',rf1,rf2,'independent source processes in a shared repository')
    issue_source_independence_certificate('si:r19:repo',rf1,rf2)
    repo_good=run('Alice is safe.',repo,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('shared_repository_certified_distinct_failure_domains_pass',repo_good['control_closure'] is True)

    # Typed SOURCE is present in the actual dependency graph, but its semantics is policy-mediated.
    rf1n,_=normalize_fact(repo[0],1)
    add('typed_source_node_in_runtime_dependency_graph',('SOURCE','',rf1n.provenance.source_id) in dependency_nodes(rf1n))
    add('source_failure_domain_node_in_runtime_dependency_graph',('FAILURE_DOMAIN','source',rf1n.source_failure_domain.failure_domain_id) in dependency_nodes(rf1n))

    # R20 / v0.2.20: UNKNOWN != DISTINCT and set-level common mode closure.
    # Default synthetic profiles are admitted as conservative placeholders but cannot prove independence.
    SUPPORT_SET_COMMON_MODE_REGISTRY.clear();SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.clear()
    dflt=[ev('R20D1','Alice','state','safe','id:alice:v1',use_default_source_semantics=True),
          ev('R20D2','Alice','state','safe','id:alice:v1',use_default_source_semantics=True)]
    dfltout=run('Alice is safe.',dflt,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_different_source_ids_without_fd_knowledge_block',dfltout['control_closure'] is False and dfltout['gates'].get('source_failure_domain_resolution_complete_valid') is False)
    df1,_=normalize_fact(dflt[0],1);df2,_=normalize_fact(dflt[1],2)
    add('r20_default_synthetic_failure_domains_do_not_prove_independence',evaluate_source_relation(df1,df2)[1]=='SOURCE_RELATION_UNRESOLVED')

    # Explicit UNKNOWN semantics are certified as UNKNOWN, not laundered into KNOWN distinctness.
    register_source_semantics('sem:r20:u1','general-record:R20U1','repo:u1','producer:u1','process:u1','fd:u1',resolution_state='UNKNOWN')
    register_source_semantics('sem:r20:u2','general-record:R20U2','repo:u2','producer:u2','process:u2','fd:u2',resolution_state='KNOWN')
    unk=[ev('R20U1','Alice','state','safe','id:alice:v1',source_id='general-record:R20U1',source_semantics_id='sem:r20:u1'),
         ev('R20U2','Alice','state','safe','id:alice:v1',source_id='general-record:R20U2',source_semantics_id='sem:r20:u2')]
    uout=run('Alice is safe.',unk,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_explicit_unknown_fd_relation_blocks',uout['control_closure'] is False and uout['gates'].get('source_failure_domain_resolution_complete_valid') is False)

    # Explicit known distinct domains + explicit set certificate PASS.
    known=[ev('R20K1','Alice','state','safe','id:alice:v1'),ev('R20K2','Alice','state','safe','id:alice:v1')]
    kout=run('Alice is safe.',known,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}})
    add('r20_proven_distinct_failure_domains_pass',kout['control_closure'] is True and kout['gates'].get('support_set_common_mode_coverage_valid') is True)

    # Resolution certificate missing/tampered must fail closed.
    miss=[ev('R20M1','Alice','state','safe','id:alice:v1'),ev('R20M2','Alice','state','safe','id:alice:v1')]
    msid=miss[0]['source_semantics_id'];mcert=SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.pop(msid)
    mout=run('Alice is safe.',miss,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_missing_source_semantics_resolution_certificate_blocks',mout['control_closure'] is False and bool(mout['evidence_errors']))
    SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY[msid]=replace(mcert,result='FAIL')
    mtout=run('Alice is safe.',miss,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_tampered_source_semantics_resolution_certificate_blocks',mtout['control_closure'] is False and bool(mtout['evidence_errors']))
    SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY[msid]=mcert

    # Alias and parent-domain closure are hard blocks.
    register_failure_domain_alias('fd:r20:alias','fd:r20:canonical')
    register_source_semantics('sem:r20:a1','general-record:R20A1','repo:a1','producer:a1','process:a1','fd:r20:canonical')
    register_source_semantics('sem:r20:a2','general-record:R20A2','repo:a2','producer:a2','process:a2','fd:r20:alias')
    alias=[ev('R20A1','Alice','state','safe','id:alice:v1',source_id='general-record:R20A1',source_semantics_id='sem:r20:a1'),
           ev('R20A2','Alice','state','safe','id:alice:v1',source_id='general-record:R20A2',source_semantics_id='sem:r20:a2')]
    aout=run('Alice is safe.',alias,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_different_source_ids_aliased_fd_block',aout['control_closure'] is False and aout['gates'].get('source_independence_semantics_valid') is False)

    register_failure_domain_parent('fd:r20:leaf1','fd:r20:parent')
    register_failure_domain_parent('fd:r20:leaf2','fd:r20:parent')
    register_source_semantics('sem:r20:p1','general-record:R20P1','repo:p1','producer:p1','process:p1','fd:r20:leaf1')
    register_source_semantics('sem:r20:p2','general-record:R20P2','repo:p2','producer:p2','process:p2','fd:r20:leaf2')
    parent=[ev('R20P1','Alice','state','safe','id:alice:v1',source_id='general-record:R20P1',source_semantics_id='sem:r20:p1'),
            ev('R20P2','Alice','state','safe','id:alice:v1',source_id='general-record:R20P2',source_semantics_id='sem:r20:p2')]
    pout=run('Alice is safe.',parent,{'c1':'id:alice:v1'},{'c1':{'required_independent_supports':2}},auto_set_certificates=False)
    add('r20_shared_parent_failure_domain_blocks',pout['control_closure'] is False and pout['gates'].get('source_independence_semantics_valid') is False)

    # Three-way common mode: every pair is distinct, but set-level relation blocks.
    tri=[ev('R20N1','Alice','state','safe','id:alice:v1'),ev('R20N2','Alice','state','safe','id:alice:v1'),ev('R20N3','Alice','state','safe','id:alice:v1')]
    RETRIEVAL_SCOPE_REGISTRY.clear();_register_fixture_retrieval_scope('r20:nway',tri,'snapshot:r20:nway')
    register_support_set_common_mode('cm:r20:nway',[x['evidence_id'] for x in tri],'latent batch common mode visible only at set level')
    nb=prepare('Alice is safe.',tri,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'r20:nway',{'c1':{'required_independent_supports':3}})
    nout=audit_text('Alice is safe.',tri,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'r20:nway',{'c1':{'required_independent_supports':3}},None,*nb)
    nf=[normalize_fact(x,i+1)[0] for i,x in enumerate(tri)]
    add('r20_three_support_pairwise_distinct_nway_common_mode_blocks',all(pair_independence(a,b)[0] for a,b in combinations(nf,2)) and nout['control_closure'] is False)

    # Exact three-way positive determination and certificate allow closure.
    SUPPORT_SET_COMMON_MODE_REGISTRY.clear();SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.clear()
    authorize_support_set_independence('ssi:r20:tri','c1','r20:nway',nf,'three independent producers, domains and common-mode review complete')
    tri_cert=issue_support_set_independence_certificate('ssi:r20:tri','c1','r20:nway',nf)
    tb=prepare('Alice is safe.',tri,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'r20:nway',{'c1':{'required_independent_supports':3}})
    tout=audit_text('Alice is safe.',tri,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'r20:nway',{'c1':{'required_independent_supports':3}},None,*tb)
    add('r20_fully_certified_independent_three_way_pass',tout['control_closure'] is True and tout['gates'].get('support_set_common_mode_coverage_valid') is True)
    SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY['ssi:r20:tri']=replace(tri_cert,result='FAIL')
    tbad=audit_text('Alice is safe.',tri,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'r20:nway',{'c1':{'required_independent_supports':3}},None,*tb)
    add('r20_tampered_set_level_independence_certificate_blocks',tbad['control_closure'] is False)
    SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY['ssi:r20:tri']=tri_cert

    add('r20_source_resolution_gate_present','source_failure_domain_resolution_complete_valid' in MANDATORY_GATES)
    add('r20_set_common_mode_gate_present','support_set_common_mode_coverage_valid' in MANDATORY_GATES)
    add('r20_source_resolution_obligation_pinned',OBLIGATION_GATE_MAP.get('source_failure_domain_resolution_complete')=='source_failure_domain_resolution_complete_valid')
    add('r20_set_common_mode_obligation_pinned',OBLIGATION_GATE_MAP.get('support_set_common_mode_coverage')=='support_set_common_mode_coverage_valid')


    # ============================================================
    # R23 / v0.2.21: matching support universe and explicit selection
    # The first 210 entries above are intentionally left untouched.
    # ============================================================
    old_210_ok=(len(T)==210 and all(x['pass'] for x in T))

    def r23_reset():
        _reset_decision_persistence_runtime_state_for_tests()
        if not _SELF_TEST_ROLE_AUTHORITY_ACTIVE or _SELF_TEST_SCOPE_GENERATION_ID is None:
            enter_self_test_role_scope()
        for reg in (RETRIEVAL_SCOPE_REGISTRY,SOURCE_SEMANTICS_REGISTRY,
                    SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY,EVIDENCE_EPISTEMIC_ROLE_REGISTRY,
                    EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY,EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY,
                    EVIDENCE_EPISTEMIC_ROLE_ORIGIN_HISTORY,EXACT_EVIDENCE_ROLE_AUTHORIZATION_INDEX,EVIDENCE_ID_IDENTITY_REGISTRY,FAILURE_DOMAIN_ALIAS_REGISTRY,
                    FAILURE_DOMAIN_PARENT_REGISTRY,SUPPORT_SET_COMMON_MODE_REGISTRY,
                    SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY,SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY,
                    SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY,PREDECESSOR_CONTROL_ARTIFACT_REGISTRY,PREDECESSOR_TRANSITION_CERTIFICATE_REGISTRY,SUPPORT_SELECTION_REGISTRY,
                    MATCHING_SUPPORT_UNIVERSE_REGISTRY,DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY,
                    SUPPORT_SELECTION_CERTIFICATE_REGISTRY,CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY,
                    RELATION_RESOLUTION_REGISTRY,RELATION_RESOLUTION_CERTIFICATE_REGISTRY,
                    EXCLUDED_SUPPORT_DISPOSITION_REGISTRY,EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY,
                    GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY,GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY,
                    GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY,GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY,
                    GENERIC_REPRESENTATION_COMPLETENESS_CERTIFICATE_REGISTRY):
            reg.clear()
        _clear_self_test_evidence_role_state()
        _reset_trusted_role_issuance_ancestry_for_tests()
        SOURCE_SEMANTICS_POLICY.clear();SOURCE_SEMANTICS_POLICY.update(PINNED_SOURCE_SEMANTICS_POLICY)
        SOURCE_INDEPENDENCE_POLICY.clear();SOURCE_INDEPENDENCE_POLICY.update(PINNED_SOURCE_INDEPENDENCE_POLICY)
        SUPPORT_UNIVERSE_POLICY.clear();SUPPORT_UNIVERSE_POLICY.update(PINNED_SUPPORT_UNIVERSE_POLICY)
        RELATION_DISCOVERY_POLICY.clear();RELATION_DISCOVERY_POLICY.update(PINNED_RELATION_DISCOVERY_POLICY)
        RELATION_RESOLUTION_POLICY.clear();RELATION_RESOLUTION_POLICY.update(PINNED_RELATION_RESOLUTION_POLICY)
        RELATION_DECISION_RELEVANCE_POLICY.clear();RELATION_DECISION_RELEVANCE_POLICY.update(PINNED_RELATION_DECISION_RELEVANCE_POLICY)
        GENERIC_RELATION_SOURCE_IDENTITY_POLICY.clear();GENERIC_RELATION_SOURCE_IDENTITY_POLICY.update(PINNED_GENERIC_RELATION_SOURCE_IDENTITY_POLICY)
        EVIDENCE_SOURCE_FIELD_POLICY.clear();EVIDENCE_SOURCE_FIELD_POLICY.update(PINNED_EVIDENCE_SOURCE_FIELD_POLICY)
        EVIDENCE_EPISTEMIC_ROLE_POLICY.clear();EVIDENCE_EPISTEMIC_ROLE_POLICY.update(copy.deepcopy(PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY))
        EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY.clear();EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY.update(copy.deepcopy(PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY))

    def r23_case(tag,n=3,need=2,common_pair=None,selection=False,classes=None,resolutions=None,
                 common_effect='UNKNOWN',relation_specific_resolution=False):
        r23_reset();letters=tuple(chr(ord('A')+i) for i in range(n));ids=tuple(f'R23{tag}{x}' for x in letters)
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        rid=f'r23:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence))
        selected=fs[:need]
        if need>1:
            iid=f'ssi:r23:{tag}'
            try:
                authorize_support_set_independence(iid,'c1',rid,selected,f'R23 selected set {tag}')
                issue_support_set_independence_certificate(iid,'c1',rid,selected)
            except ValueError:
                pass
        relation_id=None
        if common_pair is not None:
            a,b=common_pair;relation_id=f'cm:r23:{tag}'
            register_support_set_common_mode(relation_id,[ids[a],ids[b]],f'R23 common mode {tag}',
                                             relation_effect=common_effect)
        if selection:
            excluded=ids[need:]
            if classes is None:classes={eid:'EXCLUDED_NOT_NEEDED' for eid in excluded}
            elif isinstance(classes,str):classes={eid:classes for eid in excluded}
            exreasons={eid:f'explicit R23 exclusion {eid}' for eid in excluded}
            rr={}
            for pair,res in (resolutions or {}).items():
                a,b=pair
                aa=ids[a] if isinstance(a,int) else a;bb=ids[b] if isinstance(b,int) else b
                rr[(aa,bb)]=res
            register_support_selection(f'sel:r23:{tag}','c1',rid,ids,ids[:need],need,classes,
                                       f'R23 deterministic selection {tag}',exreasons,rr)
            if relation_specific_resolution and relation_id is not None:
                register_relation_resolution(f'rr:r23:{tag}',relation_id,'c1',rid,ids[:need],
                                             'REDUNDANT_RELATION_ACCOUNTED',
                                             f'R23 relation-specific redundancy resolution {tag}')
                for eid,cls in classes.items():
                    if cls=='EXCLUDED_REDUNDANT':
                        register_excluded_support_disposition(f'disp:r23:{tag}:{eid}','c1',rid,eid,ids[:need],
                                                             [relation_id],f'R23 certified redundant exclusion {eid}')
        reqx={'c1':{'required_independent_supports':need}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        bundle=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        out=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*bundle)
        return {'ids':ids,'evidence':evidence,'facts':fs,'rid':rid,'req':reqx,'bundle':bundle,'out':out}

    # 1 / 5 / 13 / 31: exact R22 false closure: a certified A+B subset exists,
    # but C remains in the matching universe and B<->C has a common mode.
    r22=r23_case('R22',common_pair=(1,2),selection=False)
    add('r23_01_r22_2of3_common_mode_without_universe_coverage_blocks',
        r22['out']['control_closure'] is False and r22['out']['gates'].get('claim_support_universe_common_mode_coverage_valid') is False)
    add('r23_05_old_subset_certificate_does_not_cover_larger_universe',
        bool(SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY) and len(r22['out'].get('matching_support_universes',[]))==1
        and len(r22['out']['matching_support_universes'][0]['matching_evidence_ids'])==3 and r22['out']['control_closure'] is False)
    add('r23_13_first_valid_subset_never_determines_closure_when_universe_unresolved',
        any(v.get('type')=='CERTIFIED_SUBSET_BUT_UNIVERSE_UNRESOLVED' for v in r22['out']['claim_support_policy_violations']))
    add('r23_31_exact_r22_false_closure_reproducer_control_closure_false',r22['out']['control_closure'] is False)

    # 2: explicit unresolved exclusion remains a hard block.
    unresolved=r23_case('UNRES',common_pair=(1,2),selection=True,classes='EXCLUDED_UNRESOLVED')
    add('r23_02_explicit_excluded_unresolved_blocks',unresolved['out']['control_closure'] is False and
        unresolved['out']['gates'].get('support_selection_justification_valid') is False)

    # 3: legal redundant C, with the B<->C relation explicitly accounted, can close.
    redundant=r23_case('RED',common_pair=(1,2),selection=True,classes='EXCLUDED_REDUNDANT',
                       resolutions={(1,2):'REDUNDANT_RELATION_ACCOUNTED'},
                       common_effect='REDUNDANCY_ONLY',relation_specific_resolution=True)
    red_out=redundant['out'];red_sel=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values()),None)
    red_cov=next(iter(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values()),None)
    red_universe=next(iter(MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()),None)
    red_claim=parse_claims('Alice is safe.')[0];attach_claim_identities([red_claim],{'c1':'id:alice:v1'})
    class _R23Ctx:pass
    redctx=_R23Ctx();redctx.audit_context_id=redundant['bundle'][4].audit_context_id;redctx.as_of_date=ASOF;redctx.retrieval_scope_id=redundant['rid']
    red_desc=_selection_descriptor(red_claim,red_universe,redundant['req']['c1'])
    red_ledger=_support_relation_ledger(red_claim,redundant['facts'],redctx,red_universe,red_desc)
    add('r23_03_redundant_exclusion_with_full_coverage_passes',red_out['control_closure'] is True and
        red_out['gates'].get('claim_support_universe_common_mode_coverage_valid') is True)
    add('r23_37_relation_ledger_retains_selected_excluded_common_mode',
        red_ledger is not None and any(row[2]=='SELECTED_EXCLUDED' and row[3]=='COMMON_MODE' for row in red_ledger))
    add('r23_38_typed_exclusion_is_bound_into_selection_certificate',
        red_sel is not None and any(cls=='EXCLUDED_REDUNDANT' for _,cls in red_sel.exclusion_classifications))

    # 4: independent but unnecessary C can be explicitly omitted.
    notneeded=r23_case('NOTNEEDED',selection=True,classes='EXCLUDED_NOT_NEEDED')
    add('r23_04_independent_not_needed_exclusion_passes',notneeded['out']['control_closure'] is True)

    # 6: certificate from universe {A,B} does not validate for {A,B,C}.
    replay_ab=r23_case('REPLAYAB',n=2,need=2)
    old_cov=next(iter(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values()),None)
    old_sel=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values()),None)
    replay_abc=r23_case('REPLAYABC',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    cur_u=next(iter(MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()),None);cur_s=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values()),None)
    cur_claim=parse_claims('Alice is safe.')[0];attach_claim_identities([cur_claim],{'c1':'id:alice:v1'})
    cur_ctx=replay_abc['bundle'][4]
    add('r23_06_universe_certificate_replay_ab_to_abc_blocks',old_cov is not None and cur_u is not None and
        validate_claim_support_universe_coverage_certificate(old_cov,cur_claim,replay_abc['facts'],cur_ctx,replay_abc['req']['c1'],cur_u,cur_s) is False)

    # 7: selection certificate is claim-bound.
    claims2=parse_claims('Alice is safe. Alice is safe.');attach_claim_identities(claims2,{'c1':'id:alice:v1','c2':'id:alice:v1'})
    c2=claims2[1];u2=make_matching_support_universe(c2,replay_abc['facts'],cur_ctx)
    add('r23_07_selection_certificate_replay_between_claims_blocks',old_sel is not None and u2 is not None and
        validate_support_selection_certificate(old_sel,c2,replay_abc['facts'],cur_ctx,replay_abc['req']['c1'],u2) is False)

    # 8: selection certificate is retrieval-snapshot/context bound.
    old_selection_for_snapshot=cur_s
    replay_snap=r23_case('REPLAYSNAP',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    snap_u=next(iter(MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()),None);snap_claim=parse_claims('Alice is safe.')[0]
    attach_claim_identities([snap_claim],{'c1':'id:alice:v1'})
    add('r23_08_selection_certificate_replay_between_snapshots_blocks',old_selection_for_snapshot is not None and
        validate_support_selection_certificate(old_selection_for_snapshot,snap_claim,replay_snap['facts'],replay_snap['bundle'][4],replay_snap['req']['c1'],snap_u) is False)

    # 9: adding a matching support after prepare changes the exact context/universe and blocks.
    mut_add=r23_case('MUTADD',n=2,need=2)
    extra=ev('R23MUTADDC','Alice','state','safe','id:alice:v1')
    evidence_plus=mut_add['evidence']+[extra]
    mout=audit_text('Alice is safe.',evidence_plus,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_add['rid'],mut_add['req'],None,*mut_add['bundle'])
    add('r23_09_matching_support_added_after_prepare_blocks',mout['control_closure'] is False)

    # 10: adding a selected<->excluded common mode after prepare invalidates policy/certificates.
    mut_cm=r23_case('MUTCM',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    register_support_set_common_mode('cm:r23:mut-after',[mut_cm['ids'][1],mut_cm['ids'][2]],'post-prepare relation')
    mco=audit_text('Alice is safe.',mut_cm['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_cm['rid'],mut_cm['req'],None,*mut_cm['bundle'])
    add('r23_10_common_mode_added_after_prepare_blocks',mco['control_closure'] is False and mco['gates'].get('closure_policy_valid') is False)

    # 11: removing a matching support after prepare blocks exact replay/context validation.
    mut_remove=r23_case('MUTREM',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    mro=audit_text('Alice is safe.',mut_remove['evidence'][:2],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_remove['rid'],mut_remove['req'],None,*mut_remove['bundle'])
    add('r23_11_matching_support_removed_after_prepare_blocks',mro['control_closure'] is False)

    # 12: evidence input permutation does not alter the epistemic result.
    perm1=r23_case('PERM1',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    # Keep the registered source-semantics profiles but isolate the second retrieval snapshot
    # so snapshot-competition policy does not turn this into a different test.
    for _reg in (RETRIEVAL_SCOPE_REGISTRY,SUPPORT_SET_COMMON_MODE_REGISTRY,SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY,
                 SUPPORT_SELECTION_REGISTRY,MATCHING_SUPPORT_UNIVERSE_REGISTRY,SUPPORT_SELECTION_CERTIFICATE_REGISTRY,
                 CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY,RELATION_RESOLUTION_REGISTRY,
                 RELATION_RESOLUTION_CERTIFICATE_REGISTRY,EXCLUDED_SUPPORT_DISPOSITION_REGISTRY,
                 EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY): _reg.clear()
    ids=perm1['ids'];evidence=list(reversed(perm1['evidence']));rid='r23:PERM2'
    _register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}');fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence))
    fmap={f.evidence_id:f for f in fs};selected=tuple(fmap[eid] for eid in ids[:2])
    authorize_support_set_independence('ssi:r23:PERM2','c1',rid,selected,'permutation selected A+B')
    issue_support_set_independence_certificate('ssi:r23:PERM2','c1',rid,selected)
    register_support_selection('sel:r23:PERM2','c1',rid,ids,ids[:2],2,{ids[2]:'EXCLUDED_NOT_NEEDED'},
                               'same canonical selection under reverse input',{ids[2]:'not needed'},None)
    preq={'c1':{'required_independent_supports':2}};pb=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,preq)
    po=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,preq,None,*pb)
    add('r23_12_support_selection_permutation_invariant_epistemic_result',
        perm1['out']['control_closure']==po['control_closure']==True and perm1['out']['claims'][0]['status']==po['claims'][0]['status']=='VERIFIED')

    def r23_fd_relation_case(tag,kind):
        r23_reset();ids=(f'R23{tag}A',f'R23{tag}B',f'R23{tag}C')
        if kind=='SAME': fda,fdb,fdc=f'fd:{tag}:A',f'fd:{tag}:shared',f'fd:{tag}:shared'
        elif kind=='PARENT':
            fda,fdb,fdc=f'fd:{tag}:A',f'fd:{tag}:leafB',f'fd:{tag}:leafC'
            register_failure_domain_parent(fdb,f'fd:{tag}:parent');register_failure_domain_parent(fdc,f'fd:{tag}:parent')
        else:
            fda,fdb,fdc=f'fd:{tag}:A',f'fd:{tag}:canonical',f'fd:{tag}:alias'
            register_failure_domain_alias(fdc,fdb)
        fds=(fda,fdb,fdc);evidence=[]
        for eid,fd in zip(ids,fds):
            sid=f'sem:{eid}';src=f'general-record:{eid}'
            register_source_semantics(sid,src,f'repo:{eid}',f'producer:{eid}',f'process:{eid}',fd)
            evidence.append(ev(eid,'Alice','state','safe','id:alice:v1',source_id=src,source_semantics_id=sid))
        rid=f'r23:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}');fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence))
        authorize_support_set_independence(f'ssi:r23:{tag}','c1',rid,fs[:2],f'{tag} A+B independent');issue_support_set_independence_certificate(f'ssi:r23:{tag}','c1',rid,fs[:2])
        register_support_selection(f'sel:r23:{tag}','c1',rid,ids,ids[:2],2,{ids[2]:'EXCLUDED_DEPENDENT'},f'{tag} selection',{ids[2]:'dependency known but unresolved for exclusion'},None)
        reqx={'c1':{'required_independent_supports':2}};b=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        return audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*b)

    add('r23_14_selected_excluded_same_failure_domain_without_resolution_blocks',r23_fd_relation_case('FDSAME','SAME')['control_closure'] is False)
    add('r23_15_selected_excluded_shared_parent_failure_domain_without_resolution_blocks',r23_fd_relation_case('FDPARENT','PARENT')['control_closure'] is False)
    add('r23_16_selected_excluded_aliased_failure_domain_without_resolution_blocks',r23_fd_relation_case('FDALIAS','ALIAS')['control_closure'] is False)

    # 17: v0.2.25 supersedes the old self-authorizing NDR expectation.  The scenario
    # is preserved, but a typed NON_DECISION_RELEVANT label is no longer sufficient
    # without exact NON_DECISION_RELEVANT_AUTHORIZED handling.
    excl=r23_case('EXCLEXCL',n=4,need=2,common_pair=(2,3),selection=True,classes='EXCLUDED_NOT_NEEDED',
                  common_effect='NON_DECISION_RELEVANT')
    add('r23_17_excluded_excluded_NDR_without_authorization_now_blocks',
        excl['out']['control_closure'] is False
        and excl['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)

    # 18: contradictory classification without an explicit resolution does not pass.
    contra=r23_case('CONTRA',n=3,need=2,selection=True,classes='EXCLUDED_CONTRADICTORY')
    add('r23_18_excluded_contradictory_without_resolution_blocks',contra['out']['control_closure'] is False)

    # 19-24: missing/tampered exact artifacts fail closed.
    missing_sel=r23_case('MISSSEL',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    SUPPORT_SELECTION_CERTIFICATE_REGISTRY.clear()
    mso=audit_text('Alice is safe.',missing_sel['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,missing_sel['rid'],missing_sel['req'],None,*missing_sel['bundle'])
    add('r23_19_missing_support_selection_certificate_blocks',mso['control_closure'] is False and mso['gates'].get('support_selection_justification_valid') is False)

    tam_sel=r23_case('TAMPSEL',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED');sk=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY))
    SUPPORT_SELECTION_CERTIFICATE_REGISTRY[sk]=replace(SUPPORT_SELECTION_CERTIFICATE_REGISTRY[sk],result='FAIL')
    tso=audit_text('Alice is safe.',tam_sel['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tam_sel['rid'],tam_sel['req'],None,*tam_sel['bundle'])
    add('r23_20_tampered_support_selection_certificate_blocks',tso['control_closure'] is False)

    missing_cov=r23_case('MISSCOV',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED');CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.clear()
    mco2=audit_text('Alice is safe.',missing_cov['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,missing_cov['rid'],missing_cov['req'],None,*missing_cov['bundle'])
    add('r23_21_missing_universe_coverage_certificate_blocks',mco2['control_closure'] is False and mco2['gates'].get('claim_support_universe_common_mode_coverage_valid') is False)

    tam_cov=r23_case('TAMPCOV',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED');ck=next(iter(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY))
    CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY[ck]=replace(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY[ck],coverage_result='FAIL')
    tco=audit_text('Alice is safe.',tam_cov['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tam_cov['rid'],tam_cov['req'],None,*tam_cov['bundle'])
    add('r23_22_tampered_universe_coverage_certificate_blocks',tco['control_closure'] is False)

    tam_u=r23_case('TAMPU',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED');uk=next(iter(MATCHING_SUPPORT_UNIVERSE_REGISTRY))
    MATCHING_SUPPORT_UNIVERSE_REGISTRY[uk]=replace(MATCHING_SUPPORT_UNIVERSE_REGISTRY[uk],universe_hash='0'*64)
    tuo=audit_text('Alice is safe.',tam_u['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tam_u['rid'],tam_u['req'],None,*tam_u['bundle'])
    add('r23_23_invalid_matching_universe_hash_blocks',tuo['control_closure'] is False)

    tam_sh=r23_case('TAMPSH',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED');sk=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY))
    SUPPORT_SELECTION_CERTIFICATE_REGISTRY[sk]=replace(SUPPORT_SELECTION_CERTIFICATE_REGISTRY[sk],selected_support_ids_hash='0'*64)
    tsh=audit_text('Alice is safe.',tam_sh['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tam_sh['rid'],tam_sh['req'],None,*tam_sh['bundle'])
    add('r23_24_invalid_selected_subset_hash_blocks',tsh['control_closure'] is False)

    # 25-26: exclusion taxonomy is typed and fail-closed at registration.
    r23_reset();dummy=[ev('R23TAXA','Alice','state','safe','id:alice:v1'),ev('R23TAXB','Alice','state','safe','id:alice:v1'),ev('R23TAXC','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('r23:TAX',dummy,'snapshot:r23:TAX')
    invalid_rejected=False;unknown_rejected=False
    try:register_support_selection('sel:invalid','c1','r23:TAX',['R23TAXA','R23TAXB','R23TAXC'],['R23TAXA','R23TAXB'],2,{'R23TAXC':'SELECTED_JUSTIFICATORY'},'invalid class',{'R23TAXC':'x'})
    except ValueError:invalid_rejected=True
    try:register_support_selection('sel:unknown','c1','r23:TAX',['R23TAXA','R23TAXB','R23TAXC'],['R23TAXA','R23TAXB'],2,{'R23TAXC':'EXCLUDED_MAGIC'},'unknown class',{'R23TAXC':'x'})
    except ValueError:unknown_rejected=True
    add('r23_25_invalid_exclusion_classification_rejected',invalid_rejected)
    add('r23_26_unknown_exclusion_classification_rejected',unknown_rejected)

    # 27-30: pinned gates/obligations/policy fingerprints.
    add('r23_27_universe_coverage_mandatory_gate_present','claim_support_universe_common_mode_coverage_valid' in MANDATORY_GATES)
    add('r23_28_support_selection_mandatory_gate_present','support_selection_justification_valid' in MANDATORY_GATES)
    add('r23_29_new_support_universe_obligations_pinned',
        OBLIGATION_GATE_MAP.get('claim_support_universe_common_mode_coverage')=='claim_support_universe_common_mode_coverage_valid' and
        OBLIGATION_GATE_MAP.get('support_selection_justification')=='support_selection_justification_valid')
    polcase=r23_case('POLPIN',n=2,need=2);pp=polcase['bundle'][0]
    add('r23_30_new_policy_and_artifact_registries_in_closure_fingerprint',pp is not None and
        pp.support_universe_policy_hash==support_universe_policy_hash() and
        pp.matching_support_universe_registry_hash==matching_support_universe_registry_hash(pp.support_artifact_context_id) and
        pp.support_selection_certificate_registry_hash==support_selection_certificate_registry_hash(pp.support_artifact_context_id) and
        pp.claim_support_universe_coverage_certificate_registry_hash==claim_support_universe_coverage_certificate_registry_hash(pp.support_artifact_context_id))

    # 32: original 3-of-3 subset-common-mode remains blocked.
    r22_3=r23_case('R223OF3',n=3,need=3,common_pair=(0,1),selection=False)
    add('r23_32_original_r22_3of3_subset_common_mode_remains_blocked',r22_3['out']['control_closure'] is False)

    # 33-35: explicitly preserve earlier attack regressions and all first 210 tests.
    add('r23_33_r20_attacks_remain_blocked',all(x['pass'] for x in T[:210] if x['name'].startswith('r20_')))
    add('r23_34_r19_attacks_remain_blocked',all(x['pass'] for x in T[:210] if x['name'].startswith('r19_')))
    add('r23_35_all_original_210_self_tests_preserved',old_210_ok)

    # 36: central invariant is pinned, not a comment-only convention.
    add('r23_36_selection_does_not_delete_evidence_relations_is_pinned',
        SUPPORT_UNIVERSE_POLICY.get('selection_does_not_delete_evidence_relations') is True and
        PINNED_SUPPORT_UNIVERSE_POLICY.get('selection_does_not_delete_evidence_relations') is True)

    # Additional mutation/meta checks beyond the minimum list.
    mut_selreg=r23_case('MUTSELREG',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    SUPPORT_SELECTION_REGISTRY['post-prepare:tamper']={'tampered':True}
    msro=audit_text('Alice is safe.',mut_selreg['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_selreg['rid'],mut_selreg['req'],None,*mut_selreg['bundle'])
    add('r23_39_support_selection_registry_mutation_after_prepare_blocks',msro['control_closure'] is False and msro['gates'].get('closure_policy_valid') is False)
    add('r23_40_support_universe_policy_requires_permutation_invariance',PINNED_SUPPORT_UNIVERSE_POLICY.get('permutation_invariant_selection_required') is True)
    add('r23_41_exact_universe_replay_binding_is_pinned',PINNED_SUPPORT_UNIVERSE_POLICY.get('exact_universe_binding_required') is True)
    add('r23_42_mandatory_gate_count_is_47',len(MANDATORY_GATES)==49)

    # Explicit prepare->audit revalidation of the new policy and derived artifact registries.
    mut_policy=r23_case('MUTPOLICY',n=2,need=2)
    saved_universe_policy=dict(SUPPORT_UNIVERSE_POLICY);SUPPORT_UNIVERSE_POLICY['algorithm']='TAMPERED_AFTER_PREPARE'
    mpo=audit_text('Alice is safe.',mut_policy['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_policy['rid'],mut_policy['req'],None,*mut_policy['bundle'])
    add('r23_43_support_universe_policy_mutation_after_prepare_blocks',mpo['control_closure'] is False)
    SUPPORT_UNIVERSE_POLICY.clear();SUPPORT_UNIVERSE_POLICY.update(saved_universe_policy)

    mut_art=r23_case('MUTART',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    _sel0=next(iter(SUPPORT_SELECTION_CERTIFICATE_REGISTRY.values()))
    SUPPORT_SELECTION_CERTIFICATE_REGISTRY['post-prepare:duplicate']=replace(_sel0,certificate_id='post-prepare:duplicate')
    mao=audit_text('Alice is safe.',mut_art['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_art['rid'],mut_art['req'],None,*mut_art['bundle'])
    add('r23_44_selection_certificate_registry_mutation_after_prepare_blocks',mao['control_closure'] is False and mao['gates'].get('closure_policy_valid') is False)

    mut_covreg=r23_case('MUTCOVREG',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    _cov0=next(iter(CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values()))
    CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY['post-prepare:duplicate']=replace(_cov0,certificate_id='post-prepare:duplicate')
    mcro=audit_text('Alice is safe.',mut_covreg['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_covreg['rid'],mut_covreg['req'],None,*mut_covreg['bundle'])
    add('r23_45_universe_coverage_certificate_registry_mutation_after_prepare_blocks',mcro['control_closure'] is False and mcro['gates'].get('closure_policy_valid') is False)

    mut_ureg=r23_case('MUTUREG',n=3,need=2,selection=True,classes='EXCLUDED_NOT_NEEDED')
    _u0=next(iter(MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()))
    MATCHING_SUPPORT_UNIVERSE_REGISTRY['post-prepare:duplicate']=replace(_u0,universe_id='post-prepare:duplicate')
    muro=audit_text('Alice is safe.',mut_ureg['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut_ureg['rid'],mut_ureg['req'],None,*mut_ureg['bundle'])
    add('r23_46_matching_universe_registry_mutation_after_prepare_blocks',muro['control_closure'] is False and muro['gates'].get('closure_policy_valid') is False)


    # ========================================================
    # R24 / v0.2.22: relation-instance identity and exact 1:1 resolution coverage.
    # The first 256 tests above are the preserved v0.2.21 regression baseline.
    # ========================================================
    old_256_ok=(len(T)==256 and all(x['pass'] for x in T))

    def r24_case(tag,relations=(),resolution_ids=(),selection_class='EXCLUDED_REDUNDANT',
                 disposition_relation_ids=None,n=3,need=2,legacy_pair_resolution=False,
                 selected_ids_override=None,relation_registration_order=None):
        r23_reset()
        letters=tuple(chr(ord('A')+i) for i in range(n))
        ids=tuple(f'R24{tag}{x}' for x in letters)
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        rid=f'r24:{tag}'
        _register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence))
        selected_ids=tuple(selected_ids_override or ids[:need])
        fmap={f.evidence_id:f for f in fs}
        selected_facts=tuple(fmap[eid] for eid in selected_ids)
        if need>1:
            iid=f'ssi:r24:{tag}'
            authorize_support_set_independence(iid,'c1',rid,selected_facts,f'R24 selected independence {tag}')
            issue_support_set_independence_certificate(iid,'c1',rid,selected_facts)
        rels=list(relations)
        if relation_registration_order is not None:
            rels=[rels[i] for i in relation_registration_order]
        relation_id_by_suffix={}
        for j,rel in enumerate(rels,1):
            # rel = (suffix, endpoint indexes, effect)
            suffix,endpoints,effect=rel
            relation_id=f'r24:{tag}:{suffix}'
            relation_id_by_suffix[suffix]=relation_id
            register_support_set_common_mode(
                relation_id,[ids[i] for i in endpoints],f'R24 {tag} relation {suffix}',
                relation_effect=effect,claim_id='c1',retrieval_scope_id=rid
            )
        # Semantic relation indexing follows the declared relation list, never registration order.
        relation_ids=[relation_id_by_suffix[suffix] for suffix,_,_ in relations]
        excluded=tuple(sorted(set(ids)-set(selected_ids)))
        if isinstance(selection_class,dict):
            classes={}
            for k,v in selection_class.items():
                eid=ids[k] if isinstance(k,int) else k
                classes[eid]=v
            if set(classes)!=set(excluded):raise ValueError('selection_class mapping must classify every excluded support')
        else:
            classes={eid:selection_class for eid in excluded}
        reasons={eid:f'R24 explicit exclusion {eid}' for eid in excluded}
        legacy_rr={}
        if legacy_pair_resolution and excluded:
            legacy_rr[(selected_ids[-1],excluded[0])]='REDUNDANT_RELATION_ACCOUNTED'
        register_support_selection(f'sel:r24:{tag}','c1',rid,ids,selected_ids,need,classes,
                                   f'R24 deterministic selection {tag}',reasons,legacy_rr)
        for index in resolution_ids:
            relation_id=relation_ids[index]
            row=SUPPORT_SET_COMMON_MODE_REGISTRY[relation_id]
            effect=_relation_row_effect(row)
            allowed=RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,())
            if not allowed:continue
            register_relation_resolution(f'rr:r24:{tag}:{index}',relation_id,'c1',rid,selected_ids,
                                         allowed[0],f'R24 exact resolution {tag} {index}')
        if disposition_relation_ids is not None:
            for eid in excluded:
                if classes[eid]!='EXCLUDED_REDUNDANT':continue
                if isinstance(disposition_relation_ids,dict):
                    key=ids.index(eid)
                    idxs=disposition_relation_ids.get(key,disposition_relation_ids.get(eid))
                    if idxs is None:continue
                else:
                    idxs=disposition_relation_ids
                support_ids=[relation_ids[i] for i in idxs]
                if not support_ids:continue
                register_excluded_support_disposition(
                    f'disp:r24:{tag}:{eid}','c1',rid,eid,selected_ids,support_ids,
                    f'R24 redundant disposition {tag} {eid}'
                )
        reqx={'c1':{'required_independent_supports':need}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        bundle=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        out=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*bundle)
        claims=parse_claims('Alice is safe.');attach_claim_identities(claims,{'c1':'id:alice:v1'})
        claim=claims[0];ctx=bundle[4]
        universe=next((u for u in MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()
                       if isinstance(u,MatchingSupportUniverse) and ctx is not None and u.audit_context_id==ctx.audit_context_id),None)
        descriptor=None if universe is None else _selection_descriptor(claim,universe,reqx['c1'])
        instances=tuple() if universe is None or descriptor is None else _relation_instances_for_claim(claim,ctx,universe,descriptor)
        return {'ids':ids,'evidence':evidence,'facts':fs,'rid':rid,'req':reqx,'bundle':bundle,'out':out,
                'claim':claim,'ctx':ctx,'universe':universe,'descriptor':descriptor,'instances':instances,
                'relation_ids':relation_ids}

    # 1-3: exact R23 class and order invariance.
    atk=r24_case('ATTACK',
                 relations=(('redundancy',(1,2),'REDUNDANCY_ONLY'),('corruption',(1,2),'RELIABILITY_DEGRADING')),
                 resolution_ids=(0,),disposition_relation_ids=(0,),legacy_pair_resolution=True)
    add('r24_01_exact_r23_pair_resolution_laundering_blocks',
        atk['out']['control_closure'] is False
        and atk['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    atk_rev=r24_case('ATTACKREV',
                 relations=(('redundancy',(1,2),'REDUNDANCY_ONLY'),('corruption',(1,2),'RELIABILITY_DEGRADING')),
                 resolution_ids=(0,),disposition_relation_ids=(0,),legacy_pair_resolution=True,
                 relation_registration_order=(1,0))
    add('r24_02_reverse_relation_registration_order_still_blocks',
        atk_rev['out']['control_closure'] is False
        and atk_rev['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    add('r24_03_only_redundancy_resolved_corruption_unresolved_blocks',
        len(atk['out'].get('relation_resolution_certificates',[]))==1
        and atk['out']['control_closure'] is False)

    # 4: both relations individually resolved and policy-acceptable can pass.
    both=r24_case('BOTH',
                 relations=(('redundancy',(1,2),'REDUNDANCY_ONLY'),('degrading',(1,2),'RELIABILITY_DEGRADING')),
                 resolution_ids=(0,1),disposition_relation_ids=(0,))
    add('r24_04_individual_valid_resolutions_for_both_policy_acceptable_relations_can_pass',
        both['out']['control_closure'] is True
        and both['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is True)

    # 5: resolution replay across relation IDs is invalid.
    rc0=next((x for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()
              if isinstance(x,RelationResolutionCertificate) and x.relation_id==both['relation_ids'][0]),None)
    inst1=next((x for x in both['instances'] if x.relation_id==both['relation_ids'][1]),None)
    replay=replace(rc0,relation_id=both['relation_ids'][1]) if rc0 is not None else None
    add('r24_05_resolution_replay_onto_other_relation_id_blocks',
        replay is not None and inst1 is not None
        and validate_relation_resolution_certificate(replay,both['claim'],both['facts'],both['ctx'],
                                                     both['universe'],both['descriptor'],inst1) is False)

    # 6-12: exact certificate binding dimensions.
    inst0=next((x for x in both['instances'] if x.relation_id==both['relation_ids'][0]),None)
    fresh0=_find_relation_resolution_certificate(both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0)
    add('r24_06_wrong_relation_type_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,relation_type='UNKNOWN'),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_07_wrong_relation_effect_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,relation_effect='RELIABILITY_DEGRADING'),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_08_wrong_endpoints_hash_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,evidence_ids_hash='0'*64),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_09_wrong_universe_hash_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,matching_support_universe_hash='0'*64),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_10_wrong_selected_subset_hash_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,selected_support_ids_hash='0'*64),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_11_wrong_retrieval_snapshot_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,retrieval_snapshot_id='snapshot:wrong'),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)
    add('r24_12_wrong_claim_in_resolution_certificate_blocks',
        fresh0 is not None and validate_relation_resolution_certificate(
            replace(fresh0,claim_id='c999'),both['claim'],both['facts'],both['ctx'],both['universe'],both['descriptor'],inst0) is False)

    # 13-14: missing/tampered relation resolution certificate fail closed.
    miss=r24_case('MISS',
                 relations=(('redundancy',(1,2),'REDUNDANCY_ONLY'),),resolution_ids=(0,),disposition_relation_ids=(0,))
    RELATION_RESOLUTION_CERTIFICATE_REGISTRY.clear()
    mo=audit_text('Alice is safe.',miss['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,miss['rid'],miss['req'],None,*miss['bundle'])
    add('r24_13_missing_relation_resolution_certificate_blocks',
        mo['control_closure'] is False and mo['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    tamp=r24_case('TAMP',
                 relations=(('redundancy',(1,2),'REDUNDANCY_ONLY'),),resolution_ids=(0,),disposition_relation_ids=(0,))
    rk=next(iter(RELATION_RESOLUTION_CERTIFICATE_REGISTRY))
    RELATION_RESOLUTION_CERTIFICATE_REGISTRY[rk]=replace(RELATION_RESOLUTION_CERTIFICATE_REGISTRY[rk],result='FAIL')
    to=audit_text('Alice is safe.',tamp['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tamp['rid'],tamp['req'],None,*tamp['bundle'])
    add('r24_14_tampered_relation_resolution_certificate_blocks',to['control_closure'] is False)

    # 15-16: relation-id identity cannot be reused with a second payload/endpoints.
    r23_reset()
    tmp=[ev('R24DUPA','Alice','state','safe','id:alice:v1'),ev('R24DUPB','Alice','state','safe','id:alice:v1'),ev('R24DUPC','Alice','state','safe','id:alice:v1')]
    _register_fixture_retrieval_scope('r24:DUP',tmp,'snapshot:r24:DUP')
    register_support_set_common_mode('r24:dup',['R24DUPA','R24DUPB'],'first',relation_effect='REDUNDANCY_ONLY')
    dup_payload=False;dup_endpoints=False
    try:register_support_set_common_mode('r24:dup',['R24DUPA','R24DUPB'],'second',relation_effect='RELIABILITY_DEGRADING')
    except ValueError:dup_payload=True
    try:register_support_set_common_mode('r24:dup',['R24DUPB','R24DUPC'],'other endpoints',relation_effect='REDUNDANCY_ONLY')
    except ValueError:dup_endpoints=True
    add('r24_15_duplicate_relation_id_different_payload_rejected',dup_payload)
    add('r24_16_relation_id_reused_for_other_endpoints_rejected',dup_endpoints)

    # 17-19: typed effect semantics fail closed.
    unknown=r24_case('UNKNOWN',relations=(('unknown',(1,2),'UNKNOWN'),),
                     resolution_ids=(),disposition_relation_ids=None,selection_class='EXCLUDED_NOT_NEEDED')
    add('r24_17_unknown_relation_effect_blocks',unknown['out']['control_closure'] is False)
    degrading=r24_case('DEGRADE',relations=(('degrading',(1,2),'RELIABILITY_DEGRADING'),),
                       resolution_ids=(),disposition_relation_ids=None,selection_class='EXCLUDED_REDUNDANT')
    add('r24_18_reliability_degrading_plus_excluded_redundant_without_resolution_blocks',
        degrading['out']['control_closure'] is False)
    invalidating=r24_case('INVALIDATE',relations=(('invalidate',(1,2),'SELECTED_SUPPORT_INVALIDATING'),),
                          resolution_ids=(),disposition_relation_ids=None,selection_class='EXCLUDED_NOT_NEEDED')
    add('r24_19_selected_support_invalidating_relation_blocks',invalidating['out']['control_closure'] is False)

    # 20: multiple legal redundancy relations each need their own resolution.
    twored=r24_case('TWORED',
                    relations=(('red1',(1,2),'REDUNDANCY_ONLY'),('red2',(1,2),'REDUNDANCY_ONLY')),
                    resolution_ids=(0,1),disposition_relation_ids=(0,1))
    add('r24_20_two_redundancy_only_relations_each_separately_accounted_pass',
        twored['out']['control_closure'] is True and len(twored['out'].get('relation_resolution_certificates',[]))==2)

    # 21-22: pair + n-way relation identity remains exact. Use D so n-way touches only one selected support.
    pair_nway_block=r24_case('NWAYBLOCK',n=4,
                    relations=(('pair',(1,2),'REDUNDANCY_ONLY'),('nway',(1,2,3),'REDUNDANCY_ONLY')),
                    resolution_ids=(0,),selection_class={2:'EXCLUDED_REDUNDANT',3:'EXCLUDED_REDUNDANT'},
                    disposition_relation_ids={2:(0,)})
    add('r24_21_pair_plus_nway_only_pair_resolved_blocks',pair_nway_block['out']['control_closure'] is False)
    pair_nway_pass=r24_case('NWAYPASS',n=4,
                    relations=(('pair',(1,2),'REDUNDANCY_ONLY'),('nway',(1,2,3),'REDUNDANCY_ONLY')),
                    resolution_ids=(0,1),selection_class={2:'EXCLUDED_REDUNDANT',3:'EXCLUDED_REDUNDANT'},
                    disposition_relation_ids={2:(0,1),3:(1,)})
    add('r24_22_pair_plus_nway_both_individually_resolved_can_pass',pair_nway_pass['out']['control_closure'] is True)

    # 23: free-text "redundant" is not typed proof; default relation effect is UNKNOWN.
    free=r24_case('FREETEXT',relations=(('text',(1,2),'UNKNOWN'),),
                  resolution_ids=(),disposition_relation_ids=None,selection_class='EXCLUDED_REDUNDANT',
                  legacy_pair_resolution=True)
    add('r24_23_free_text_redundant_without_typed_proof_blocks',free['out']['control_closure'] is False)

    # 24-25: redundant exclusion requires a valid disposition certificate.
    nodisp=r24_case('NODISP',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                    resolution_ids=(0,),disposition_relation_ids=None)
    add('r24_24_excluded_redundant_without_disposition_certificate_blocks',nodisp['out']['control_closure'] is False)
    tdisp=r24_case('TDISP',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                   resolution_ids=(0,),disposition_relation_ids=(0,))
    dk=next(iter(EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY))
    EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY[dk]=replace(EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY[dk],result='FAIL')
    tdo=audit_text('Alice is safe.',tdisp['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tdisp['rid'],tdisp['req'],None,*tdisp['bundle'])
    add('r24_25_tampered_excluded_support_disposition_certificate_blocks',tdo['control_closure'] is False)

    # 26-28: prepare->audit policy/registry mutation.
    mcompat=r24_case('MCOMPAT',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                     resolution_ids=(0,),disposition_relation_ids=(0,))
    saved_compat=RELATION_RESOLUTION_POLICY['effect_resolution_compatibility']
    RELATION_RESOLUTION_POLICY['effect_resolution_compatibility']={'REDUNDANCY_ONLY':tuple()}
    mco=audit_text('Alice is safe.',mcompat['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mcompat['rid'],mcompat['req'],None,*mcompat['bundle'])
    add('r24_26_relation_effect_compatibility_matrix_mutation_prepare_audit_blocks',mco['control_closure'] is False)
    RELATION_RESOLUTION_POLICY['effect_resolution_compatibility']=saved_compat

    mreg=r24_case('MREG',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                  resolution_ids=(0,),disposition_relation_ids=(0,))
    RELATION_RESOLUTION_REGISTRY['post-prepare:tamper']={'tampered':True}
    mro=audit_text('Alice is safe.',mreg['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mreg['rid'],mreg['req'],None,*mreg['bundle'])
    add('r24_27_relation_resolution_registry_mutation_prepare_audit_blocks',mro['control_closure'] is False)

    mpol=r24_case('MPOL',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                  resolution_ids=(0,),disposition_relation_ids=(0,))
    saved_pol=dict(RELATION_RESOLUTION_POLICY);RELATION_RESOLUTION_POLICY['algorithm']='TAMPERED_AFTER_PREPARE'
    mpo2=audit_text('Alice is safe.',mpol['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mpol['rid'],mpol['req'],None,*mpol['bundle'])
    add('r24_28_relation_resolution_policy_mutation_prepare_audit_blocks',mpo2['control_closure'] is False)
    RELATION_RESOLUTION_POLICY.clear();RELATION_RESOLUTION_POLICY.update(saved_pol)

    # 29-31: mandatory/meta/policy integration.
    add('r24_29_relation_instance_resolution_coverage_gate_is_mandatory',
        'support_relation_instance_resolution_coverage_valid' in MANDATORY_GATES)
    add('r24_30_relation_instance_resolution_obligation_is_pinned',
        OBLIGATION_GATE_MAP.get('support_relation_instance_resolution_coverage')=='support_relation_instance_resolution_coverage_valid')
    pin=r24_case('PIN',relations=(),selection_class='EXCLUDED_NOT_NEEDED')
    pp=pin['bundle'][0]
    add('r24_31_new_relation_policies_and_registries_in_closure_fingerprint',
        pp is not None and pp.relation_resolution_policy_hash==relation_resolution_policy_hash()
        and pp.relation_resolution_registry_hash==relation_resolution_registry_hash()
        and pp.relation_resolution_certificate_registry_hash==relation_resolution_certificate_registry_hash(pp.support_artifact_context_id)
        and pp.excluded_support_disposition_registry_hash==excluded_support_disposition_registry_hash()
        and pp.excluded_support_disposition_certificate_registry_hash==excluded_support_disposition_certificate_registry_hash(pp.support_artifact_context_id))

    # 32: v0.2.21 legal redundant exclusion still passes when upgraded to typed relation semantics.
    positive=r24_case('POSITIVE',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                      resolution_ids=(0,),disposition_relation_ids=(0,),legacy_pair_resolution=True)
    add('r24_32_original_positive_redundant_exclusion_semantics_remain_pass',positive['out']['control_closure'] is True)

    # 33-38: earlier rounds and prior 256 baseline stay intact.
    r22b=r23_case('R24R22',common_pair=(1,2),selection=False)
    add('r24_33_r22_false_closure_remains_blocked',r22b['out']['control_closure'] is False)
    r223=r23_case('R24R223',n=3,need=3,common_pair=(0,1),selection=False)
    add('r24_34_r22_original_3of3_remains_blocked',r223['out']['control_closure'] is False)
    add('r24_35_r20_attacks_remain_blocked',all(x['pass'] for x in T[:256] if x['name'].startswith('r20_')))
    add('r24_36_r19_attacks_remain_blocked',all(x['pass'] for x in T[:256] if x['name'].startswith('r19_')))
    add('r24_37_support_selection_permutation_invariance_regression_preserved',
        all(x['pass'] for x in T[:256] if x['name']=='r23_12_support_selection_permutation_invariant_epistemic_result'))
    add('r24_38_all_previous_256_self_tests_preserved',old_256_ok)

    # 39: relation registry order cannot change the epistemic outcome.
    ord1=r24_case('ORD1',
                  relations=(('red',(1,2),'REDUNDANCY_ONLY'),('deg',(1,2),'RELIABILITY_DEGRADING')),
                  resolution_ids=(0,),disposition_relation_ids=(0,),relation_registration_order=(0,1))
    ord2=r24_case('ORD2',
                  relations=(('red',(1,2),'REDUNDANCY_ONLY'),('deg',(1,2),'RELIABILITY_DEGRADING')),
                  resolution_ids=(0,),disposition_relation_ids=(0,),relation_registration_order=(1,0))
    add('r24_39_relation_registry_order_invariant_epistemic_result',
        ord1['out']['control_closure']==ord2['out']['control_closure']==False
        and ord1['out']['claims'][0]['status']==ord2['out']['claims'][0]['status'])

    # 40: pair-level legacy token no longer counts as relation-instance coverage.
    legacy=r24_case('LEGACYPAIR',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                    resolution_ids=(),disposition_relation_ids=None,legacy_pair_resolution=True)
    add('r24_40_legacy_pair_level_resolution_token_does_not_cover_relation_instance',
        legacy['out']['control_closure'] is False
        and legacy['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)

    # 41: exact endpoint-set binding distinguishes pair from n-way.
    pair_cert=next((x for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()
                    if isinstance(x,RelationResolutionCertificate)),None)
    # fresh case to avoid previous registry state ambiguity
    ep=r24_case('ENDPOINT',n=4,
                relations=(('pair',(1,2),'REDUNDANCY_ONLY'),('nway',(1,2,3),'REDUNDANCY_ONLY')),
                resolution_ids=(0,1),selection_class={2:'EXCLUDED_REDUNDANT',3:'EXCLUDED_REDUNDANT'},
                disposition_relation_ids={2:(0,1),3:(1,)})
    pinst=next(x for x in ep['instances'] if x.relation_id==ep['relation_ids'][0])
    ninst=next(x for x in ep['instances'] if x.relation_id==ep['relation_ids'][1])
    pcert=_find_relation_resolution_certificate(ep['claim'],ep['facts'],ep['ctx'],ep['universe'],ep['descriptor'],pinst)
    add('r24_41_pair_resolution_cannot_validate_nway_relation_instance',
        pcert is not None and validate_relation_resolution_certificate(
            replace(pcert,relation_id=ninst.relation_id),ep['claim'],ep['facts'],ep['ctx'],ep['universe'],ep['descriptor'],ninst) is False)

    # 42-46: additional pinned and tamper coverage.
    add('r24_42_mandatory_gate_count_is_48',len(MANDATORY_GATES)==49)
    add('r24_43_relation_specific_resolution_invariant_is_pinned',
        RELATION_RESOLUTION_POLICY.get('resolution_is_relation_specific_not_pair_generic') is True
        and PINNED_RELATION_RESOLUTION_POLICY.get('resolution_is_relation_specific_not_pair_generic') is True)
    add('r24_44_free_text_is_not_semantic_authority_is_pinned',
        RELATION_RESOLUTION_POLICY.get('free_text_is_not_semantic_authority') is True)
    mcert=r24_case('MCERT',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                   resolution_ids=(0,),disposition_relation_ids=(0,))
    rr0=next(iter(RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()))
    RELATION_RESOLUTION_CERTIFICATE_REGISTRY['post-prepare:duplicate']=replace(rr0,certificate_id='post-prepare:duplicate')
    mcertout=audit_text('Alice is safe.',mcert['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mcert['rid'],mcert['req'],None,*mcert['bundle'])
    add('r24_45_relation_resolution_certificate_registry_mutation_prepare_audit_blocks',mcertout['control_closure'] is False)
    mdisp=r24_case('MDISP',relations=(('red',(1,2),'REDUNDANCY_ONLY'),),
                   resolution_ids=(0,),disposition_relation_ids=(0,))
    dd0=next(iter(EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY.values()))
    EXCLUDED_SUPPORT_DISPOSITION_CERTIFICATE_REGISTRY['post-prepare:duplicate']=replace(dd0,certificate_id='post-prepare:duplicate')
    mdispout=audit_text('Alice is safe.',mdisp['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mdisp['rid'],mdisp['req'],None,*mdisp['bundle'])
    add('r24_46_excluded_disposition_certificate_registry_mutation_prepare_audit_blocks',mdispout['control_closure'] is False)


    # ========================================================
    # R25 / v0.2.23: discovery closure around selected supports.
    # The first 302 tests above are the preserved v0.2.22 baseline.
    # ========================================================
    old_302_ok=(len(T)==302 and all(x['pass'] for x in T))

    def r25_case(tag,effect='RELIABILITY_DEGRADING',resolve=False,evidence_order=('A','B','X'),
                 relation_endpoints=('B','X'),outside_endpoint=False,relation_type='COMMON_MODE'):
        r23_reset()
        ids={k:f'R25{tag}{k}' for k in ('A','B','X')}
        rows={k:ev(ids[k],'Alice','state','safe','id:alice:v1') for k in ('A','B','X')}
        rows['X']['predicate']='location';rows['X']['value']='London'
        evidence=[rows[k] for k in evidence_order]
        rid=f'r25:{tag}'
        _register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence))
        fmap={f.evidence_id:f for f in fs}
        selected=(fmap[ids['A']],fmap[ids['B']])
        iid=f'ssi:r25:{tag}'
        authorize_support_set_independence(iid,'c1',rid,selected,f'R25 selected independence {tag}')
        issue_support_set_independence_certificate(iid,'c1',rid,selected)
        relation_id=f'rel:r25:{tag}'
        endpoint_ids=[]
        for x in relation_endpoints:
            if x=='OUTSIDE' or outside_endpoint and x=='X':endpoint_ids.append(f'R25{tag}OUTSIDE')
            else:endpoint_ids.append(ids.get(x,x))
        if relation_type=='UNKNOWN':
            register_support_set_unknown(relation_id,'c1',rid,endpoint_ids,f'R25 unknown relation {tag}')
        else:
            register_support_set_common_mode(relation_id,endpoint_ids,f'R25 relation {tag}',
                                             relation_effect=effect,claim_id='c1',retrieval_scope_id=rid)
        if resolve:
            allowed=RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,())
            if allowed:
                register_relation_resolution(f'rr:r25:{tag}',relation_id,'c1',rid,
                                             [ids['A'],ids['B']],allowed[0],f'R25 exact relation resolution {tag}')
        reqx={'c1':{'required_independent_supports':2}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        bundle=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        out=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*bundle)
        claims=parse_claims('Alice is safe.');attach_claim_identities(claims,{'c1':'id:alice:v1'})
        ctx=bundle[4]
        universe=next((u for u in MATCHING_SUPPORT_UNIVERSE_REGISTRY.values()
                       if isinstance(u,MatchingSupportUniverse) and ctx is not None and u.audit_context_id==ctx.audit_context_id),None)
        descriptor=None if universe is None else _selection_descriptor(claims[0],universe,reqx['c1'])
        neighborhood=None if universe is None or descriptor is None or ctx is None else _find_decision_relevant_relation_universe(claims[0],ctx,universe,descriptor)
        instances=tuple() if universe is None or descriptor is None or ctx is None else _relation_instances_for_claim(claims[0],ctx,universe,descriptor)
        return {'ids':ids,'evidence':evidence,'facts':fs,'rid':rid,'req':reqx,'bundle':bundle,'out':out,
                'claim':claims[0],'ctx':ctx,'universe':universe,'descriptor':descriptor,
                'neighborhood':neighborhood,'instances':instances,'relation_id':relation_id}

    # 1: exact R24 counterexample is now discovered and blocked by missing relation-specific resolution.
    gap=r25_case('GAP',effect='RELIABILITY_DEGRADING',resolve=False)
    add('r25_01_selected_to_nonmatching_degrading_relation_is_discovered_and_blocks',
        gap['out']['control_closure'] is False
        and gap['out']['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and gap['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False
        and tuple(x.relation_id for x in gap['instances'])==(gap['relation_id'],))

    # 2-3: fail-closed typed effects outside the matching support universe.
    unk=r25_case('UNKNOWN',effect='UNKNOWN',resolve=False)
    add('r25_02_selected_to_nonmatching_unknown_relation_blocks',
        unk['out']['control_closure'] is False
        and unk['out']['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and unk['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    inv=r25_case('INVALIDATING',effect='SELECTED_SUPPORT_INVALIDATING',resolve=False)
    add('r25_03_selected_to_nonmatching_invalidating_relation_blocks',
        inv['out']['control_closure'] is False
        and inv['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)

    # 4: typed NON_DECISION_RELEVANT semantics can pass only with its exact relation resolution.
    ndr=r25_case('NDR',effect='NON_DECISION_RELEVANT',resolve=True)
    add('r25_04_selected_to_nonmatching_nondecision_relation_with_typed_authorization_can_pass',
        ndr['out']['control_closure'] is True
        and ndr['out']['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and ndr['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is True)

    # 5: a selected-anchored relation with an endpoint outside the retrieval snapshot is visible but invalid.
    outside=r25_case('OUTSIDE',effect='RELIABILITY_DEGRADING',resolve=False,relation_endpoints=('B','OUTSIDE'))
    add('r25_05_selected_relation_endpoint_outside_snapshot_fails_discovery_closed',
        outside['out']['control_closure'] is False
        and outside['out']['gates'].get('decision_relevant_relation_discovery_complete_valid') is False
        and outside['neighborhood'] is not None
        and outside['neighborhood'].out_of_snapshot_relation_ids==(outside['relation_id'],))

    # 6: relation-neighborhood mutation after prepare invalidates the exact policy/artifact binding.
    mut=r25_case('MUT',effect='NON_DECISION_RELEVANT',resolve=True)
    register_support_set_common_mode('rel:r25:MUT:post',[mut['ids']['A'],mut['ids']['X']],
                                     'post-prepare relation neighborhood change',relation_effect='NON_DECISION_RELEVANT',
                                     claim_id='c1',retrieval_scope_id=mut['rid'])
    mout=audit_text('Alice is safe.',mut['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut['rid'],mut['req'],None,*mut['bundle'])
    add('r25_06_relation_neighborhood_change_after_prepare_blocks',
        mout['control_closure'] is False and mout['gates'].get('closure_policy_valid') is False)

    # 7: evidence ordering cannot change the epistemic result.
    p1=r25_case('PERM1',effect='RELIABILITY_DEGRADING',resolve=False,evidence_order=('A','B','X'))
    p2=r25_case('PERM2',effect='RELIABILITY_DEGRADING',resolve=False,evidence_order=('X','B','A'))
    add('r25_07_selected_nonmatching_relation_discovery_is_permutation_invariant',
        (p1['out']['claims'][0]['status'],p1['out']['stop_type'],p1['out']['control_closure'])==
        (p2['out']['claims'][0]['status'],p2['out']['stop_type'],p2['out']['control_closure'])
        and p1['out']['control_closure'] is False)

    # 8-9: exact discovered relation set is an explicit artifact and is bound into universe coverage.
    bound=r25_case('BOUND',effect='NON_DECISION_RELEVANT',resolve=True)
    bcov=next((x for x in CLAIM_SUPPORT_UNIVERSE_COVERAGE_CERTIFICATE_REGISTRY.values()
               if isinstance(x,ClaimSupportUniverseCoverageCertificate)
               and bound['ctx'] is not None and x.audit_context_id==bound['ctx'].audit_context_id),None)
    add('r25_08_decision_relevant_relation_universe_binds_exact_relation_id_set',
        bound['neighborhood'] is not None and bound['neighborhood'].relation_ids==(bound['relation_id'],)
        and bound['neighborhood'].relation_ids_hash==sha((bound['relation_id'],)))
    add('r25_09_claim_universe_coverage_certificate_binds_relation_neighborhood',
        bcov is not None and bound['neighborhood'] is not None
        and bcov.decision_relevant_relation_universe_hash==bound['neighborhood'].universe_hash
        and bcov.decision_relevant_relation_ids_hash==bound['neighborhood'].relation_ids_hash)

    # 10-11: missing/tampered discovery artifact fails closed.
    miss=r25_case('MISS',effect='NON_DECISION_RELEVANT',resolve=True)
    if miss['neighborhood'] is not None:
        DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY.pop(miss['neighborhood'].universe_id,None)
    missout=audit_text('Alice is safe.',miss['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,miss['rid'],miss['req'],None,*miss['bundle'])
    add('r25_10_missing_relation_neighborhood_artifact_blocks',
        missout['control_closure'] is False
        and missout['gates'].get('decision_relevant_relation_discovery_complete_valid') is False)
    tamp=r25_case('TAMP',effect='NON_DECISION_RELEVANT',resolve=True)
    if tamp['neighborhood'] is not None:
        DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY[tamp['neighborhood'].universe_id]=replace(
            tamp['neighborhood'],relation_ids_hash='0'*64)
    tampout=audit_text('Alice is safe.',tamp['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,tamp['rid'],tamp['req'],None,*tamp['bundle'])
    add('r25_11_tampered_relation_neighborhood_artifact_blocks',
        tampout['control_closure'] is False
        and tampout['gates'].get('closure_policy_valid') is False)

    # 12: unrelated relation among nonmatching evidence is not pulled into the selected-support neighborhood.
    r23_reset()
    ida,idb,idx,idy='R25UNRELA','R25UNRELB','R25UNRELX','R25UNRELY'
    ea=ev(ida,'Alice','state','safe','id:alice:v1');eb=ev(idb,'Alice','state','safe','id:alice:v1')
    ex=ev(idx,'Alice','location','London','id:alice:v1');ey=ev(idy,'Alice','location','London','id:alice:v1')
    ue=[ea,eb,ex,ey];urid='r25:unrelated';_register_fixture_retrieval_scope(urid,ue,f'snapshot:{urid}')
    ufs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(ue));ufmap={f.evidence_id:f for f in ufs}
    authorize_support_set_independence('ssi:r25:unrelated','c1',urid,(ufmap[ida],ufmap[idb]),'selected independence')
    issue_support_set_independence_certificate('ssi:r25:unrelated','c1',urid,(ufmap[ida],ufmap[idb]))
    register_support_set_common_mode('rel:r25:unrelated',[idx,idy],'unrelated nonmatching relation',
                                     relation_effect='RELIABILITY_DEGRADING',claim_id='c1',retrieval_scope_id=urid)
    ureq={'c1':{'required_independent_supports':2}}
    ub=prepare('Alice is safe.',ue,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,urid,ureq)
    uo=audit_text('Alice is safe.',ue,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,urid,ureq,None,*ub)
    uneigh=next((x for x in DECISION_RELEVANT_RELATION_UNIVERSE_REGISTRY.values()
                 if isinstance(x,DecisionRelevantRelationUniverse) and ub[4] is not None and x.audit_context_id==ub[4].audit_context_id),None)
    add('r25_12_unrelated_nonmatching_relation_does_not_overblock_selected_supports',
        uo['control_closure'] is False and uneigh is not None and uneigh.relation_ids==tuple())

    # 13: n-way selected-anchored relation with nonmatching endpoints is discovered and blocks without resolution.
    r23_reset()
    na,nb,nx,ny='R25NWAYA','R25NWAYB','R25NWAYX','R25NWAYY'
    nea=ev(na,'Alice','state','safe','id:alice:v1');neb=ev(nb,'Alice','state','safe','id:alice:v1')
    nex=ev(nx,'Alice','location','London','id:alice:v1');ney=ev(ny,'Alice','location','London','id:alice:v1')
    ne=[nea,neb,nex,ney];nrid='r25:nway';_register_fixture_retrieval_scope(nrid,ne,f'snapshot:{nrid}')
    nfs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(ne));nfmap={f.evidence_id:f for f in nfs}
    authorize_support_set_independence('ssi:r25:nway','c1',nrid,(nfmap[na],nfmap[nb]),'selected independence')
    issue_support_set_independence_certificate('ssi:r25:nway','c1',nrid,(nfmap[na],nfmap[nb]))
    register_support_set_common_mode('rel:r25:nway',[nb,nx,ny],'n-way degrading neighborhood relation',
                                     relation_effect='RELIABILITY_DEGRADING',claim_id='c1',retrieval_scope_id=nrid)
    nreq={'c1':{'required_independent_supports':2}};nbu=prepare('Alice is safe.',ne,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,nrid,nreq)
    no=audit_text('Alice is safe.',ne,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,nrid,nreq,None,*nbu)
    add('r25_13_nway_selected_to_nonmatching_relation_is_discovered_and_blocks',
        no['control_closure'] is False and no['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and no['gates'].get('support_relation_instance_resolution_coverage_valid') is False)

    # 14: a degrading selected->nonmatching relation can pass only when individually resolved.
    degok=r25_case('DEGOK',effect='RELIABILITY_DEGRADING',resolve=True)
    add('r25_14_selected_to_nonmatching_degrading_relation_with_exact_resolution_can_pass',
        degok['out']['control_closure'] is True
        and degok['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is True)

    # 15: discovery policy mutation after prepare is revalidated and blocks.
    pmt=r25_case('POLMUT',effect='NON_DECISION_RELEVANT',resolve=True)
    saved_disc=dict(RELATION_DISCOVERY_POLICY);RELATION_DISCOVERY_POLICY['algorithm']='CHANGED_AFTER_PREPARE'
    pmo=audit_text('Alice is safe.',pmt['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,pmt['rid'],pmt['req'],None,*pmt['bundle'])
    add('r25_15_relation_discovery_policy_mutation_prepare_audit_blocks',
        pmo['control_closure'] is False and pmo['gates'].get('closure_policy_valid') is False)
    RELATION_DISCOVERY_POLICY.clear();RELATION_DISCOVERY_POLICY.update(saved_disc)

    # 16-18: mandatory/meta/fingerprint integration and previous baseline.
    add('r25_16_relation_discovery_gate_is_mandatory_and_obligation_pinned',
        'decision_relevant_relation_discovery_complete_valid' in MANDATORY_GATES
        and OBLIGATION_GATE_MAP.get('decision_relevant_relation_discovery_complete')=='decision_relevant_relation_discovery_complete_valid')
    fp=r25_case('FP',effect='NON_DECISION_RELEVANT',resolve=True)
    fpol=fp['bundle'][0]
    add('r25_17_relation_discovery_policy_and_universe_registry_are_in_closure_fingerprint',
        fpol is not None and fpol.relation_discovery_policy_hash==relation_discovery_policy_hash()
        and fpol.decision_relevant_relation_universe_registry_hash==decision_relevant_relation_universe_registry_hash(fpol.support_artifact_context_id))
    add('r25_18_all_previous_302_self_tests_preserved',old_302_ok)
    add('r25_19_mandatory_gate_count_is_49',len(MANDATORY_GATES)==49)

    # ========================================================
    # R26 / v0.2.24: effect-first relevance for excluded supports.
    # The first 321 tests above are the preserved v0.2.23 baseline.
    # Detailed v0.2.24 cases live in acceptance_v0_2_24.py.
    # ========================================================
    old_321_ok=(len(T)==321 and all(x['pass'] for x in T))

    def r26_exact_case():
        r23_reset();tag='EXACT';ids=tuple(f'R26{tag}{x}' for x in 'ABCD')
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        rid='r26:EXACT';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence));fmap={f.evidence_id:f for f in fs}
        selected=(fmap[ids[0]],fmap[ids[1]])
        authorize_support_set_independence('ssi:r26:EXACT','c1',rid,selected,'R26 selected independence')
        issue_support_set_independence_certificate('ssi:r26:EXACT','c1',rid,selected)
        rels=(('ac',(0,2),'REDUNDANCY_ONLY'),('bd',(1,3),'REDUNDANCY_ONLY'),('cd',(2,3),'RELIABILITY_DEGRADING'))
        rids=[]
        for suffix,ep,effect in rels:
            rr=f'rel:r26:EXACT:{suffix}';rids.append(rr)
            register_support_set_common_mode(rr,[ids[i] for i in ep],f'R26 exact {suffix}',relation_effect=effect,claim_id='c1',retrieval_scope_id=rid)
        register_support_selection('sel:r26:EXACT','c1',rid,ids,ids[:2],2,
            {ids[2]:'EXCLUDED_REDUNDANT',ids[3]:'EXCLUDED_REDUNDANT'},'R26 deterministic selection',
            {ids[2]:'redundant to A',ids[3]:'redundant to B'}, {})
        for i in (0,1):
            effect=_relation_row_effect(SUPPORT_SET_COMMON_MODE_REGISTRY[rids[i]]);allowed=RELATION_EFFECT_RESOLUTION_COMPATIBILITY[effect]
            register_relation_resolution(f'rr:r26:EXACT:{i}',rids[i],'c1',rid,ids[:2],allowed[0],f'R26 exact resolution {i}')
        register_excluded_support_disposition('disp:r26:C','c1',rid,ids[2],ids[:2],[rids[0]],'C redundant to A')
        register_excluded_support_disposition('disp:r26:D','c1',rid,ids[3],ids[:2],[rids[1]],'D redundant to B')
        reqx={'c1':{'required_independent_supports':2}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        bundle=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        out=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*bundle)
        return bundle,out

    r26bundle,r26out=r26_exact_case()
    add('r26_01_exact_r25_excluded_excluded_degrading_false_closure_now_blocks',
        r26out['control_closure'] is False
        and r26out['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and r26out['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    add('r26_02_v0_2_23_baseline_preserved_policy_pinned_and_gate_count_49',
        old_321_ok and len(MANDATORY_GATES)==49 and relation_decision_relevance_policy_adequate(ASOF)
        and PINNED_META_AUTHORITY.get('relation_decision_relevance_policy_hash')==relation_decision_relevance_policy_hash()
        and r26bundle[0] is not None and r26bundle[0].relation_decision_relevance_policy_hash==relation_decision_relevance_policy_hash())

    # ========================================================
    # R27 / v0.2.25: required handling precedes nonblocking NDR status.
    # One historical v0.2.23 assertion was intentionally superseded above because it
    # encoded the exact self-authorizing behavior falsified in Runda 26.
    # ========================================================
    old_323_semantic_cases_ok=(len(T)==323 and all(x['pass'] for x in T))

    def r27_ndr_case(tag,resolve=False,evidence_order=None):
        r23_reset();ids=tuple(f'R27{tag}{x}' for x in 'ABC')
        rows={eid:ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids}
        order=range(3) if evidence_order is None else evidence_order
        evidence=[rows[ids[i]] for i in order]
        rid=f'r27:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        register_support_set_common_mode(f'rel:r27:{tag}:bc',[ids[1],ids[2]],f'{tag} all-excluded NDR',
                                         relation_effect='NON_DECISION_RELEVANT',claim_id='c1',retrieval_scope_id=rid)
        register_support_selection(f'sel:r27:{tag}','c1',rid,ids,(ids[0],),1,
                                   {ids[1]:'EXCLUDED_NOT_NEEDED',ids[2]:'EXCLUDED_NOT_NEEDED'},
                                   f'{tag} deterministic selection',
                                   {ids[1]:'not needed',ids[2]:'not needed'}, {})
        if resolve:
            register_relation_resolution(f'rr:r27:{tag}',f'rel:r27:{tag}:bc','c1',rid,(ids[0],),
                                         'NON_DECISION_RELEVANT_AUTHORIZED',f'{tag} exact NDR authorization')
        reqx={'c1':{'required_independent_supports':1}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        b=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        o=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*b)
        return o

    r27miss=r27_ndr_case('MISS',False)
    add('r27_01_all_excluded_NDR_without_exact_authorization_blocks',
        r27miss['control_closure'] is False
        and r27miss['gates'].get('decision_relevant_relation_discovery_complete_valid') is True
        and r27miss['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    r27ok=r27_ndr_case('OK',True)
    add('r27_02_all_excluded_NDR_with_exact_authorization_can_pass',
        r27ok['control_closure'] is True
        and r27ok['claims'][0]['status']=='VERIFIED'
        and r27ok['stop_type']=='EPISTEMIC_STOP'
        and len(r27ok.get('relation_resolution_certificates',()))==1)
    r27rev=r27_ndr_case('REV',False,[2,1,0])
    add('r27_03_NDR_required_handling_is_evidence_order_invariant',
        r27rev['control_closure'] is False
        and r27rev['gates'].get('support_relation_instance_resolution_coverage_valid') is False
        and (r27rev['claims'][0]['status'],r27rev['stop_type'],r27rev['control_closure'])==
            (r27miss['claims'][0]['status'],r27miss['stop_type'],r27miss['control_closure']))
    add('r27_04_required_handling_policy_is_pinned_and_executable',
        old_323_semantic_cases_ok and relation_decision_relevance_policy_adequate(ASOF)
        and RELATION_DECISION_RELEVANCE_POLICY.get('effect_required_handling',{}).get('NON_DECISION_RELEVANT')=='AUTHORIZATION_REQUIRED'
        and RELATION_DECISION_RELEVANCE_POLICY.get('authorization_precedes_nonblocking_status') is True
        and len(MANDATORY_GATES)==49)

    # ========================================================
    # R28 / v0.2.26: authorization-source scope must already cover certificate scope.
    # A pre-context declaration is PENDING and cannot mint any certificate until an
    # explicit deterministic context-binding step is performed.
    # ========================================================
    old_327_ok=(len(T)==327 and all(x['pass'] for x in T))

    def r28_setup(tag,asof=ASOF,bind=False,resolution_id=None):
        r23_reset();ids=tuple(f'R28{tag}{x}' for x in 'ABC')
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1',obs=asof,avail=asof) for eid in ids]
        rid=f'r28:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        relid=f'rel:r28:{tag}:bc'
        register_support_set_common_mode(relid,[ids[1],ids[2]],f'{tag} all-excluded NDR',
                                         relation_effect='NON_DECISION_RELEVANT',claim_id='c1',retrieval_scope_id=rid)
        register_support_selection(f'sel:r28:{tag}','c1',rid,ids,(ids[0],),1,
                                   {ids[1]:'EXCLUDED_NOT_NEEDED',ids[2]:'EXCLUDED_NOT_NEEDED'},
                                   f'{tag} deterministic selection',
                                   {ids[1]:'not needed',ids[2]:'not needed'}, {})
        rrid=resolution_id or f'rr:r28:{tag}:1'
        register_relation_resolution(rrid,relid,'c1',rid,(ids[0],),
                                     'NON_DECISION_RELEVANT_AUTHORIZED',f'{tag} NDR authorization')
        reqx={'c1':{'required_independent_supports':1}}
        bound_ok=None
        if bind:
            bound_ok=bind_relation_resolution_authorizations_for_prepare(
                'Alice is safe.',evidence,{'c1':'id:alice:v1'},asof,SCOPE,EXTRACT,rid,reqx,(rrid,))
        bundle=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},asof,SCOPE,EXTRACT,rid,reqx)
        out=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},asof,SCOPE,EXTRACT,rid,reqx,None,*bundle)
        return {'ids':ids,'evidence':evidence,'rid':rid,'relid':relid,'rrid':rrid,'req':reqx,
                'bundle':bundle,'out':out,'bound_ok':bound_ok}

    # 1: an under-bound declaration is not itself sufficient for issuance.
    ub=r28_setup('UNBOUND',bind=False)
    ubrow=RELATION_RESOLUTION_REGISTRY.get(ub['rrid'])
    add('r28_01_precontext_authorization_declaration_without_explicit_binding_blocks',
        ub['out']['control_closure'] is False
        and ub['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False
        and not ub['out'].get('relation_resolution_certificates')
        and isinstance(ubrow,dict) and ubrow.get('authorization_binding_state')=='PENDING')

    # 2: exact explicit binding before prepare is a legal positive control.
    ok=r28_setup('BOUND',bind=True)
    okrow=RELATION_RESOLUTION_REGISTRY.get(ok['rrid'])
    okcert=next((x for x in RELATION_RESOLUTION_CERTIFICATE_REGISTRY.values()
                 if isinstance(x,RelationResolutionCertificate)),None)
    add('r28_02_exact_context_bound_authorization_can_pass',
        ok['bound_ok'] is True and ok['out']['control_closure'] is True
        and ok['out']['claims'][0]['status']=='VERIFIED' and ok['out']['stop_type']=='EPISTEMIC_STOP'
        and isinstance(okrow,dict) and okrow.get('authorization_binding_state')=='BOUND'
        and okcert is not None and okcert.authorization_scope_hash==okrow.get('authorization_scope_hash'))

    # 3: the same bound source cannot mint a second certificate for another audit context.
    second_asof='2026-08-11'
    b2=prepare('Alice is safe.',ok['evidence'],{'c1':'id:alice:v1'},second_asof,SCOPE,EXTRACT,ok['rid'],ok['req'])
    o2=audit_text('Alice is safe.',ok['evidence'],{'c1':'id:alice:v1'},second_asof,SCOPE,EXTRACT,ok['rid'],ok['req'],None,*b2)
    add('r28_03_bound_authorization_not_reusable_for_different_audit_context',
        b2[4] is not None and ok['bundle'][4] is not None
        and b2[4].audit_context_id!=ok['bundle'][4].audit_context_id
        and o2['control_closure'] is False
        and o2['gates'].get('support_relation_instance_resolution_coverage_valid') is False)

    # 4: a fresh declaration explicitly bound to the second context can pass.
    rr2='rr:r28:BOUND:2'
    register_relation_resolution(rr2,ok['relid'],'c1',ok['rid'],(ok['ids'][0],),
                                 'NON_DECISION_RELEVANT_AUTHORIZED','second-context exact authorization')
    b2ok=bind_relation_resolution_authorizations_for_prepare(
        'Alice is safe.',ok['evidence'],{'c1':'id:alice:v1'},second_asof,SCOPE,EXTRACT,ok['rid'],ok['req'],(rr2,))
    b2p=prepare('Alice is safe.',ok['evidence'],{'c1':'id:alice:v1'},second_asof,SCOPE,EXTRACT,ok['rid'],ok['req'])
    o2p=audit_text('Alice is safe.',ok['evidence'],{'c1':'id:alice:v1'},second_asof,SCOPE,EXTRACT,ok['rid'],ok['req'],None,*b2p)
    add('r28_04_fresh_second_context_authorization_can_pass',
        b2ok is True and o2p['control_closure'] is True
        and o2p['claims'][0]['status']=='VERIFIED' and o2p['stop_type']=='EPISTEMIC_STOP')

    # 5: exact scope binding includes context, universe, selected subset and relation neighborhood.
    row2=RELATION_RESOLUTION_REGISTRY.get(rr2)
    add('r28_05_authorization_source_binds_exact_context_universe_subset_and_neighborhood',
        isinstance(row2,dict) and all(nonblank(row2.get(k)) for k in (
            'audit_context_id','matching_support_universe_hash','selected_support_ids_hash',
            'decision_relevant_relation_universe_hash','decision_relevant_relation_ids_hash',
            'authorization_scope_hash'))
        and row2.get('audit_context_id')==b2p[4].audit_context_id)

    # 6: direct old-certificate replay into the second context remains invalid.
    claims2=parse_claims('Alice is safe.');attach_claim_identities(claims2,{'c1':'id:alice:v1'})
    facts2=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(ok['evidence']))
    u2=_find_matching_support_universe(claims2[0],facts2,b2p[4])
    d2=None if u2 is None else _selection_descriptor(claims2[0],u2,ok['req']['c1'])
    i2=tuple() if d2 is None else _relation_instances_for_claim(claims2[0],b2p[4],u2,d2)
    add('r28_06_old_context_certificate_direct_replay_remains_invalid',
        okcert is not None and len(i2)==1
        and validate_relation_resolution_certificate(okcert,claims2[0],facts2,b2p[4],u2,d2,i2[0]) is False)

    # 7: binding-field mutation after prepare is covered by the closure fingerprint.
    mut=r28_setup('MUT',bind=True)
    mrow=dict(RELATION_RESOLUTION_REGISTRY[mut['rrid']]);mrow['authorization_scope_hash']='0'*64
    RELATION_RESOLUTION_REGISTRY[mut['rrid']]=mrow
    mout=audit_text('Alice is safe.',mut['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut['rid'],mut['req'],None,*mut['bundle'])
    add('r28_07_authorization_binding_mutation_prepare_audit_blocks',
        mout['control_closure'] is False and mout['gates'].get('closure_policy_valid') is False)

    # 8: make_relation_resolution_certificate never repairs a PENDING source by adding scope.
    pend=r28_setup('NOMINT',bind=False)
    pcl=parse_claims('Alice is safe.');attach_claim_identities(pcl,{'c1':'id:alice:v1'})
    pfacts=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(pend['evidence']))
    pctx=pend['bundle'][4];pu=_find_matching_support_universe(pcl[0],pfacts,pctx) if pctx else None
    pd=None if pu is None else _selection_descriptor(pcl[0],pu,pend['req']['c1'])
    pins=tuple() if pd is None else _relation_instances_for_claim(pcl[0],pctx,pu,pd)
    add('r28_08_certificate_issuance_does_not_repair_underbound_authorization_source',
        len(pins)==1 and make_relation_resolution_certificate(pcl[0],pfacts,pctx,pu,pd,pins[0]) is None)

    # 9: the v0.2.26 scope-source invariants are pinned and all previous 327 self-tests survive.
    add('r28_09_scope_source_invariants_pinned_and_previous_327_tests_preserved',
        old_327_ok and relation_resolution_policy_adequate(ASOF) and len(MANDATORY_GATES)==49
        and RELATION_RESOLUTION_POLICY.get('authorization_declaration_scope_must_cover_certificate_scope') is True
        and RELATION_RESOLUTION_POLICY.get('certificate_binding_cannot_repair_underbound_authorization_source') is True
        and RELATION_RESOLUTION_POLICY.get('non_decision_relevant_authorization_is_audit_context_specific') is True
        and RELATION_RESOLUTION_POLICY.get('issuance_must_not_add_unauthorized_epistemic_scope') is True)

    # ========================================================
    # R29 / v0.2.27: full-universe source/failure-domain dependency closure.
    # The previous 336 tests above are retained unchanged.
    # ========================================================
    old_336_ok=(len(T)==336 and all(x['pass'] for x in T))

    def r29_fd_path_case(tag,mode='ALIAS',resolve_middle=False,reverse=False,connect_b=True):
        r23_reset();ids=tuple(f'R29{tag}{x}' for x in 'ABCD')
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        semids={row['evidence_id']:row['source_semantics_id'] for row in evidence}
        if mode=='ALIAS':register_failure_domain_alias(SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['failure_domain_id'],SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['failure_domain_id'])
        elif mode=='PARENT':
            register_failure_domain_parent(SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['failure_domain_id'],f'fd:r29:{tag}:parent')
            register_failure_domain_parent(SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['failure_domain_id'],f'fd:r29:{tag}:parent')
        elif mode=='COMMON_MODE':
            SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['source_common_mode_ids']=(f'scm:r29:{tag}',)
            SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['source_common_mode_ids']=(f'scm:r29:{tag}',)
        for sid in semids.values():issue_source_semantics_resolution_certificate(sid)
        if reverse:evidence=list(reversed(evidence))
        rid=f'r29:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence));fmap={f.evidence_id:f for f in fs}
        selected=(ids[0],ids[1]);sf=tuple(fmap[x] for x in selected)
        authorize_support_set_independence(f'ssi:r29:{tag}','c1',rid,sf,f'{tag} selected independence')
        issue_support_set_independence_certificate(f'ssi:r29:{tag}','c1',rid,sf)
        rel_ac=f'rel:r29:{tag}:ac';register_support_set_common_mode(rel_ac,[ids[0],ids[2]],'A-C redundant',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        rel_bd=None
        if connect_b:
            rel_bd=f'rel:r29:{tag}:bd';register_support_set_common_mode(rel_bd,[ids[1],ids[3]],'B-D redundant',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        classes={ids[2]:'EXCLUDED_REDUNDANT',ids[3]:'EXCLUDED_REDUNDANT' if connect_b else 'EXCLUDED_NOT_NEEDED'}
        reasons={ids[2]:'C redundant to A',ids[3]:'D redundant to B' if connect_b else 'D not needed'}
        pairres={(ids[2],ids[3]):'DEPENDENCY_ACCOUNTED_NOT_COUNTED'} if resolve_middle else {}
        register_support_selection(f'sel:r29:{tag}','c1',rid,ids,selected,2,classes,f'{tag} selection',reasons,pairres)
        register_relation_resolution(f'rr:r29:{tag}:ac',rel_ac,'c1',rid,selected,'REDUNDANT_RELATION_ACCOUNTED','A-C accounted')
        register_excluded_support_disposition(f'disp:r29:{tag}:C','c1',rid,ids[2],selected,[rel_ac],'C redundant')
        if connect_b:
            register_relation_resolution(f'rr:r29:{tag}:bd',rel_bd,'c1',rid,selected,'REDUNDANT_RELATION_ACCOUNTED','B-D accounted')
            register_excluded_support_disposition(f'disp:r29:{tag}:D','c1',rid,ids[3],selected,[rel_bd],'D redundant')
        reqx={'c1':{'required_independent_supports':2}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        b=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        o=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*b)
        claimsx=parse_claims('Alice is safe.');attach_claim_identities(claimsx,{'c1':'id:alice:v1'})
        ux=_find_matching_support_universe(claimsx[0],fs,b[4]);dx=_selection_descriptor(claimsx[0],ux,reqx['c1'])
        led=_support_relation_ledger(claimsx[0],fs,b[4],ux,dx)
        cd=next(x for x in led if set(x[:2])=={ids[2],ids[3]})
        return {'out':o,'bundle':b,'ids':ids,'rid':rid,'req':reqx,'evidence':evidence,'cd':cd}

    r29a=r29_fd_path_case('ALIAS','ALIAS',False,False,True)
    add('r29_01_exact_R28_excluded_excluded_failure_domain_path_now_blocks',
        r29a['out']['control_closure'] is False and r29a['cd'][3]=='DEPENDENT' and r29a['cd'][9] is True
        and r29a['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    r29ar=r29_fd_path_case('ALIASREV','ALIAS',False,True,True)
    add('r29_02_failure_domain_path_block_is_order_invariant',
        r29ar['out']['control_closure'] is False and r29ar['cd'][9] is True
        and (r29ar['out']['claims'][0]['status'],r29ar['out']['stop_type'],r29ar['out']['control_closure'])==
            (r29a['out']['claims'][0]['status'],r29a['out']['stop_type'],r29a['out']['control_closure']))
    r29p=r29_fd_path_case('PARENT','PARENT',False,False,True)
    add('r29_03_shared_parent_failure_domain_path_blocks',r29p['out']['control_closure'] is False and r29p['cd'][9] is True)
    r29cm=r29_fd_path_case('CM','COMMON_MODE',False,False,True)
    add('r29_04_shared_source_common_mode_path_blocks',r29cm['out']['control_closure'] is False and r29cm['cd'][5]=='SOURCE_SHARED_DEPENDENCY')
    r29ok=r29_fd_path_case('RESOLVED','ALIAS',True,False,True)
    add('r29_05_explicit_source_dependency_path_resolution_can_pass',
        r29ok['out']['control_closure'] is True and r29ok['cd'][10]=='DEPENDENCY_ACCOUNTED_NOT_COUNTED')
    r29iso=r29_fd_path_case('ISOLATED','ALIAS',False,False,False)
    add('r29_06_isolated_excluded_dependency_without_selected_to_selected_path_can_pass',
        r29iso['out']['control_closure'] is True and r29iso['cd'][9] is False)
    add('r29_07_support_universe_policy_pins_source_dependency_path_closure',
        support_universe_policy_adequate(ASOF)
        and SUPPORT_UNIVERSE_POLICY.get('source_failure_domain_dependency_graph_required') is True
        and SUPPORT_UNIVERSE_POLICY.get('source_dependency_path_through_excluded_supports_preserved') is True
        and SUPPORT_UNIVERSE_POLICY.get('excluded_redundant_disposition_closed_under_source_dependency_paths') is True)
    mut=r29_fd_path_case('MUT','ALIAS',True,False,True)
    register_failure_domain_alias('fd:r29:mut:newalias','fd:r29:mut:newcanon')
    mout=audit_text('Alice is safe.',mut['evidence'],{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,mut['rid'],mut['req'],None,*mut['bundle'])
    add('r29_08_failure_domain_registry_mutation_prepare_audit_blocks',mout['control_closure'] is False and mout['gates'].get('closure_policy_valid') is False)
    add('r29_09_previous_336_self_tests_preserved_and_gate_count_49',old_336_ok and len(MANDATORY_GATES)==49)

    # ========================================================
    # R30 / v0.2.28: orthogonal multi-channel pair semantics.
    # The previous 345 tests above are retained unchanged.
    # ========================================================
    old_345_ok=(len(T)==345 and all(x['pass'] for x in T))

    def r30_overlap_case(tag,mode='ALIAS',resolve_middle=False,reverse=False,extra_middle=False):
        r23_reset();ids=tuple(f'R30{tag}{x}' for x in 'ABCD')
        evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        semids={row['evidence_id']:row['source_semantics_id'] for row in evidence}
        if mode=='ALIAS':
            register_failure_domain_alias(SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['failure_domain_id'],SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['failure_domain_id'])
        elif mode=='PARENT':
            register_failure_domain_parent(SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['failure_domain_id'],f'fd:r30:{tag}:parent')
            register_failure_domain_parent(SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['failure_domain_id'],f'fd:r30:{tag}:parent')
        elif mode=='COMMON_MODE':
            SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['source_common_mode_ids']=(f'scm:r30:{tag}',)
            SOURCE_SEMANTICS_REGISTRY[semids[ids[3]]]['source_common_mode_ids']=(f'scm:r30:{tag}',)
        for sid in semids.values():issue_source_semantics_resolution_certificate(sid)
        if reverse:evidence=list(reversed(evidence))
        rid=f'r30:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence));fmap={f.evidence_id:f for f in fs}
        selected=(ids[0],ids[1]);sf=tuple(fmap[x] for x in selected)
        authorize_support_set_independence(f'ssi:r30:{tag}','c1',rid,sf,f'{tag} selected independence')
        issue_support_set_independence_certificate(f'ssi:r30:{tag}','c1',rid,sf)
        rel_ac=f'rel:r30:{tag}:ac';rel_bd=f'rel:r30:{tag}:bd';rel_cd=f'rel:r30:{tag}:cd'
        register_support_set_common_mode(rel_ac,[ids[0],ids[2]],'A-C redundant',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        register_support_set_common_mode(rel_bd,[ids[1],ids[3]],'B-D redundant',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        register_support_set_common_mode(rel_cd,[ids[2],ids[3]],'C-D duplicate marker',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        if extra_middle:
            register_support_set_common_mode(f'{rel_cd}:2',[ids[2],ids[3]],'C-D second duplicate marker',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        classes={ids[2]:'EXCLUDED_REDUNDANT',ids[3]:'EXCLUDED_REDUNDANT'}
        reasons={ids[2]:'C redundant to A',ids[3]:'D redundant to B'}
        pairres={(ids[2],ids[3]):'DEPENDENCY_ACCOUNTED_NOT_COUNTED'} if resolve_middle else {}
        register_support_selection(f'sel:r30:{tag}','c1',rid,ids,selected,2,classes,f'{tag} selection',reasons,pairres)
        register_relation_resolution(f'rr:r30:{tag}:ac',rel_ac,'c1',rid,selected,'REDUNDANT_RELATION_ACCOUNTED','A-C accounted')
        register_relation_resolution(f'rr:r30:{tag}:bd',rel_bd,'c1',rid,selected,'REDUNDANT_RELATION_ACCOUNTED','B-D accounted')
        register_excluded_support_disposition(f'disp:r30:{tag}:C','c1',rid,ids[2],selected,[rel_ac],'C redundant')
        register_excluded_support_disposition(f'disp:r30:{tag}:D','c1',rid,ids[3],selected,[rel_bd],'D redundant')
        reqx={'c1':{'required_independent_supports':2}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        b=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        o=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*b)
        claimsx=parse_claims('Alice is safe.');attach_claim_identities(claimsx,{'c1':'id:alice:v1'})
        ux=_find_matching_support_universe(claimsx[0],fs,b[4]);dx=_selection_descriptor(claimsx[0],ux,reqx['c1'])
        led=_support_relation_ledger(claimsx[0],fs,b[4],ux,dx)
        cd=next(x for x in led if set(x[:2])=={ids[2],ids[3]})
        return {'out':o,'ids':ids,'cd':cd}

    r30a=r30_overlap_case('OVERLAP','ALIAS',False,False,False)
    add('r30_01_overlap_common_mode_plus_source_dependency_blocks',
        r30a['out']['control_closure'] is False and r30a['cd'][3]=='COMMON_MODE'
        and r30a['cd'][5]=='SOURCE_SHARED_DEPENDENCY' and r30a['cd'][9] is True
        and r30a['out']['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    r30ar=r30_overlap_case('OVERLAPREV','ALIAS',False,True,False)
    add('r30_02_overlap_block_is_evidence_order_invariant',
        r30ar['out']['control_closure'] is False and r30ar['cd'][9] is True
        and (r30ar['out']['claims'][0]['status'],r30ar['out']['stop_type'],r30ar['out']['control_closure'])==
            (r30a['out']['claims'][0]['status'],r30a['out']['stop_type'],r30a['out']['control_closure']))
    r30p=r30_overlap_case('OVERPARENT','PARENT',False,False,False)
    add('r30_03_overlap_shared_parent_failure_domain_blocks',
        r30p['out']['control_closure'] is False and r30p['cd'][5]=='SOURCE_SHARED_DEPENDENCY' and r30p['cd'][9] is True)
    r30cm=r30_overlap_case('OVERSCM','COMMON_MODE',False,False,False)
    add('r30_04_overlap_shared_source_common_mode_blocks',
        r30cm['out']['control_closure'] is False and r30cm['cd'][5]=='SOURCE_SHARED_DEPENDENCY' and r30cm['cd'][9] is True)
    r30ok=r30_overlap_case('OVERRES','ALIAS',True,False,False)
    add('r30_05_overlap_exact_dependency_accounting_can_pass',
        r30ok['out']['control_closure'] is True and r30ok['cd'][3]=='COMMON_MODE'
        and r30ok['cd'][5]=='SOURCE_SHARED_DEPENDENCY' and r30ok['cd'][10]=='DEPENDENCY_ACCOUNTED_NOT_COUNTED'
        and sum(r30ok['out']['gates'].get(g) is True for g in MANDATORY_GATES)==len(MANDATORY_GATES)==49)
    add('r30_06_unresolved_overlap_invalidates_redundant_dispositions',
        len(r30a['out'].get('excluded_support_disposition_certificates',()))==0)
    r30multi=r30_overlap_case('OVERMULTI','ALIAS',False,False,True)
    add('r30_07_multiple_typed_relations_do_not_erase_source_dependency_channel',
        r30multi['out']['control_closure'] is False and r30multi['cd'][5]=='SOURCE_SHARED_DEPENDENCY' and r30multi['cd'][9] is True)

    synthetic_common=[
        {'aid':'A','bid':'C','scope':'SELECTED_EXCLUDED','state':'COMMON_MODE','source_state':'SOURCE_INDEPENDENCE_DISTINCT',
         'set_rows':(('rAC','COMMON_MODE','REDUNDANCY_ONLY',('A','C'),'x'),),'exclass':'EXCLUDED_REDUNDANT','resolution':None},
        {'aid':'C','bid':'D','scope':'EXCLUDED_EXCLUDED','state':'COMMON_MODE','source_state':'SOURCE_SHARED_DEPENDENCY',
         'set_rows':(('rCD','COMMON_MODE','REDUNDANCY_ONLY',('C','D'),'x'),),'exclass':None,'resolution':None},
        {'aid':'B','bid':'D','scope':'SELECTED_EXCLUDED','state':'COMMON_MODE','source_state':'SOURCE_INDEPENDENCE_DISTINCT',
         'set_rows':(('rBD','COMMON_MODE','REDUNDANCY_ONLY',('B','D'),'x'),),'exclass':'EXCLUDED_REDUNDANT','resolution':None},
    ]
    synthetic_dependent=[dict(x) for x in synthetic_common];synthetic_dependent[1]=dict(synthetic_dependent[1]);synthetic_dependent[1]['state']='DEPENDENT'
    add('r30_08_pair_summary_does_not_control_source_dependency_path_membership',
        _source_dependency_path_relevant_pair_keys({'A','B'},synthetic_common)=={('C','D')}
        and _source_dependency_path_relevant_pair_keys({'A','B'},synthetic_dependent)=={('C','D')})

    def r30_selected_excluded_overlap(tag):
        r23_reset();ids=tuple(f'R30{tag}{x}' for x in 'ABC');evidence=[ev(eid,'Alice','state','safe','id:alice:v1') for eid in ids]
        semids={row['evidence_id']:row['source_semantics_id'] for row in evidence}
        register_failure_domain_alias(SOURCE_SEMANTICS_REGISTRY[semids[ids[2]]]['failure_domain_id'],SOURCE_SEMANTICS_REGISTRY[semids[ids[0]]]['failure_domain_id'])
        for sid in semids.values():issue_source_semantics_resolution_certificate(sid)
        rid=f'r30:{tag}';_register_fixture_retrieval_scope(rid,evidence,f'snapshot:{rid}')
        fs=tuple(normalize_fact(x,i+1)[0] for i,x in enumerate(evidence));fmap={f.evidence_id:f for f in fs}
        selected=(ids[0],ids[1]);sf=tuple(fmap[x] for x in selected)
        authorize_support_set_independence(f'ssi:r30:{tag}','c1',rid,sf,'selected independent')
        issue_support_set_independence_certificate(f'ssi:r30:{tag}','c1',rid,sf)
        rel=f'rel:r30:{tag}:ac';register_support_set_common_mode(rel,[ids[0],ids[2]],'A-C redundant',relation_effect='REDUNDANCY_ONLY',claim_id='c1',retrieval_scope_id=rid)
        register_support_selection(f'sel:r30:{tag}','c1',rid,ids,selected,2,{ids[2]:'EXCLUDED_REDUNDANT'},'selection',{ids[2]:'C redundant'}, {})
        register_relation_resolution(f'rr:r30:{tag}:ac',rel,'c1',rid,selected,'REDUNDANT_RELATION_ACCOUNTED','A-C redundancy accounted')
        register_excluded_support_disposition(f'disp:r30:{tag}:C','c1',rid,ids[2],selected,[rel],'C redundant')
        reqx={'c1':{'required_independent_supports':2}}
        bind_relation_resolution_authorizations_for_prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        b=prepare('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx)
        o=audit_text('Alice is safe.',evidence,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rid,reqx,None,*b)
        claimsx=parse_claims('Alice is safe.');attach_claim_identities(claimsx,{'c1':'id:alice:v1'})
        ux=_find_matching_support_universe(claimsx[0],fs,b[4]);dx=_selection_descriptor(claimsx[0],ux,reqx['c1']);led=_support_relation_ledger(claimsx[0],fs,b[4],ux,dx)
        ac=next(x for x in led if set(x[:2])=={ids[0],ids[2]})
        return o,ac
    r30se,r30se_row=r30_selected_excluded_overlap('SE')
    add('r30_09_selected_excluded_overlap_preserves_source_dependency_obligation',
        r30se['control_closure'] is False and r30se_row[3]=='COMMON_MODE' and r30se_row[5]=='SOURCE_SHARED_DEPENDENCY'
        and r30se_row[9] is True and r30se['gates'].get('support_relation_instance_resolution_coverage_valid') is False)
    add('r30_10_policy_pins_orthogonal_multi_channel_semantics_and_preserves_345',
        old_345_ok and len(MANDATORY_GATES)==49 and support_universe_policy_adequate(ASOF)
        and SUPPORT_UNIVERSE_POLICY.get('pair_summary_not_complete_semantic_state') is True
        and SUPPORT_UNIVERSE_POLICY.get('orthogonal_dependency_channels_preserved') is True
        and SUPPORT_UNIVERSE_POLICY.get('source_dependency_relevance_uses_source_state_independently') is True)

    # ========================================================
    # R139 / v0.2.65: persisted history commitment / rehydration rollback guard.
    # All previous 355 tests above are retained unchanged.
    # ========================================================
    old_355_ok=(len(T)==355 and all(x['pass'] for x in T))
    _reset_decision_persistence_runtime_state_for_tests()
    state_a=export_decision_persistence_state()
    fake_id='r139:selftest:decision-row'
    fake_row={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':fake_id,
              'binding_state':'PENDING','persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
              'persistence_history_commitment':state_a['history_commitment']}
    SUPPORT_SELECTION_REGISTRY[fake_id]=fake_row
    add('r139_01_previous_355_self_tests_preserved',old_355_ok and len(MANDATORY_GATES)==49)
    add('r139_02_persistence_checkpoint_json_roundtrip_deterministic',
        json.loads(json.dumps(state_a,sort_keys=True))==state_a
        and state_a['history_commitment']==decision_persistence_history_commitment())
    marker_key='r139:selftest:history-marker'; marker={'source_id':'r139:selftest:B'}
    SOURCE_SEMANTICS_REGISTRY[marker_key]=marker
    state_b=export_decision_persistence_state()
    del SOURCE_SEMANTICS_REGISTRY[marker_key]
    begin_ok=begin_decision_rehydration(state_b)
    incomplete_ok=(complete_decision_rehydration() is False and decision_rehydration_status()['active'] is True
                   and fake_id not in set(decision_rehydration_status()['authorized_decision_row_ids']))
    add('r139_03_incomplete_history_replay_cannot_complete_checkpoint',begin_ok and incomplete_ok)
    SOURCE_SEMANTICS_REGISTRY[marker_key]=marker
    complete_ok=complete_decision_rehydration()
    add('r139_04_complete_history_replay_authorizes_bound_format_rows',
        complete_ok and fake_id in set(decision_rehydration_status()['authorized_decision_row_ids']))
    add('r139_05_pending_row_requires_current_history_commitment_at_bind',
        not _pending_decision_row_history_current(fake_id,SUPPORT_SELECTION_REGISTRY[fake_id]))
    legacy_id='r139:selftest:legacy-row'
    SUPPORT_SELECTION_REGISTRY[legacy_id]={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':legacy_id,'binding_state':'BOUND'}
    _reset_decision_persistence_runtime_state_for_tests(); exact_b=export_decision_persistence_state()
    begin_decision_rehydration(exact_b); legacy_complete=complete_decision_rehydration()
    add('r139_06_legacy_serialized_decision_row_without_commitment_fails_closed',
        legacy_complete and legacy_id not in set(decision_rehydration_status()['authorized_decision_row_ids']))

    # ========================================================
    # R143 / v0.2.66: active trusted rehydration checkpoint is immutable until completion.
    # Exactly six new self-tests; previous 361 entries above are retained unchanged.
    # ========================================================
    old_361_ok=(len(T)==361 and all(x['pass'] for x in T))

    def r143_history_fixture(tag):
        r23_reset()
        keys=tuple(f'r143:{tag}:history:{x}' for x in 'ABC')
        rows=tuple({'source_id':f'r143:{tag}:source:{x}'} for x in 'ABC')
        base=export_decision_persistence_state()
        states=[]
        for key,row in zip(keys,rows):
            SOURCE_SEMANTICS_REGISTRY[key]=copy.deepcopy(row)
            states.append(export_decision_persistence_state())
        return keys,rows,base,tuple(states)

    def r143_replay_level(keys,rows,level):
        for key in keys:SOURCE_SEMANTICS_REGISTRY.pop(key,None)
        for key,row in zip(keys[:level],rows[:level]):SOURCE_SEMANTICS_REGISTRY[key]=copy.deepcopy(row)

    def r143_seed_serialized_rows(prefix,commitment,count=36,json_roundtrip=False,include_duplicate=True):
        ids=[]
        for i in range(count):
            rid=f'{prefix}:{i:02d}'
            row={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':rid,
                 'binding_state':'PENDING','persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
                 'persistence_history_commitment':commitment}
            if json_roundtrip:row=json.loads(json.dumps(row,sort_keys=True))
            SUPPORT_SELECTION_REGISTRY[rid]=row;ids.append(rid)
        if include_duplicate:
            dup=f'{prefix}:duplicate-stale'
            SUPPORT_SELECTION_REGISTRY[dup]=copy.deepcopy(SUPPORT_SELECTION_REGISTRY[ids[0]])
        return tuple(ids)

    # 1. Required C -> stale B rejection -> failed B replay -> exact C retry matrix.
    keys,rows,base,states=r143_history_fixture('matrix')
    state_a,state_b,state_c=states
    r143_replay_level(keys,rows,1)
    begin_c=begin_decision_rehydration(state_c)
    s_begin=decision_rehydration_status()
    rebegin_b=begin_decision_rehydration(state_b)
    s_rebegin=decision_rehydration_status()
    r143_replay_level(keys,rows,2)
    failed_b=complete_decision_rehydration()
    s_failed=decision_rehydration_status()
    r143_replay_level(keys,rows,3)
    exact_c=complete_decision_rehydration()
    s_exact=decision_rehydration_status()
    r143_01_ok=(begin_c is True and rebegin_b is False
        and s_begin['active'] is True and s_begin['expected_history_commitment']==state_c['history_commitment']
        and s_begin['last_validated_history_commitment'] is None and s_begin['authorized_decision_row_ids']==()
        and s_rebegin['active'] is True and s_rebegin['expected_history_commitment']==state_c['history_commitment']
        and s_rebegin['last_validated_history_commitment'] is None and s_rebegin['authorized_decision_row_ids']==()
        and failed_b is False and s_failed['active'] is True
        and s_failed['expected_history_commitment']==state_c['history_commitment']
        and s_failed['last_validated_history_commitment'] is None and s_failed['authorized_decision_row_ids']==()
        and exact_c is True and s_exact['active'] is False and s_exact['expected_history_commitment'] is None
        and s_exact['last_validated_history_commitment']==state_c['history_commitment']
        and decision_persistence_history_commitment()==state_c['history_commitment']
        and all(SOURCE_SEMANTICS_REGISTRY.get(k)==r for k,r in zip(keys,rows)))
    add('r143_01_active_stale_rebegin_rejected_and_C_remains_pinned',r143_01_ok)

    # 2. Same, older A, and well-formed foreign checkpoints cannot replace active C.
    keys,rows,base,states=r143_history_fixture('atomic')
    state_a,state_b,state_c=states
    r143_replay_level(keys,rows,0)
    begin_c=begin_decision_rehydration(state_c);before=decision_rehydration_status()
    foreign={'format_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'history_commitment':sha(('r143','foreign-checkpoint'))}
    same_reject=begin_decision_rehydration(copy.deepcopy(state_c)) is False
    after_same=decision_rehydration_status()
    old_reject=begin_decision_rehydration(state_a) is False
    after_old=decision_rehydration_status()
    foreign_reject=begin_decision_rehydration(foreign) is False
    after_foreign=decision_rehydration_status()
    add('r143_02_active_same_and_foreign_rebegin_rejected_atomically',
        begin_c and same_reject and old_reject and foreign_reject
        and before==after_same==after_old==after_foreign
        and before['active'] is True and before['expected_history_commitment']==state_c['history_commitment']
        and before['authorized_decision_row_ids']==())

    # 3. Invalid/malformed/wrong-version inputs are rejected without any session mutation.
    keys,rows,base,states=r143_history_fixture('invalid')
    state_c=states[2];r143_replay_level(keys,rows,1)
    begin_c=begin_decision_rehydration(state_c);snapshot=decision_rehydration_status()
    invalid_inputs=(None,{},json.dumps(state_c,sort_keys=True),
                    {'format_version':'WRONG_VERSION','history_commitment':state_c['history_commitment']},
                    {'format_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'history_commitment':'malformed'})
    invalid_results=[]
    for bad in invalid_inputs:
        invalid_results.append(begin_decision_rehydration(bad) is False and decision_rehydration_status()==snapshot)
    add('r143_03_invalid_begin_while_active_preserves_session_exactly',
        begin_c and all(invalid_results) and snapshot['active'] is True
        and snapshot['expected_history_commitment']==state_c['history_commitment']
        and snapshot['authorized_decision_row_ids']==())

    # 4. A failed completion cannot mint authority, including >30 stale serialized rows,
    # duplicate stale input, a PENDING row from a failed session, and implicit authorization attempts.
    keys,rows,base,states=r143_history_fixture('failed')
    state_a,state_b,state_c=states;r143_replay_level(keys,rows,0)
    stale_ids=r143_seed_serialized_rows('r143:failed:old',state_b['history_commitment'],36,include_duplicate=True)
    pending_previous='r143:failed:pending-previous'
    SUPPORT_SELECTION_REGISTRY[pending_previous]={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':pending_previous,
        'binding_state':'PENDING','persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_b['history_commitment']}
    begin_c=begin_decision_rehydration(state_c)
    _authorize_fresh_decision_row('r143:failed:implicit-authority-attempt')
    retry_levels=(0,1,2,1,2)
    retry_ok=[]
    for level in retry_levels:
        r143_replay_level(keys,rows,level)
        retry_ok.append(complete_decision_rehydration() is False)
        st=decision_rehydration_status()
        retry_ok.append(st['active'] is True and st['expected_history_commitment']==state_c['history_commitment']
                        and st['last_validated_history_commitment'] is None and st['authorized_decision_row_ids']==())
    failed_status=decision_rehydration_status()
    add('r143_04_failed_complete_keeps_expected_C_and_authorization_empty',
        begin_c and len(stale_ids)>=30 and all(retry_ok) and failed_status['active'] is True
        and failed_status['expected_history_commitment']==state_c['history_commitment']
        and failed_status['authorized_decision_row_ids']==()
        and SUPPORT_SELECTION_REGISTRY[pending_previous]['binding_state']=='PENDING'
        and SUPPORT_SELECTION_REGISTRY['r143:failed:old:duplicate-stale']['resolution_id']==stale_ids[0])

    # 5. Exact C may complete only within the same still-active session. Exercise native/JSON,
    # history-first/rows-first, explicit rows plus implicit authorization, and five retry schedules.
    schedules=(
        ('native-rows-first',False,True,(2,)),
        ('json-rows-first',True,True,(1,2)),
        ('native-history-first',False,False,(0,2,2)),
        ('json-history-first',True,False,(0,1,2)),
        ('json-mixed-retry',True,True,(1,1,2,1,2)),
    )
    schedule_results=[]
    for stag,use_json,rows_first,retries in schedules:
        keys,rows,base,states=r143_history_fixture(stag);state_a,state_b,state_c=states
        r143_replay_level(keys,rows,0)
        current_id=f'r143:{stag}:current-C-row'
        current_row={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':current_id,
                     'binding_state':'PENDING','persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
                     'persistence_history_commitment':state_c['history_commitment']}
        if use_json:
            state_c=json.loads(json.dumps(state_c,sort_keys=True));current_row=json.loads(json.dumps(current_row,sort_keys=True))
        if rows_first:SUPPORT_SELECTION_REGISTRY[current_id]=current_row
        began=begin_decision_rehydration(state_c)
        if not rows_first:SUPPORT_SELECTION_REGISTRY[current_id]=current_row
        _authorize_fresh_decision_row(f'r143:{stag}:implicit')
        local_ok=[began is True]
        for level in retries:
            r143_replay_level(keys,rows,level)
            local_ok.append(complete_decision_rehydration() is False)
            st=decision_rehydration_status()
            local_ok.append(st['active'] is True and st['expected_history_commitment']==state_c['history_commitment']
                            and st['authorized_decision_row_ids']==())
        r143_replay_level(keys,rows,3)
        completed=complete_decision_rehydration();st=decision_rehydration_status()
        local_ok.extend((completed is True,st['active'] is False,st['expected_history_commitment'] is None,
                         st['last_validated_history_commitment']==state_c['history_commitment'],
                         current_id in set(st['authorized_decision_row_ids']),
                         _pending_decision_row_history_current(current_id,SUPPORT_SELECTION_REGISTRY[current_id]),
                         decision_persistence_history_commitment()==state_c['history_commitment']))
        schedule_results.append(all(local_ok))
    add('r143_05_same_session_exact_C_retry_completes_safely',all(schedule_results) and len(schedule_results)>=5)

    add('r143_06_previous_361_preserved_and_gate_count_49',
        old_361_ok and len(MANDATORY_GATES)==49 and len(T)==366 and all(x['pass'] for x in T)
        and r143_01_ok
        and decision_rehydration_status()['active'] is False)

    # ========================================================
    # R145 / v0.2.67: rehydrated BOUND rows require exact current persistence commitment.
    # Exactly six new self-tests; previous 367 entries above are retained unchanged.
    # ========================================================
    old_367_ok=(len(T)==367 and all(x['pass'] for x in T))

    # 1. Successful exact-C completion excludes a BOUND row carrying a different valid commitment.
    keys,rows,base,states=r143_history_fixture('r145-stale-bound');state_a,state_b,state_c=states
    r143_replay_level(keys,rows,3)
    stale_id='r145:stale-bound'
    SUPPORT_SELECTION_REGISTRY[stale_id]={
        'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':stale_id,'binding_state':'BOUND',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_b['history_commitment']}
    began=begin_decision_rehydration(state_c);completed=complete_decision_rehydration();st=decision_rehydration_status()
    add('r145_01_complete_excludes_stale_bound_row_commitment',
        began is True and completed is True and stale_id not in set(st['authorized_decision_row_ids'])
        and _decision_row_runtime_authorized(stale_id,SUPPORT_SELECTION_REGISTRY[stale_id]) is False)

    # 2. Use-time authorization rejects a BOUND row if its commitment changes after completion.
    keys,rows,base,states=r143_history_fixture('r145-use-time');state_c=states[2];r143_replay_level(keys,rows,3)
    use_id='r145:use-time-current'
    SUPPORT_SELECTION_REGISTRY[use_id]={
        'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':use_id,'binding_state':'BOUND',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_c['history_commitment']}
    begin_decision_rehydration(state_c);complete_decision_rehydration()
    before=_decision_row_runtime_authorized(use_id,SUPPORT_SELECTION_REGISTRY[use_id])
    mutated=dict(SUPPORT_SELECTION_REGISTRY[use_id]);mutated['persistence_history_commitment']=sha(('r145','different-row-commitment'))
    SUPPORT_SELECTION_REGISTRY[use_id]=mutated
    after=_decision_row_runtime_authorized(use_id,SUPPORT_SELECTION_REGISTRY[use_id])
    add('r145_02_runtime_authorization_requires_current_history_commitment',before is True and after is False)

    # 3. Exact-current BOUND rows remain authorized after successful exact replay.
    keys,rows,base,states=r143_history_fixture('r145-current');state_c=states[2];r143_replay_level(keys,rows,3)
    current_id='r145:current-bound'
    SUPPORT_SELECTION_REGISTRY[current_id]={
        'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':current_id,'binding_state':'BOUND',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_c['history_commitment']}
    began=begin_decision_rehydration(state_c);completed=complete_decision_rehydration();st=decision_rehydration_status()
    add('r145_03_exact_current_bound_row_still_authorized',
        began is True and completed is True and current_id in set(st['authorized_decision_row_ids'])
        and _decision_row_runtime_authorized(current_id,SUPPORT_SELECTION_REGISTRY[current_id]) is True)

    # 4. Advancing persistence history invalidates prior BOUND runtime authority until rebound to current history.
    keys,rows,base,states=r143_history_fixture('r145-advance');state_c=states[2];r143_replay_level(keys,rows,3)
    advance_id='r145:advance-bound'
    SUPPORT_SELECTION_REGISTRY[advance_id]={
        'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':advance_id,'binding_state':'BOUND',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_c['history_commitment']}
    begin_decision_rehydration(state_c);complete_decision_rehydration();before=_decision_row_runtime_authorized(advance_id,SUPPORT_SELECTION_REGISTRY[advance_id])
    SOURCE_SEMANTICS_REGISTRY['r145:advance:marker']={'source_id':'r145:advance:new-history'}
    advanced=decision_persistence_history_commitment()!=state_c['history_commitment']
    after=_decision_row_runtime_authorized(advance_id,SUPPORT_SELECTION_REGISTRY[advance_id])
    add('r145_04_history_advance_invalidates_prior_runtime_authority',before is True and advanced and after is False)

    # 5. Native/JSON matrix across relation, generic and source decision-row record types.
    record_specs=(
        ('DECISION_TYPED_RELATION_RESOLUTION','resolution_id'),
        ('DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING','accounting_id'),
        ('DECISION_SOURCE_DEPENDENCY_ACCOUNTING','accounting_id'),
    )
    matrix_ok=[]
    for use_json in (False,True):
        keys,rows,base,states=r143_history_fixture(f'r145-matrix-{int(use_json)}');state_b,state_c=states[1],states[2]
        r143_replay_level(keys,rows,3);current_ids=[];stale_ids=[]
        for idx,(record_type,id_field) in enumerate(record_specs):
            current=f'r145:matrix:{int(use_json)}:{idx}:current';stale=f'r145:matrix:{int(use_json)}:{idx}:stale'
            crow={'record_type':record_type,id_field:current,'binding_state':'BOUND',
                  'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
                  'persistence_history_commitment':state_c['history_commitment']}
            srow={'record_type':record_type,id_field:stale,'binding_state':'BOUND',
                  'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
                  'persistence_history_commitment':state_b['history_commitment']}
            if use_json:
                crow=json.loads(json.dumps(crow,sort_keys=True));srow=json.loads(json.dumps(srow,sort_keys=True))
            SUPPORT_SELECTION_REGISTRY[current]=crow;SUPPORT_SELECTION_REGISTRY[stale]=srow
            current_ids.append(current);stale_ids.append(stale)
        began=begin_decision_rehydration(json.loads(json.dumps(state_c,sort_keys=True)) if use_json else state_c)
        completed=complete_decision_rehydration();auth=set(decision_rehydration_status()['authorized_decision_row_ids'])
        matrix_ok.append(began is True and completed is True
                         and all(x in auth for x in current_ids) and all(x not in auth for x in stale_ids)
                         and all(_decision_row_runtime_authorized(x,SUPPORT_SELECTION_REGISTRY[x]) for x in current_ids)
                         and all(not _decision_row_runtime_authorized(x,SUPPORT_SELECTION_REGISTRY[x]) for x in stale_ids))
    add('r145_05_native_json_typed_generic_source_stale_binding_matrix',all(matrix_ok) and len(matrix_ok)==2)

    add('r145_06_previous_367_preserved_and_gate_count_49',
        old_367_ok and len(MANDATORY_GATES)==49 and len(T)==372 and all(x['pass'] for x in T))

    # ========================================================
    # R149 / v0.2.68: runtime authorization is bound to the persistence commitment
    # captured when each decision row ID was authorized. Exactly six new self-tests.
    # ========================================================
    old_373_ok=(len(T)==373 and all(x['pass'] for x in T))

    # 1. A C-authorized row cannot regain runtime authorization by changing only its stamp to D.
    rebase_ok=[]
    for channel,record_type,id_field in ((
        'relation','DECISION_TYPED_RELATION_RESOLUTION','resolution_id'),
        ('generic','DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING','accounting_id'),
        ('source','DECISION_SOURCE_DEPENDENCY_ACCOUNTING','accounting_id')):
        r23_reset();SOURCE_SEMANTICS_REGISTRY[f'r149:{channel}:hist:C']={'source_id':f'r149:{channel}:source:C'}
        state_c=export_decision_persistence_state();rid=f'r149:rebase:{channel}'
        SUPPORT_SELECTION_REGISTRY[rid]={'record_type':record_type,id_field:rid,'binding_state':'BOUND',
            'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
            'persistence_history_commitment':state_c['history_commitment']}
        began=begin_decision_rehydration(state_c);completed=complete_decision_rehydration()
        at_c=_decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid])
        SOURCE_SEMANTICS_REGISTRY[f'r149:{channel}:hist:D']={'source_id':f'r149:{channel}:source:D'}
        state_d=export_decision_persistence_state();before_edit=_decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid])
        SUPPORT_SELECTION_REGISTRY[rid]['persistence_history_commitment']=state_d['history_commitment']
        after_rebase=_decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid])
        rebase_ok.append(began is True and completed is True and at_c is True and before_edit is False and after_rebase is False)
    add('r149_01_persistence_rebase_cannot_reactivate_prior_runtime_authorization',all(rebase_ok) and len(rebase_ok)==3)

    # 2. Real relation lookup stays absent after only the row persistence stamp is rebased C -> D.
    r23_reset();relid='rel:r149:rebase';rel={'relation':'COMMON_MODE','evidence_ids':('E1','E2'),
        'relation_effect':'RELIABILITY_DEGRADING','claim_id':'*'};SUPPORT_SET_COMMON_MODE_REGISTRY[relid]=rel
    SOURCE_SEMANTICS_REGISTRY['r149:real:hist:C']={'source_id':'r149:real:source:C'};state_c=export_decision_persistence_state()
    h=lambda label:sha(('r149-real-relation',label))
    class R149Obj:
        def __init__(self,**kw):self.__dict__.update(kw)
    ctx=R149Obj(audit_context_id='ctx:r149:rel',retrieval_scope_id='scope:r149:rel')
    dgraph={'claim_ids_hash':h('cl'),'selected_support_map_hash':h('ss'),'matching_support_universe_map_hash':h('msu'),'graph_hash':h('g')}
    universe=R149Obj(retrieval_snapshot_id='snap:r149:rel',decision_evidence_ownership_map_hash=h('own'),universe_hash=h('u'),relation_ids_hash=h('rids'))
    info={'relation_id':relid,'relation_type':'COMMON_MODE','relation_effect':'RELIABILITY_DEGRADING','evidence_ids_hash':sha(('E1','E2')),'claim_scope':'*'}
    rid='rr:r149:rebase';row={'record_type':DECISION_RELATION_RESOLUTION_RECORD_TYPE,'resolution_id':rid,'binding_state':'BOUND',
        'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,'retrieval_snapshot_id':universe.retrieval_snapshot_id,
        'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],'decision_dependency_graph_hash':dgraph['graph_hash'],
        'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,'decision_relation_universe_hash':universe.universe_hash,
        'decision_relation_ids_hash':universe.relation_ids_hash,'relation_id':relid,'relation_type':info['relation_type'],
        'relation_effect':info['relation_effect'],'evidence_ids_hash':info['evidence_ids_hash'],'relation_claim_scope':info['claim_scope'],
        'relation_entry_hash':sha(rel),'resolution_type':'RELIABILITY_DEGRADATION_RESOLVED','authorizer_id':'LOCAL_RELATION_RESOLUTION_AUTHORITY',
        'reason':'r149 relation fixture','relation_registry_hash':support_set_common_mode_registry_hash(),
        'relation_discovery_policy_hash':relation_discovery_policy_hash(),'relation_resolution_policy_hash':relation_resolution_policy_hash(),
        'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),'support_universe_policy_hash':support_universe_policy_hash(),
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
    payload={'resolution_id':rid,'audit_context_id':ctx.audit_context_id,'retrieval_scope_id':ctx.retrieval_scope_id,
        'retrieval_snapshot_id':universe.retrieval_snapshot_id,'claim_ids_hash':dgraph['claim_ids_hash'],'selected_support_map_hash':dgraph['selected_support_map_hash'],
        'matching_support_universe_map_hash':dgraph['matching_support_universe_map_hash'],'decision_dependency_graph_hash':dgraph['graph_hash'],
        'decision_evidence_ownership_map_hash':universe.decision_evidence_ownership_map_hash,'decision_relation_universe_hash':universe.universe_hash,
        'decision_relation_ids_hash':universe.relation_ids_hash,'relation_id':relid,'relation_type':info['relation_type'],'relation_effect':info['relation_effect'],
        'evidence_ids_hash':info['evidence_ids_hash'],'relation_claim_scope':info['claim_scope'],'relation_entry_hash':sha(rel),
        'resolution_type':row['resolution_type'],'authorizer_id':row['authorizer_id'],'reason_hash':sha(row['reason']),
        'relation_registry_hash':support_set_common_mode_registry_hash(),'relation_discovery_policy_hash':relation_discovery_policy_hash(),
        'relation_resolution_policy_hash':relation_resolution_policy_hash(),'relation_decision_relevance_policy_hash':relation_decision_relevance_policy_hash(),
        'support_universe_policy_hash':support_universe_policy_hash()}
    row['resolution_scope_hash']=sha(payload);SUPPORT_SELECTION_REGISTRY[rid]=row
    begin_decision_rehydration(state_c);complete_decision_rehydration();lookup_c=_find_bound_decision_relation_resolution(dgraph,universe,ctx,info)
    SOURCE_SEMANTICS_REGISTRY['r149:real:hist:D']={'source_id':'r149:real:source:D'};state_d=export_decision_persistence_state()
    lookup_d_before=_find_bound_decision_relation_resolution(dgraph,universe,ctx,info)
    SUPPORT_SELECTION_REGISTRY[rid]['persistence_history_commitment']=state_d['history_commitment']
    lookup_d_after=_find_bound_decision_relation_resolution(dgraph,universe,ctx,info)
    add('r149_02_real_relation_lookup_rebase_remains_rejected',lookup_c is not None and lookup_d_before is None and lookup_d_after is None)

    # 3. Generic and source rows obey the same authorization-commitment binding.
    gs_ok=[]
    for record_type,id_field in ((
        'DECISION_GENERIC_PROVENANCE_DEPENDENCY_ACCOUNTING','accounting_id'),
        ('DECISION_SOURCE_DEPENDENCY_ACCOUNTING','accounting_id')):
        r23_reset();SOURCE_SEMANTICS_REGISTRY['r149:gs:C']={'source_id':'r149:gs:source:C'};state_c=export_decision_persistence_state();rid=f'r149:gs:{record_type}'
        SUPPORT_SELECTION_REGISTRY[rid]={'record_type':record_type,id_field:rid,'binding_state':'BOUND',
            'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
        begin_decision_rehydration(state_c);complete_decision_rehydration();ok_c=_decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid])
        SOURCE_SEMANTICS_REGISTRY['r149:gs:D']={'source_id':'r149:gs:source:D'};state_d=export_decision_persistence_state()
        SUPPORT_SELECTION_REGISTRY[rid]['persistence_history_commitment']=state_d['history_commitment']
        gs_ok.append(ok_c is True and _decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid]) is False)
    add('r149_03_generic_source_rebase_remains_rejected',all(gs_ok) and len(gs_ok)==2)

    # 4. A genuinely fresh current row records its own current commitment and remains usable.
    r23_reset();SOURCE_SEMANTICS_REGISTRY['r149:fresh:D']={'source_id':'r149:fresh:source:D'};state_d=export_decision_persistence_state();rid='r149:fresh:relation'
    SUPPORT_SELECTION_REGISTRY[rid]={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':rid,'binding_state':'PENDING',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_d['history_commitment']}
    _authorize_fresh_decision_row(rid)
    add('r149_04_fresh_current_row_records_authorized_commitment',
        rid in _DECISION_ROW_RUNTIME_AUTHORIZED_IDS and _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.get(rid)==state_d['history_commitment']
        and _decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid]) is True
        and _pending_decision_row_history_current(rid,SUPPORT_SELECTION_REGISTRY[rid]) is True)

    # 5. R139 PENDING behavior remains: stale-format row may be rehydrated but is not current-bindable.
    r23_reset();SOURCE_SEMANTICS_REGISTRY['r149:pending:A']={'source_id':'r149:pending:source:A'};state_a=export_decision_persistence_state();pid='r149:pending:stale'
    SUPPORT_SELECTION_REGISTRY[pid]={'record_type':'DECISION_TYPED_RELATION_RESOLUTION','resolution_id':pid,'binding_state':'PENDING',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_a['history_commitment']}
    SOURCE_SEMANTICS_REGISTRY['r149:pending:B']={'source_id':'r149:pending:source:B'};state_b=export_decision_persistence_state()
    begin_decision_rehydration(state_b);complete_decision_rehydration()
    add('r149_05_pending_R139_contract_preserved_with_authorized_commitment_map',
        pid in _DECISION_ROW_RUNTIME_AUTHORIZED_IDS and _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.get(pid)==state_a['history_commitment']
        and _decision_row_runtime_authorized(pid,SUPPORT_SELECTION_REGISTRY[pid]) is True
        and _pending_decision_row_history_current(pid,SUPPORT_SELECTION_REGISTRY[pid]) is False)

    add('r149_06_previous_373_preserved_and_gate_count_49',
        old_373_ok and len(MANDATORY_GATES)==49 and len(T)==378 and all(x['pass'] for x in T))

    # ========================================================
    # R152 / v0.2.69: runtime authorization is bound to the exact canonical decision-row content.
    # Exactly six new self-tests; previous 379 entries above are retained unchanged.
    # ========================================================
    old_379_ok=(len(T)==379 and all(x['pass'] for x in T))

    # 1. Same registry ID + same persistence commitment cannot transfer authorization to changed row content.
    r23_reset();state_c=export_decision_persistence_state();rid='r152:same-id'
    r1={'record_type':DECISION_RELATION_RESOLUTION_RECORD_TYPE,'resolution_id':rid,'binding_state':'BOUND',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        'persistence_history_commitment':state_c['history_commitment'],'r152_marker':'R1'}
    SUPPORT_SELECTION_REGISTRY[rid]=r1;begin_decision_rehydration(state_c);complete_decision_rehydration()
    before=_decision_row_runtime_authorized(rid,SUPPORT_SELECTION_REGISTRY[rid])
    r2=dict(r1);r2['r152_marker']='R2_DIFFERENT_CONTENT';SUPPORT_SELECTION_REGISTRY[rid]=r2
    add('r152_01_same_id_same_commitment_replacement_rejected',before is True and _decision_row_runtime_authorized(rid,r2) is False)

    # 2. Relation obligation identity cannot change under a previously authorized ID/commitment.
    r23_reset();state_c=export_decision_persistence_state();rid='r152:relation-obligation'
    r1={'record_type':DECISION_RELATION_RESOLUTION_RECORD_TYPE,'resolution_id':rid,'binding_state':'BOUND','relation_id':'rel:r152:one',
        'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
    SUPPORT_SELECTION_REGISTRY[rid]=r1;begin_decision_rehydration(state_c);complete_decision_rehydration()
    r2=dict(r1);r2['relation_id']='rel:r152:two';SUPPORT_SELECTION_REGISTRY[rid]=r2
    add('r152_02_relation_replacement_with_new_obligation_rejected',
        _decision_row_runtime_authorized(rid,r1) is True and _decision_row_runtime_authorized(rid,r2) is False)

    # 3. Generic/source content replacement and cross-record-type replacement are both rejected.
    gs_cross_ok=[]
    for rt in (DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE,DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE):
        r23_reset();state_c=export_decision_persistence_state();rid=f'r152:gs:{rt}'
        row={'record_type':rt,'accounting_id':rid,'binding_state':'BOUND','r152_obligation':'one',
             'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
        SUPPORT_SELECTION_REGISTRY[rid]=row;begin_decision_rehydration(state_c);complete_decision_rehydration()
        changed=dict(row);changed['r152_obligation']='two';SUPPORT_SELECTION_REGISTRY[rid]=changed
        gs_cross_ok.append(_decision_row_runtime_authorized(rid,changed) is False)
    r23_reset();state_c=export_decision_persistence_state();rid='r152:cross-type'
    grow={'record_type':DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE,'accounting_id':rid,'binding_state':'BOUND',
          'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
    SUPPORT_SELECTION_REGISTRY[rid]=grow;begin_decision_rehydration(state_c);complete_decision_rehydration()
    srow=dict(grow);srow['record_type']=DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE;SUPPORT_SELECTION_REGISTRY[rid]=srow
    add('r152_03_generic_source_replacement_and_cross_type_rejected',all(gs_cross_ok) and len(gs_cross_ok)==2 and _decision_row_runtime_authorized(rid,srow) is False)

    # 4. Legal controller PENDING -> BOUND transitions refresh exact-row fingerprints for all three channels.
    bind_refresh_ok=[]
    # relation
    r23_reset();e=[ev('R152A','Alice','state','safe','id:alice:v1'),ev('R152B','Bob','state','safe','id:bob:v1')]
    rs='r152:bind:rel';_register_fixture_retrieval_scope(rs,e,'snapshot:r152:bind:rel')
    register_support_selection('r152:sel:rel:c1','c1',rs,('R152A',),('R152A',),1,{},'r152 select A',{}, {})
    register_support_selection('r152:sel:rel:c2','c2',rs,('R152B',),('R152B',),1,{},'r152 select B',{}, {})
    relid='rel:r152:bind';register_support_set_common_mode(relid,('R152A','R152B'),'r152 cross relation',
        relation_effect='RELIABILITY_DEGRADING',claim_id='*',retrieval_scope_id=rs)
    drid='rr:r152:bind';register_decision_relation_resolution(drid,rs,('c1','c2'),{'c1':('R152A',),'c2':('R152B',)},
        relid,'RELIABILITY_DEGRADATION_RESOLVED','r152 legal relation bind')
    pfp=_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(drid)
    cnt=bind_decision_relation_resolutions_for_prepare('Alice is safe. Bob is safe.',e,{'c1':'id:alice:v1','c2':'id:bob:v1'},
        ASOF,SCOPE,EXTRACT,rs,{'c1':{'required_independent_supports':1},'c2':{'required_independent_supports':1}},(drid,))
    brow=SUPPORT_SELECTION_REGISTRY[drid]
    bind_refresh_ok.append(cnt==1 and brow.get('binding_state')=='BOUND' and pfp!=canonical_hash(brow)
        and _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(drid)==canonical_hash(brow) and _decision_row_runtime_authorized(drid,brow))
    # generic provenance dependency
    r23_reset();shared_model='model:shared:r152';ga=ev('R152GA','Alice','state','safe','id:alice:v1',dependencies=dep('R152GA',{'model':{'state':'KNOWN','id':shared_model}}));gb=ev('R152GB','Bob','state','safe','id:bob:v1',dependencies=dep('R152GB',{'model':{'state':'KNOWN','id':shared_model}}));e=[ga,gb]
    rs='r152:bind:gen';_register_fixture_retrieval_scope(rs,e,'snapshot:r152:bind:gen')
    register_support_selection('r152:sel:gen:c1','c1',rs,('R152GA',),('R152GA',),1,{},'r152 select GA',{}, {})
    register_support_selection('r152:sel:gen:c2','c2',rs,('R152GB',),('R152GB',),1,{},'r152 select GB',{}, {})
    gid='ga:r152:bind';gnode=('DEPENDENCY','model','shared:r152')
    register_decision_generic_dependency_accounting(gid,rs,('c1','c2'),{'c1':('R152GA',),'c2':('R152GB',)},gnode,('R152GA','R152GB'),
        SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_resolution_type'],'r152 legal generic bind')
    pfp=_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(gid)
    cnt=bind_decision_generic_dependency_accountings_for_prepare('Alice is safe. Bob is safe.',e,{'c1':'id:alice:v1','c2':'id:bob:v1'},
        ASOF,SCOPE,EXTRACT,rs,{'c1':{'required_independent_supports':1},'c2':{'required_independent_supports':1}},(gid,))
    brow=SUPPORT_SELECTION_REGISTRY[gid]
    bind_refresh_ok.append(cnt==1 and brow.get('binding_state')=='BOUND' and pfp!=canonical_hash(brow)
        and _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(gid)==canonical_hash(brow) and _decision_row_runtime_authorized(gid,brow))
    # source dependency
    r23_reset();shared_source='general-record:r152:shared-source';e=[ev('R152SA','Alice','state','safe','id:alice:v1',source_id=shared_source),ev('R152SB','Bob','state','safe','id:bob:v1',source_id=shared_source)]
    rs='r152:bind:src';_register_fixture_retrieval_scope(rs,e,'snapshot:r152:bind:src')
    register_support_selection('r152:sel:src:c1','c1',rs,('R152SA',),('R152SA',),1,{},'r152 select SA',{}, {})
    register_support_selection('r152:sel:src:c2','c2',rs,('R152SB',),('R152SB',),1,{},'r152 select SB',{}, {})
    sid='sa:r152:bind';register_decision_dependency_accounting(sid,rs,('c1','c2'),{'c1':('R152SA',),'c2':('R152SB',)},('R152SA','R152SB'),
        SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_resolution_type'],'r152 legal source bind')
    pfp=_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(sid)
    cnt=bind_decision_dependency_accountings_for_prepare('Alice is safe. Bob is safe.',e,{'c1':'id:alice:v1','c2':'id:bob:v1'},
        ASOF,SCOPE,EXTRACT,rs,{'c1':{'required_independent_supports':1},'c2':{'required_independent_supports':1}})
    brow=SUPPORT_SELECTION_REGISTRY[sid]
    bind_refresh_ok.append(cnt==1 and brow.get('binding_state')=='BOUND' and pfp!=canonical_hash(brow)
        and _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.get(sid)==canonical_hash(brow) and _decision_row_runtime_authorized(sid,brow))
    add('r152_04_legal_pending_to_bound_refreshes_exact_row_fingerprint',all(bind_refresh_ok) and len(bind_refresh_ok)==3)

    # 5. Native/JSON, delete+reinsert and high-cardinality rows preserve only exact canonical content.
    r23_reset();state_c=export_decision_persistence_state();rows={}
    specs=(DECISION_RELATION_RESOLUTION_RECORD_TYPE,DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE,DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE)
    for i in range(36):
        rt=specs[i%3];idf='resolution_id' if rt==DECISION_RELATION_RESOLUTION_RECORD_TYPE else 'accounting_id';rid=f'r152:high:{i:02d}'
        row={'record_type':rt,idf:rid,'binding_state':'BOUND','r152_payload':('stable',i),
             'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,'persistence_history_commitment':state_c['history_commitment']}
        SUPPORT_SELECTION_REGISTRY[rid]=row;rows[rid]=copy.deepcopy(row)
    begin_decision_rehydration(json.loads(json.dumps(state_c,sort_keys=True)));complete_decision_rehydration()
    exact_ok=[];changed_ok=[]
    for i,(rid,row) in enumerate(sorted(rows.items())):
        del SUPPORT_SELECTION_REGISTRY[rid]
        if i%2==0:
            restored=json.loads(json.dumps(row,sort_keys=True));SUPPORT_SELECTION_REGISTRY[rid]=restored
            exact_ok.append(_decision_row_runtime_authorized(rid,restored) is True)
        else:
            changed=json.loads(json.dumps(row,sort_keys=True));changed['r152_payload']=['changed',i];SUPPORT_SELECTION_REGISTRY[rid]=changed
            changed_ok.append(_decision_row_runtime_authorized(rid,changed) is False)
    add('r152_05_native_json_delete_reinsert_and_highcard_matrix',len(rows)>=30 and all(exact_ok) and all(changed_ok) and len(exact_ok)==18 and len(changed_ok)==18)

    add('r152_06_previous_379_preserved_and_gate_count_49',
        old_379_ok and len(MANDATORY_GATES)==49 and len(T)==384 and all(x['pass'] for x in T))

    # ========================================================
    # R163 / v0.2.70: final AuditContextCertificate pins private decision runtime state.
    # Exactly six new self-tests; previous 385 entries above are retained unchanged.
    # ========================================================
    old_385_ok=(len(T)==385 and all(x['pass'] for x in T))

    # 1. The runtime-state hash is deterministic and changes on a legal begin transition.
    r23_reset();r163_state=export_decision_persistence_state();h0=_decision_runtime_authorization_state_hash()
    b0=begin_decision_rehydration(copy.deepcopy(r163_state));h1=_decision_runtime_authorization_state_hash()
    add('r163_01_runtime_state_hash_deterministic_and_begin_sensitive',
        b0 is True and h0!=h1 and h1==_decision_runtime_authorization_state_hash())

    # 2. Exact completion changes the pin again and records the validated checkpoint.
    c0=complete_decision_rehydration();h2=_decision_runtime_authorization_state_hash();s2=decision_rehydration_status()
    add('r163_02_runtime_state_hash_complete_sensitive',
        c0 is True and h2!=h1 and s2['active'] is False
        and s2['last_validated_history_commitment']==r163_state['history_commitment'])

    # 3. Authorized row commitment/fingerprint content contributes to the final-state pin.
    r23_reset();r163_state=export_decision_persistence_state();rid='r163:pin-row'
    row={'record_type':DECISION_RELATION_RESOLUTION_RECORD_TYPE,'resolution_id':rid,'binding_state':'BOUND',
         'persistence_history_commitment_version':PERSISTENCE_HISTORY_COMMITMENT_VERSION,
         'persistence_history_commitment':r163_state['history_commitment'],'r163_marker':'A'}
    SUPPORT_SELECTION_REGISTRY[rid]=row;begin_decision_rehydration(r163_state);complete_decision_rehydration();ha=_decision_runtime_authorization_state_hash()
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[rid]=sha(('r163','different-fingerprint'));hb=_decision_runtime_authorization_state_hash()
    add('r163_03_authorized_row_fingerprint_is_runtime_pin_input',ha!=hb)

    # 4. The stable audit-context seed does not depend on runtime authorization transitions.
    r23_reset();e=[ev('R163E1','Alice','state','safe','id:alice:v1')];rs='scope:r163:seed';_register_fixture_retrieval_scope(rs,e,'snapshot:r163:seed')
    claims=parse_claims('Alice is safe.');reqs=normalize_requirements(claims,None);rh=sha(reqs)
    aid0=_audit_context_seed('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,rh)
    st=export_decision_persistence_state();begin_decision_rehydration(st)
    aid1=_audit_context_seed('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,rh)
    add('r163_04_audit_context_seed_stable_across_runtime_state_change',aid0 is not None and aid0==aid1)

    # 5. A final context certificate revalidates only against the same runtime-state hash.
    complete_decision_rehydration()
    # R209 fixture lifecycle: production rehydration correctly terminates SELF_TEST_ONLY authority.
    # This legacy test explicitly starts a fresh test generation and reissues the same fixture role_record_id
    # before reusing the unchanged retrieval record, so snapshot content identity remains unchanged.
    enter_self_test_role_scope()
    for _r163_rec in e:
        _r163_rid=_r163_rec.get('epistemic_role_record_id')
        if isinstance(_r163_rid,str) and _r163_rid.startswith('role:auto:'):
            _fixture_issue_evidence_epistemic_role(_r163_rec,'DIRECT_WORLD_RECORD',role_record_id=_r163_rid)
    _fixture_issue_set_certificates('Alice is safe.',e,{'c1':'id:alice:v1'},None,rs,ASOF)
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs)
    ctx=bundle[4];ctx_hash=None if ctx is None else ctx.decision_runtime_authorization_state_hash
    st=export_decision_persistence_state();begin_decision_rehydration(st)
    fresh=make_context('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1])
    add('r163_05_final_context_pin_changes_without_changing_audit_context_id',
        ctx is not None and fresh is not None and fresh.audit_context_id==ctx.audit_context_id
        and fresh.decision_runtime_authorization_state_hash!=ctx_hash
        and validate_context(ctx,'Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1]) is False)

    # 6. Returning to the exact pinned runtime state restores certificate equivalence; gates remain 49.
    complete_decision_rehydration()
    exact_again=validate_context(ctx,'Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1])
    add('r163_06_previous_385_preserved_exact_state_equivalence_and_gate_count_49',
        old_385_ok and exact_again is True and len(MANDATORY_GATES)==49 and len(T)==390 and all(x['pass'] for x in T))

    # ========================================================
    # R168 / v0.2.71: strict runtime-map shape pin.
    # Exactly six new self-tests; previous 391 entries above are retained unchanged.
    # ========================================================
    old_391_ok=(len(T)==391 and all(x['pass'] for x in T))

    # 1. Authorized ID + absent commitment key differs from an explicit commitment=None key.
    r23_reset();rid='r168:presence:commitment';_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(rid)
    h_abs=_decision_runtime_authorization_state_hash();_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[rid]=None
    h_none=_decision_runtime_authorization_state_hash()
    add('r168_01_commitment_absent_and_explicit_none_have_distinct_runtime_hash',h_abs!=h_none)

    # 2. Authorized ID + absent fingerprint key differs from an explicit fingerprint=None key.
    r23_reset();rid='r168:presence:fingerprint';_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(rid)
    h_abs=_decision_runtime_authorization_state_hash();_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[rid]=None
    h_none=_decision_runtime_authorization_state_hash()
    add('r168_02_fingerprint_absent_and_explicit_none_have_distinct_runtime_hash',h_abs!=h_none)

    # 3. After prepare, commitment absent -> explicit None invalidates the old final context pin.
    r23_reset();e=[ev('R168C1','Alice','state','safe','id:alice:v1')];rs='scope:r168:commitment';_register_fixture_retrieval_scope(rs,e,'snapshot:r168:commitment')
    orphan='r168:orphan:commitment';_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(orphan)
    _fixture_issue_set_certificates('Alice is safe.',e,{'c1':'id:alice:v1'},None,rs,ASOF)
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs);ctx=bundle[4]
    reg_before=canonical_hash(SUPPORT_SELECTION_REGISTRY);pin_before=None if ctx is None else ctx.decision_runtime_authorization_state_hash
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[orphan]=None;pin_after=_decision_runtime_authorization_state_hash()
    invalid=ctx is not None and validate_context(ctx,'Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1]) is False
    add('r168_03_post_prepare_commitment_key_presence_change_invalidates_old_context',
        pin_before is not None and pin_before!=pin_after and canonical_hash(SUPPORT_SELECTION_REGISTRY)==reg_before and invalid)

    # 4. After prepare, fingerprint absent -> explicit None likewise invalidates the old context.
    r23_reset();e=[ev('R168F1','Alice','state','safe','id:alice:v1')];rs='scope:r168:fingerprint';_register_fixture_retrieval_scope(rs,e,'snapshot:r168:fingerprint')
    orphan='r168:orphan:fingerprint';_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(orphan)
    _fixture_issue_set_certificates('Alice is safe.',e,{'c1':'id:alice:v1'},None,rs,ASOF)
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs);ctx=bundle[4]
    reg_before=canonical_hash(SUPPORT_SELECTION_REGISTRY);pin_before=None if ctx is None else ctx.decision_runtime_authorization_state_hash
    _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[orphan]=None;pin_after=_decision_runtime_authorization_state_hash()
    invalid=ctx is not None and validate_context(ctx,'Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1]) is False
    add('r168_04_post_prepare_fingerprint_key_presence_change_invalidates_old_context',
        pin_before is not None and pin_before!=pin_after and canonical_hash(SUPPORT_SELECTION_REGISTRY)==reg_before and invalid)

    # 5. Restoring the exact previous key shape restores the exact hash/context equivalence.
    r23_reset();e=[ev('R168R1','Alice','state','safe','id:alice:v1')];rs='scope:r168:restore';_register_fixture_retrieval_scope(rs,e,'snapshot:r168:restore')
    orphan='r168:orphan:restore';_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(orphan)
    _fixture_issue_set_certificates('Alice is safe.',e,{'c1':'id:alice:v1'},None,rs,ASOF)
    bundle=prepare('Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs);ctx=bundle[4]
    h0=_decision_runtime_authorization_state_hash();_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[orphan]=None;h1=_decision_runtime_authorization_state_hash()
    _DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.pop(orphan,None);h2=_decision_runtime_authorization_state_hash()
    restored=ctx is not None and validate_context(ctx,'Alice is safe.',e,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,rs,bundle[2],bundle[3],bundle[0],bundle[1]) is True
    add('r168_05_exact_map_shape_restoration_regains_hash_and_context_equivalence',h0!=h1 and h2==h0 and restored)

    # 6. Insertion order remains irrelevant; previous tests/gates and a prior legal closure control remain intact.
    r23_reset();specs=(('r168:o:a','ca','fa'),('r168:o:b',None,'fb'),('r168:o:c','cc',None))
    for rid,com,fp in specs:
        _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(rid);_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[rid]=com;_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[rid]=fp
    ho1=_decision_runtime_authorization_state_hash()
    _DECISION_ROW_RUNTIME_AUTHORIZED_IDS.clear();_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS.clear();_DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    for rid,com,fp in reversed(specs):
        _DECISION_ROW_RUNTIME_AUTHORIZED_FINGERPRINTS[rid]=fp;_DECISION_ROW_RUNTIME_AUTHORIZED_COMMITMENTS[rid]=com;_DECISION_ROW_RUNTIME_AUTHORIZED_IDS.add(rid)
    ho2=_decision_runtime_authorization_state_hash()
    prior_legal_control=any(x.get('name')=='clean_cross_claim_decision_can_close' and x.get('pass') is True for x in T)
    add('r168_06_previous_391_preserved_order_invariant_gate49_and_legal_control',
        old_391_ok and ho1==ho2 and len(MANDATORY_GATES)==49 and prior_legal_control and len(T)==396 and all(x['pass'] for x in T))

    # ========================================================
    # R174 / v0.2.72: interrogative surface cannot be audited as an assertion.
    # Exactly eight new self-tests; previous 397 entries are retained unchanged.
    # ========================================================
    old_397_ok=(len(T)==397 and all(x['pass'] for x in T))
    add('r174_01_previous_397_preserved_and_gate_count_49',old_397_ok and len(MANDATORY_GATES)==49)

    r23_reset();pos=[ev('R174P','Alice','state','safe','id:alice:v1')]
    pos_control=run('Alice is safe.',pos,{'c1':'id:alice:v1'})
    add('r174_02_declarative_control_still_closes',
        pos_control['control_closure'] is True and pos_control['claims'][0]['status']=='VERIFIED')

    q_variants=('Alice is safe?','Alice is safe ?','Alice is safe???','Alice is safe?!','Alice is safe?\n')
    q_out=[run(q,pos,{'c1':'id:alice:v1'}) for q in q_variants]
    add('r174_03_interrogative_punctuation_variants_fail_closed',
        all(o['control_closure'] is False and o['claims'][0]['status']=='UNRESOLVED' for o in q_out))

    r23_reset();neg=[ev('R174N','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')]
    nq_out=[run(q,neg,{'c1':'id:alice:v1'}) for q in ('Alice is not safe?','Alice is not safe???')]
    add('r174_04_negated_interrogatives_do_not_become_negative_assertions',
        all(o['control_closure'] is False and o['claims'][0]['status']=='UNRESOLVED' for o in nq_out))

    aux=run('Is Alice safe?',pos,{})
    add('r174_05_auxiliary_question_remains_fail_closed',
        aux['control_closure'] is False and aux['claims'][0]['status']=='UNRESOLVED')

    qno=run('Alice is safe? No.',pos,{'c1':'id:alice:v1'})
    add('r174_06_question_plus_no_does_not_verify_question_surface',
        qno['control_closure'] is False and len(qno['claims'])==2 and qno['claims'][0]['status']=='UNRESOLVED')

    qyes=run('Alice is safe? Yes.',pos,{'c1':'id:alice:v1'})
    add('r174_07_question_plus_yes_does_not_verify_question_surface',
        qyes['control_closure'] is False and len(qyes['claims'])==2 and qyes['claims'][0]['status']=='UNRESOLVED')

    add('r174_08_previous_and_new_tests_all_pass_gate_count_49',
        len(T)==404 and all(x['pass'] for x in T) and len(MANDATORY_GATES)==49)

    # ========================================================
    # R177 / v0.2.73: explicit question/answer transition control.
    # Twelve new self-tests; previous 405 entries are retained unchanged.
    # ========================================================
    old_405_ok=(len(T)==405 and all(x['pass'] for x in T))
    add('r177_01_previous_405_preserved_and_gate_count_49',old_405_ok and len(MANDATORY_GATES)==49)

    def r177_setup(tag,evidence):
        rid=f'r177:self:{tag}';snap=f'snapshot:{rid}'
        _register_fixture_retrieval_scope(rid,evidence,snap)
        return rid,snap
    def r177_binding(qid='q',pid='p'):
        return make_question_answer_binding(qid,pid,'Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    def r177_basis(evidence,rid,asof=ASOF):
        return transition_epistemic_basis_hash(evidence,asof,SCOPE,EXTRACT,rid,None,'id:alice:v1')
    def r177_prior_from_source(b,evidence,rid):
        a=issue_predecessor_control_artifact(b,evidence,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Alice safe?')
        return None if a is None else prior_epistemic_state_from_artifact(a.artifact_id)
    def r177_audit(pr,b,ans,evidence,rid):
        return audit_answer_transition(pr,b,ans,evidence,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Alice safe?')

    r23_reset();b=r177_binding()
    add('r177_02_binding_valid_and_stale_question_rejected',
        b is not None and validate_question_answer_binding(b,'Is Alice safe?') and not validate_question_answer_binding(b,'Is Alice calm?'))

    r23_reset();e=[ev('R177U1','Alice','state','warm','id:alice:v1')];rid,snap=r177_setup('unknown',e);b=r177_binding();pr=r177_prior_from_source(b,e,rid)
    ry=r177_audit(pr,b,'YES',e,rid);rn=r177_audit(pr,b,'NO',e,rid)
    add('r177_03_unknown_same_basis_yes_blocks',ry.transition_decision=='BLOCK' and ry.core_control_closure is False)
    add('r177_04_unknown_same_basis_no_blocks',rn.transition_decision=='BLOCK' and rn.core_control_closure is False)

    r23_reset();old=[ev('R177U2','Alice','state','warm','id:alice:v1')];orid,osnap=r177_setup('oldp',old);obh=r177_basis(old,orid)
    pos=[ev('R177P2','Alice','state','safe','id:alice:v1')];nrid,_=r177_setup('newp',pos);b=r177_binding();pr=r177_prior_from_source(b,old,orid);rp=r177_audit(pr,b,'YES',pos,nrid)
    add('r177_05_changed_evidence_positive_yes_allows',rp.transition_decision=='ALLOW' and rp.core_claim_status=='VERIFIED' and rp.current_epistemic_basis_hash!=obh)

    r23_reset();old=[ev('R177U3','Alice','state','warm','id:alice:v1')];orid,osnap=r177_setup('oldn',old);obh=r177_basis(old,orid)
    neg=[ev('R177N3','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')];nrid,_=r177_setup('newn',neg);b=r177_binding();pr=r177_prior_from_source(b,old,orid);rn=r177_audit(pr,b,'NO',neg,nrid)
    add('r177_06_changed_evidence_negative_no_allows',rn.transition_decision=='ALLOW' and rn.core_claim_status=='VERIFIED' and rn.current_epistemic_basis_hash!=obh)

    r23_reset();pos=[ev('R177P4','Alice','state','safe','id:alice:v1')];rid,snap=r177_setup('vp',pos);b=r177_binding();pr=r177_prior_from_source(b,pos,rid);rr=r177_audit(pr,b,'NO',pos,rid)
    add('r177_07_verified_positive_reversal_no_blocks',rr.transition_decision=='BLOCK' and rr.reason=='VERIFIED_REVERSAL_REQUIRES_EXTERNAL_UPDATE_AND_ROLLBACK_PROOF')

    r23_reset();neg=[ev('R177N4','Alice','state','safe','id:alice:v1',polarity='NEGATIVE')];rid,snap=r177_setup('vn',neg);b=r177_binding();pr=r177_prior_from_source(b,neg,rid);rr=r177_audit(pr,b,'YES',neg,rid)
    add('r177_08_verified_negative_reversal_yes_blocks',rr.transition_decision=='BLOCK' and rr.reason=='VERIFIED_REVERSAL_REQUIRES_EXTERNAL_UPDATE_AND_ROLLBACK_PROOF')

    r23_reset();e=[ev('R177U5','Alice','state','warm','id:alice:v1')];rid,snap=r177_setup('abstain',e);b=r177_binding();pr=r177_prior_from_source(b,e,rid);ra=r177_audit(pr,b,'UNKNOWN',e,rid)
    add('r177_09_explicit_abstention_preserves_unresolved',ra.transition_decision=='PRESERVE_UNRESOLVED' and ra.bound_polarity=='ABSTAIN')

    r23_reset();e=[ev('R177P5','Alice','state','safe','id:alice:v1')];rid,snap=r177_setup('token',e);b=r177_binding();pr=r177_prior_from_source(b,e,rid);rok=r177_audit(pr,b,'  yEs  ',e,rid);rbad=r177_audit(pr,b,'YES.',e,rid)
    add('r177_10_token_normalization_is_exact_not_punctuation_stripping',rok.transition_decision=='ALLOW' and rok.normalized_answer_token=='yes' and rbad.transition_decision=='BLOCK' and rbad.bound_polarity=='UNBOUND')

    r23_reset();e=[ev('R177F6','Alice','state','warm','id:alice:v1')];rid,snap=r177_setup('format',e);h1=r177_basis(e,rid);b1=r177_binding('q1','p');b2=make_question_answer_binding('q2','p','Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1','TRUE','FALSE');h2=r177_basis(e,rid)
    add('r177_11_format_mapping_has_no_epistemic_basis_authority',b1 is not None and b2 is not None and h1==h2)

    r23_reset();e=[ev('R177Q7','Alice','state','safe','id:alice:v1')];qs=('Alice is safe?','Alice is safe ?','Alice is safe???','Alice is safe?!','Alice is safe?\n');qo=[run(q,e,{'c1':'id:alice:v1'}) for q in qs]
    add('r177_12_all_transition_tests_and_r174_interrogative_regression_pass',
        all(o['control_closure'] is False and o['claims'][0]['status']=='UNRESOLVED' for o in qo)
        and len(T)==416 and all(x['pass'] for x in T) and len(MANDATORY_GATES)==49)

    # ========================================================
    # R181 / v0.2.74: controller-owned predecessor authority.
    # Eight new self-tests; previous 417 entries are retained unchanged.
    # ========================================================
    old_417_ok=(len(T)==417 and all(x['pass'] for x in T))
    add('r181_01_previous_417_preserved_and_gate_count_49',old_417_ok and len(MANDATORY_GATES)==49)

    def r181_setup(tag,evidence):
        rid=f'r181:self:{tag}';snap=f'snapshot:{rid}'
        _register_fixture_retrieval_scope(rid,evidence,snap)
        return rid,snap
    def r181_binding(pid='p181',qid='q181'):
        return make_question_answer_binding(qid,pid,'Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    def r181_issue_prior(b,evidence,rid):
        a=issue_predecessor_control_artifact(b,evidence,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Alice safe?')
        return a,None if a is None else prior_epistemic_state_from_artifact(a.artifact_id)
    def r181_audit(pr,b,ans,evidence,rid):
        return audit_answer_transition(pr,b,ans,evidence,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Alice safe?')

    r23_reset();e=[ev('R181U2','Alice','state','warm','id:alice:v1')];rid,snap=r181_setup('plain',e);b=r181_binding()
    bh=transition_epistemic_basis_hash(e,ASOF,SCOPE,EXTRACT,rid,None,'id:alice:v1')
    plain=make_prior_epistemic_state('p181','UNRESOLVED','UNRESOLVED',bh,snap);rr=r181_audit(plain,b,'YES',e,rid)
    add('r181_02_structural_self_mint_has_no_predecessor_authority',validate_prior_epistemic_state(plain) and rr.transition_decision=='BLOCK' and rr.reason=='INVALID_OR_UNAUTHORIZED_PRIOR_STATE')

    r23_reset();e=[ev('R181U3','Alice','state','warm','id:alice:v1')];rid,_=r181_setup('unknown',e);b=r181_binding();a,pr=r181_issue_prior(b,e,rid)
    ry=r181_audit(pr,b,'YES',e,rid);rn=r181_audit(pr,b,'NO',e,rid)
    add('r181_03_authoritative_unknown_yes_no_both_block',a is not None and pr is not None and validate_authoritative_prior_epistemic_state(pr,b) and ry.transition_decision=='BLOCK' and rn.transition_decision=='BLOCK')

    r23_reset();pos=[ev('R181P4','Alice','state','safe','id:alice:v1')];rid,_=r181_setup('verified',pos);b=r181_binding();a,pr=r181_issue_prior(b,pos,rid);rr=r181_audit(pr,b,'NO',pos,rid)
    add('r181_04_authoritative_verified_reversal_guard_preserved',a is not None and a.positive_status=='VERIFIED' and rr.transition_decision=='BLOCK' and rr.reason=='VERIFIED_REVERSAL_REQUIRES_EXTERNAL_UPDATE_AND_ROLLBACK_PROOF')

    r23_reset();pos=[ev('R181P5','Alice','state','safe','id:alice:v1')];rid,_=r181_setup('forge',pos);b=r181_binding();a,pr=r181_issue_prior(b,pos,rid)
    forged=make_prior_epistemic_state(pr.proposition_id,'UNRESOLVED','UNRESOLVED',pr.epistemic_basis_hash,pr.source_snapshot_id,pr.source_artifact_id,pr.source_artifact_fingerprint,pr.source_sequence)
    rf=r181_audit(forged,b,'NO',pos,rid)
    add('r181_05_rehashed_status_downgrade_cannot_bypass_authority',validate_prior_epistemic_state(forged) and not validate_authoritative_prior_epistemic_state(forged,b) and rf.transition_decision=='BLOCK')

    r23_reset();e=[ev('R181U6','Alice','state','warm','id:alice:v1')];rid,_=r181_setup('stale',e);b=r181_binding();a1,pr1=r181_issue_prior(b,e,rid);a2,pr2=r181_issue_prior(b,e,rid)
    add('r181_06_only_latest_predecessor_is_authoritative',a1 is not None and a2 is not None and a2.sequence==2 and a2.predecessor_artifact_id==a1.artifact_id and not validate_authoritative_prior_epistemic_state(pr1,b) and validate_authoritative_prior_epistemic_state(pr2,b))

    r23_reset();e=[ev('R181U7','Alice','state','warm','id:alice:v1')];rid,_=r181_setup('partial',e);b=r181_binding();a,pr=r181_issue_prior(b,e,rid);state=export_decision_persistence_state();beg=begin_decision_rehydration(state);PREDECESSOR_CONTROL_ARTIFACT_REGISTRY.pop(a.artifact_id,None);comp=complete_decision_rehydration()
    add('r181_07_partial_rehydration_cannot_mint_predecessor_authority',beg and comp is False and decision_rehydration_status()['active'] is True and not decision_rehydration_status()['authorized_predecessor_artifact_ids'])

    r23_reset();e=[ev('R181U8','Alice','state','warm','id:alice:v1')];rid,_=r181_setup('exact',e);b=r181_binding();a,pr=r181_issue_prior(b,e,rid);state=export_decision_persistence_state();beg=begin_decision_rehydration(state);pre=not validate_authoritative_prior_epistemic_state(pr,b);comp=complete_decision_rehydration();post=validate_authoritative_prior_epistemic_state(pr,b)
    add('r181_08_exact_rehydration_restores_authority_and_all_tests_pass',beg and pre and comp and post and len(T)==424 and all(x['pass'] for x in T) and len(MANDATORY_GATES)==49)

    # ========================================================
    # R192 / v0.2.77: question/proposition semantic binding and controller-owned YES/NO polarity.
    # Eight new self-tests; previous 425 entries are retained unchanged.
    # ========================================================
    old_425_ok=(len(T)==425 and all(x['pass'] for x in T))
    add('r192_01_previous_425_preserved_and_gate_count_49',old_425_ok and len(MANDATORY_GATES)==49)

    r23_reset();b=make_question_answer_binding('r192:q1','r192:p1','Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    sem=resolve_question_semantics('Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    add('r192_02_direct_world_state_semantics_bind_to_canonical_proposition',b is not None and validate_question_answer_binding(b,'Is Alice safe?') and sem.get('question_semantic_kind')=='WORLD_STATE_BINARY' and sem.get('question_canonical_proposition_id')==b.canonical_proposition_id)

    r23_reset();bad=make_question_answer_binding('r192:q2','r192:p2','Is Bob safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    add('r192_03_unrelated_question_cannot_mint_binding',bad is None)

    r23_reset();meta=make_question_answer_binding('r192:q3','r192:p3','Does the evidence establish that Alice is safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    add('r192_04_entailment_meta_question_cannot_mint_world_state_binding',meta is None)

    r23_reset();swap=make_question_answer_binding('r192:q4','r192:p4','Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1','NO','YES')
    add('r192_05_swapped_yes_no_mapping_rejected',swap is None)

    r23_reset();tf=make_question_answer_binding('r192:q5','r192:p5','Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1','TRUE','FALSE')
    add('r192_06_true_false_is_separate_nontransition_profile',tf is not None and tf.format_kind=='BINARY_TRUE_FALSE' and not validate_question_answer_binding(tf,'Is Alice safe?'))

    r23_reset();negq=make_question_answer_binding('r192:q6','r192:p6','Is Alice not safe?','Alice is safe.','Alice is not safe.','id:alice:v1')
    add('r192_07_negated_question_fails_closed_in_current_scope',negq is None)

    r23_reset();e=[ev('R192P8','Alice','state','safe','id:alice:v1')];rid,_=r177_setup('r192end',e);good=make_question_answer_binding('r192:q8','r192:p8','Is Alice safe?','Alice is safe.','Alice is not safe.','id:alice:v1');a=issue_predecessor_control_artifact(good,e,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Alice safe?');pr=None if a is None else prior_epistemic_state_from_artifact(a.artifact_id)
    forged_payload=_binding_payload('r192:q8bad','r192:p8','x','Alice is safe.','Alice is not safe.','id:alice:v1','YES','NO','BINARY_YES_NO','NONE',good.canonical_proposition_id,'Is Bob safe?')
    forged_payload['question_text_hash']=_question_text_hash('Is Bob safe?');forged=QuestionAnswerBinding(_binding_id_from_payload(forged_payload),forged_payload['question_id'],forged_payload['proposition_id'],forged_payload['question_text_hash'],forged_payload['positive_claim_text'],forged_payload['negative_claim_text'],forged_payload['claim_identity_id'],forged_payload['yes_token'],forged_payload['no_token'],forged_payload['format_kind'],forged_payload['epistemic_authority'],forged_payload['canonical_proposition_id'],forged_payload['question_text'])
    rr=audit_answer_transition(pr,forged,'YES',e,ASOF,SCOPE,EXTRACT,rid,None,current_question_text='Is Bob safe?')
    add('r192_08_forged_unrelated_semantic_binding_fails_closed_and_all_tests_pass',rr.transition_decision=='BLOCK' and rr.reason=='INVALID_OR_UNAUTHORIZED_PRIOR_STATE' and len(T)==432 and all(x['pass'] for x in T) and len(MANDATORY_GATES)==49)

    failures=sum(not t['pass'] for t in T)
    _SELF_TEST_FIXTURE_ROLE_AUTOREBIND=False
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_FINGERPRINTS.clear()
    _EVIDENCE_ROLE_RUNTIME_AUTHORIZED_COMMITMENTS.clear()
    exit_self_test_role_scope()
    return {'failures':failures,'tests':T}


def main():
    if len(sys.argv)==1 or sys.argv[1]=='--self-test':
        r=self_tests();print(json.dumps(r,indent=2,ensure_ascii=False));sys.exit(1 if r['failures'] else 0)
    if sys.argv[1]=='--demo':
        ASOF='2026-08-10'; SCOPE=CANONICAL_SCOPE; EXTRACT=CANONICAL_EXTRACTION
        def dep_local(eid):
            return {dim:{'state':'KNOWN','id':f'{DEPENDENCY_PREFIX[dim]}:{eid}'} for dim in DEPENDENCY_DIMENSIONS}
        def rec(eid,value='safe',root=None,origin=None,group=None,extractor=None):
            root=root or f'general-record:root:{eid}'; origin=origin or f'general-record:origin:{eid}'
            return {'evidence_id':eid,'subject':'Alice','predicate':'state','value':value,'source':f'display:{eid}',
                    'polarity':'POSITIVE','identity_registry_entry_id':'id:alice:v1','authority_id':'GENERAL_RECORD_V5',
                    'authority_record_entity_id':'entity:alice','authority_record_event_id':'event:current',
                    'authority_record_version_id':'v1','valid_from':'2026-01-01','valid_to':'2026-12-31',
                    'observed_at':ASOF,'available_at':ASOF,
                    'provenance':{'source_id':f'general-record:{eid}','root_origin_id':root,'origin_id':origin,
                                  'referent_entity_id':'entity:alice','referent_event_id':'event:current',
                                  'referent_version_id':'v1','extractor_id':extractor or f'extractor:{eid}',
                                  'common_mode_group':group or f'group:{eid}','lineage':[root,origin],
                                  'dependencies':dep_local(eid)}}
        pred=[rec('P1')]
        branch_a=[pred[0],rec('A2',root='general-record:A:r',origin='general-record:A:o',group='A',extractor='A')]
        branch_b=[rec('B1','unsafe',root='general-record:B:r',origin='general-record:B:o',group='B',extractor='B')]
        _register_fixture_retrieval_scope('demo:pred',pred,'snapshot:demo:pred',snapshot_version=1)
        _register_fixture_retrieval_scope('demo:A',branch_a,'snapshot:demo:A',snapshot_version=2,
                                          supersedes='demo:pred')
        _register_fixture_retrieval_scope('demo:B',branch_b,'snapshot:demo:B',snapshot_version=2,
                                          supersedes='demo:pred',retracted_evidence_ids=['P1'])
        desc=claim_descriptors('Alice is safe.',{'c1':'id:alice:v1'})[0]
        cmap,_=decision_relevant_candidate_map('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,ASOF)
        brow=snapshot_projection_rows('demo:B',desc,ASOF)
        comp=make_snapshot_competition('Alice is safe.',{'c1':'id:alice:v1'},SCOPE,'demo:A',ASOF)
        bundle=prepare('Alice is safe.',branch_a,{'c1':'id:alice:v1'},ASOF,SCOPE,EXTRACT,'demo:A',
                       {'c1':{'required_independent_supports':2}})
        print(json.dumps({
            'scenario':'RELATIONAL_VALUE_CHANGING_FORK_ESCAPE',
            'candidate_map':cmap,
            'unsafe_branch_projection':[{'evidence_id':x['evidence_id'],'value':x['value_key'],'relation':x['claim_relation']} for x in brow],
            'competition_certificate_created':comp is not None,
            'context_created':bundle[4] is not None,
            'stop_type':'NONE',
            'control_closure':False,
            'mandatory_gate_count':len(MANDATORY_GATES),
        },indent=2,ensure_ascii=False))
        return
    raise SystemExit('Use --self-test or --demo')

if __name__=='__main__':main()
