from __future__ import annotations

import argparse
import json
from . import __version__
from .api import Controller
from . import _engine


def main() -> int:
    parser = argparse.ArgumentParser(prog="cfc-anchor")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("info", help="show packaged controller identity")
    sub.add_parser("self-test", help="run the controller's full built-in self-test")
    args = parser.parse_args()

    if args.command == "info":
        c = Controller()
        print(json.dumps({
            "package_version": __version__,
            "controller_sha256": c.controller_sha256,
            "persistence_schema": c.persistence_schema,
            "mandatory_gate_count": c.mandatory_gate_count,
            "status": "INTERFACE_FREEZE_CANDIDATE_V1",
        }, indent=2))
        return 0

    result = _engine.self_tests()
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 1 if result.get("failures") else 0
