"""Explicit NON-PRODUCTION helpers for CFC Anchor local tests.

Importing this module opts into test-only dynamic verifier trust and fixture installation.
Production integrations should use cfc_anchor.Controller with HostTrustPolicy instead.
"""
from __future__ import annotations

from .api import Controller, DeveloperFixtureSession, _DynamicTestingHostTrustPolicy


def make_test_controller(*, scope: str | None = None, extraction: str | None = None) -> Controller:
    """Return a Controller with explicit test-only dynamic verifier trust."""
    return Controller(scope=scope, extraction=extraction, trust_policy=_DynamicTestingHostTrustPolicy())


def fixture_session(controller: Controller) -> DeveloperFixtureSession:
    """Return the explicit test-only fixture session for a testing Controller."""
    if not isinstance(controller, Controller):
        raise TypeError("controller must be Controller")
    if not isinstance(getattr(controller, "_trust_policy", None), _DynamicTestingHostTrustPolicy):
        raise RuntimeError("fixture_session requires cfc_anchor.testing.testing_controller()")
    return DeveloperFixtureSession(controller)


__all__ = ["make_test_controller", "fixture_session"]
