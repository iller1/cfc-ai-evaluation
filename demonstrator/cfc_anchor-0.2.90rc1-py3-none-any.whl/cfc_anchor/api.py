"""Developer-preview public wrapper for the frozen/recovery-lineage CFC engine.

R248 adds a non-authorizing snapshot-draft interface.  R249 adds an externally
verified retrieval-authority boundary.  R250 adds the same separation for identity: describing an identity is not authority
to register it. R251 adds a canonical EvidenceRecord draft/inspection boundary:
describing evidence never creates provenance, source semantics, authority, epistemic
role, or independence. R252 adds externally verified provenance and source-semantics
trust boundaries: provenance is runtime-pinned without being minted by CFC, while
source-semantics registry installation requires an exact host attestation. R253 adds externally verified evidence-authority and epistemic-role trust boundaries: selecting an authority policy or role label is never sufficient by itself. R254 adds externally verified dependency-relation boundaries for source independence, support-set COMMON_MODE/UNKNOWN declarations, and support-set independence. R255 adds externally verified decision-authority boundaries for explicit support selection, relation resolution, and excluded-support disposition. R259 requires a host-attested complete failure-domain topology. R260 adds externally verified generic representation equivalence and exact-context distinctness boundaries; absence of either never implies distinctness or equivalence. R261 adds externally verified decision-level source and generic dependency accounting boundaries with explicit PENDING-to-BOUND context binding. R263 isolates runtime trust pins by Controller trust context so verification in one Controller cannot authorize another Controller in the same process. R265 isolates explicit developer-fixture runtime from production Controller calls. R266 exposes the frozen V6 checkpoint/rehydration lifecycle and invalidates wrapper runtime trust across replay. R267 defines the V1 interface freeze candidate without changing frozen-engine semantics. Production-facing
identity rows require an exact external attestation plus a live runtime verification pin.
A separate DeveloperFixtureSession exists only for local tests and is explicitly non-production.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Mapping, Sequence, Protocol
import copy
import hashlib
import threading
import functools
import inspect
from contextlib import contextmanager

from . import _engine

_ENGINE_LOCK = threading.RLock()
_VERIFIED_RETRIEVAL_RUNTIME: dict[str, str] = {}
_DEVELOPER_FIXTURE_RUNTIME: dict[str, str] = {}
_RETRIEVAL_ATTESTATION_SCHEMA = "CFC_RETRIEVAL_AUTHORITY_ATTESTATION_V1"
_VERIFIED_IDENTITY_RUNTIME: dict[str, str] = {}
_DEVELOPER_IDENTITY_RUNTIME: dict[str, str] = {}
_IDENTITY_ATTESTATION_SCHEMA = "CFC_IDENTITY_AUTHORITY_ATTESTATION_V1"
_RESERVED_LOCAL_IDENTITY_AUTHORITY = "LOCAL_IDENTITY_FIXTURE_AUTHORITY"
_BUILTIN_IDENTITY_FIXTURES = copy.deepcopy(_engine.IDENTITY_REGISTRY)
_BUILTIN_IDENTITY_FIXTURE_HASHES = {
    key: _engine.canonical_hash(value) for key, value in _BUILTIN_IDENTITY_FIXTURES.items()
}

_VERIFIED_PROVENANCE_RUNTIME: dict[str, str] = {}
_VERIFIED_PROVENANCE_METADATA: dict[str, dict[str, str]] = {}
_DEVELOPER_PROVENANCE_RUNTIME: dict[str, str] = {}
_PROVENANCE_ATTESTATION_SCHEMA = "CFC_PROVENANCE_AUTHORITY_ATTESTATION_V1"
_RESERVED_LOCAL_PROVENANCE_AUTHORITY = "LOCAL_PROVENANCE_FIXTURE_AUTHORITY"

_VERIFIED_SOURCE_SEMANTICS_RUNTIME: dict[str, str] = {}
_DEVELOPER_SOURCE_SEMANTICS_RUNTIME: dict[str, str] = {}
_SOURCE_SEMANTICS_ATTESTATION_SCHEMA = "CFC_SOURCE_SEMANTICS_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_SOURCE_SEMANTICS_AUTHORITY = "LOCAL_SOURCE_SEMANTICS_AUTHORITY"

_VERIFIED_EVIDENCE_AUTHORITY_RUNTIME: dict[str, str] = {}
_VERIFIED_EVIDENCE_AUTHORITY_METADATA: dict[str, dict[str, str]] = {}
_DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME: dict[str, str] = {}
_EVIDENCE_AUTHORITY_ATTESTATION_SCHEMA = "CFC_EVIDENCE_AUTHORITY_ATTESTATION_V1"
_RESERVED_LOCAL_EVIDENCE_AUTHORITY = "LOCAL_EVIDENCE_AUTHORITY_FIXTURE"

_VERIFIED_EPISTEMIC_ROLE_RUNTIME: dict[str, str] = {}
_VERIFIED_EPISTEMIC_ROLE_METADATA: dict[str, dict[str, str]] = {}
_DEVELOPER_EPISTEMIC_ROLE_RUNTIME: dict[str, str] = {}
_EPISTEMIC_ROLE_ATTESTATION_SCHEMA = "CFC_EPISTEMIC_ROLE_AUTHORITY_ATTESTATION_V1"
_RESERVED_EXTERNAL_ROLE_AUTHORITIES = frozenset(
    ["LOCAL_EPISTEMIC_ROLE_AUTHORITY"]
    + [authority for _gid, authority, _roles in _engine.PINNED_EVIDENCE_EPISTEMIC_ROLE_ISSUER_POLICY["grants"]]
)


_VERIFIED_SOURCE_INDEPENDENCE_RUNTIME: dict[str, str] = {}
_VERIFIED_SOURCE_INDEPENDENCE_METADATA: dict[str, dict[str, str]] = {}
_SOURCE_INDEPENDENCE_ATTESTATION_SCHEMA = "CFC_SOURCE_INDEPENDENCE_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_SOURCE_INDEPENDENCE_AUTHORITY = "LOCAL_SOURCE_INDEPENDENCE_AUTHORITY"

_VERIFIED_SUPPORT_RELATION_RUNTIME: dict[str, str] = {}
_VERIFIED_SUPPORT_RELATION_METADATA: dict[str, dict[str, str]] = {}
_SUPPORT_RELATION_ATTESTATION_SCHEMA = "CFC_SUPPORT_RELATION_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_RELATION_AUTHORITY = "LOCAL_SOURCE_SEMANTICS_AUTHORITY"

_VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME: dict[str, str] = {}
_VERIFIED_SUPPORT_SET_INDEPENDENCE_METADATA: dict[str, dict[str, str]] = {}
_SUPPORT_SET_INDEPENDENCE_ATTESTATION_SCHEMA = "CFC_SUPPORT_SET_INDEPENDENCE_AUTHORITY_ATTESTATION_V1"

_VERIFIED_SUPPORT_SELECTION_RUNTIME: dict[str, str] = {}
_VERIFIED_SUPPORT_SELECTION_METADATA: dict[str, dict[str, str]] = {}
_SUPPORT_SELECTION_ATTESTATION_SCHEMA = "CFC_SUPPORT_SELECTION_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_SUPPORT_SELECTION_AUTHORITY = "LOCAL_SUPPORT_UNIVERSE_AUTHORITY"

_VERIFIED_RELATION_RESOLUTION_RUNTIME: dict[str, str] = {}
_VERIFIED_RELATION_RESOLUTION_METADATA: dict[str, dict[str, str]] = {}
_RELATION_RESOLUTION_ATTESTATION_SCHEMA = "CFC_RELATION_RESOLUTION_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_RELATION_RESOLUTION_AUTHORITY = "LOCAL_RELATION_RESOLUTION_AUTHORITY"

_VERIFIED_EXCLUDED_DISPOSITION_RUNTIME: dict[str, str] = {}
_VERIFIED_EXCLUDED_DISPOSITION_METADATA: dict[str, dict[str, str]] = {}
_EXCLUDED_DISPOSITION_ATTESTATION_SCHEMA = "CFC_EXCLUDED_SUPPORT_DISPOSITION_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_EXCLUDED_DISPOSITION_AUTHORITY = "LOCAL_EXCLUSION_DISPOSITION_AUTHORITY"

_VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME: dict[str, str] = {}
_VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA: dict[str, dict[str, str]] = {}
_FAILURE_DOMAIN_TOPOLOGY_ATTESTATION_SCHEMA = "CFC_FAILURE_DOMAIN_TOPOLOGY_ATTESTATION_V1"
_RESERVED_FAILURE_DOMAIN_TOPOLOGY_AUTHORITIES = frozenset({
    "LOCAL_FAILURE_DOMAIN_TOPOLOGY_AUTHORITY", "LOCAL_SOURCE_SEMANTICS_AUTHORITY"
})

_VERIFIED_GENERIC_EQUIVALENCE_RUNTIME: dict[str, str] = {}
_VERIFIED_GENERIC_EQUIVALENCE_METADATA: dict[str, dict[str, str]] = {}
_GENERIC_EQUIVALENCE_ATTESTATION_SCHEMA = "CFC_GENERIC_EQUIVALENCE_AUTHORITY_ATTESTATION_V1"
_VERIFIED_GENERIC_DISTINCTNESS_RUNTIME: dict[str, str] = {}
_VERIFIED_GENERIC_DISTINCTNESS_METADATA: dict[str, dict[str, str]] = {}
_GENERIC_DISTINCTNESS_ATTESTATION_SCHEMA = "CFC_GENERIC_DISTINCTNESS_AUTHORITY_ATTESTATION_V1"
_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY = "LOCAL_GENERIC_EQUIVALENCE_AUTHORITY"

_VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME: dict[str, str] = {}
_VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA: dict[str, dict[str, str]] = {}
_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA = "CFC_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_ATTESTATION_V1"
_VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME: dict[str, str] = {}
_VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA: dict[str, dict[str, str]] = {}
_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA = "CFC_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_ATTESTATION_V1"
_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY = "LOCAL_SUPPORT_UNIVERSE_AUTHORITY"


_TRUST_BOUNDARIES = frozenset({
    "IDENTITY", "RETRIEVAL", "PROVENANCE", "SOURCE_SEMANTICS",
    "EVIDENCE_AUTHORITY", "EPISTEMIC_ROLE", "SOURCE_INDEPENDENCE",
    "SUPPORT_RELATION", "SUPPORT_SET_INDEPENDENCE", "SUPPORT_SELECTION",
    "RELATION_RESOLUTION", "EXCLUDED_SUPPORT_DISPOSITION",
    "FAILURE_DOMAIN_TOPOLOGY", "GENERIC_EQUIVALENCE", "GENERIC_DISTINCTNESS",
    "DECISION_SOURCE_DEPENDENCY_ACCOUNTING", "DECISION_GENERIC_DEPENDENCY_ACCOUNTING",
})

# R263: verified runtime pins remain process-global storage because the frozen engine is
# process-global, but every pin is owned by one wrapper trust context.  Public methods
# only see pins owned by their own Controller.  This prevents cross-Controller trust
# bleed while preserving the frozen engine and existing persisted registries.
_VERIFIED_RUNTIME_OWNER: dict[tuple[str, str], set[object]] = {}
_WRAPPER_REHYDRATION_OWNER: object | None = None

_VERIFIED_METADATA_MAPS = (
    _VERIFIED_PROVENANCE_METADATA,
    _VERIFIED_EVIDENCE_AUTHORITY_METADATA,
    _VERIFIED_EPISTEMIC_ROLE_METADATA,
    _VERIFIED_SOURCE_INDEPENDENCE_METADATA,
    _VERIFIED_SUPPORT_RELATION_METADATA,
    _VERIFIED_SUPPORT_SET_INDEPENDENCE_METADATA,
    _VERIFIED_SUPPORT_SELECTION_METADATA,
    _VERIFIED_RELATION_RESOLUTION_METADATA,
    _VERIFIED_EXCLUDED_DISPOSITION_METADATA,
    _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA,
    _VERIFIED_GENERIC_EQUIVALENCE_METADATA,
    _VERIFIED_GENERIC_DISTINCTNESS_METADATA,
    _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA,
    _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA,
)

_DEVELOPER_RUNTIME_MAPS = (
    _DEVELOPER_FIXTURE_RUNTIME,
    _DEVELOPER_IDENTITY_RUNTIME,
    _DEVELOPER_PROVENANCE_RUNTIME,
    _DEVELOPER_SOURCE_SEMANTICS_RUNTIME,
    _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME,
    _DEVELOPER_EPISTEMIC_ROLE_RUNTIME,
)

_RUNTIME_MAP_BY_BOUNDARY = {
    "IDENTITY": _VERIFIED_IDENTITY_RUNTIME,
    "RETRIEVAL": _VERIFIED_RETRIEVAL_RUNTIME,
    "PROVENANCE": _VERIFIED_PROVENANCE_RUNTIME,
    "SOURCE_SEMANTICS": _VERIFIED_SOURCE_SEMANTICS_RUNTIME,
    "EVIDENCE_AUTHORITY": _VERIFIED_EVIDENCE_AUTHORITY_RUNTIME,
    "EPISTEMIC_ROLE": _VERIFIED_EPISTEMIC_ROLE_RUNTIME,
    "SOURCE_INDEPENDENCE": _VERIFIED_SOURCE_INDEPENDENCE_RUNTIME,
    "SUPPORT_RELATION": _VERIFIED_SUPPORT_RELATION_RUNTIME,
    "SUPPORT_SET_INDEPENDENCE": _VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME,
    "SUPPORT_SELECTION": _VERIFIED_SUPPORT_SELECTION_RUNTIME,
    "RELATION_RESOLUTION": _VERIFIED_RELATION_RESOLUTION_RUNTIME,
    "EXCLUDED_SUPPORT_DISPOSITION": _VERIFIED_EXCLUDED_DISPOSITION_RUNTIME,
    "FAILURE_DOMAIN_TOPOLOGY": _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME,
    "GENERIC_EQUIVALENCE": _VERIFIED_GENERIC_EQUIVALENCE_RUNTIME,
    "GENERIC_DISTINCTNESS": _VERIFIED_GENERIC_DISTINCTNESS_RUNTIME,
    "DECISION_SOURCE_DEPENDENCY_ACCOUNTING": _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME,
    "DECISION_GENERIC_DEPENDENCY_ACCOUNTING": _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME,
}

_RUNTIME_KEY_ATTR = {
    "IDENTITY": ("draft", "registry_entry_id"),
    "RETRIEVAL": ("draft", "scope_id"),
    "PROVENANCE": ("draft", "evidence_id"),
    "SOURCE_SEMANTICS": ("draft", "semantics_registry_entry_id"),
    "EVIDENCE_AUTHORITY": ("draft", "evidence_id"),
    "EPISTEMIC_ROLE": ("evidence", "evidence_id"),
    "SOURCE_INDEPENDENCE": ("draft", "independence_id"),
    "SUPPORT_RELATION": ("draft", "relation_id"),
    "SUPPORT_SET_INDEPENDENCE": ("draft", "independence_id"),
    "SUPPORT_SELECTION": ("draft", "selection_id"),
    "RELATION_RESOLUTION": ("draft", "resolution_id"),
    "EXCLUDED_SUPPORT_DISPOSITION": ("draft", "disposition_id"),
    "GENERIC_EQUIVALENCE": ("draft", "equivalence_id"),
    "GENERIC_DISTINCTNESS": ("draft", "distinctness_id"),
    "DECISION_SOURCE_DEPENDENCY_ACCOUNTING": ("draft", "accounting_id"),
    "DECISION_GENERIC_DEPENDENCY_ACCOUNTING": ("draft", "accounting_id"),
}


@dataclass(frozen=True)
class HostTrustRegistration:
    """One host-pinned verifier for one exact authority boundary and authority_id.

    The verifier object is intentionally compared by object identity.  The trusted host
    owns Controller construction; untrusted input producers are not expected to supply
    or replace this registration after construction.
    """

    boundary: str
    authority_id: str
    verifier: Any

    def __post_init__(self) -> None:
        if self.boundary not in _TRUST_BOUNDARIES:
            raise ValueError("unknown host trust boundary")
        if not isinstance(self.authority_id, str) or not self.authority_id.strip():
            raise ValueError("host trust authority_id must be nonblank")
        if self.verifier is None:
            raise ValueError("host trust verifier must not be None")


@dataclass(frozen=True)
class HostTrustPolicy:
    """Immutable production trust-root configuration owned by the host application."""

    registrations: tuple[HostTrustRegistration, ...] = ()

    def __post_init__(self) -> None:
        regs = tuple(self.registrations)
        object.__setattr__(self, "registrations", regs)
        seen: set[tuple[str, str]] = set()
        for reg in regs:
            if not isinstance(reg, HostTrustRegistration):
                raise TypeError("registrations must contain HostTrustRegistration values")
            key = (reg.boundary, reg.authority_id)
            if key in seen:
                raise ValueError("duplicate host trust registration")
            seen.add(key)

    def resolve(self, boundary: str, authority_id: str) -> HostTrustRegistration | None:
        for reg in self.registrations:
            if reg.boundary == boundary and reg.authority_id == authority_id:
                return reg
        return None


@dataclass(frozen=True)
class PersistenceCheckpoint:
    """Independent V6 history checkpoint; registry contents are host-persisted separately."""

    format_version: str
    history_commitment: str


@dataclass(frozen=True)
class PersistenceRehydrationStatus:
    active: bool
    expected_history_commitment: str | None
    current_history_commitment: str
    last_validated_history_commitment: str | None
    authorized_decision_row_ids: tuple[str, ...]
    authorized_predecessor_artifact_ids: tuple[str, ...]
    authorized_evidence_role_artifact_ids: tuple[str, ...]



class _DynamicTestingHostTrustPolicy:
    """Explicit test-only policy used by cfc_anchor.testing; never a production trust root."""

    __slots__ = ()

    def allows(self, boundary: str, authority_id: str, verifier: Any) -> bool:
        return boundary in _TRUST_BOUNDARIES and isinstance(authority_id, str) and bool(authority_id.strip()) and verifier is not None


def _runtime_key_for_call(boundary: str, bound_arguments: Mapping[str, Any]) -> str:
    if boundary == "FAILURE_DOMAIN_TOPOLOGY":
        return "GLOBAL"
    arg_name, attr_name = _RUNTIME_KEY_ATTR[boundary]
    obj = bound_arguments.get(arg_name)
    key = getattr(obj, attr_name, None)
    if not isinstance(key, str) or not key:
        raise RuntimeError(f"cannot derive runtime trust key for {boundary}")
    return key


def _requires_host_trust(boundary: str):
    if boundary not in _TRUST_BOUNDARIES:
        raise ValueError("unknown host trust boundary decorator")

    def decorate(fn):
        sig = inspect.signature(fn)

        @functools.wraps(fn)
        def guarded(self, *args, **kwargs):
            bound = sig.bind(self, *args, **kwargs)
            bound.apply_defaults()
            attestation = bound.arguments.get("attestation")
            verifier = bound.arguments.get("verifier")
            authority_id = getattr(attestation, "authority_id", None)
            # Preserve the original method's attestation-shape errors.  For a structurally
            # plausible attestation, host trust must be established before verifier code runs.
            if isinstance(authority_id, str) and authority_id.strip():
                self._require_registered_verifier(boundary, authority_id, verifier)
            key = _runtime_key_for_call(boundary, bound.arguments)
            owner_slot = (boundary, key)
            previous_owners = set(_VERIFIED_RUNTIME_OWNER.get(owner_slot, set()))
            # Reserve this context only after host-root admission.  Some verification
            # methods create a runtime-only pin and call inspect() before returning; the
            # temporary membership lets nested inspection see its own new pin.  Failure
            # restores the exact previous owner set.
            _VERIFIED_RUNTIME_OWNER.setdefault(owner_slot, set()).add(self._runtime_trust_context)
            try:
                result = fn(self, *args, **kwargs)
            except Exception:
                if previous_owners:
                    _VERIFIED_RUNTIME_OWNER[owner_slot] = previous_owners
                else:
                    _VERIFIED_RUNTIME_OWNER.pop(owner_slot, None)
                raise
            # Multiple Controllers may independently reverify the same persisted row; each
            # keeps its own membership.  A context that never verified it remains excluded.
            runtime_map = _RUNTIME_MAP_BY_BOUNDARY[boundary]
            if key not in runtime_map:
                if previous_owners:
                    _VERIFIED_RUNTIME_OWNER[owner_slot] = previous_owners
                else:
                    _VERIFIED_RUNTIME_OWNER.pop(owner_slot, None)
            return result

        return guarded

    return decorate


@dataclass(frozen=True)
class GenericEquivalenceDraft:
    """Non-authorizing class-level generic representation equivalence declaration."""

    equivalence_id: str
    left_node_type: str
    left_dimension: str
    right_node_type: str
    right_dimension: str
    semantic_node_type: str
    semantic_dimension: str
    identifier_semantics: str
    scope_id: str
    valid_from: str
    valid_to: str


@dataclass(frozen=True)
class GenericEquivalenceAuthorityAttestation:
    attestation_id: str
    authority_id: str
    equivalence_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _GENERIC_EQUIVALENCE_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class GenericEquivalenceAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    equivalence_id: str
    verification_method: str
    reason: str = ""


class GenericEquivalenceAuthorityVerifier(Protocol):
    def verify(self, attestation: GenericEquivalenceAuthorityAttestation, *, draft: GenericEquivalenceDraft) -> GenericEquivalenceAuthorityVerdict: ...


@dataclass(frozen=True)
class GenericEquivalenceInstallation:
    equivalence_id: str
    certificate_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    equivalence_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class GenericEquivalenceInspection:
    equivalence_id: str
    state: str
    installed: bool
    certificate_valid: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class GenericDistinctnessDraft:
    """Non-authorizing exact-context PROVEN_DISTINCT candidate declaration."""

    distinctness_id: str
    left_node_type: str
    left_dimension: str
    left_identifier: str
    right_node_type: str
    right_dimension: str
    right_identifier: str
    retrieval_scope_id: str
    as_of_date: str


@dataclass(frozen=True)
class GenericDistinctnessAuthorityAttestation:
    attestation_id: str
    authority_id: str
    distinctness_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _GENERIC_DISTINCTNESS_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class GenericDistinctnessAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    distinctness_id: str
    verification_method: str
    reason: str = ""


class GenericDistinctnessAuthorityVerifier(Protocol):
    def verify(self, attestation: GenericDistinctnessAuthorityAttestation, *, draft: GenericDistinctnessDraft) -> GenericDistinctnessAuthorityVerdict: ...


@dataclass(frozen=True)
class GenericDistinctnessInstallation:
    distinctness_id: str
    certificate_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    distinctness_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class GenericDistinctnessInspection:
    distinctness_id: str
    state: str
    installed: bool
    certificate_valid: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class FailureDomainTopologyDraft:
    """Complete, non-authorizing failure-domain alias/ancestor topology snapshot."""

    aliases: tuple[tuple[str, str], ...] = ()
    parents: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class FailureDomainTopologyAttestation:
    attestation_id: str
    authority_id: str
    topology_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _FAILURE_DOMAIN_TOPOLOGY_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class FailureDomainTopologyVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    topology_commitment: str
    verification_method: str
    reason: str = ""


class FailureDomainTopologyVerifier(Protocol):
    def verify(
        self, attestation: FailureDomainTopologyAttestation, *, draft: FailureDomainTopologyDraft
    ) -> FailureDomainTopologyVerdict: ...


@dataclass(frozen=True)
class FailureDomainTopologyInstallation:
    topology_commitment: str
    topology_registry_hash: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    idempotent: bool
    runtime_verified: bool = True


@dataclass(frozen=True)
class FailureDomainTopologyInspection:
    topology_commitment: str
    topology_registry_hash: str
    exact_match: bool
    runtime_verified: bool
    attestation_id: str | None = None
    authority_id: str | None = None
    verifier_id: str | None = None


@dataclass(frozen=True)
class SourceIndependenceDraft:
    """Non-authorizing request to justify one exact pair as source-independent."""

    independence_id: str
    evidence_ids: tuple[str, str]
    reason: str


@dataclass(frozen=True)
class SourceIndependenceAuthorityAttestation:
    attestation_id: str
    authority_id: str
    independence_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _SOURCE_INDEPENDENCE_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class SourceIndependenceAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    independence_id: str
    verification_method: str
    reason: str = ""


class SourceIndependenceAuthorityVerifier(Protocol):
    def verify(
        self, attestation: SourceIndependenceAuthorityAttestation, *,
        draft: SourceIndependenceDraft, evidence: tuple["EvidenceRecordDraft", ...]
    ) -> SourceIndependenceAuthorityVerdict: ...


@dataclass(frozen=True)
class SourceIndependenceInstallation:
    independence_id: str
    certificate_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    independence_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class SourceIndependenceInspection:
    independence_id: str
    state: str
    installed: bool
    certificate_valid: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class SupportRelationDraft:
    """Non-authorizing COMMON_MODE or UNKNOWN relation declaration."""

    relation_id: str
    relation_type: str
    relation_effect: str
    claim_id: str
    retrieval_scope_id: str
    evidence_ids: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class SupportRelationAuthorityAttestation:
    attestation_id: str
    authority_id: str
    relation_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _SUPPORT_RELATION_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class SupportRelationAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    relation_id: str
    verification_method: str
    reason: str = ""


class SupportRelationAuthorityVerifier(Protocol):
    def verify(
        self, attestation: SupportRelationAuthorityAttestation, *,
        draft: SupportRelationDraft, evidence: tuple["EvidenceRecordDraft", ...]
    ) -> SupportRelationAuthorityVerdict: ...


@dataclass(frozen=True)
class SupportRelationInstallation:
    relation_id: str
    relation_type: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    relation_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class SupportRelationInspection:
    relation_id: str
    relation_type: str | None
    state: str
    installed: bool
    certificate_valid: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class SupportSetIndependenceDraft:
    """Non-authorizing request to certify an exact support set as independent."""

    independence_id: str
    claim_id: str
    retrieval_scope_id: str
    evidence_ids: tuple[str, ...]
    reason: str
    as_of_date: str


@dataclass(frozen=True)
class SupportSetIndependenceAuthorityAttestation:
    attestation_id: str
    authority_id: str
    independence_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _SUPPORT_SET_INDEPENDENCE_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class SupportSetIndependenceAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    independence_id: str
    verification_method: str
    reason: str = ""


class SupportSetIndependenceAuthorityVerifier(Protocol):
    def verify(
        self, attestation: SupportSetIndependenceAuthorityAttestation, *,
        draft: SupportSetIndependenceDraft, evidence: tuple["EvidenceRecordDraft", ...]
    ) -> SupportSetIndependenceAuthorityVerdict: ...


@dataclass(frozen=True)
class SupportSetIndependenceInstallation:
    independence_id: str
    certificate_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    independence_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class SupportSelectionDraft:
    selection_id: str
    claim_id: str
    retrieval_scope_id: str
    matching_evidence_ids: tuple[str, ...]
    selected_support_ids: tuple[str, ...]
    required_supports: int
    exclusion_classifications: tuple[tuple[str, str], ...]
    exclusion_reasons: tuple[tuple[str, str], ...]
    justification_reason: str
    decision_context_commitment: str


@dataclass(frozen=True)
class SupportSelectionAuthorityAttestation:
    attestation_id: str
    authority_id: str
    selection_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _SUPPORT_SELECTION_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class SupportSelectionAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    selection_id: str
    verification_method: str
    reason: str = ""


class SupportSelectionAuthorityVerifier(Protocol):
    def verify(self, attestation: SupportSelectionAuthorityAttestation, *, draft: SupportSelectionDraft, evidence: tuple["EvidenceRecordDraft", ...]) -> SupportSelectionAuthorityVerdict: ...


@dataclass(frozen=True)
class SupportSelectionInstallation:
    selection_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    selection_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class RelationResolutionDraft:
    resolution_id: str
    relation_id: str
    claim_id: str
    retrieval_scope_id: str
    selected_support_ids: tuple[str, ...]
    resolution_type: str
    justification_reason: str
    decision_context_commitment: str


@dataclass(frozen=True)
class RelationResolutionAuthorityAttestation:
    attestation_id: str
    authority_id: str
    resolution_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _RELATION_RESOLUTION_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class RelationResolutionAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    resolution_id: str
    verification_method: str
    reason: str = ""


class RelationResolutionAuthorityVerifier(Protocol):
    def verify(self, attestation: RelationResolutionAuthorityAttestation, *, draft: RelationResolutionDraft, evidence: tuple["EvidenceRecordDraft", ...]) -> RelationResolutionAuthorityVerdict: ...


@dataclass(frozen=True)
class RelationResolutionInstallation:
    resolution_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    resolution_commitment: str
    runtime_verified: bool
    bound: bool
    idempotent: bool


@dataclass(frozen=True)
class ExcludedSupportDispositionDraft:
    disposition_id: str
    claim_id: str
    retrieval_scope_id: str
    excluded_evidence_id: str
    selected_evidence_ids: tuple[str, ...]
    supporting_relation_ids: tuple[str, ...]
    justification_reason: str
    decision_context_commitment: str


@dataclass(frozen=True)
class ExcludedSupportDispositionAuthorityAttestation:
    attestation_id: str
    authority_id: str
    disposition_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _EXCLUDED_DISPOSITION_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class ExcludedSupportDispositionAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    disposition_id: str
    verification_method: str
    reason: str = ""


class ExcludedSupportDispositionAuthorityVerifier(Protocol):
    def verify(self, attestation: ExcludedSupportDispositionAuthorityAttestation, *, draft: ExcludedSupportDispositionDraft, evidence: tuple["EvidenceRecordDraft", ...]) -> ExcludedSupportDispositionAuthorityVerdict: ...


@dataclass(frozen=True)
class ExcludedSupportDispositionInstallation:
    disposition_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    disposition_commitment: str
    runtime_verified: bool
    idempotent: bool


@dataclass(frozen=True)
class DecisionSourceDependencyAccountingDraft:
    accounting_id: str
    retrieval_scope_id: str
    claim_ids: tuple[str, ...]
    selected_support_map: tuple[tuple[str, tuple[str, ...]], ...]
    evidence_ids: tuple[str, str]
    resolution_type: str
    reason: str
    decision_context_commitment: str

@dataclass(frozen=True)
class DecisionSourceDependencyAccountingAttestation:
    attestation_id: str
    authority_id: str
    accounting_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _DECISION_SOURCE_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA

@dataclass(frozen=True)
class DecisionSourceDependencyAccountingVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    accounting_id: str
    verification_method: str
    reason: str = ""

class DecisionSourceDependencyAccountingVerifier(Protocol):
    def verify(self, attestation: DecisionSourceDependencyAccountingAttestation, *, draft: DecisionSourceDependencyAccountingDraft, evidence: tuple["EvidenceRecordDraft", ...]) -> DecisionSourceDependencyAccountingVerdict: ...

@dataclass(frozen=True)
class DecisionSourceDependencyAccountingInstallation:
    accounting_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    accounting_commitment: str
    runtime_verified: bool
    bound: bool
    idempotent: bool

@dataclass(frozen=True)
class DecisionGenericDependencyAccountingDraft:
    accounting_id: str
    retrieval_scope_id: str
    claim_ids: tuple[str, ...]
    selected_support_map: tuple[tuple[str, tuple[str, ...]], ...]
    generic_dependency_node: tuple[str, str, str]
    evidence_ids: tuple[str, ...]
    resolution_type: str
    reason: str
    decision_context_commitment: str

@dataclass(frozen=True)
class DecisionGenericDependencyAccountingAttestation:
    attestation_id: str
    authority_id: str
    accounting_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _DECISION_GENERIC_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA

@dataclass(frozen=True)
class DecisionGenericDependencyAccountingVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    accounting_id: str
    verification_method: str
    reason: str = ""

class DecisionGenericDependencyAccountingVerifier(Protocol):
    def verify(self, attestation: DecisionGenericDependencyAccountingAttestation, *, draft: DecisionGenericDependencyAccountingDraft, evidence: tuple["EvidenceRecordDraft", ...]) -> DecisionGenericDependencyAccountingVerdict: ...

@dataclass(frozen=True)
class DecisionGenericDependencyAccountingInstallation:
    accounting_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    accounting_commitment: str
    runtime_verified: bool
    bound: bool
    idempotent: bool

@dataclass(frozen=True)
class EvaluationResult:
    """Thin typed view over the engine's existing audit result."""

    stop_type: str
    control_closure: bool
    claims: tuple[Mapping[str, Any], ...]
    gates: Mapping[str, Any]
    raw: Mapping[str, Any]

    @property
    def status(self) -> str:
        """Compatibility convenience: exactly the engine's serialized stop_type."""
        return self.stop_type




@dataclass(frozen=True)
class EvidenceDependencyDraft:
    """One non-authorizing dependency declaration inside evidence provenance."""

    dimension: str
    state: str
    identifier: str | None = None
    justification_id: str | None = None


@dataclass(frozen=True)
class EvidenceProvenanceDraft:
    """Data-only provenance description. It does not register source semantics."""

    source_id: str
    root_origin_id: str
    origin_id: str
    referent_entity_id: str
    referent_event_id: str
    referent_version_id: str
    extractor_id: str
    common_mode_group: str
    lineage: tuple[str, ...]
    dependencies: tuple[EvidenceDependencyDraft, ...]


@dataclass(frozen=True)
class EvidenceRecordDraft:
    """Canonical data-only CFC evidence input record.

    References to identity, authority, source semantics, or epistemic role are names
    only. Constructing this object does not create or authorize any referenced state.
    """

    evidence_id: str
    subject: str
    predicate: str
    value: str
    source: str
    polarity: str
    identity_registry_entry_id: str
    authority_id: str
    authority_record_entity_id: str
    authority_record_event_id: str
    authority_record_version_id: str
    valid_from: str
    valid_to: str
    observed_at: str
    available_at: str
    provenance: EvidenceProvenanceDraft
    source_semantics_id: str | None = None
    epistemic_role_record_id: str | None = None


@dataclass(frozen=True)
class EvidenceRecordInspection:
    evidence_id: str
    state: str
    structurally_valid: bool
    identity_reference_state: str
    authority_reference_state: str
    source_semantics_reference_state: str
    epistemic_role_reference_state: str
    record_hash: str | None
    errors: tuple[str, ...]


@dataclass(frozen=True)
class ProvenanceAuthorityAttestation:
    """External statement approving the exact provenance projection of one evidence record."""

    attestation_id: str
    authority_id: str
    evidence_id: str
    provenance_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _PROVENANCE_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class ProvenanceAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    evidence_id: str
    verification_method: str
    reason: str = ""


class ProvenanceAuthorityVerifier(Protocol):
    def verify(
        self,
        attestation: ProvenanceAuthorityAttestation,
        *,
        draft: EvidenceRecordDraft,
    ) -> ProvenanceAuthorityVerdict: ...


@dataclass(frozen=True)
class ProvenanceAuthorityInspection:
    evidence_id: str
    state: str
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None
    provenance_commitment: str


@dataclass(frozen=True)
class SourceSemanticsDraft:
    """Non-authorizing description of one source-semantics registry entry."""

    semantics_registry_entry_id: str
    source_id: str
    repository_id: str
    producer_id: str
    process_id: str
    failure_domain_id: str
    resolution_state: str
    source_common_mode_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class SourceSemanticsAuthorityAttestation:
    attestation_id: str
    authority_id: str
    source_semantics_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _SOURCE_SEMANTICS_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class SourceSemanticsAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    verification_method: str
    reason: str = ""


class SourceSemanticsAuthorityVerifier(Protocol):
    def verify(
        self,
        attestation: SourceSemanticsAuthorityAttestation,
        *,
        draft: SourceSemanticsDraft,
    ) -> SourceSemanticsAuthorityVerdict: ...


@dataclass(frozen=True)
class SourceSemanticsAuthorityInspection:
    semantics_registry_entry_id: str
    state: str
    installed: bool
    exact_semantics_match: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class SourceSemanticsInstallation:
    semantics_registry_entry_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    source_semantics_commitment: str
    registry_hash: str
    resolution_certificate_id: str
    idempotent: bool


@dataclass(frozen=True)
class EvidenceAuthorityAttestation:
    """External approval of the exact evidence-authority projection for one record."""

    attestation_id: str
    authority_id: str
    evidence_id: str
    evidence_authority_policy_id: str
    evidence_authority_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _EVIDENCE_AUTHORITY_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class EvidenceAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    evidence_id: str
    verification_method: str
    reason: str = ""


class EvidenceAuthorityVerifier(Protocol):
    def verify(
        self,
        attestation: EvidenceAuthorityAttestation,
        *,
        draft: EvidenceRecordDraft,
    ) -> EvidenceAuthorityVerdict: ...


@dataclass(frozen=True)
class EvidenceAuthorityInspection:
    evidence_id: str
    state: str
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None
    evidence_authority_policy_id: str
    evidence_authority_commitment: str


@dataclass(frozen=True)
class EpistemicRoleDraft:
    """Non-authorizing request to classify one exact evidence assertion."""

    evidence_id: str
    epistemic_role: str
    issuer_grant_id: str
    issuer_authority_id: str
    evidence_record_commitment: str
    role_commitment: str


@dataclass(frozen=True)
class EpistemicRoleAuthorityAttestation:
    attestation_id: str
    authority_id: str
    evidence_id: str
    epistemic_role: str
    role_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _EPISTEMIC_ROLE_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class EpistemicRoleAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    evidence_id: str
    epistemic_role: str
    verification_method: str
    reason: str = ""


class EpistemicRoleAuthorityVerifier(Protocol):
    def verify(
        self,
        attestation: EpistemicRoleAuthorityAttestation,
        *,
        draft: EpistemicRoleDraft,
        evidence: EvidenceRecordDraft,
    ) -> EpistemicRoleAuthorityVerdict: ...


@dataclass(frozen=True)
class EpistemicRoleInstallation:
    evidence_id: str
    epistemic_role: str
    role_record_id: str
    authorization_artifact_id: str
    certificate_id: str
    external_authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    role_commitment: str
    idempotent: bool


@dataclass(frozen=True)
class EpistemicRoleAuthorityInspection:
    evidence_id: str
    role_record_id: str | None
    epistemic_role: str | None
    state: str
    installed: bool
    engine_runtime_authorized: bool
    external_runtime_verified: bool
    external_authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class SnapshotDraft:
    """Deterministic, non-authorizing description of a retrieval snapshot.

    This object is data only.  Constructing it does not register the snapshot and
    does not confer any authority on its evidence.
    """

    scope_id: str
    snapshot_id: str
    expected_evidence_ids: tuple[str, ...]
    expected_record_hashes: tuple[tuple[str, str], ...]
    semantic_scope: str
    entity_ids: tuple[str, ...]
    event_ids: tuple[str, ...]
    version_ids: tuple[str, ...]
    predicates: tuple[str, ...]
    retrieval_universe_id: str
    applicability_group_id: str
    snapshot_created_at: str
    snapshot_available_at: str
    valid_from: str
    valid_to: str
    snapshot_version: int
    supersedes: str | None
    retracted_evidence_ids: tuple[str, ...]




@dataclass(frozen=True)
class IdentityDraft:
    """Deterministic, non-authorizing description of one identity registry row."""

    registry_entry_id: str
    surface_subject: str
    domain_id: str
    entity_id: str
    event_id: str
    version_id: str


@dataclass(frozen=True)
class IdentityAuthorityAttestation:
    """External authority statement bound to one exact IdentityDraft commitment."""

    attestation_id: str
    authority_id: str
    identity_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    schema: str = _IDENTITY_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class IdentityAuthorityVerdict:
    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    verification_method: str
    reason: str = ""


class IdentityAuthorityVerifier(Protocol):
    """Host integration boundary for external identity trust roots."""

    def verify(
        self,
        attestation: IdentityAuthorityAttestation,
        *,
        draft: IdentityDraft,
    ) -> IdentityAuthorityVerdict: ...


@dataclass(frozen=True)
class IdentityAuthorityInspection:
    registry_entry_id: str
    state: str
    installed: bool
    exact_identity_match: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class IdentityInstallation:
    registry_entry_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    identity_commitment: str
    registry_hash: str
    idempotent: bool


@dataclass(frozen=True)
class RetrievalAuthorityAttestation:
    """External authority statement bound to one exact SnapshotDraft commitment."""

    attestation_id: str
    authority_id: str
    snapshot_commitment: str
    issued_at: str
    valid_from: str
    valid_to: str
    supersession_authority_id: str | None = None
    schema: str = _RETRIEVAL_ATTESTATION_SCHEMA


@dataclass(frozen=True)
class RetrievalAuthorityVerdict:
    """Verdict returned by a host-supplied verifier.  CFC ships no permissive verifier."""

    approved: bool
    verifier_id: str
    attestation_id: str
    authority_id: str
    verification_method: str
    reason: str = ""


class RetrievalAuthorityVerifier(Protocol):
    """Host integration boundary for signatures, allow-lists, HSMs, IAM, etc."""

    def verify(
        self,
        attestation: RetrievalAuthorityAttestation,
        *,
        draft: SnapshotDraft,
        evidence: Sequence[Mapping[str, Any]],
    ) -> RetrievalAuthorityVerdict: ...


@dataclass(frozen=True)
class RetrievalAuthorityInspection:
    scope_id: str
    snapshot_id: str
    state: str
    installed: bool
    exact_snapshot_match: bool
    runtime_verified: bool
    authority_id: str | None
    attestation_id: str | None
    verifier_id: str | None


@dataclass(frozen=True)
class RetrievalInstallation:
    scope_id: str
    snapshot_id: str
    authority_id: str
    attestation_id: str
    verifier_id: str
    verification_method: str
    snapshot_commitment: str
    registry_hash: str
    idempotent: bool


@dataclass(frozen=True)
class SnapshotInspection:
    """Integration state only; not an epistemic/terminal CFC status."""

    scope_id: str
    snapshot_id: str
    state: str  # DRAFT_ONLY | INSTALLED_MATCH | INSTALLED_MISMATCH
    installed: bool
    exact_match: bool


class Controller:
    """Minimal developer-preview façade over controller_v0_2_90_RECOVERY.

    The engine remains stateful and process-global.  The wrapper serializes calls
    but does not pretend to provide isolated controller instances yet.
    """

    def __init__(self, *, scope: str | None = None, extraction: str | None = None, trust_policy: HostTrustPolicy | None = None):
        self.scope = scope or _engine.CANONICAL_SCOPE
        self.extraction = extraction or _engine.CANONICAL_EXTRACTION
        if trust_policy is not None and not isinstance(trust_policy, (HostTrustPolicy, _DynamicTestingHostTrustPolicy)):
            raise TypeError("trust_policy must be HostTrustPolicy or None")
        self._trust_policy = trust_policy
        # Opaque per-Controller runtime trust context.  It is deliberately not derived
        # from public data and is never serialized.  Rehydrated authority must be
        # explicitly reverified by the Controller that intends to use it.
        self._runtime_trust_context = object()

    @contextmanager
    def _runtime_trust_scope(self):
        """Expose only runtime pins owned by this Controller during one public call.

        R265 additionally hides every DeveloperFixtureSession runtime map from ordinary
        production Controllers. The explicit cfc_anchor.testing Controller may see those
        maps; production and testing authority therefore cannot bleed across Controller
        facades even though the frozen engine remains process-global.
        """
        with _ENGINE_LOCK:
            backups = {boundary: dict(runtime_map) for boundary, runtime_map in _RUNTIME_MAP_BY_BOUNDARY.items()}
            developer_backups = [dict(runtime_map) for runtime_map in _DEVELOPER_RUNTIME_MAPS]
            testing_context = isinstance(self._trust_policy, _DynamicTestingHostTrustPolicy)
            try:
                for boundary, runtime_map in _RUNTIME_MAP_BY_BOUNDARY.items():
                    runtime_map.clear()
                    for key, value in backups[boundary].items():
                        if self._runtime_trust_context in _VERIFIED_RUNTIME_OWNER.get((boundary, key), set()):
                            runtime_map[key] = value
                if not testing_context:
                    for runtime_map in _DEVELOPER_RUNTIME_MAPS:
                        runtime_map.clear()
                yield
            finally:
                # Preserve modifications made by this call while restoring pins hidden
                # from this trust context. Ownership is assigned by host-trust methods.
                visible_after = {boundary: dict(runtime_map) for boundary, runtime_map in _RUNTIME_MAP_BY_BOUNDARY.items()}
                for boundary, runtime_map in _RUNTIME_MAP_BY_BOUNDARY.items():
                    runtime_map.clear()
                    runtime_map.update(backups[boundary])
                    runtime_map.update(visible_after[boundary])
                # Developer maps are writable only by the explicit testing surface. For a
                # production Controller any hidden-map mutations are discarded; for a
                # testing Controller the call's changes are retained.
                for runtime_map, before in zip(_DEVELOPER_RUNTIME_MAPS, developer_backups):
                    after = dict(runtime_map)
                    runtime_map.clear()
                    runtime_map.update(before)
                    if testing_context:
                        runtime_map.update(after)

    def _require_registered_verifier(self, boundary: str, authority_id: str, verifier: Any) -> None:
        policy = self._trust_policy
        if isinstance(policy, _DynamicTestingHostTrustPolicy):
            if not policy.allows(boundary, authority_id, verifier):
                raise ValueError("test trust policy rejected verifier")
            return
        if not isinstance(policy, HostTrustPolicy):
            raise ValueError("no host trust root registered for this Controller")
        reg = policy.resolve(boundary, authority_id)
        if reg is None:
            raise ValueError("authority_id is not registered for this host trust boundary")
        if verifier is not reg.verifier:
            raise ValueError("verifier is not the host-pinned verifier for this authority boundary")

    @property
    def persistence_schema(self) -> str:
        return _engine.PERSISTENCE_HISTORY_COMMITMENT_VERSION

    @property
    def mandatory_gate_count(self) -> int:
        return len(_engine.MANDATORY_GATES)

    @property
    def controller_sha256(self) -> str:
        path = Path(_engine.__file__)
        return hashlib.sha256(path.read_bytes()).hexdigest()


    @staticmethod
    def _rehydration_status_from_engine() -> PersistenceRehydrationStatus:
        status = _engine.decision_rehydration_status()
        return PersistenceRehydrationStatus(
            active=bool(status.get("active", False)),
            expected_history_commitment=status.get("expected_history_commitment"),
            current_history_commitment=str(status.get("current_history_commitment", "")),
            last_validated_history_commitment=status.get("last_validated_history_commitment"),
            authorized_decision_row_ids=tuple(status.get("authorized_decision_row_ids", ())),
            authorized_predecessor_artifact_ids=tuple(status.get("authorized_predecessor_artifact_ids", ())),
            authorized_evidence_role_artifact_ids=tuple(status.get("authorized_evidence_role_artifact_ids", ())),
        )

    def export_persistence_checkpoint(self) -> PersistenceCheckpoint:
        """Export the independent V6 history commitment for trusted host persistence.

        This does not serialize registry contents. The trusted host must persist and replay
        those contents separately; the checkpoint exists to detect rollback/truncation.
        Export is forbidden during active rehydration or developer-fixture activity so an
        incomplete/test state cannot be promoted to a new trusted checkpoint.
        """
        with _ENGINE_LOCK:
            if _engine.decision_rehydration_status().get("active") is True:
                raise ValueError("cannot export a persistence checkpoint during active rehydration")
            if any(bool(runtime_map) for runtime_map in _DEVELOPER_RUNTIME_MAPS):
                raise ValueError("cannot export a production checkpoint while developer fixture runtime is active")
            state = _engine.export_decision_persistence_state()
            return PersistenceCheckpoint(
                format_version=str(state["format_version"]),
                history_commitment=str(state["history_commitment"]),
            )

    def rehydration_status(self) -> PersistenceRehydrationStatus:
        with _ENGINE_LOCK:
            return self._rehydration_status_from_engine()

    def begin_rehydration(self, checkpoint: PersistenceCheckpoint) -> PersistenceRehydrationStatus:
        """Pin one independently persisted V6 checkpoint before trusted registry replay.

        Beginning rehydration globally invalidates all wrapper runtime trust memberships.
        External authorities must be explicitly reverified after replay/completion.
        """
        global _WRAPPER_REHYDRATION_OWNER
        if not isinstance(checkpoint, PersistenceCheckpoint):
            raise TypeError("checkpoint must be PersistenceCheckpoint")
        if checkpoint.format_version != _engine.PERSISTENCE_HISTORY_COMMITMENT_VERSION:
            raise ValueError("persistence checkpoint version mismatch")
        if not _engine._valid_history_commitment_value(checkpoint.history_commitment):
            raise ValueError("persistence checkpoint history_commitment must be SHA-256 hex")
        with _ENGINE_LOCK:
            if isinstance(self._trust_policy, _DynamicTestingHostTrustPolicy):
                raise ValueError("production rehydration is not available through cfc_anchor.testing")
            if any(bool(runtime_map) for runtime_map in _DEVELOPER_RUNTIME_MAPS):
                raise ValueError("cannot begin production rehydration while developer fixture runtime is active")
            ok = _engine.begin_decision_rehydration({
                "format_version": checkpoint.format_version,
                "history_commitment": checkpoint.history_commitment,
            })
            if not ok:
                raise ValueError("engine rejected persistence rehydration begin")
            _WRAPPER_REHYDRATION_OWNER = self._runtime_trust_context
            # A real restart has no live wrapper trust. In an in-process replay simulation,
            # remove every Controller membership and process-local verifier metadata so the
            # same rule is enforced. Raw pin values may remain internally but are ownerless
            # and therefore invisible through all public Controller calls.
            _VERIFIED_RUNTIME_OWNER.clear()
            for metadata in _VERIFIED_METADATA_MAPS:
                metadata.clear()
            return self._rehydration_status_from_engine()

    def complete_rehydration(self) -> PersistenceRehydrationStatus:
        """Complete only when trusted replay exactly matches the pinned V6 checkpoint."""
        global _WRAPPER_REHYDRATION_OWNER
        with _ENGINE_LOCK:
            if isinstance(self._trust_policy, _DynamicTestingHostTrustPolicy):
                raise ValueError("production rehydration completion is not available through cfc_anchor.testing")
            if _WRAPPER_REHYDRATION_OWNER is not self._runtime_trust_context:
                raise ValueError("this Controller does not own the active rehydration session")
            if not _engine.complete_decision_rehydration():
                raise ValueError("rehydration replay does not exactly match the pinned checkpoint")
            _WRAPPER_REHYDRATION_OWNER = None
            return self._rehydration_status_from_engine()

    def draft_identity(
        self,
        *,
        registry_entry_id: str,
        surface_subject: str,
        domain_id: str,
        entity_id: str,
        event_id: str,
        version_id: str,
    ) -> IdentityDraft:
        """Describe an identity without mutating IDENTITY_REGISTRY."""
        values = {
            "registry_entry_id": registry_entry_id,
            "surface_subject": surface_subject,
            "domain_id": domain_id,
            "entity_id": entity_id,
            "event_id": event_id,
            "version_id": version_id,
        }
        for name, value in values.items():
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be nonblank")
        return IdentityDraft(**values)

    def identity_commitment(self, draft: IdentityDraft) -> str:
        if not isinstance(draft, IdentityDraft):
            raise TypeError("draft must be IdentityDraft")
        return _engine.canonical_hash({
            "schema": "CFC_IDENTITY_DRAFT_V1",
            "registry_entry_id": draft.registry_entry_id,
            "surface_subject": draft.surface_subject,
            "domain_id": draft.domain_id,
            "entity_id": draft.entity_id,
            "event_id": draft.event_id,
            "version_id": draft.version_id,
        })

    def _canonical_identity_draft(self, draft: IdentityDraft) -> IdentityDraft:
        if not isinstance(draft, IdentityDraft):
            raise TypeError("draft must be IdentityDraft")
        rebuilt = self.draft_identity(
            registry_entry_id=draft.registry_entry_id,
            surface_subject=draft.surface_subject,
            domain_id=draft.domain_id,
            entity_id=draft.entity_id,
            event_id=draft.event_id,
            version_id=draft.version_id,
        )
        if rebuilt != draft:
            raise ValueError("IdentityDraft is not canonical")
        return rebuilt

    def _validate_identity_attestation(
        self, draft: IdentityDraft, attestation: IdentityAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation, IdentityAuthorityAttestation):
            raise TypeError("attestation must be IdentityAuthorityAttestation")
        if attestation.schema != _IDENTITY_ATTESTATION_SCHEMA:
            raise ValueError("unsupported identity authority attestation schema")
        if attestation.authority_id == _RESERVED_LOCAL_IDENTITY_AUTHORITY:
            raise ValueError("LOCAL_IDENTITY_FIXTURE_AUTHORITY is reserved for DeveloperFixtureSession")
        for name in ("attestation_id", "authority_id", "identity_commitment", "issued_at", "valid_from", "valid_to"):
            value = getattr(attestation, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"identity attestation {name} must be nonblank")
        if not _engine._valid_hash64(attestation.identity_commitment):
            raise ValueError("identity_commitment must be a SHA-256 hex digest")
        if attestation.identity_commitment != self.identity_commitment(draft):
            raise ValueError("attestation does not bind this IdentityDraft")
        try:
            issued = _engine.strict_date(attestation.issued_at)
            vf = _engine.strict_date(attestation.valid_from)
            vt = _engine.strict_date(attestation.valid_to)
            when = _engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid identity authority attestation dates") from exc
        if vf > vt or issued > when or not (vf <= when <= vt):
            raise ValueError("identity authority attestation is not applicable at as_of")

    def _verified_identity_row(
        self, draft: IdentityDraft, attestation: IdentityAuthorityAttestation, verdict: IdentityAuthorityVerdict
    ) -> dict[str, Any]:
        attestation_commitment = _engine.canonical_hash({
            "schema": attestation.schema,
            "attestation_id": attestation.attestation_id,
            "authority_id": attestation.authority_id,
            "identity_commitment": attestation.identity_commitment,
            "issued_at": attestation.issued_at,
            "valid_from": attestation.valid_from,
            "valid_to": attestation.valid_to,
        })
        return {
            "surface_subject": draft.surface_subject,
            "domain_id": draft.domain_id,
            "entity_id": draft.entity_id,
            "event_id": draft.event_id,
            "version_id": draft.version_id,
            "identity_authority_id": attestation.authority_id,
            "identity_authority_identity_commitment": attestation.identity_commitment,
            "identity_authority_attestation_schema": attestation.schema,
            "identity_authority_attestation_id": attestation.attestation_id,
            "identity_authority_attestation_commitment": attestation_commitment,
            "identity_authority_verifier_id": verdict.verifier_id,
            "identity_authority_verification_method": verdict.verification_method,
        }

    @_requires_host_trust("IDENTITY")
    def install_verified_identity(
        self,
        draft: IdentityDraft,
        attestation: IdentityAuthorityAttestation,
        verifier: IdentityAuthorityVerifier,
        *,
        as_of: str,
    ) -> IdentityInstallation:
        """Install one identity only after a host verifier approves exact binding."""
        self._canonical_identity_draft(draft)
        self._validate_identity_attestation(draft, attestation, as_of=as_of)
        if draft.registry_entry_id in _BUILTIN_IDENTITY_FIXTURES:
            raise ValueError("built-in identity fixture IDs are reserved and cannot be externally installed")
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft)")
        try:
            verdict = verify(attestation, draft=draft)
        except Exception as exc:
            raise ValueError("identity authority verifier failed closed") from exc
        if not isinstance(verdict, IdentityAuthorityVerdict) or verdict.approved is not True:
            raise ValueError("identity authority verifier did not approve attestation")
        if (verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id):
            raise ValueError("identity authority verifier did not re-approve exact attestation")
        if not isinstance(verdict.verifier_id, str) or not verdict.verifier_id.strip():
            raise ValueError("identity verifier_id must be nonblank")
        if not isinstance(verdict.verification_method, str) or not verdict.verification_method.strip():
            raise ValueError("identity verification_method must be nonblank")
        row = self._verified_identity_row(draft, attestation, verdict)
        with _ENGINE_LOCK:
            current = _engine.IDENTITY_REGISTRY.get(draft.registry_entry_id)
            idempotent = False
            if current is None:
                _engine.IDENTITY_REGISTRY[draft.registry_entry_id] = copy.deepcopy(row)
            elif current == row:
                idempotent = True
            else:
                raise ValueError("identity registry entry already exists with different content")
            row_hash = _engine.canonical_hash(_engine.IDENTITY_REGISTRY[draft.registry_entry_id])
            _VERIFIED_IDENTITY_RUNTIME[draft.registry_entry_id] = row_hash
            registry_hash = _engine.identity_registry_hash()
        return IdentityInstallation(
            registry_entry_id=draft.registry_entry_id,
            authority_id=attestation.authority_id,
            attestation_id=attestation.attestation_id,
            verifier_id=verdict.verifier_id,
            verification_method=verdict.verification_method,
            identity_commitment=attestation.identity_commitment,
            registry_hash=registry_hash,
            idempotent=idempotent,
        )

    @_requires_host_trust("IDENTITY")
    def reverify_installed_identity(
        self,
        draft: IdentityDraft,
        attestation: IdentityAuthorityAttestation,
        verifier: IdentityAuthorityVerifier,
        *,
        as_of: str,
    ) -> IdentityAuthorityInspection:
        """Re-establish runtime trust for an exact persisted external identity row."""
        self._canonical_identity_draft(draft)
        self._validate_identity_attestation(draft, attestation, as_of=as_of)
        if draft.registry_entry_id in _BUILTIN_IDENTITY_FIXTURES:
            raise ValueError("built-in identity fixtures cannot be externally reverified")
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft)")
        try:
            verdict = verify(attestation, draft=draft)
        except Exception as exc:
            raise ValueError("identity authority verifier failed closed") from exc
        if not isinstance(verdict, IdentityAuthorityVerdict) or verdict.approved is not True:
            raise ValueError("identity authority verifier did not approve attestation")
        if (verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id):
            raise ValueError("identity authority verifier did not re-approve exact attestation")
        attestation_commitment = _engine.canonical_hash({
            "schema": attestation.schema,
            "attestation_id": attestation.attestation_id,
            "authority_id": attestation.authority_id,
            "identity_commitment": attestation.identity_commitment,
            "issued_at": attestation.issued_at,
            "valid_from": attestation.valid_from,
            "valid_to": attestation.valid_to,
        })
        with _ENGINE_LOCK:
            row = _engine.IDENTITY_REGISTRY.get(draft.registry_entry_id)
            if row is None:
                raise ValueError("identity is not installed")
            if (row.get("surface_subject") != draft.surface_subject
                or row.get("domain_id") != draft.domain_id
                or row.get("entity_id") != draft.entity_id
                or row.get("event_id") != draft.event_id
                or row.get("version_id") != draft.version_id
                or row.get("identity_authority_id") != attestation.authority_id
                or row.get("identity_authority_identity_commitment") != attestation.identity_commitment
                or row.get("identity_authority_attestation_schema") != attestation.schema
                or row.get("identity_authority_attestation_id") != attestation.attestation_id
                or row.get("identity_authority_attestation_commitment") != attestation_commitment):
                raise ValueError("installed identity row does not match externally verified attestation")
            _VERIFIED_IDENTITY_RUNTIME[draft.registry_entry_id] = _engine.canonical_hash(row)
        return self.inspect_identity_authority(draft)

    def inspect_identity_authority(self, draft: IdentityDraft) -> IdentityAuthorityInspection:
        if not isinstance(draft, IdentityDraft):
            raise TypeError("draft must be IdentityDraft")
        with _ENGINE_LOCK:
            row = _engine.IDENTITY_REGISTRY.get(draft.registry_entry_id)
            if row is None:
                return IdentityAuthorityInspection(
                    draft.registry_entry_id, "DRAFT_ONLY", False, False, False, None, None, None
                )
            exact = (
                row.get("surface_subject") == draft.surface_subject
                and row.get("domain_id") == draft.domain_id
                and row.get("entity_id") == draft.entity_id
                and row.get("event_id") == draft.event_id
                and row.get("version_id") == draft.version_id
            )
            row_hash = _engine.canonical_hash(row)
            if draft.registry_entry_id in _BUILTIN_IDENTITY_FIXTURES:
                builtin_exact = row_hash == _BUILTIN_IDENTITY_FIXTURE_HASHES[draft.registry_entry_id]
                runtime = _DEVELOPER_IDENTITY_RUNTIME.get(draft.registry_entry_id) == row_hash
                state = ("INSTALLED_DEVELOPER_IDENTITY_FIXTURE_ACTIVE" if builtin_exact and runtime
                         else "INSTALLED_DEVELOPER_IDENTITY_FIXTURE_INACTIVE" if builtin_exact
                         else "BUILTIN_IDENTITY_FIXTURE_MUTATED")
                return IdentityAuthorityInspection(
                    draft.registry_entry_id, state, True, exact and builtin_exact, runtime and builtin_exact,
                    _RESERVED_LOCAL_IDENTITY_AUTHORITY, None, None,
                )
            fixture_runtime = _DEVELOPER_IDENTITY_RUNTIME.get(draft.registry_entry_id) == row_hash
            runtime = _VERIFIED_IDENTITY_RUNTIME.get(draft.registry_entry_id) == row_hash
            att_id = row.get("identity_authority_attestation_id")
            authority_id = row.get("identity_authority_id")
            verifier_id = row.get("identity_authority_verifier_id")
            commitment_match = row.get("identity_authority_identity_commitment") == self.identity_commitment(draft)
            if fixture_runtime:
                state = "INSTALLED_DEVELOPER_IDENTITY_FIXTURE_ACTIVE"
                runtime = True
            elif att_id is None:
                state = "INSTALLED_EXTERNAL_IDENTITY_UNATTESTED"
                runtime = False
            elif exact and commitment_match and runtime:
                state = "INSTALLED_VERIFIED_IDENTITY_RUNTIME"
            elif exact and commitment_match:
                state = "INSTALLED_ATTESTED_IDENTITY_NOT_RUNTIME_VERIFIED"
            else:
                state = "INSTALLED_ATTESTED_IDENTITY_MISMATCH"
            return IdentityAuthorityInspection(
                draft.registry_entry_id, state, True, exact, runtime,
                authority_id if isinstance(authority_id, str) else None,
                att_id if isinstance(att_id, str) else None,
                verifier_id if isinstance(verifier_id, str) else None,
            )

    def _identity_integration_errors(
        self, evidence: Sequence[Mapping[str, Any]], claim_identity_map: Mapping[str, str]
    ) -> list[dict[str, Any]]:
        required: set[str] = set()
        for identity_id in dict(claim_identity_map).values():
            if isinstance(identity_id, str) and identity_id.strip():
                required.add(identity_id)
            else:
                return [{"type": "IDENTITY_REFERENCE_INVALID", "identity_registry_entry_id": identity_id}]
        for record in evidence:
            identity_id = dict(record).get("identity_registry_entry_id")
            if isinstance(identity_id, str) and identity_id.strip():
                required.add(identity_id)
            else:
                return [{"type": "IDENTITY_REFERENCE_INVALID", "identity_registry_entry_id": identity_id}]
        errors: list[dict[str, Any]] = []
        for identity_id in sorted(required):
            row = _engine.IDENTITY_REGISTRY.get(identity_id)
            if not isinstance(row, dict):
                errors.append({"type": "IDENTITY_NOT_INSTALLED", "identity_registry_entry_id": identity_id})
                continue
            row_hash = _engine.canonical_hash(row)
            if identity_id in _BUILTIN_IDENTITY_FIXTURES:
                if row_hash != _BUILTIN_IDENTITY_FIXTURE_HASHES[identity_id]:
                    errors.append({"type": "BUILTIN_IDENTITY_FIXTURE_MUTATED", "identity_registry_entry_id": identity_id})
                elif _DEVELOPER_IDENTITY_RUNTIME.get(identity_id) != row_hash:
                    errors.append({"type": "DEVELOPER_IDENTITY_FIXTURE_RUNTIME_NOT_ACTIVE", "identity_registry_entry_id": identity_id})
                continue
            if _DEVELOPER_IDENTITY_RUNTIME.get(identity_id) == row_hash:
                continue
            if row.get("identity_authority_attestation_id") is None:
                errors.append({"type": "EXTERNAL_IDENTITY_AUTHORITY_UNATTESTED", "identity_registry_entry_id": identity_id})
            elif _VERIFIED_IDENTITY_RUNTIME.get(identity_id) != row_hash:
                errors.append({"type": "IDENTITY_AUTHORITY_RUNTIME_NOT_VERIFIED", "identity_registry_entry_id": identity_id})
        return errors

    def draft_evidence_record(
        self,
        *,
        evidence_id: str,
        subject: str,
        predicate: str,
        value: str,
        source: str,
        identity_registry_entry_id: str,
        authority_id: str,
        authority_record_entity_id: str,
        authority_record_event_id: str,
        authority_record_version_id: str,
        valid_from: str,
        valid_to: str,
        observed_at: str,
        available_at: str,
        provenance: Mapping[str, Any],
        polarity: str = "POSITIVE",
        source_semantics_id: str | None = None,
        epistemic_role_record_id: str | None = None,
    ) -> EvidenceRecordDraft:
        """Create a canonical evidence record without minting any authority.

        The method validates input shape only. References may remain unresolved and
        are reported by :meth:`inspect_evidence_record`. No engine registry is written.
        """
        required = {
            "evidence_id": evidence_id, "subject": subject, "predicate": predicate,
            "value": value, "source": source,
            "identity_registry_entry_id": identity_registry_entry_id,
            "authority_id": authority_id,
            "authority_record_entity_id": authority_record_entity_id,
            "authority_record_event_id": authority_record_event_id,
            "authority_record_version_id": authority_record_version_id,
            "valid_from": valid_from, "valid_to": valid_to,
            "observed_at": observed_at, "available_at": available_at,
        }
        for name, item in required.items():
            if not isinstance(item, str) or not item.strip():
                raise ValueError(f"{name} must be nonblank")
        if polarity not in {"POSITIVE", "NEGATIVE"}:
            raise ValueError("polarity must be POSITIVE or NEGATIVE")
        if not _engine.evidence_source_field_valid(source):
            raise ValueError("source does not satisfy the frozen evidence-source field policy")
        if not _engine.subject_shape_ok(subject):
            raise ValueError("subject admission failed")
        if not _engine.value_shape_ok(value, predicate):
            raise ValueError("value admission failed")
        if _engine.make_temporal(valid_from, valid_to, observed_at, available_at) is None:
            raise ValueError("invalid temporal semantics")
        for name, item in (("source_semantics_id", source_semantics_id),
                           ("epistemic_role_record_id", epistemic_role_record_id)):
            if item is not None and (not isinstance(item, str) or not item.strip()):
                raise ValueError(f"{name} must be None or nonblank")

        if not isinstance(provenance, Mapping):
            raise TypeError("provenance must be a mapping")
        p = dict(provenance)
        if set(p) != set(_engine.PROV_KEYS):
            raise ValueError(f"provenance must contain exactly {sorted(_engine.PROV_KEYS)}")
        for name in ("source_id", "root_origin_id", "origin_id", "referent_entity_id",
                     "referent_event_id", "referent_version_id", "extractor_id", "common_mode_group"):
            if not isinstance(p.get(name), str) or not p[name].strip():
                raise ValueError(f"provenance.{name} must be nonblank")
        lineage = p.get("lineage")
        if not isinstance(lineage, (list, tuple)) or not lineage or any(not isinstance(x, str) or not x.strip() for x in lineage):
            raise ValueError("provenance.lineage must be a nonempty sequence of nonblank strings")
        lineage_t = tuple(lineage)
        if lineage_t[0] != p["root_origin_id"] or lineage_t[-1] != p["origin_id"] or len(set(lineage_t)) != len(lineage_t):
            raise ValueError("provenance lineage must run uniquely from root_origin_id to origin_id")

        dependencies = p.get("dependencies")
        if not isinstance(dependencies, Mapping) or set(dependencies) != set(_engine.DEPENDENCY_DIMENSIONS):
            raise ValueError("provenance.dependencies must contain every frozen dependency dimension exactly once")
        dep_rows: list[EvidenceDependencyDraft] = []
        for dim in _engine.DEPENDENCY_DIMENSIONS:
            row = dependencies[dim]
            if not isinstance(row, Mapping):
                raise ValueError(f"dependency {dim} must be a mapping")
            row = dict(row)
            if set(row) - {"state", "id", "justification_id"}:
                raise ValueError(f"dependency {dim} contains unknown fields")
            state = row.get("state")
            if state not in _engine.DEPENDENCY_STATES:
                raise ValueError(f"dependency {dim} has invalid state")
            ident = row.get("id")
            jid = row.get("justification_id")
            if state == "KNOWN":
                if not isinstance(ident, str) or not ident.strip():
                    raise ValueError(f"KNOWN dependency {dim} requires nonblank id")
                if jid not in (None, ""):
                    raise ValueError(f"KNOWN dependency {dim} cannot carry justification_id")
                if _engine.canonical_dependency_id(dim, ident) is None:
                    raise ValueError(f"dependency {dim} id is not admissible")
                dep_rows.append(EvidenceDependencyDraft(dim, state, ident, None))
            elif state in _engine.PROVENANCE_POLICY["justification_required_states"]:
                if ident not in (None, ""):
                    raise ValueError(f"dependency {dim} state {state} cannot carry id")
                if not isinstance(jid, str) or not jid.strip():
                    raise ValueError(f"dependency {dim} state {state} requires justification_id")
                dep_rows.append(EvidenceDependencyDraft(dim, state, None, jid))
            else:
                if ident not in (None, "") or jid not in (None, ""):
                    raise ValueError(f"dependency {dim} state {state} cannot carry id/justification_id")
                dep_rows.append(EvidenceDependencyDraft(dim, state, None, None))

        prov = EvidenceProvenanceDraft(
            source_id=p["source_id"], root_origin_id=p["root_origin_id"], origin_id=p["origin_id"],
            referent_entity_id=p["referent_entity_id"], referent_event_id=p["referent_event_id"],
            referent_version_id=p["referent_version_id"], extractor_id=p["extractor_id"],
            common_mode_group=p["common_mode_group"], lineage=lineage_t, dependencies=tuple(dep_rows),
        )
        return EvidenceRecordDraft(
            evidence_id=evidence_id, subject=subject, predicate=predicate, value=value, source=source,
            polarity=polarity, identity_registry_entry_id=identity_registry_entry_id, authority_id=authority_id,
            authority_record_entity_id=authority_record_entity_id, authority_record_event_id=authority_record_event_id,
            authority_record_version_id=authority_record_version_id, valid_from=valid_from, valid_to=valid_to,
            observed_at=observed_at, available_at=available_at, provenance=prov,
            source_semantics_id=source_semantics_id, epistemic_role_record_id=epistemic_role_record_id,
        )

    def _canonical_evidence_draft(self, draft: EvidenceRecordDraft) -> EvidenceRecordDraft:
        if not isinstance(draft, EvidenceRecordDraft):
            raise TypeError("draft must be EvidenceRecordDraft")
        provenance = {
            "source_id": draft.provenance.source_id, "root_origin_id": draft.provenance.root_origin_id,
            "origin_id": draft.provenance.origin_id, "referent_entity_id": draft.provenance.referent_entity_id,
            "referent_event_id": draft.provenance.referent_event_id,
            "referent_version_id": draft.provenance.referent_version_id,
            "extractor_id": draft.provenance.extractor_id,
            "common_mode_group": draft.provenance.common_mode_group,
            "lineage": list(draft.provenance.lineage),
            "dependencies": {
                dep.dimension: ({"state": dep.state, **({"id": dep.identifier} if dep.identifier is not None else {}),
                                 **({"justification_id": dep.justification_id} if dep.justification_id is not None else {})})
                for dep in draft.provenance.dependencies
            },
        }
        rebuilt = self.draft_evidence_record(
            evidence_id=draft.evidence_id, subject=draft.subject, predicate=draft.predicate, value=draft.value,
            source=draft.source, identity_registry_entry_id=draft.identity_registry_entry_id,
            authority_id=draft.authority_id, authority_record_entity_id=draft.authority_record_entity_id,
            authority_record_event_id=draft.authority_record_event_id,
            authority_record_version_id=draft.authority_record_version_id, valid_from=draft.valid_from,
            valid_to=draft.valid_to, observed_at=draft.observed_at, available_at=draft.available_at,
            provenance=provenance, polarity=draft.polarity, source_semantics_id=draft.source_semantics_id,
            epistemic_role_record_id=draft.epistemic_role_record_id,
        )
        if rebuilt != draft:
            raise ValueError("EvidenceRecordDraft is not canonical")
        return rebuilt

    def evidence_record_mapping(self, draft: EvidenceRecordDraft) -> dict[str, Any]:
        """Serialize a canonical draft to the exact engine input vocabulary without side effects."""
        draft = self._canonical_evidence_draft(draft)
        deps: dict[str, dict[str, str]] = {}
        for dep in draft.provenance.dependencies:
            row = {"state": dep.state}
            if dep.identifier is not None:
                row["id"] = dep.identifier
            if dep.justification_id is not None:
                row["justification_id"] = dep.justification_id
            deps[dep.dimension] = row
        record = {
            "evidence_id": draft.evidence_id, "subject": draft.subject, "predicate": draft.predicate,
            "value": draft.value, "source": draft.source, "polarity": draft.polarity,
            "identity_registry_entry_id": draft.identity_registry_entry_id, "authority_id": draft.authority_id,
            "authority_record_entity_id": draft.authority_record_entity_id,
            "authority_record_event_id": draft.authority_record_event_id,
            "authority_record_version_id": draft.authority_record_version_id,
            "valid_from": draft.valid_from, "valid_to": draft.valid_to,
            "observed_at": draft.observed_at, "available_at": draft.available_at,
            "provenance": {
                "source_id": draft.provenance.source_id, "root_origin_id": draft.provenance.root_origin_id,
                "origin_id": draft.provenance.origin_id, "referent_entity_id": draft.provenance.referent_entity_id,
                "referent_event_id": draft.provenance.referent_event_id,
                "referent_version_id": draft.provenance.referent_version_id,
                "extractor_id": draft.provenance.extractor_id,
                "common_mode_group": draft.provenance.common_mode_group,
                "lineage": list(draft.provenance.lineage), "dependencies": deps,
            },
        }
        if draft.source_semantics_id is not None:
            record["source_semantics_id"] = draft.source_semantics_id
        if draft.epistemic_role_record_id is not None:
            record["epistemic_role_record_id"] = draft.epistemic_role_record_id
        return record

    def evidence_record_commitment(self, draft: EvidenceRecordDraft) -> str:
        return _engine.evidence_record_hash(self.evidence_record_mapping(draft))

    def inspect_evidence_record(self, draft: EvidenceRecordDraft) -> EvidenceRecordInspection:
        """Read-only inspection of structural validity and existing authority references."""
        record = self.evidence_record_mapping(draft)
        errors: list[str] = []
        identity = _engine.IDENTITY_REGISTRY.get(draft.identity_registry_entry_id)
        identity_state = "RESOLVED" if isinstance(identity, dict) else "UNRESOLVED"
        if identity_state != "RESOLVED": errors.append("identity reference unresolved")

        authority_state = "KNOWN_POLICY" if draft.authority_id in _engine.AUTHORITY_POLICIES else "UNRESOLVED"
        if authority_state == "UNRESOLVED": errors.append("authority reference unresolved")

        if draft.source_semantics_id is None:
            source_state = "ABSENT"
        else:
            source_cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(draft.source_semantics_id)
            source_state = "RESOLVED" if _engine.validate_source_semantics_resolution_certificate(source_cert) else "UNRESOLVED"
            if source_state == "UNRESOLVED": errors.append("source semantics reference unresolved")

        if draft.epistemic_role_record_id is None:
            role_state = "ABSENT"
        else:
            cert = _engine.EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(draft.epistemic_role_record_id)
            if cert is None and _engine._ensure_self_test_scope_generation() is not None:
                cert = _engine._SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(draft.epistemic_role_record_id)
            role_state = "PRESENT" if cert is not None else "UNRESOLVED"
            if role_state == "UNRESOLVED": errors.append("epistemic role reference unresolved")

        # Canonical drafting proves the input schema/shape. Authority resolution is separate.
        structurally_valid = True
        if isinstance(identity, dict):
            expected = (identity.get("entity_id"), identity.get("event_id"), identity.get("version_id"))
            declared = (draft.provenance.referent_entity_id, draft.provenance.referent_event_id,
                        draft.provenance.referent_version_id)
            authority_declared = (draft.authority_record_entity_id, draft.authority_record_event_id,
                                  draft.authority_record_version_id)
            if declared != expected:
                structurally_valid = False; errors.append("provenance referent does not match identity")
            if authority_declared != expected:
                structurally_valid = False; errors.append("authority record referent does not match identity")
        state = ("DRAFT_STRUCTURALLY_VALID_REFERENCES_RESOLVED" if structurally_valid and not errors
                 else "DRAFT_STRUCTURALLY_VALID_REFERENCES_UNRESOLVED" if structurally_valid
                 else "DRAFT_INVALID")
        return EvidenceRecordInspection(
            evidence_id=draft.evidence_id, state=state, structurally_valid=structurally_valid,
            identity_reference_state=identity_state, authority_reference_state=authority_state,
            source_semantics_reference_state=source_state, epistemic_role_reference_state=role_state,
            record_hash=_engine.evidence_record_hash(record), errors=tuple(errors),
        )

    def provenance_commitment(self, draft: EvidenceRecordDraft) -> str:
        """Canonical commitment to the evidence id plus provenance projection only."""
        draft = self._canonical_evidence_draft(draft)
        payload = {
            "schema": "CFC_EVIDENCE_PROVENANCE_DRAFT_V1",
            "evidence_id": draft.evidence_id,
            "source_id": draft.provenance.source_id,
            "root_origin_id": draft.provenance.root_origin_id,
            "origin_id": draft.provenance.origin_id,
            "referent_entity_id": draft.provenance.referent_entity_id,
            "referent_event_id": draft.provenance.referent_event_id,
            "referent_version_id": draft.provenance.referent_version_id,
            "extractor_id": draft.provenance.extractor_id,
            "common_mode_group": draft.provenance.common_mode_group,
            "lineage": draft.provenance.lineage,
            "dependencies": tuple(
                (d.dimension, d.state, d.identifier, d.justification_id)
                for d in draft.provenance.dependencies
            ),
        }
        return _engine.canonical_hash(payload)

    def _validate_provenance_attestation(
        self, draft: EvidenceRecordDraft, attestation: ProvenanceAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation, ProvenanceAuthorityAttestation):
            raise TypeError("attestation must be ProvenanceAuthorityAttestation")
        if attestation.schema != _PROVENANCE_ATTESTATION_SCHEMA:
            raise ValueError("unsupported provenance authority attestation schema")
        if attestation.authority_id == _RESERVED_LOCAL_PROVENANCE_AUTHORITY:
            raise ValueError("LOCAL_PROVENANCE_FIXTURE_AUTHORITY is reserved for DeveloperFixtureSession")
        for name in ("attestation_id", "authority_id", "evidence_id", "provenance_commitment",
                     "issued_at", "valid_from", "valid_to"):
            value = getattr(attestation, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"provenance attestation {name} must be nonblank")
        if attestation.evidence_id != draft.evidence_id:
            raise ValueError("provenance attestation does not bind this evidence_id")
        if not _engine._valid_hash64(attestation.provenance_commitment):
            raise ValueError("provenance_commitment must be a SHA-256 hex digest")
        if attestation.provenance_commitment != self.provenance_commitment(draft):
            raise ValueError("provenance attestation does not bind this provenance draft")
        try:
            issued = _engine.strict_date(attestation.issued_at)
            vf = _engine.strict_date(attestation.valid_from)
            vt = _engine.strict_date(attestation.valid_to)
            when = _engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid provenance authority attestation dates") from exc
        if vf > vt or issued > when or not (vf <= when <= vt):
            raise ValueError("provenance authority attestation is not applicable at as_of")

    @_requires_host_trust("PROVENANCE")
    def verify_evidence_provenance(
        self, draft: EvidenceRecordDraft, attestation: ProvenanceAuthorityAttestation,
        verifier: ProvenanceAuthorityVerifier, *, as_of: str
    ) -> ProvenanceAuthorityInspection:
        """Establish only an in-process verification pin; no engine authority registry is minted."""
        draft = self._canonical_evidence_draft(draft)
        self._validate_provenance_attestation(draft, attestation, as_of=as_of)
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft)")
        try:
            verdict = verify(attestation, draft=draft)
        except Exception as exc:
            raise ValueError("provenance authority verifier failed closed") from exc
        if not isinstance(verdict, ProvenanceAuthorityVerdict) or verdict.approved is not True:
            raise ValueError("provenance authority verifier did not approve attestation")
        if (verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id
            or verdict.evidence_id != draft.evidence_id
            or not isinstance(verdict.verifier_id, str) or not verdict.verifier_id.strip()
            or not isinstance(verdict.verification_method, str) or not verdict.verification_method.strip()):
            raise ValueError("provenance verifier verdict is not exactly bound to attestation")
        commitment = self.provenance_commitment(draft)
        with _ENGINE_LOCK:
            _VERIFIED_PROVENANCE_RUNTIME[draft.evidence_id] = commitment
            _VERIFIED_PROVENANCE_METADATA[draft.evidence_id] = {
                "authority_id": attestation.authority_id,
                "attestation_id": attestation.attestation_id,
                "verifier_id": verdict.verifier_id,
                "verification_method": verdict.verification_method,
            }
        return self.inspect_provenance_authority(draft)

    def inspect_provenance_authority(self, draft: EvidenceRecordDraft) -> ProvenanceAuthorityInspection:
        draft = self._canonical_evidence_draft(draft)
        commitment = self.provenance_commitment(draft)
        with _ENGINE_LOCK:
            developer = _DEVELOPER_PROVENANCE_RUNTIME.get(draft.evidence_id) == commitment
            runtime = developer or _VERIFIED_PROVENANCE_RUNTIME.get(draft.evidence_id) == commitment
            meta = _VERIFIED_PROVENANCE_METADATA.get(draft.evidence_id, {})
            if developer:
                state = "DEVELOPER_FIXTURE_RUNTIME_VERIFIED"
            elif runtime:
                state = "EXTERNAL_RUNTIME_VERIFIED"
            elif draft.evidence_id in _VERIFIED_PROVENANCE_RUNTIME:
                state = "RUNTIME_PIN_MISMATCH"
            else:
                state = "NOT_RUNTIME_VERIFIED"
            return ProvenanceAuthorityInspection(
                draft.evidence_id, state, runtime,
                meta.get("authority_id"), meta.get("attestation_id"), meta.get("verifier_id"), commitment
            )

    def draft_source_semantics(
        self, *, semantics_registry_entry_id: str, source_id: str, repository_id: str,
        producer_id: str, process_id: str, failure_domain_id: str,
        resolution_state: str = "KNOWN", source_common_mode_ids: Sequence[str] = (),
    ) -> SourceSemanticsDraft:
        values = {
            "semantics_registry_entry_id": semantics_registry_entry_id, "source_id": source_id,
            "repository_id": repository_id, "producer_id": producer_id, "process_id": process_id,
            "failure_domain_id": failure_domain_id, "resolution_state": resolution_state,
        }
        for name, value in values.items():
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be nonblank")
        if resolution_state not in set(_engine.SOURCE_SEMANTICS_POLICY["allowed_resolution_states"]):
            raise ValueError("invalid source semantics resolution_state")
        cm = tuple(sorted(set(source_common_mode_ids)))
        if any(not isinstance(x, str) or not x.strip() for x in cm):
            raise ValueError("source_common_mode_ids must contain nonblank strings")
        if _engine.canonical_failure_domain_id(failure_domain_id) is None:
            raise ValueError("failure_domain_id is not admissible in the current failure-domain graph")
        return SourceSemanticsDraft(
            semantics_registry_entry_id, source_id, repository_id, producer_id, process_id,
            failure_domain_id, resolution_state, cm
        )

    def source_semantics_commitment(self, draft: SourceSemanticsDraft) -> str:
        if not isinstance(draft, SourceSemanticsDraft):
            raise TypeError("draft must be SourceSemanticsDraft")
        canonical = self.draft_source_semantics(
            semantics_registry_entry_id=draft.semantics_registry_entry_id, source_id=draft.source_id,
            repository_id=draft.repository_id, producer_id=draft.producer_id, process_id=draft.process_id,
            failure_domain_id=draft.failure_domain_id, resolution_state=draft.resolution_state,
            source_common_mode_ids=draft.source_common_mode_ids,
        )
        if canonical != draft:
            raise ValueError("SourceSemanticsDraft is not canonical")
        return _engine.canonical_hash({
            "schema": "CFC_SOURCE_SEMANTICS_DRAFT_V1",
            "semantics_registry_entry_id": draft.semantics_registry_entry_id,
            "source_id": draft.source_id, "repository_id": draft.repository_id,
            "producer_id": draft.producer_id, "process_id": draft.process_id,
            "failure_domain_id": draft.failure_domain_id, "resolution_state": draft.resolution_state,
            "source_common_mode_ids": draft.source_common_mode_ids,
        })

    def _validate_source_semantics_attestation(
        self, draft: SourceSemanticsDraft, attestation: SourceSemanticsAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation, SourceSemanticsAuthorityAttestation):
            raise TypeError("attestation must be SourceSemanticsAuthorityAttestation")
        if attestation.schema != _SOURCE_SEMANTICS_ATTESTATION_SCHEMA:
            raise ValueError("unsupported source semantics authority attestation schema")
        if attestation.authority_id == _RESERVED_ENGINE_SOURCE_SEMANTICS_AUTHORITY:
            raise ValueError("LOCAL_SOURCE_SEMANTICS_AUTHORITY is reserved for the engine adapter")
        for name in ("attestation_id", "authority_id", "source_semantics_commitment",
                     "issued_at", "valid_from", "valid_to"):
            value = getattr(attestation, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"source semantics attestation {name} must be nonblank")
        if not _engine._valid_hash64(attestation.source_semantics_commitment):
            raise ValueError("source_semantics_commitment must be a SHA-256 hex digest")
        if attestation.source_semantics_commitment != self.source_semantics_commitment(draft):
            raise ValueError("source semantics attestation does not bind this draft")
        try:
            issued = _engine.strict_date(attestation.issued_at)
            vf = _engine.strict_date(attestation.valid_from)
            vt = _engine.strict_date(attestation.valid_to)
            when = _engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid source semantics attestation dates") from exc
        if vf > vt or issued > when or not (vf <= when <= vt):
            raise ValueError("source semantics attestation is not applicable at as_of")

    def _source_semantics_row(
        self, draft: SourceSemanticsDraft, attestation: SourceSemanticsAuthorityAttestation,
        verdict: SourceSemanticsAuthorityVerdict
    ) -> dict[str, Any]:
        att_commitment = _engine.canonical_hash({
            "schema": attestation.schema, "attestation_id": attestation.attestation_id,
            "authority_id": attestation.authority_id,
            "source_semantics_commitment": attestation.source_semantics_commitment,
            "issued_at": attestation.issued_at, "valid_from": attestation.valid_from,
            "valid_to": attestation.valid_to,
        })
        return {
            "source_id": draft.source_id, "repository_id": draft.repository_id,
            "producer_id": draft.producer_id, "process_id": draft.process_id,
            "failure_domain_id": draft.failure_domain_id,
            "authority_id": _RESERVED_ENGINE_SOURCE_SEMANTICS_AUTHORITY,
            "resolution_state": draft.resolution_state,
            "source_common_mode_ids": draft.source_common_mode_ids,
            "external_source_semantics_attestation_schema": attestation.schema,
            "external_source_semantics_authority_id": attestation.authority_id,
            "external_source_semantics_commitment": attestation.source_semantics_commitment,
            "external_source_semantics_attestation_id": attestation.attestation_id,
            "external_source_semantics_attestation_commitment": att_commitment,
            "external_source_semantics_verifier_id": verdict.verifier_id,
            "external_source_semantics_verification_method": verdict.verification_method,
        }

    @_requires_host_trust("SOURCE_SEMANTICS")
    def install_verified_source_semantics(
        self, draft: SourceSemanticsDraft, attestation: SourceSemanticsAuthorityAttestation,
        verifier: SourceSemanticsAuthorityVerifier, *, as_of: str
    ) -> SourceSemanticsInstallation:
        self.source_semantics_commitment(draft)
        self._validate_source_semantics_attestation(draft, attestation, as_of=as_of)
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft)")
        try:
            verdict = verify(attestation, draft=draft)
        except Exception as exc:
            raise ValueError("source semantics authority verifier failed closed") from exc
        if not isinstance(verdict, SourceSemanticsAuthorityVerdict) or verdict.approved is not True:
            raise ValueError("source semantics authority verifier did not approve attestation")
        if (verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id
            or not isinstance(verdict.verifier_id, str) or not verdict.verifier_id.strip()
            or not isinstance(verdict.verification_method, str) or not verdict.verification_method.strip()):
            raise ValueError("source semantics verifier verdict is not exactly bound to attestation")
        row = self._source_semantics_row(draft, attestation, verdict)
        row_hash = _engine.canonical_hash(row)
        with _ENGINE_LOCK:
            existing = _engine.SOURCE_SEMANTICS_REGISTRY.get(draft.semantics_registry_entry_id)
            idempotent = existing is not None
            if existing is not None and _engine.canonical_hash(existing) != row_hash:
                raise ValueError("source semantics id already exists with different content or authority")
            if existing is None:
                _engine.SOURCE_SEMANTICS_REGISTRY[draft.semantics_registry_entry_id] = copy.deepcopy(row)
                try:
                    cert = _engine.issue_source_semantics_resolution_certificate(draft.semantics_registry_entry_id)
                except Exception:
                    _engine.SOURCE_SEMANTICS_REGISTRY.pop(draft.semantics_registry_entry_id, None)
                    raise
            else:
                cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(draft.semantics_registry_entry_id)
                if not _engine.validate_source_semantics_resolution_certificate(cert):
                    raise ValueError("installed source semantics resolution certificate is invalid")
            _VERIFIED_SOURCE_SEMANTICS_RUNTIME[draft.semantics_registry_entry_id] = row_hash
            registry_hash = _engine.source_semantics_registry_hash()
        return SourceSemanticsInstallation(
            draft.semantics_registry_entry_id, attestation.authority_id, attestation.attestation_id,
            verdict.verifier_id, verdict.verification_method, attestation.source_semantics_commitment,
            registry_hash, cert.certificate_id, idempotent
        )

    @_requires_host_trust("SOURCE_SEMANTICS")
    def reverify_installed_source_semantics(
        self, draft: SourceSemanticsDraft, attestation: SourceSemanticsAuthorityAttestation,
        verifier: SourceSemanticsAuthorityVerifier, *, as_of: str
    ) -> SourceSemanticsAuthorityInspection:
        self.source_semantics_commitment(draft)
        self._validate_source_semantics_attestation(draft, attestation, as_of=as_of)
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft)")
        try:
            verdict = verify(attestation, draft=draft)
        except Exception as exc:
            raise ValueError("source semantics authority verifier failed closed") from exc
        if (not isinstance(verdict, SourceSemanticsAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id):
            raise ValueError("source semantics authority verifier did not re-approve exact attestation")
        att_commitment = _engine.canonical_hash({
            "schema": attestation.schema, "attestation_id": attestation.attestation_id,
            "authority_id": attestation.authority_id,
            "source_semantics_commitment": attestation.source_semantics_commitment,
            "issued_at": attestation.issued_at, "valid_from": attestation.valid_from,
            "valid_to": attestation.valid_to,
        })
        with _ENGINE_LOCK:
            row = _engine.SOURCE_SEMANTICS_REGISTRY.get(draft.semantics_registry_entry_id)
            cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(draft.semantics_registry_entry_id)
            exact_row = isinstance(row, dict) and (
                row.get("source_id") == draft.source_id
                and row.get("repository_id") == draft.repository_id
                and row.get("producer_id") == draft.producer_id
                and row.get("process_id") == draft.process_id
                and row.get("failure_domain_id") == draft.failure_domain_id
                and row.get("authority_id") == _RESERVED_ENGINE_SOURCE_SEMANTICS_AUTHORITY
                and row.get("resolution_state") == draft.resolution_state
                and tuple(row.get("source_common_mode_ids", ())) == draft.source_common_mode_ids
                and row.get("external_source_semantics_attestation_schema") == attestation.schema
                and row.get("external_source_semantics_authority_id") == attestation.authority_id
                and row.get("external_source_semantics_commitment") == attestation.source_semantics_commitment
                and row.get("external_source_semantics_attestation_id") == attestation.attestation_id
                and row.get("external_source_semantics_attestation_commitment") == att_commitment
            )
            if not exact_row:
                raise ValueError("installed source semantics row does not match externally verified attestation")
            if not _engine.validate_source_semantics_resolution_certificate(cert):
                raise ValueError("installed source semantics resolution certificate is invalid")
            _VERIFIED_SOURCE_SEMANTICS_RUNTIME[draft.semantics_registry_entry_id] = _engine.canonical_hash(row)
        return self.inspect_source_semantics_authority(draft)

    def inspect_source_semantics_authority(self, draft: SourceSemanticsDraft) -> SourceSemanticsAuthorityInspection:
        self.source_semantics_commitment(draft)
        with _ENGINE_LOCK:
            row = _engine.SOURCE_SEMANTICS_REGISTRY.get(draft.semantics_registry_entry_id)
            if row is None:
                return SourceSemanticsAuthorityInspection(
                    draft.semantics_registry_entry_id, "DRAFT_ONLY", False, False, False, None, None, None
                )
            exact = (
                row.get("source_id") == draft.source_id
                and row.get("repository_id") == draft.repository_id
                and row.get("producer_id") == draft.producer_id
                and row.get("process_id") == draft.process_id
                and row.get("failure_domain_id") == draft.failure_domain_id
                and row.get("resolution_state") == draft.resolution_state
                and tuple(row.get("source_common_mode_ids", ())) == draft.source_common_mode_ids
            )
            row_hash = _engine.canonical_hash(row)
            developer = _DEVELOPER_SOURCE_SEMANTICS_RUNTIME.get(draft.semantics_registry_entry_id) == row_hash
            runtime = developer or _VERIFIED_SOURCE_SEMANTICS_RUNTIME.get(draft.semantics_registry_entry_id) == row_hash
            att_id = row.get("external_source_semantics_attestation_id")
            authority_id = row.get("external_source_semantics_authority_id")
            verifier_id = row.get("external_source_semantics_verifier_id")
            cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(draft.semantics_registry_entry_id)
            cert_valid = _engine.validate_source_semantics_resolution_certificate(cert)
            if developer:
                state = "INSTALLED_DEVELOPER_FIXTURE_ACTIVE"
            elif att_id is None:
                state = "INSTALLED_EXTERNAL_AUTHORITY_UNATTESTED"
                runtime = False
            elif exact and runtime and cert_valid:
                state = "INSTALLED_VERIFIED_RUNTIME"
            elif exact and cert_valid:
                state = "INSTALLED_ATTESTED_NOT_RUNTIME_VERIFIED"
            else:
                state = "INSTALLED_ATTESTED_MISMATCH"
                runtime = False
            return SourceSemanticsAuthorityInspection(
                draft.semantics_registry_entry_id, state, True, exact, runtime,
                authority_id if isinstance(authority_id, str) else None,
                att_id if isinstance(att_id, str) else None,
                verifier_id if isinstance(verifier_id, str) else None,
            )

    def _draft_evidence_from_mapping(self, raw: Mapping[str, Any]) -> EvidenceRecordDraft | None:
        if not isinstance(raw, Mapping):
            return None
        record = dict(raw)
        required = (
            "evidence_id", "subject", "predicate", "value", "source", "identity_registry_entry_id",
            "authority_id", "authority_record_entity_id", "authority_record_event_id",
            "authority_record_version_id", "valid_from", "valid_to", "observed_at", "available_at", "provenance"
        )
        if any(k not in record for k in required):
            return None
        try:
            return self.draft_evidence_record(
                evidence_id=record["evidence_id"], subject=record["subject"], predicate=record["predicate"],
                value=record["value"], source=record["source"],
                identity_registry_entry_id=record["identity_registry_entry_id"],
                authority_id=record["authority_id"],
                authority_record_entity_id=record["authority_record_entity_id"],
                authority_record_event_id=record["authority_record_event_id"],
                authority_record_version_id=record["authority_record_version_id"],
                valid_from=record["valid_from"], valid_to=record["valid_to"],
                observed_at=record["observed_at"], available_at=record["available_at"],
                provenance=record["provenance"], polarity=record.get("polarity", "POSITIVE"),
                source_semantics_id=record.get("source_semantics_id"),
                epistemic_role_record_id=record.get("epistemic_role_record_id"),
            )
        except Exception:
            return None

    def _provenance_source_semantics_integration_errors(
        self, evidence: Sequence[Mapping[str, Any]]
    ) -> list[dict[str, Any]]:
        errors: list[dict[str, Any]] = []
        for index, raw in enumerate(evidence, 1):
            if not isinstance(raw, Mapping):
                continue
            record = dict(raw)
            # Legacy/minimal records without provenance remain engine-fail-closed rather than being
            # silently upgraded by the wrapper. R252 applies whenever provenance is explicitly supplied.
            if "provenance" not in record:
                continue
            draft = self._draft_evidence_from_mapping(record)
            eid = record.get("evidence_id")
            if draft is None:
                errors.append({"type": "PROVENANCE_DRAFT_INVALID", "index": index, "evidence_id": eid})
                continue
            commitment = self.provenance_commitment(draft)
            if (_DEVELOPER_PROVENANCE_RUNTIME.get(draft.evidence_id) != commitment
                and _VERIFIED_PROVENANCE_RUNTIME.get(draft.evidence_id) != commitment):
                errors.append({"type": "PROVENANCE_AUTHORITY_RUNTIME_NOT_VERIFIED", "evidence_id": draft.evidence_id})
            sid = draft.source_semantics_id
            if sid is None:
                continue
            row = _engine.SOURCE_SEMANTICS_REGISTRY.get(sid)
            if not isinstance(row, dict):
                errors.append({"type": "SOURCE_SEMANTICS_NOT_INSTALLED", "evidence_id": draft.evidence_id,
                               "source_semantics_id": sid})
                continue
            row_hash = _engine.canonical_hash(row)
            cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(sid)
            if not _engine.validate_source_semantics_resolution_certificate(cert):
                errors.append({"type": "SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_INVALID",
                               "evidence_id": draft.evidence_id, "source_semantics_id": sid})
                continue
            if row.get("source_id") != draft.provenance.source_id:
                errors.append({"type": "SOURCE_SEMANTICS_SOURCE_ID_MISMATCH",
                               "evidence_id": draft.evidence_id, "source_semantics_id": sid})
                continue
            if _DEVELOPER_SOURCE_SEMANTICS_RUNTIME.get(sid) == row_hash:
                continue
            if row.get("external_source_semantics_attestation_id") is None:
                errors.append({"type": "EXTERNAL_SOURCE_SEMANTICS_AUTHORITY_UNATTESTED",
                               "evidence_id": draft.evidence_id, "source_semantics_id": sid})
            elif _VERIFIED_SOURCE_SEMANTICS_RUNTIME.get(sid) != row_hash:
                errors.append({"type": "SOURCE_SEMANTICS_AUTHORITY_RUNTIME_NOT_VERIFIED",
                               "evidence_id": draft.evidence_id, "source_semantics_id": sid})
        return errors

    def _evidence_schema_integration_errors(self, evidence: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
        errors: list[dict[str, Any]] = []
        seen: set[str] = set()
        for index, raw in enumerate(evidence, 1):
            if not isinstance(raw, Mapping):
                errors.append({"type": "EVIDENCE_RECORD_NOT_MAPPING", "index": index})
                continue
            record = dict(raw)
            unknown = set(record) - set(_engine.EVIDENCE_KEYS)
            if unknown:
                errors.append({"type": "EVIDENCE_RECORD_UNKNOWN_FIELDS", "index": index, "fields": sorted(unknown)})
            eid = record.get("evidence_id")
            if not isinstance(eid, str) or not eid.strip():
                errors.append({"type": "EVIDENCE_ID_REQUIRED", "index": index})
            elif eid in seen:
                errors.append({"type": "EVIDENCE_ID_DUPLICATE", "evidence_id": eid})
            else:
                seen.add(eid)
        return errors

    def evidence_authority_commitment(self, draft: EvidenceRecordDraft) -> str:
        """Bind exact evidence content, referent, provenance and the selected engine authority policy."""
        draft = self._canonical_evidence_draft(draft)
        policy = _engine.AUTHORITY_POLICIES.get(draft.authority_id)
        if not isinstance(policy, dict):
            raise ValueError("evidence authority policy is not known to the frozen engine")
        return _engine.canonical_hash({
            "schema": "CFC_EVIDENCE_AUTHORITY_PROJECTION_V1",
            "evidence_id": draft.evidence_id,
            "evidence_record_commitment": self.evidence_record_commitment(draft),
            "authority_policy_id": draft.authority_id,
            "authority_policy_fingerprint": _engine.canonical_hash(policy),
            "predicate": _engine.pkey(draft.predicate),
            "identity_registry_entry_id": draft.identity_registry_entry_id,
            "authority_record_referent": (
                draft.authority_record_entity_id,
                draft.authority_record_event_id,
                draft.authority_record_version_id,
            ),
            "provenance_commitment": self.provenance_commitment(draft),
        })

    def _validate_evidence_authority_attestation(
        self, draft: EvidenceRecordDraft, attestation: EvidenceAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation, EvidenceAuthorityAttestation):
            raise TypeError("attestation must be EvidenceAuthorityAttestation")
        if attestation.schema != _EVIDENCE_AUTHORITY_ATTESTATION_SCHEMA:
            raise ValueError("unsupported evidence authority attestation schema")
        if attestation.authority_id == _RESERVED_LOCAL_EVIDENCE_AUTHORITY:
            raise ValueError("LOCAL_EVIDENCE_AUTHORITY_FIXTURE is reserved for DeveloperFixtureSession")
        for name in ("attestation_id","authority_id","evidence_id","evidence_authority_policy_id",
                     "evidence_authority_commitment","issued_at","valid_from","valid_to"):
            value=getattr(attestation,name)
            if not isinstance(value,str) or not value.strip():
                raise ValueError(f"evidence authority attestation {name} must be nonblank")
        if attestation.evidence_id != draft.evidence_id:
            raise ValueError("attestation evidence_id mismatch")
        if attestation.evidence_authority_policy_id != draft.authority_id:
            raise ValueError("attestation authority policy mismatch")
        if attestation.evidence_authority_commitment != self.evidence_authority_commitment(draft):
            raise ValueError("attestation does not bind this evidence authority projection")
        try:
            issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from)
            vt=_engine.strict_date(attestation.valid_to); when=_engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid evidence authority attestation dates") from exc
        if vf>vt or issued>when or not (vf<=when<=vt):
            raise ValueError("evidence authority attestation is not applicable at as_of")

    @_requires_host_trust("EVIDENCE_AUTHORITY")
    def verify_evidence_authority(
        self, draft: EvidenceRecordDraft, attestation: EvidenceAuthorityAttestation,
        verifier: EvidenceAuthorityVerifier, *, as_of: str
    ) -> EvidenceAuthorityInspection:
        draft=self._canonical_evidence_draft(draft)
        self._validate_evidence_authority_attestation(draft,attestation,as_of=as_of)
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft)")
        try: verdict=verify(attestation,draft=draft)
        except Exception as exc: raise ValueError("evidence authority verifier failed closed") from exc
        if (not isinstance(verdict,EvidenceAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
            or verdict.evidence_id!=draft.evidence_id):
            raise ValueError("evidence authority verifier did not approve exact attestation")
        if not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip():
            raise ValueError("evidence authority verifier_id must be nonblank")
        if not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip():
            raise ValueError("evidence authority verification_method must be nonblank")
        commitment=self.evidence_authority_commitment(draft)
        with _ENGINE_LOCK:
            _VERIFIED_EVIDENCE_AUTHORITY_RUNTIME[draft.evidence_id]=commitment
            _VERIFIED_EVIDENCE_AUTHORITY_METADATA[draft.evidence_id]={
                "authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,
                "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,
                "evidence_authority_policy_id":draft.authority_id,
            }
        return self.inspect_evidence_authority(draft)

    @_requires_host_trust("EVIDENCE_AUTHORITY")
    def reverify_evidence_authority(
        self, draft: EvidenceRecordDraft, attestation: EvidenceAuthorityAttestation,
        verifier: EvidenceAuthorityVerifier, *, as_of: str
    ) -> EvidenceAuthorityInspection:
        return self.verify_evidence_authority(draft,attestation,verifier,as_of=as_of)

    def inspect_evidence_authority(self, draft: EvidenceRecordDraft) -> EvidenceAuthorityInspection:
        draft=self._canonical_evidence_draft(draft)
        commitment=self.evidence_authority_commitment(draft)
        runtime=(_DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME.get(draft.evidence_id)==commitment
                 or _VERIFIED_EVIDENCE_AUTHORITY_RUNTIME.get(draft.evidence_id)==commitment)
        meta=_VERIFIED_EVIDENCE_AUTHORITY_METADATA.get(draft.evidence_id,{})
        if _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME.get(draft.evidence_id)==commitment:
            state="DEVELOPER_FIXTURE_RUNTIME_VERIFIED"
        elif runtime:
            state="EXTERNAL_RUNTIME_VERIFIED"
        else:
            state="NOT_RUNTIME_VERIFIED"
        return EvidenceAuthorityInspection(
            draft.evidence_id,state,runtime,meta.get("authority_id"),meta.get("attestation_id"),
            meta.get("verifier_id"),draft.authority_id,commitment,
        )

    def draft_epistemic_role(self, evidence: EvidenceRecordDraft, *, epistemic_role: str) -> EpistemicRoleDraft:
        evidence=self._canonical_evidence_draft(evidence)
        if epistemic_role not in set(_engine.PINNED_EVIDENCE_EPISTEMIC_ROLE_POLICY["allowed_roles"]):
            raise ValueError("invalid epistemic role")
        gid=_engine._default_role_issuer_grant_id(epistemic_role)
        grant=_engine._role_issuer_grant(gid)
        if gid is None or grant is None:
            raise ValueError("frozen engine has no issuer grant for epistemic role")
        record_commitment=self.evidence_record_commitment(evidence)
        role_commitment=_engine.canonical_hash({
            "schema":"CFC_EPISTEMIC_ROLE_DRAFT_V1","evidence_id":evidence.evidence_id,
            "evidence_record_commitment":record_commitment,"epistemic_role":epistemic_role,
            "issuer_grant_id":gid,"issuer_authority_id":grant["issuer_authority_id"],
            "issuer_grant_fingerprint":_engine.canonical_hash(grant),
            "role_policy_hash":_engine.pinned_evidence_epistemic_role_policy_hash(),
            "role_issuer_policy_hash":_engine.pinned_evidence_epistemic_role_issuer_policy_hash(),
        })
        return EpistemicRoleDraft(evidence.evidence_id,epistemic_role,gid,grant["issuer_authority_id"],
                                  record_commitment,role_commitment)

    def _validate_epistemic_role_attestation(
        self, role: EpistemicRoleDraft, attestation: EpistemicRoleAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation,EpistemicRoleAuthorityAttestation):
            raise TypeError("attestation must be EpistemicRoleAuthorityAttestation")
        if attestation.schema!=_EPISTEMIC_ROLE_ATTESTATION_SCHEMA:
            raise ValueError("unsupported epistemic role authority attestation schema")
        if attestation.authority_id in _RESERVED_EXTERNAL_ROLE_AUTHORITIES:
            raise ValueError("controller-owned epistemic-role authority IDs cannot be used as external attestors")
        for name in ("attestation_id","authority_id","evidence_id","epistemic_role","role_commitment",
                     "issued_at","valid_from","valid_to"):
            value=getattr(attestation,name)
            if not isinstance(value,str) or not value.strip():
                raise ValueError(f"epistemic role attestation {name} must be nonblank")
        if attestation.evidence_id!=role.evidence_id or attestation.epistemic_role!=role.epistemic_role:
            raise ValueError("epistemic role attestation subject mismatch")
        if attestation.role_commitment!=role.role_commitment:
            raise ValueError("attestation does not bind this EpistemicRoleDraft")
        try:
            issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from)
            vt=_engine.strict_date(attestation.valid_to); when=_engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid epistemic role attestation dates") from exc
        if vf>vt or issued>when or not (vf<=when<=vt):
            raise ValueError("epistemic role attestation is not applicable at as_of")

    @_requires_host_trust("EPISTEMIC_ROLE")
    def install_verified_epistemic_role(
        self, evidence: EvidenceRecordDraft, role: EpistemicRoleDraft,
        attestation: EpistemicRoleAuthorityAttestation, verifier: EpistemicRoleAuthorityVerifier,
        *, as_of: str
    ) -> EpistemicRoleInstallation:
        evidence=self._canonical_evidence_draft(evidence)
        expected=self.draft_epistemic_role(evidence,epistemic_role=role.epistemic_role)
        if expected!=role: raise ValueError("EpistemicRoleDraft is not canonical for this evidence")
        if self.inspect_evidence_authority(evidence).runtime_verified is not True:
            raise ValueError("evidence authority must be runtime verified before epistemic-role issuance")
        prov=self.provenance_commitment(evidence)
        if (_VERIFIED_PROVENANCE_RUNTIME.get(evidence.evidence_id)!=prov
            and _DEVELOPER_PROVENANCE_RUNTIME.get(evidence.evidence_id)!=prov):
            raise ValueError("provenance authority must be runtime verified before epistemic-role issuance")
        sid=evidence.source_semantics_id
        if sid is not None:
            row=_engine.SOURCE_SEMANTICS_REGISTRY.get(sid)
            if not isinstance(row,dict): raise ValueError("source semantics must be installed before epistemic-role issuance")
            rh=_engine.canonical_hash(row)
            if (_VERIFIED_SOURCE_SEMANTICS_RUNTIME.get(sid)!=rh
                and _DEVELOPER_SOURCE_SEMANTICS_RUNTIME.get(sid)!=rh):
                raise ValueError("source semantics authority must be runtime verified before epistemic-role issuance")
        self._validate_epistemic_role_attestation(role,attestation,as_of=as_of)
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=role,evidence=evidence)
        except Exception as exc: raise ValueError("epistemic role authority verifier failed closed") from exc
        if (not isinstance(verdict,EpistemicRoleAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
            or verdict.evidence_id!=evidence.evidence_id or verdict.epistemic_role!=role.epistemic_role):
            raise ValueError("epistemic role verifier did not approve exact attestation")
        if not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip():
            raise ValueError("epistemic role verifier_id must be nonblank")
        if not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip():
            raise ValueError("epistemic role verification_method must be nonblank")
        raw=self.evidence_record_mapping(evidence)
        before=set(_engine.EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY)
        with _ENGINE_LOCK:
            cert=_engine._controller_issue_evidence_epistemic_role(
                raw,role.epistemic_role,issuer_grant_id=role.issuer_grant_id,
                _capability=_engine._EVIDENCE_ROLE_ISSUER_CAPABILITY,
            )
            if cert is None: raise ValueError("controller did not issue epistemic role certificate")
            artifact=_engine.EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
            if artifact is None or not _engine.validate_evidence_epistemic_role_certificate(cert,cert.assertion_commitment):
                raise ValueError("issued epistemic role certificate is not runtime-authorized")
            ext=_engine.canonical_hash({
                "role_commitment":role.role_commitment,"role_record_id":cert.role_record_id,
                "authorization_artifact_id":cert.authorization_artifact_id,
                "authorization_artifact_fingerprint":cert.authorization_artifact_fingerprint,
            })
            _VERIFIED_EPISTEMIC_ROLE_RUNTIME[evidence.evidence_id]=ext
            _VERIFIED_EPISTEMIC_ROLE_METADATA[evidence.evidence_id]={
                "role_record_id":cert.role_record_id,"epistemic_role":role.epistemic_role,
                "authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,
                "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,
                "role_commitment":role.role_commitment,
            }
            idem=cert.authorization_artifact_id in before
        return EpistemicRoleInstallation(
            evidence.evidence_id,role.epistemic_role,cert.role_record_id,cert.authorization_artifact_id,
            cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,
            verdict.verification_method,role.role_commitment,idem,
        )

    def evidence_with_epistemic_role(
        self, evidence: EvidenceRecordDraft, installation: EpistemicRoleInstallation
    ) -> EvidenceRecordDraft:
        evidence=self._canonical_evidence_draft(evidence)
        if installation.evidence_id!=evidence.evidence_id:
            raise ValueError("installation is for a different evidence_id")
        return replace(evidence,epistemic_role_record_id=installation.role_record_id)

    def inspect_epistemic_role_authority(self, evidence: EvidenceRecordDraft) -> EpistemicRoleAuthorityInspection:
        evidence=self._canonical_evidence_draft(evidence)
        rid=evidence.epistemic_role_record_id
        if rid is None:
            return EpistemicRoleAuthorityInspection(evidence.evidence_id,None,None,"ABSENT",False,False,False,None,None,None)
        cert=_engine.EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(rid)
        if cert is None:
            return EpistemicRoleAuthorityInspection(evidence.evidence_id,rid,None,"UNRESOLVED",False,False,False,None,None,None)
        artifact=_engine.EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
        engine_runtime=bool(artifact is not None and _engine.validate_evidence_epistemic_role_certificate(cert,cert.assertion_commitment))
        ext_expected=None
        if artifact is not None:
            role=self.draft_epistemic_role(replace(evidence,epistemic_role_record_id=None),epistemic_role=cert.epistemic_role)
            ext_expected=_engine.canonical_hash({
                "role_commitment":role.role_commitment,"role_record_id":cert.role_record_id,
                "authorization_artifact_id":cert.authorization_artifact_id,
                "authorization_artifact_fingerprint":cert.authorization_artifact_fingerprint,
            })
        external=ext_expected is not None and (
            _VERIFIED_EPISTEMIC_ROLE_RUNTIME.get(evidence.evidence_id)==ext_expected
            or _DEVELOPER_EPISTEMIC_ROLE_RUNTIME.get(evidence.evidence_id)==ext_expected)
        meta=_VERIFIED_EPISTEMIC_ROLE_METADATA.get(evidence.evidence_id,{})
        state=("INSTALLED_VERIFIED_RUNTIME" if engine_runtime and external else
               "INSTALLED_ENGINE_RUNTIME_ONLY" if engine_runtime else "INSTALLED_NOT_RUNTIME_AUTHORIZED")
        return EpistemicRoleAuthorityInspection(
            evidence.evidence_id,rid,cert.epistemic_role,state,True,engine_runtime,external,
            meta.get("authority_id"),meta.get("attestation_id"),meta.get("verifier_id"),
        )

    @_requires_host_trust("EPISTEMIC_ROLE")
    def reverify_installed_epistemic_role(
        self, evidence: EvidenceRecordDraft, role: EpistemicRoleDraft,
        attestation: EpistemicRoleAuthorityAttestation, verifier: EpistemicRoleAuthorityVerifier,
        *, as_of: str
    ) -> EpistemicRoleAuthorityInspection:
        evidence=self._canonical_evidence_draft(evidence)
        if evidence.epistemic_role_record_id is None:
            raise ValueError("evidence has no installed epistemic role reference")
        base=replace(evidence,epistemic_role_record_id=None)
        expected=self.draft_epistemic_role(base,epistemic_role=role.epistemic_role)
        if expected!=role: raise ValueError("EpistemicRoleDraft is not canonical for installed evidence")
        self._validate_epistemic_role_attestation(role,attestation,as_of=as_of)
        cert=_engine.EVIDENCE_EPISTEMIC_ROLE_CERTIFICATE_REGISTRY.get(evidence.epistemic_role_record_id)
        if cert is None or cert.epistemic_role!=role.epistemic_role:
            raise ValueError("installed epistemic role does not match draft")
        artifact=_engine.EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
        if artifact is None or not _engine.validate_evidence_epistemic_role_certificate(cert,cert.assertion_commitment):
            raise ValueError("engine epistemic role runtime authority is not active")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=role,evidence=base)
        except Exception as exc: raise ValueError("epistemic role authority verifier failed closed") from exc
        if (not isinstance(verdict,EpistemicRoleAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
            or verdict.evidence_id!=evidence.evidence_id or verdict.epistemic_role!=role.epistemic_role):
            raise ValueError("epistemic role verifier did not re-approve exact attestation")
        ext=_engine.canonical_hash({
            "role_commitment":role.role_commitment,"role_record_id":cert.role_record_id,
            "authorization_artifact_id":cert.authorization_artifact_id,
            "authorization_artifact_fingerprint":cert.authorization_artifact_fingerprint,
        })
        _VERIFIED_EPISTEMIC_ROLE_RUNTIME[evidence.evidence_id]=ext
        _VERIFIED_EPISTEMIC_ROLE_METADATA[evidence.evidence_id]={
            "role_record_id":cert.role_record_id,"epistemic_role":role.epistemic_role,
            "authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,
            "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,
            "role_commitment":role.role_commitment,
        }
        return self.inspect_epistemic_role_authority(evidence)

    def _evidence_authority_role_integration_errors(
        self, evidence: Sequence[Mapping[str, Any]]
    ) -> list[dict[str, Any]]:
        errors=[]
        for index,raw in enumerate(evidence,1):
            if not isinstance(raw,Mapping): continue
            draft=self._draft_evidence_from_mapping(raw)
            if draft is None: continue
            try: authority_commitment=self.evidence_authority_commitment(draft)
            except Exception:
                errors.append({"type":"EVIDENCE_AUTHORITY_POLICY_UNRESOLVED","evidence_id":draft.evidence_id}); continue
            if (_VERIFIED_EVIDENCE_AUTHORITY_RUNTIME.get(draft.evidence_id)!=authority_commitment
                and _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME.get(draft.evidence_id)!=authority_commitment):
                errors.append({"type":"EVIDENCE_AUTHORITY_RUNTIME_NOT_VERIFIED","evidence_id":draft.evidence_id}); continue
            rid=draft.epistemic_role_record_id
            if rid is None:
                errors.append({"type":"EPISTEMIC_ROLE_NOT_INSTALLED","evidence_id":draft.evidence_id}); continue
            inspection=self.inspect_epistemic_role_authority(draft)
            if not inspection.engine_runtime_authorized:
                errors.append({"type":"EPISTEMIC_ROLE_ENGINE_RUNTIME_NOT_AUTHORIZED","evidence_id":draft.evidence_id,"role_record_id":rid})
            elif not inspection.external_runtime_verified:
                errors.append({"type":"EPISTEMIC_ROLE_EXTERNAL_RUNTIME_NOT_VERIFIED","evidence_id":draft.evidence_id,"role_record_id":rid})
        return errors

    def _canonical_dependency_evidence(self, evidence: Sequence[EvidenceRecordDraft]) -> tuple[EvidenceRecordDraft, ...]:
        rows=tuple(self._canonical_evidence_draft(x) for x in evidence)
        ids=tuple(x.evidence_id for x in rows)
        if len(rows)<2 or len(set(ids))!=len(ids):
            raise ValueError("dependency relation requires at least two unique evidence records")
        return tuple(sorted(rows,key=lambda x:x.evidence_id))

    def _trusted_dependency_facts(self, evidence: Sequence[EvidenceRecordDraft]) -> tuple[Any, ...]:
        rows=self._canonical_dependency_evidence(evidence)
        raw=[self.evidence_record_mapping(x) for x in rows]
        errs=[]
        errs.extend(self._identity_integration_errors(raw,{}))
        errs.extend(self._provenance_source_semantics_integration_errors(raw))
        errs.extend(self._evidence_authority_role_integration_errors(raw))
        if errs:
            raise ValueError(f"dependency evidence prerequisites are not externally/runtime verified: {errs}")
        facts=[]
        for i,r in enumerate(raw,1):
            fact,fe=_engine.normalize_fact(r,i)
            if fact is None or fe:
                raise ValueError(f"dependency evidence could not normalize as trusted fact: {fe}")
            facts.append(fact)
        return tuple(sorted(facts,key=lambda x:x.evidence_id))

    def _require_retrieval_runtime_verified(self, retrieval_scope_id: str) -> None:
        if retrieval_scope_id == "*": return
        row=_engine.RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope_id)
        if not isinstance(row,dict): raise ValueError("retrieval scope is not installed")
        rh=_engine.canonical_hash(row); aid=row.get("retrieval_authority_id")
        if aid=="LOCAL_RETRIEVAL_AUTHORITY":
            if _DEVELOPER_FIXTURE_RUNTIME.get(retrieval_scope_id)!=rh:
                raise ValueError("developer retrieval fixture runtime is not active")
        elif row.get("retrieval_authority_attestation_id") is None:
            raise ValueError("external retrieval authority is unattested")
        elif _VERIFIED_RETRIEVAL_RUNTIME.get(retrieval_scope_id)!=rh:
            raise ValueError("retrieval authority runtime is not verified")

    @staticmethod
    def _validate_external_relation_attestation_dates(attestation: Any, *, as_of: str) -> None:
        try:
            issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from)
            vt=_engine.strict_date(attestation.valid_to); when=_engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid dependency authority attestation dates") from exc
        if vf>vt or issued>when or not (vf<=when<=vt):
            raise ValueError("dependency authority attestation is not applicable at as_of")

    def _canonical_failure_domain_topology(self, draft: FailureDomainTopologyDraft) -> tuple[tuple[tuple[str,str],...], tuple[tuple[str,str],...], dict[str,str], dict[str,tuple[str,...]]]:
        if not isinstance(draft, FailureDomainTopologyDraft):
            raise TypeError("draft must be FailureDomainTopologyDraft")
        aliases = tuple(draft.aliases)
        parents = tuple(draft.parents)
        if any(not (isinstance(x, tuple) and len(x)==2 and all(isinstance(v,str) and v.strip() for v in x)) for x in aliases + parents):
            raise ValueError("failure-domain topology entries must be nonblank string pairs")
        if len(aliases) != len(set(aliases)) or len(parents) != len(set(parents)):
            raise ValueError("duplicate failure-domain topology entry")
        amap: dict[str,str] = {}
        for alias, canonical in aliases:
            if alias == canonical or alias in amap:
                raise ValueError("invalid or duplicate failure-domain alias")
            amap[alias] = canonical
        def resolve(node: str) -> str:
            seen=set(); cur=node
            while cur in amap:
                if cur in seen: raise ValueError("failure-domain alias cycle")
                seen.add(cur); cur=amap[cur]
            return cur
        for a in amap: resolve(a)
        pmap: dict[str,set[str]] = {}
        for child,parent in parents:
            c=resolve(child); p=resolve(parent)
            if c == p: raise ValueError("invalid failure-domain parent")
            pmap.setdefault(c,set()).add(p)
        def closure(node: str) -> set[str]:
            out=set(); stack=[node]
            while stack:
                cur=stack.pop()
                if cur in out: continue
                out.add(cur)
                stack.extend(pmap.get(cur,()))
            return out
        for child, ps in pmap.items():
            for parent in ps:
                if child in closure(parent): raise ValueError("failure-domain parent cycle")
        canonical_aliases=tuple(sorted(amap.items()))
        canonical_parents=tuple(sorted((c,p) for c,ps in pmap.items() for p in ps))
        expected_parent={c:tuple(sorted(ps)) for c,ps in sorted(pmap.items())}
        return canonical_aliases, canonical_parents, dict(canonical_aliases), expected_parent

    def draft_generic_equivalence(
        self, *, equivalence_id: str, left_node_type: str, left_dimension: str,
        right_node_type: str, right_dimension: str, semantic_node_type: str,
        semantic_dimension: str, identifier_semantics: str, scope_id: str = "*",
        valid_from: str = "2000-01-01", valid_to: str = "2099-12-31",
    ) -> GenericEquivalenceDraft:
        vals=(equivalence_id,left_node_type,right_node_type,semantic_node_type,semantic_dimension,identifier_semantics,scope_id,valid_from,valid_to)
        if not all(isinstance(x,str) and x.strip() for x in vals):
            raise ValueError("invalid generic equivalence draft")
        if not isinstance(left_dimension,str) or not isinstance(right_dimension,str):
            raise ValueError("invalid generic equivalence dimensions")
        if left_node_type not in _engine.DEPENDENCY_NODE_TYPES or right_node_type not in _engine.DEPENDENCY_NODE_TYPES or semantic_node_type not in _engine.DEPENDENCY_NODE_TYPES:
            raise ValueError("invalid generic equivalence node type")
        if identifier_semantics not in set(_engine.GENERIC_RELATION_SOURCE_IDENTITY_POLICY.get("allowed_identifier_semantics",())):
            raise ValueError("invalid identifier semantics")
        specs=_engine._equivalence_authorization_specs_for_classes(left_node_type,left_dimension,right_node_type,right_dimension)
        if not specs or (semantic_node_type,semantic_dimension,identifier_semantics) not in set(specs):
            raise ValueError("generic equivalence semantic class is not engine-authorized")
        try:
            if _engine.strict_date(valid_from)>_engine.strict_date(valid_to): raise ValueError
        except Exception as exc:
            raise ValueError("invalid generic equivalence validity") from exc
        return GenericEquivalenceDraft(equivalence_id,left_node_type,left_dimension,right_node_type,right_dimension,semantic_node_type,semantic_dimension,identifier_semantics,scope_id,valid_from,valid_to)

    def generic_equivalence_commitment(self,draft:GenericEquivalenceDraft) -> str:
        if not isinstance(draft,GenericEquivalenceDraft): raise TypeError("draft must be GenericEquivalenceDraft")
        payload={
            "schema":"CFC_GENERIC_EQUIVALENCE_DRAFT_V1",
            "draft":draft.__dict__,
            "policy_hash":_engine.generic_relation_source_identity_policy_hash(),
            "ontology_id":_engine.PINNED_DEPENDENCY_ONTOLOGY_SPEC["ontology_id"],
            "persistence_version":_engine.PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        }
        return _engine.canonical_hash(payload)

    def _generic_equivalence_expected_row(self,draft:GenericEquivalenceDraft) -> dict[str,Any]:
        return {
            "equivalence_id":draft.equivalence_id,"left_node_type":draft.left_node_type,"left_dimension":draft.left_dimension,
            "right_node_type":draft.right_node_type,"right_dimension":draft.right_dimension,"semantic_node_type":draft.semantic_node_type,
            "semantic_dimension":draft.semantic_dimension,"identifier_semantics":draft.identifier_semantics,"scope_id":draft.scope_id,
            "ontology_id":_engine.PINNED_DEPENDENCY_ONTOLOGY_SPEC["ontology_id"],"policy_id":_engine.GENERIC_RELATION_SOURCE_IDENTITY_POLICY["policy_id"],
            "authorizer_id":_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY,"valid_from":draft.valid_from,"valid_to":draft.valid_to,
        }

    def _validate_generic_equivalence_attestation(self,draft,attestation,*,as_of):
        if not isinstance(attestation,GenericEquivalenceAuthorityAttestation): raise TypeError("attestation must be GenericEquivalenceAuthorityAttestation")
        if attestation.schema!=_GENERIC_EQUIVALENCE_ATTESTATION_SCHEMA: raise ValueError("invalid generic equivalence attestation schema")
        if attestation.authority_id==_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY: raise ValueError("reserved generic representation authority")
        if not all(isinstance(x,str) and x.strip() for x in (attestation.attestation_id,attestation.authority_id,attestation.issued_at,attestation.valid_from,attestation.valid_to)):
            raise ValueError("invalid generic equivalence attestation")
        try:
            now=_engine.strict_date(as_of); issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from); vt=_engine.strict_date(attestation.valid_to)
        except Exception as exc: raise ValueError("invalid generic equivalence attestation date") from exc
        if issued>now or vf>now or now>vt or vf>vt: raise ValueError("generic equivalence attestation not applicable")
        expected=self.generic_equivalence_commitment(draft)
        if attestation.equivalence_commitment!=expected: raise ValueError("generic equivalence commitment mismatch")
        return expected

    def _generic_equivalence_runtime_fingerprint(self,equivalence_id:str) -> str | None:
        row=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(equivalence_id)
        cert=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(equivalence_id)
        if not isinstance(row,dict) or not _engine.validate_generic_representation_equivalence_certificate(cert,equivalence_id): return None
        return _engine.canonical_hash({"row":row,"certificate":_engine.asdict(cert)})

    @_requires_host_trust("GENERIC_EQUIVALENCE")
    def install_verified_generic_equivalence(self,draft:GenericEquivalenceDraft,attestation:GenericEquivalenceAuthorityAttestation,verifier:GenericEquivalenceAuthorityVerifier,*,as_of:str) -> GenericEquivalenceInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_generic_equivalence_attestation(draft,attestation,as_of=as_of)
            try: verdict=verifier.verify(attestation,draft=draft)
            except Exception as exc: raise ValueError("generic equivalence verifier failed closed") from exc
            if (not isinstance(verdict,GenericEquivalenceAuthorityVerdict) or verdict.approved is not True
                or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
                or verdict.equivalence_id!=draft.equivalence_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip()
                or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
                raise ValueError("generic equivalence verifier verdict mismatch")
            expected_row=self._generic_equivalence_expected_row(draft)
            row=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(draft.equivalence_id)
            cert=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(draft.equivalence_id)
            idempotent=row is not None
            if row is None:
                if cert is not None: raise ValueError("orphan generic equivalence certificate")
                try:
                    _engine.register_generic_representation_equivalence(
                        draft.equivalence_id,draft.left_node_type,draft.left_dimension,draft.right_node_type,draft.right_dimension,
                        draft.semantic_node_type,draft.semantic_dimension,draft.identifier_semantics,draft.scope_id,
                        _RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY,draft.valid_from,draft.valid_to)
                    cert=_engine.issue_generic_representation_equivalence_certificate(draft.equivalence_id)
                    row=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(draft.equivalence_id)
                    if row!=expected_row or not _engine.validate_generic_representation_equivalence_certificate(cert,draft.equivalence_id):
                        raise ValueError("engine generic equivalence issuance mismatch")
                except Exception:
                    _engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.pop(draft.equivalence_id,None)
                    _engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.pop(draft.equivalence_id,None)
                    raise
            else:
                if row!=expected_row or not _engine.validate_generic_representation_equivalence_certificate(cert,draft.equivalence_id):
                    raise ValueError("installed generic equivalence differs from attested draft")
            fp=self._generic_equivalence_runtime_fingerprint(draft.equivalence_id)
            if fp is None: raise ValueError("generic equivalence certificate invalid")
            _VERIFIED_GENERIC_EQUIVALENCE_RUNTIME[draft.equivalence_id]=fp
            _VERIFIED_GENERIC_EQUIVALENCE_METADATA[draft.equivalence_id]={
                "equivalence_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,
                "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"runtime_fingerprint":fp,
            }
            return GenericEquivalenceInstallation(draft.equivalence_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,expected,True,idempotent)

    @_requires_host_trust("GENERIC_EQUIVALENCE")
    def reverify_installed_generic_equivalence(self,draft:GenericEquivalenceDraft,attestation:GenericEquivalenceAuthorityAttestation,verifier:GenericEquivalenceAuthorityVerifier,*,as_of:str) -> GenericEquivalenceInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_generic_equivalence_attestation(draft,attestation,as_of=as_of)
            row=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(draft.equivalence_id)
            cert=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(draft.equivalence_id)
            if row!=self._generic_equivalence_expected_row(draft) or not _engine.validate_generic_representation_equivalence_certificate(cert,draft.equivalence_id):
                raise ValueError("installed generic equivalence differs from attested draft")
            verdict=verifier.verify(attestation,draft=draft)
            if (not isinstance(verdict,GenericEquivalenceAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id
                or verdict.authority_id!=attestation.authority_id or verdict.equivalence_id!=draft.equivalence_id
                or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
                raise ValueError("generic equivalence verifier verdict mismatch")
            fp=self._generic_equivalence_runtime_fingerprint(draft.equivalence_id)
            if fp is None: raise ValueError("generic equivalence certificate invalid")
            _VERIFIED_GENERIC_EQUIVALENCE_RUNTIME[draft.equivalence_id]=fp
            _VERIFIED_GENERIC_EQUIVALENCE_METADATA[draft.equivalence_id]={"equivalence_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,"verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"runtime_fingerprint":fp}
            return GenericEquivalenceInstallation(draft.equivalence_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,expected,True,True)

    def inspect_generic_equivalence(self,draft:GenericEquivalenceDraft) -> GenericEquivalenceInspection:
        with _ENGINE_LOCK:
            row=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.get(draft.equivalence_id)
            cert=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(draft.equivalence_id)
            installed=isinstance(row,dict); exact=installed and row==self._generic_equivalence_expected_row(draft)
            valid=exact and _engine.validate_generic_representation_equivalence_certificate(cert,draft.equivalence_id)
            fp=self._generic_equivalence_runtime_fingerprint(draft.equivalence_id) if valid else None
            meta=_VERIFIED_GENERIC_EQUIVALENCE_METADATA.get(draft.equivalence_id,{})
            runtime=bool(fp and _VERIFIED_GENERIC_EQUIVALENCE_RUNTIME.get(draft.equivalence_id)==fp and meta.get("runtime_fingerprint")==fp and meta.get("equivalence_commitment")==self.generic_equivalence_commitment(draft))
            state="DRAFT_ONLY" if not installed else ("INSTALLED_VERIFIED_RUNTIME" if runtime else "INSTALLED_NOT_RUNTIME_VERIFIED") if valid else "INSTALLED_INVALID_OR_MISMATCH"
            return GenericEquivalenceInspection(draft.equivalence_id,state,installed,bool(valid),runtime,meta.get("authority_id"),meta.get("attestation_id"),meta.get("verifier_id"))

    def draft_generic_distinctness(self, *, distinctness_id:str, left_node_type:str,left_dimension:str,left_identifier:str,
                                   right_node_type:str,right_dimension:str,right_identifier:str,retrieval_scope_id:str,as_of_date:str) -> GenericDistinctnessDraft:
        vals=(distinctness_id,left_node_type,left_identifier,right_node_type,right_identifier,retrieval_scope_id,as_of_date)
        if not all(isinstance(x,str) and x.strip() for x in vals) or not isinstance(left_dimension,str) or not isinstance(right_dimension,str):
            raise ValueError("invalid generic distinctness draft")
        try: _engine.strict_date(as_of_date)
        except Exception as exc: raise ValueError("invalid generic distinctness as_of_date") from exc
        raw_a=_engine.typed_node(left_node_type,left_dimension,left_identifier); raw_b=_engine.typed_node(right_node_type,right_dimension,right_identifier)
        if raw_a is None or raw_b is None or _engine._candidate_semantic_spec_for_nodes(raw_a,raw_b) is None:
            raise ValueError("generic distinctness requires an exact engine-discovered candidate pair")
        left,right=_engine._canonical_raw_node_pair(raw_a,raw_b)
        return GenericDistinctnessDraft(distinctness_id,left[0],left[1],left[2],right[0],right[1],right[2],retrieval_scope_id,as_of_date)

    def generic_distinctness_commitment(self,draft:GenericDistinctnessDraft) -> str:
        if not isinstance(draft,GenericDistinctnessDraft): raise TypeError("draft must be GenericDistinctnessDraft")
        payload={"schema":"CFC_GENERIC_DISTINCTNESS_DRAFT_V1","draft":draft.__dict__,"policy_hash":_engine.generic_relation_source_identity_policy_hash(),"ontology_id":_engine.PINNED_DEPENDENCY_ONTOLOGY_SPEC["ontology_id"],"persistence_version":_engine.PERSISTENCE_HISTORY_COMMITMENT_VERSION}
        return _engine.canonical_hash(payload)

    def _generic_distinctness_expected_row(self,draft:GenericDistinctnessDraft) -> dict[str,Any]:
        raw_a=_engine.typed_node(draft.left_node_type,draft.left_dimension,draft.left_identifier); raw_b=_engine.typed_node(draft.right_node_type,draft.right_dimension,draft.right_identifier)
        spec=_engine._candidate_semantic_spec_for_nodes(raw_a,raw_b)
        if spec is None: raise ValueError("generic distinctness candidate no longer engine-valid")
        left,right=_engine._canonical_raw_node_pair(raw_a,raw_b); st,sd,isem,_ident,_basis=spec
        return {"distinctness_id":draft.distinctness_id,"left_node_type":left[0],"left_dimension":left[1],"left_identifier":left[2],"right_node_type":right[0],"right_dimension":right[1],"right_identifier":right[2],"semantic_node_type":st,"semantic_dimension":sd,"identifier_semantics":isem,"retrieval_scope_id":draft.retrieval_scope_id,"as_of_date":draft.as_of_date,"ontology_id":_engine.PINNED_DEPENDENCY_ONTOLOGY_SPEC["ontology_id"],"policy_id":_engine.GENERIC_RELATION_SOURCE_IDENTITY_POLICY["policy_id"],"authorizer_id":_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY}

    def _validate_generic_distinctness_attestation(self,draft,attestation,*,as_of):
        if not isinstance(attestation,GenericDistinctnessAuthorityAttestation): raise TypeError("attestation must be GenericDistinctnessAuthorityAttestation")
        if attestation.schema!=_GENERIC_DISTINCTNESS_ATTESTATION_SCHEMA: raise ValueError("invalid generic distinctness attestation schema")
        if attestation.authority_id==_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY: raise ValueError("reserved generic representation authority")
        if not all(isinstance(x,str) and x.strip() for x in (attestation.attestation_id,attestation.authority_id,attestation.issued_at,attestation.valid_from,attestation.valid_to)): raise ValueError("invalid generic distinctness attestation")
        try: now=_engine.strict_date(as_of); issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from); vt=_engine.strict_date(attestation.valid_to)
        except Exception as exc: raise ValueError("invalid generic distinctness attestation date") from exc
        if issued>now or vf>now or now>vt or vf>vt: raise ValueError("generic distinctness attestation not applicable")
        expected=self.generic_distinctness_commitment(draft)
        if attestation.distinctness_commitment!=expected: raise ValueError("generic distinctness commitment mismatch")
        return expected

    def _generic_distinctness_runtime_fingerprint(self,distinctness_id:str) -> str | None:
        row=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(distinctness_id); cert=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(distinctness_id)
        if not isinstance(row,dict) or not _engine.validate_generic_representation_distinctness_certificate(cert,distinctness_id): return None
        return _engine.canonical_hash({"row":row,"certificate":_engine.asdict(cert)})

    @_requires_host_trust("GENERIC_DISTINCTNESS")
    def install_verified_generic_distinctness(self,draft:GenericDistinctnessDraft,attestation:GenericDistinctnessAuthorityAttestation,verifier:GenericDistinctnessAuthorityVerifier,*,as_of:str) -> GenericDistinctnessInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_generic_distinctness_attestation(draft,attestation,as_of=as_of)
            try: verdict=verifier.verify(attestation,draft=draft)
            except Exception as exc: raise ValueError("generic distinctness verifier failed closed") from exc
            if (not isinstance(verdict,GenericDistinctnessAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id
                or verdict.authority_id!=attestation.authority_id or verdict.distinctness_id!=draft.distinctness_id
                or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("generic distinctness verifier verdict mismatch")
            expected_row=self._generic_distinctness_expected_row(draft)
            row=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(draft.distinctness_id); cert=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(draft.distinctness_id)
            idempotent=row is not None
            if row is None:
                if cert is not None: raise ValueError("orphan generic distinctness certificate")
                try:
                    _engine.register_generic_representation_distinctness(draft.distinctness_id,draft.left_node_type,draft.left_dimension,draft.left_identifier,draft.right_node_type,draft.right_dimension,draft.right_identifier,draft.retrieval_scope_id,draft.as_of_date,_RESERVED_ENGINE_GENERIC_REPRESENTATION_AUTHORITY)
                    cert=_engine.issue_generic_representation_distinctness_certificate(draft.distinctness_id); row=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(draft.distinctness_id)
                    if row!=expected_row or not _engine.validate_generic_representation_distinctness_certificate(cert,draft.distinctness_id): raise ValueError("engine generic distinctness issuance mismatch")
                except Exception:
                    _engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.pop(draft.distinctness_id,None); _engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.pop(draft.distinctness_id,None); raise
            else:
                if row!=expected_row or not _engine.validate_generic_representation_distinctness_certificate(cert,draft.distinctness_id): raise ValueError("installed generic distinctness differs from attested draft")
            fp=self._generic_distinctness_runtime_fingerprint(draft.distinctness_id)
            if fp is None: raise ValueError("generic distinctness certificate invalid")
            _VERIFIED_GENERIC_DISTINCTNESS_RUNTIME[draft.distinctness_id]=fp
            _VERIFIED_GENERIC_DISTINCTNESS_METADATA[draft.distinctness_id]={"distinctness_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,"verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"runtime_fingerprint":fp}
            return GenericDistinctnessInstallation(draft.distinctness_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,expected,True,idempotent)

    @_requires_host_trust("GENERIC_DISTINCTNESS")
    def reverify_installed_generic_distinctness(self,draft:GenericDistinctnessDraft,attestation:GenericDistinctnessAuthorityAttestation,verifier:GenericDistinctnessAuthorityVerifier,*,as_of:str) -> GenericDistinctnessInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_generic_distinctness_attestation(draft,attestation,as_of=as_of)
            row=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(draft.distinctness_id); cert=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(draft.distinctness_id)
            if row!=self._generic_distinctness_expected_row(draft) or not _engine.validate_generic_representation_distinctness_certificate(cert,draft.distinctness_id): raise ValueError("installed generic distinctness differs from attested draft")
            verdict=verifier.verify(attestation,draft=draft)
            if (not isinstance(verdict,GenericDistinctnessAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.distinctness_id!=draft.distinctness_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("generic distinctness verifier verdict mismatch")
            fp=self._generic_distinctness_runtime_fingerprint(draft.distinctness_id)
            if fp is None: raise ValueError("generic distinctness certificate invalid")
            _VERIFIED_GENERIC_DISTINCTNESS_RUNTIME[draft.distinctness_id]=fp
            _VERIFIED_GENERIC_DISTINCTNESS_METADATA[draft.distinctness_id]={"distinctness_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,"verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"runtime_fingerprint":fp}
            return GenericDistinctnessInstallation(draft.distinctness_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,expected,True,True)

    def inspect_generic_distinctness(self,draft:GenericDistinctnessDraft) -> GenericDistinctnessInspection:
        with _ENGINE_LOCK:
            row=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.get(draft.distinctness_id); cert=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(draft.distinctness_id)
            installed=isinstance(row,dict); exact=installed and row==self._generic_distinctness_expected_row(draft)
            valid=exact and _engine.validate_generic_representation_distinctness_certificate(cert,draft.distinctness_id)
            fp=self._generic_distinctness_runtime_fingerprint(draft.distinctness_id) if valid else None; meta=_VERIFIED_GENERIC_DISTINCTNESS_METADATA.get(draft.distinctness_id,{})
            runtime=bool(fp and _VERIFIED_GENERIC_DISTINCTNESS_RUNTIME.get(draft.distinctness_id)==fp and meta.get("runtime_fingerprint")==fp and meta.get("distinctness_commitment")==self.generic_distinctness_commitment(draft))
            state="DRAFT_ONLY" if not installed else ("INSTALLED_VERIFIED_RUNTIME" if runtime else "INSTALLED_NOT_RUNTIME_VERIFIED") if valid else "INSTALLED_INVALID_OR_MISMATCH"
            return GenericDistinctnessInspection(draft.distinctness_id,state,installed,bool(valid),runtime,meta.get("authority_id"),meta.get("attestation_id"),meta.get("verifier_id"))

    def _generic_representation_integration_errors(self) -> list[dict[str,Any]]:
        if isinstance(self._trust_policy,_DynamicTestingHostTrustPolicy): return []
        errors=[]
        for eid,row in sorted(_engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY.items()):
            cert=_engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY.get(eid); fp=self._generic_equivalence_runtime_fingerprint(eid); meta=_VERIFIED_GENERIC_EQUIVALENCE_METADATA.get(eid)
            if not isinstance(row,dict) or not _engine.validate_generic_representation_equivalence_structure(row,eid) or not _engine.validate_generic_representation_equivalence_certificate(cert,eid): errors.append({"type":"GENERIC_EQUIVALENCE_INVALID","equivalence_id":eid}); continue
            if not isinstance(meta,dict) or fp is None or _VERIFIED_GENERIC_EQUIVALENCE_RUNTIME.get(eid)!=fp or meta.get("runtime_fingerprint")!=fp: errors.append({"type":"GENERIC_EQUIVALENCE_AUTHORITY_RUNTIME_NOT_VERIFIED","equivalence_id":eid})
        for eid in _engine.GENERIC_REPRESENTATION_EQUIVALENCE_CERTIFICATE_REGISTRY:
            if eid not in _engine.GENERIC_REPRESENTATION_EQUIVALENCE_REGISTRY: errors.append({"type":"GENERIC_EQUIVALENCE_ORPHAN_CERTIFICATE","equivalence_id":eid})
        for did,row in sorted(_engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY.items()):
            cert=_engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY.get(did); fp=self._generic_distinctness_runtime_fingerprint(did); meta=_VERIFIED_GENERIC_DISTINCTNESS_METADATA.get(did)
            if not isinstance(row,dict) or not _engine.validate_generic_representation_distinctness_certificate(cert,did): errors.append({"type":"GENERIC_DISTINCTNESS_INVALID","distinctness_id":did}); continue
            if not isinstance(meta,dict) or fp is None or _VERIFIED_GENERIC_DISTINCTNESS_RUNTIME.get(did)!=fp or meta.get("runtime_fingerprint")!=fp: errors.append({"type":"GENERIC_DISTINCTNESS_AUTHORITY_RUNTIME_NOT_VERIFIED","distinctness_id":did})
        for did in _engine.GENERIC_REPRESENTATION_DISTINCTNESS_CERTIFICATE_REGISTRY:
            if did not in _engine.GENERIC_REPRESENTATION_DISTINCTNESS_REGISTRY: errors.append({"type":"GENERIC_DISTINCTNESS_ORPHAN_CERTIFICATE","distinctness_id":did})
        return errors

    def draft_failure_domain_topology(self, *, aliases: Sequence[tuple[str,str]] = (), parents: Sequence[tuple[str,str]] = ()) -> FailureDomainTopologyDraft:
        draft=FailureDomainTopologyDraft(tuple(aliases),tuple(parents))
        a,p,_,_=self._canonical_failure_domain_topology(draft)
        return FailureDomainTopologyDraft(a,p)

    def failure_domain_topology_commitment(self, draft: FailureDomainTopologyDraft) -> str:
        aliases,parents,alias_map,parent_map=self._canonical_failure_domain_topology(draft)
        payload={
            "schema":"CFC_FAILURE_DOMAIN_TOPOLOGY_DRAFT_V1",
            "aliases":aliases,"parents":parents,
            "expected_alias_registry":tuple(sorted(alias_map.items())),
            "expected_parent_registry":tuple(sorted(parent_map.items())),
            "source_semantics_policy_hash":_engine.source_semantics_policy_hash(),
            "source_independence_policy_hash":_engine.source_independence_policy_hash(),
            "persistence_version":_engine.PERSISTENCE_HISTORY_COMMITMENT_VERSION,
        }
        return _engine.canonical_hash(payload)

    def _validate_failure_domain_topology_attestation(self,draft,attestation,*,as_of):
        if not isinstance(attestation,FailureDomainTopologyAttestation): raise TypeError("attestation must be FailureDomainTopologyAttestation")
        if attestation.schema != _FAILURE_DOMAIN_TOPOLOGY_ATTESTATION_SCHEMA: raise ValueError("invalid failure-domain topology attestation schema")
        if attestation.authority_id in _RESERVED_FAILURE_DOMAIN_TOPOLOGY_AUTHORITIES: raise ValueError("reserved failure-domain topology authority")
        if not all(isinstance(x,str) and x.strip() for x in (attestation.attestation_id,attestation.authority_id,attestation.issued_at,attestation.valid_from,attestation.valid_to)):
            raise ValueError("invalid failure-domain topology attestation")
        try:
            now=_engine.strict_date(as_of); issued=_engine.strict_date(attestation.issued_at); vf=_engine.strict_date(attestation.valid_from); vt=_engine.strict_date(attestation.valid_to)
        except Exception as exc: raise ValueError("invalid failure-domain topology attestation date") from exc
        if issued>now or vf>now or now>vt or vf>vt: raise ValueError("failure-domain topology attestation not applicable")
        expected=self.failure_domain_topology_commitment(draft)
        if attestation.topology_commitment != expected: raise ValueError("failure-domain topology commitment mismatch")
        return expected

    def _failure_domain_topology_registry_matches(self,draft:FailureDomainTopologyDraft) -> bool:
        _,_,alias_map,parent_map=self._canonical_failure_domain_topology(draft)
        return dict(_engine.FAILURE_DOMAIN_ALIAS_REGISTRY)==alias_map and dict(_engine.FAILURE_DOMAIN_PARENT_REGISTRY)==parent_map

    @_requires_host_trust("FAILURE_DOMAIN_TOPOLOGY")
    def install_verified_failure_domain_topology(self,draft:FailureDomainTopologyDraft,attestation:FailureDomainTopologyAttestation,verifier:FailureDomainTopologyVerifier,*,as_of:str) -> FailureDomainTopologyInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_failure_domain_topology_attestation(draft,attestation,as_of=as_of)
            verdict=verifier.verify(attestation,draft=draft)
            if not isinstance(verdict,FailureDomainTopologyVerdict) or not verdict.approved:
                raise ValueError("failure-domain topology verifier rejected attestation")
            if (verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
                or verdict.topology_commitment!=expected or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip()
                or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
                raise ValueError("failure-domain topology verifier verdict mismatch")
            exact_before=self._failure_domain_topology_registry_matches(draft)
            if not exact_before:
                old_a=copy.deepcopy(_engine.FAILURE_DOMAIN_ALIAS_REGISTRY); old_p=copy.deepcopy(_engine.FAILURE_DOMAIN_PARENT_REGISTRY)
                try:
                    _engine.FAILURE_DOMAIN_ALIAS_REGISTRY.clear(); _engine.FAILURE_DOMAIN_PARENT_REGISTRY.clear()
                    for alias,canonical in draft.aliases: _engine.register_failure_domain_alias(alias,canonical)
                    for child,parent in draft.parents: _engine.register_failure_domain_parent(child,parent)
                    if not self._failure_domain_topology_registry_matches(draft): raise ValueError("installed failure-domain topology mismatch")
                except Exception:
                    _engine.FAILURE_DOMAIN_ALIAS_REGISTRY.clear(); _engine.FAILURE_DOMAIN_ALIAS_REGISTRY.update(old_a)
                    _engine.FAILURE_DOMAIN_PARENT_REGISTRY.clear(); _engine.FAILURE_DOMAIN_PARENT_REGISTRY.update(old_p)
                    raise
            reg_hash=_engine.failure_domain_relation_registry_hash()
            _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME["GLOBAL"]=reg_hash
            _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA["GLOBAL"]={
                "topology_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,
                "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"registry_hash":reg_hash,
            }
            return FailureDomainTopologyInstallation(expected,reg_hash,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,exact_before,True)

    @_requires_host_trust("FAILURE_DOMAIN_TOPOLOGY")
    def reverify_installed_failure_domain_topology(self,draft:FailureDomainTopologyDraft,attestation:FailureDomainTopologyAttestation,verifier:FailureDomainTopologyVerifier,*,as_of:str) -> FailureDomainTopologyInstallation:
        with _ENGINE_LOCK:
            expected=self._validate_failure_domain_topology_attestation(draft,attestation,as_of=as_of)
            if not self._failure_domain_topology_registry_matches(draft): raise ValueError("installed failure-domain topology differs from attested draft")
            verdict=verifier.verify(attestation,draft=draft)
            if not isinstance(verdict,FailureDomainTopologyVerdict) or not verdict.approved: raise ValueError("failure-domain topology verifier rejected attestation")
            if (verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
                or verdict.topology_commitment!=expected or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip()
                or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
                raise ValueError("failure-domain topology verifier verdict mismatch")
            reg_hash=_engine.failure_domain_relation_registry_hash()
            _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME["GLOBAL"]=reg_hash
            _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA["GLOBAL"]={
                "topology_commitment":expected,"attestation_id":attestation.attestation_id,"authority_id":attestation.authority_id,
                "verifier_id":verdict.verifier_id,"verification_method":verdict.verification_method,"registry_hash":reg_hash,
            }
            return FailureDomainTopologyInstallation(expected,reg_hash,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,True,True)

    def inspect_failure_domain_topology(self,draft:FailureDomainTopologyDraft) -> FailureDomainTopologyInspection:
        with _ENGINE_LOCK:
            expected=self.failure_domain_topology_commitment(draft); reg_hash=_engine.failure_domain_relation_registry_hash(); exact=self._failure_domain_topology_registry_matches(draft)
            meta=_VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA.get("GLOBAL",{})
            runtime=exact and _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME.get("GLOBAL")==reg_hash and meta.get("topology_commitment")==expected and meta.get("registry_hash")==reg_hash
            return FailureDomainTopologyInspection(expected,reg_hash,exact,runtime,meta.get("attestation_id"),meta.get("authority_id"),meta.get("verifier_id"))

    def _failure_domain_topology_integration_errors(self) -> list[dict[str,Any]]:
        if isinstance(self._trust_policy,_DynamicTestingHostTrustPolicy): return []
        reg_hash=_engine.failure_domain_relation_registry_hash(); meta=_VERIFIED_FAILURE_DOMAIN_TOPOLOGY_METADATA.get("GLOBAL")
        if not isinstance(meta,dict): return [{"type":"FAILURE_DOMAIN_TOPOLOGY_AUTHORITY_UNATTESTED"}]
        if _VERIFIED_FAILURE_DOMAIN_TOPOLOGY_RUNTIME.get("GLOBAL")!=reg_hash or meta.get("registry_hash")!=reg_hash:
            return [{"type":"FAILURE_DOMAIN_TOPOLOGY_AUTHORITY_RUNTIME_NOT_VERIFIED"}]
        return []

    def draft_source_independence(
        self, *, independence_id: str, evidence_ids: Sequence[str], reason: str
    ) -> SourceIndependenceDraft:
        ids=tuple(sorted(set(evidence_ids or ())))
        if not isinstance(independence_id,str) or not independence_id.strip() or len(ids)!=2:
            raise ValueError("source independence requires a nonblank id and exactly two unique evidence_ids")
        if any(not isinstance(x,str) or not x.strip() for x in ids) or not isinstance(reason,str) or not reason.strip():
            raise ValueError("invalid source independence draft")
        return SourceIndependenceDraft(independence_id,ids,reason)

    def source_independence_commitment(
        self, draft: SourceIndependenceDraft, evidence: Sequence[EvidenceRecordDraft]
    ) -> str:
        if not isinstance(draft,SourceIndependenceDraft): raise TypeError("draft must be SourceIndependenceDraft")
        rows=self._canonical_dependency_evidence(evidence)
        if tuple(x.evidence_id for x in rows)!=draft.evidence_ids: raise ValueError("evidence does not match SourceIndependenceDraft")
        facts=self._trusted_dependency_facts(rows)
        return _engine.canonical_hash({
            "schema":"CFC_SOURCE_INDEPENDENCE_PROJECTION_V1","independence_id":draft.independence_id,
            "evidence_ids":draft.evidence_ids,"reason":draft.reason,
            "evidence_record_commitments":tuple(self.evidence_record_commitment(x) for x in rows),
            "source_failure_domain_certificate_ids":tuple(f.source_failure_domain.certificate_id for f in facts),
            "source_semantics_resolution_certificate_ids":tuple(f.source_semantics_resolution.certificate_id for f in facts),
            "provenance_certificate_ids":tuple(f.provenance.certificate_id for f in facts),
            "authority_certificate_ids":tuple(f.authority.certificate_id for f in facts),
            "source_independence_policy_hash":_engine.source_independence_policy_hash(),
            "source_semantics_policy_hash":_engine.source_semantics_policy_hash(),
            "failure_domain_relation_registry_hash":_engine.failure_domain_relation_registry_hash(),
        })

    def _validate_source_independence_attestation(self,draft,evidence,attestation,*,as_of):
        if not isinstance(attestation,SourceIndependenceAuthorityAttestation): raise TypeError("attestation must be SourceIndependenceAuthorityAttestation")
        if attestation.schema!=_SOURCE_INDEPENDENCE_ATTESTATION_SCHEMA: raise ValueError("unsupported source independence attestation schema")
        if attestation.authority_id==_RESERVED_ENGINE_SOURCE_INDEPENDENCE_AUTHORITY: raise ValueError("engine-local source independence authority cannot pose as external attestor")
        for name in ("attestation_id","authority_id","independence_commitment","issued_at","valid_from","valid_to"):
            v=getattr(attestation,name)
            if not isinstance(v,str) or not v.strip(): raise ValueError(f"source independence attestation {name} must be nonblank")
        expected=self.source_independence_commitment(draft,evidence)
        if attestation.independence_commitment!=expected: raise ValueError("attestation does not bind this source independence projection")
        self._validate_external_relation_attestation_dates(attestation,as_of=as_of)

    @staticmethod
    def _source_independence_runtime_commitment(independence_id: str) -> str | None:
        row=_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.get(independence_id)
        cert=_engine.SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.get(independence_id)
        if not isinstance(row,dict) or cert is None:return None
        return _engine.canonical_hash({"authorization":row,"certificate":_engine.asdict(cert)})

    @_requires_host_trust("SOURCE_INDEPENDENCE")
    def install_verified_source_independence(self,draft,evidence,attestation,verifier,*,as_of):
        rows=self._canonical_dependency_evidence(evidence); self._validate_source_independence_attestation(draft,rows,attestation,as_of=as_of)
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("source independence authority verifier failed closed") from exc
        if (not isinstance(verdict,SourceIndependenceAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
            or verdict.independence_id!=draft.independence_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip()
            or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
            raise ValueError("source independence verifier did not approve exact attestation")
        facts=self._trusted_dependency_facts(rows); existing=_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.get(draft.independence_id)
        idem=existing is not None
        if existing is not None:
            if (existing.get("external_source_independence_attestation_id")!=attestation.attestation_id
                or existing.get("external_source_independence_authority_id")!=attestation.authority_id
                or existing.get("external_source_independence_commitment")!=attestation.independence_commitment):
                raise ValueError("source independence id already exists with different or unattested content")
            cert=_engine.SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.get(draft.independence_id)
            if cert is None or not _engine.validate_source_independence_certificate(cert,*facts): raise ValueError("installed source independence certificate is invalid")
        else:
            _engine.authorize_source_independence(draft.independence_id,*facts,draft.reason)
            row=_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY[draft.independence_id]
            row.update({
                "external_source_independence_attestation_schema":attestation.schema,
                "external_source_independence_authority_id":attestation.authority_id,
                "external_source_independence_attestation_id":attestation.attestation_id,
                "external_source_independence_commitment":attestation.independence_commitment,
                "external_source_independence_verifier_id":verdict.verifier_id,
                "external_source_independence_verification_method":verdict.verification_method,
            })
            cert=_engine.issue_source_independence_certificate(draft.independence_id,*facts)
        runtime=self._source_independence_runtime_commitment(draft.independence_id)
        if runtime is None: raise ValueError("source independence runtime commitment unavailable")
        _VERIFIED_SOURCE_INDEPENDENCE_RUNTIME[draft.independence_id]=runtime
        _VERIFIED_SOURCE_INDEPENDENCE_METADATA[draft.independence_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return SourceIndependenceInstallation(draft.independence_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.independence_commitment,True,idem)

    def inspect_source_independence(self,draft,evidence) -> SourceIndependenceInspection:
        rows=self._canonical_dependency_evidence(evidence); facts=self._trusted_dependency_facts(rows)
        row=_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.get(draft.independence_id); cert=_engine.SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.get(draft.independence_id)
        if not isinstance(row,dict): return SourceIndependenceInspection(draft.independence_id,"DRAFT_ONLY",False,False,False,None,None,None)
        valid=bool(cert is not None and _engine.validate_source_independence_certificate(cert,*facts))
        runtime=self._source_independence_runtime_commitment(draft.independence_id)
        verified=runtime is not None and _VERIFIED_SOURCE_INDEPENDENCE_RUNTIME.get(draft.independence_id)==runtime
        att=row.get("external_source_independence_attestation_id"); auth=row.get("external_source_independence_authority_id"); vid=row.get("external_source_independence_verifier_id")
        meta=_VERIFIED_SOURCE_INDEPENDENCE_METADATA.get(draft.independence_id,{}) if verified else {}
        if isinstance(meta.get("verifier_id"),str): vid=meta.get("verifier_id")
        state=("INSTALLED_VERIFIED_RUNTIME" if valid and verified else "INSTALLED_ATTESTED_NOT_RUNTIME_VERIFIED" if valid and att else "INSTALLED_UNATTESTED" if valid else "INSTALLED_INVALID")
        return SourceIndependenceInspection(draft.independence_id,state,True,valid,verified,auth if isinstance(auth,str) else None,att if isinstance(att,str) else None,vid if isinstance(vid,str) else None)

    @_requires_host_trust("SOURCE_INDEPENDENCE")
    def reverify_installed_source_independence(self,draft,evidence,attestation,verifier,*,as_of):
        rows=self._canonical_dependency_evidence(evidence); self._validate_source_independence_attestation(draft,rows,attestation,as_of=as_of)
        facts=self._trusted_dependency_facts(rows); row=_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.get(draft.independence_id); cert=_engine.SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.get(draft.independence_id)
        if not isinstance(row,dict) or cert is None or not _engine.validate_source_independence_certificate(cert,*facts): raise ValueError("source independence is not installed and valid")
        if (row.get("external_source_independence_attestation_id")!=attestation.attestation_id or row.get("external_source_independence_authority_id")!=attestation.authority_id or row.get("external_source_independence_commitment")!=attestation.independence_commitment): raise ValueError("installed source independence does not match attestation")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("source independence authority verifier failed closed") from exc
        if (not isinstance(verdict,SourceIndependenceAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.independence_id!=draft.independence_id): raise ValueError("source independence verifier did not re-approve exact attestation")
        runtime=self._source_independence_runtime_commitment(draft.independence_id); _VERIFIED_SOURCE_INDEPENDENCE_RUNTIME[draft.independence_id]=runtime
        _VERIFIED_SOURCE_INDEPENDENCE_METADATA[draft.independence_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return self.inspect_source_independence(draft,rows)

    def draft_support_relation(self,*,relation_id:str,relation_type:str,evidence_ids:Sequence[str],reason:str,relation_effect:str="UNKNOWN",claim_id:str="*",retrieval_scope_id:str="*") -> SupportRelationDraft:
        ids=tuple(sorted(set(evidence_ids or ())))
        if not isinstance(relation_id,str) or not relation_id.strip() or relation_type not in {"COMMON_MODE","UNKNOWN"} or len(ids)<2 or any(not isinstance(x,str) or not x.strip() for x in ids): raise ValueError("invalid support relation draft")
        if not isinstance(reason,str) or not reason.strip() or not isinstance(claim_id,str) or not claim_id.strip() or not isinstance(retrieval_scope_id,str) or not retrieval_scope_id.strip(): raise ValueError("invalid support relation scope/reason")
        if relation_type=="UNKNOWN": relation_effect="UNKNOWN"
        elif relation_effect not in set(_engine.RELATION_EFFECTS): raise ValueError("invalid relation effect")
        return SupportRelationDraft(relation_id,relation_type,relation_effect,claim_id,retrieval_scope_id,ids,reason)

    def support_relation_commitment(self,draft:SupportRelationDraft,evidence:Sequence[EvidenceRecordDraft]) -> str:
        rows=self._canonical_dependency_evidence(evidence)
        if tuple(x.evidence_id for x in rows)!=draft.evidence_ids: raise ValueError("evidence does not match SupportRelationDraft")
        if draft.retrieval_scope_id!="*": self._require_retrieval_runtime_verified(draft.retrieval_scope_id)
        return _engine.canonical_hash({"schema":"CFC_SUPPORT_RELATION_PROJECTION_V1","relation_id":draft.relation_id,"relation_type":draft.relation_type,"relation_effect":draft.relation_effect,"claim_id":draft.claim_id,"retrieval_scope_id":draft.retrieval_scope_id,"evidence_ids":draft.evidence_ids,"reason":draft.reason,"evidence_record_commitments":tuple(self.evidence_record_commitment(x) for x in rows),"relation_resolution_policy_hash":_engine.relation_resolution_policy_hash(),"source_semantics_policy_hash":_engine.source_semantics_policy_hash()})

    def _validate_support_relation_attestation(self,draft,evidence,attestation,*,as_of):
        if not isinstance(attestation,SupportRelationAuthorityAttestation): raise TypeError("attestation must be SupportRelationAuthorityAttestation")
        if attestation.schema!=_SUPPORT_RELATION_ATTESTATION_SCHEMA: raise ValueError("unsupported support relation attestation schema")
        if attestation.authority_id==_RESERVED_ENGINE_RELATION_AUTHORITY: raise ValueError("engine-local relation authority cannot pose as external attestor")
        for name in ("attestation_id","authority_id","relation_commitment","issued_at","valid_from","valid_to"):
            v=getattr(attestation,name)
            if not isinstance(v,str) or not v.strip(): raise ValueError(f"support relation attestation {name} must be nonblank")
        if attestation.relation_commitment!=self.support_relation_commitment(draft,evidence): raise ValueError("attestation does not bind this support relation")
        self._validate_external_relation_attestation_dates(attestation,as_of=as_of)

    @_requires_host_trust("SUPPORT_RELATION")
    def install_verified_support_relation(self,draft,evidence,attestation,verifier,*,as_of):
        rows=self._canonical_dependency_evidence(evidence); self._validate_support_relation_attestation(draft,rows,attestation,as_of=as_of)
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("support relation authority verifier failed closed") from exc
        if (not isinstance(verdict,SupportRelationAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.relation_id!=draft.relation_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("support relation verifier did not approve exact attestation")
        existing=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.relation_id); idem=existing is not None
        if existing is not None:
            if (existing.get("external_support_relation_attestation_id")!=attestation.attestation_id or existing.get("external_support_relation_authority_id")!=attestation.authority_id or existing.get("external_support_relation_commitment")!=attestation.relation_commitment): raise ValueError("support relation id already exists with different or unattested content")
        else:
            if draft.relation_type=="COMMON_MODE": _engine.register_support_set_common_mode(draft.relation_id,draft.evidence_ids,draft.reason,relation_effect=draft.relation_effect,claim_id=draft.claim_id,retrieval_scope_id=draft.retrieval_scope_id)
            else: _engine.register_support_set_unknown(draft.relation_id,draft.claim_id,draft.retrieval_scope_id,draft.evidence_ids,draft.reason)
            row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY[draft.relation_id]
            row.update({"external_support_relation_attestation_schema":attestation.schema,"external_support_relation_authority_id":attestation.authority_id,"external_support_relation_attestation_id":attestation.attestation_id,"external_support_relation_commitment":attestation.relation_commitment,"external_support_relation_verifier_id":verdict.verifier_id,"external_support_relation_verification_method":verdict.verification_method})
        runtime=_engine.canonical_hash(_engine.SUPPORT_SET_COMMON_MODE_REGISTRY[draft.relation_id]); _VERIFIED_SUPPORT_RELATION_RUNTIME[draft.relation_id]=runtime
        _VERIFIED_SUPPORT_RELATION_METADATA[draft.relation_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return SupportRelationInstallation(draft.relation_id,draft.relation_type,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.relation_commitment,True,idem)

    def inspect_support_relation(self,draft:SupportRelationDraft) -> SupportRelationInspection:
        row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.relation_id)
        if not isinstance(row,dict): return SupportRelationInspection(draft.relation_id,None,"DRAFT_ONLY",False,False,False,None,None,None)
        rel=row.get("relation"); valid=(rel==draft.relation_type and tuple(row.get("evidence_ids",()))==draft.evidence_ids and row.get("claim_id")==draft.claim_id and row.get("retrieval_scope_id")==draft.retrieval_scope_id and row.get("relation_effect")==draft.relation_effect and row.get("reason")==draft.reason)
        if rel=="INDEPENDENT":
            runtime=self._support_set_independence_runtime_commitment(draft.relation_id); verified=runtime is not None and _VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME.get(draft.relation_id)==runtime
            att=row.get("external_support_set_independence_attestation_id"); auth=row.get("external_support_set_independence_authority_id"); vid=row.get("external_support_set_independence_verifier_id")
            meta=_VERIFIED_SUPPORT_SET_INDEPENDENCE_METADATA.get(draft.relation_id,{}) if verified else {}
        else:
            runtime=_engine.canonical_hash(row); verified=_VERIFIED_SUPPORT_RELATION_RUNTIME.get(draft.relation_id)==runtime
            att=row.get("external_support_relation_attestation_id"); auth=row.get("external_support_relation_authority_id"); vid=row.get("external_support_relation_verifier_id")
            meta=_VERIFIED_SUPPORT_RELATION_METADATA.get(draft.relation_id,{}) if verified else {}
        if isinstance(meta.get("verifier_id"),str): vid=meta.get("verifier_id")
        state=("INSTALLED_VERIFIED_RUNTIME" if valid and verified else "INSTALLED_ATTESTED_NOT_RUNTIME_VERIFIED" if valid and att else "INSTALLED_UNATTESTED" if valid else "INSTALLED_INVALID")
        return SupportRelationInspection(draft.relation_id,rel if isinstance(rel,str) else None,state,True,valid,verified,auth if isinstance(auth,str) else None,att if isinstance(att,str) else None,vid if isinstance(vid,str) else None)

    @_requires_host_trust("SUPPORT_RELATION")
    def reverify_installed_support_relation(self,draft,evidence,attestation,verifier,*,as_of):
        rows=self._canonical_dependency_evidence(evidence); self._validate_support_relation_attestation(draft,rows,attestation,as_of=as_of); ins=self.inspect_support_relation(draft)
        if not ins.installed or not ins.certificate_valid: raise ValueError("support relation is not installed exactly")
        row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY[draft.relation_id]
        if (row.get("external_support_relation_attestation_id")!=attestation.attestation_id or row.get("external_support_relation_authority_id")!=attestation.authority_id or row.get("external_support_relation_commitment")!=attestation.relation_commitment): raise ValueError("installed support relation does not match attestation")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("support relation authority verifier failed closed") from exc
        if (not isinstance(verdict,SupportRelationAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.relation_id!=draft.relation_id): raise ValueError("support relation verifier did not re-approve exact attestation")
        _VERIFIED_SUPPORT_RELATION_RUNTIME[draft.relation_id]=_engine.canonical_hash(row); _VERIFIED_SUPPORT_RELATION_METADATA[draft.relation_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return self.inspect_support_relation(draft)

    def draft_support_set_independence(self,*,independence_id:str,claim_id:str,retrieval_scope_id:str,evidence_ids:Sequence[str],reason:str,as_of_date:str) -> SupportSetIndependenceDraft:
        ids=tuple(sorted(set(evidence_ids or ())))
        if not all(isinstance(x,str) and x.strip() for x in (independence_id,claim_id,retrieval_scope_id,reason,as_of_date)) or len(ids)<2 or any(not isinstance(x,str) or not x.strip() for x in ids): raise ValueError("invalid support-set independence draft")
        _engine.strict_date(as_of_date)
        return SupportSetIndependenceDraft(independence_id,claim_id,retrieval_scope_id,ids,reason,as_of_date)

    def support_set_independence_commitment(self,draft:SupportSetIndependenceDraft,evidence:Sequence[EvidenceRecordDraft]) -> str:
        rows=self._canonical_dependency_evidence(evidence)
        if tuple(x.evidence_id for x in rows)!=draft.evidence_ids: raise ValueError("evidence does not match SupportSetIndependenceDraft")
        self._require_retrieval_runtime_verified(draft.retrieval_scope_id); facts=self._trusted_dependency_facts(rows)
        es=set(draft.evidence_ids); relctx={}
        for rid,row in _engine.SUPPORT_SET_COMMON_MODE_REGISTRY.items():
            if rid==draft.independence_id or not isinstance(row,dict): continue
            rs=set(row.get("evidence_ids",())); rel=row.get("relation")
            if len(rs)<2: continue
            if (rel in {"COMMON_MODE","UNKNOWN"} and len(rs & es)>=2) or (rel=="INDEPENDENT" and rs.issubset(es)):
                relctx[rid]=row
        return _engine.canonical_hash({"schema":"CFC_SUPPORT_SET_INDEPENDENCE_PROJECTION_V1","independence_id":draft.independence_id,"claim_id":draft.claim_id,"retrieval_scope_id":draft.retrieval_scope_id,"evidence_ids":draft.evidence_ids,"reason":draft.reason,"as_of_date":draft.as_of_date,"evidence_record_commitments":tuple(self.evidence_record_commitment(x) for x in rows),"source_failure_domain_certificate_ids":tuple(f.source_failure_domain.certificate_id for f in facts),"source_semantics_resolution_certificate_ids":tuple(f.source_semantics_resolution.certificate_id for f in facts),"source_independence_policy_hash":_engine.source_independence_policy_hash(),"source_semantics_policy_hash":_engine.source_semantics_policy_hash(),"support_relation_context_hash":_engine.canonical_hash(relctx)})

    def _validate_support_set_independence_attestation(self,draft,evidence,attestation,*,as_of):
        if not isinstance(attestation,SupportSetIndependenceAuthorityAttestation): raise TypeError("attestation must be SupportSetIndependenceAuthorityAttestation")
        if attestation.schema!=_SUPPORT_SET_INDEPENDENCE_ATTESTATION_SCHEMA: raise ValueError("unsupported support-set independence attestation schema")
        if attestation.authority_id==_RESERVED_ENGINE_RELATION_AUTHORITY: raise ValueError("engine-local set-independence authority cannot pose as external attestor")
        for name in ("attestation_id","authority_id","independence_commitment","issued_at","valid_from","valid_to"):
            v=getattr(attestation,name)
            if not isinstance(v,str) or not v.strip(): raise ValueError(f"support-set independence attestation {name} must be nonblank")
        if attestation.independence_commitment!=self.support_set_independence_commitment(draft,evidence): raise ValueError("attestation does not bind this support-set independence projection")
        self._validate_external_relation_attestation_dates(attestation,as_of=as_of)

    @staticmethod
    def _support_set_independence_runtime_commitment(independence_id:str) -> str | None:
        row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(independence_id); cert=_engine.SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.get(independence_id)
        if not isinstance(row,dict) or cert is None:return None
        return _engine.canonical_hash({"relation":row,"certificate":_engine.asdict(cert)})

    @_requires_host_trust("SUPPORT_SET_INDEPENDENCE")
    def install_verified_support_set_independence(self,draft,evidence,attestation,verifier,*,as_of):
        rows=self._canonical_dependency_evidence(evidence); self._validate_support_set_independence_attestation(draft,rows,attestation,as_of=as_of); facts=self._trusted_dependency_facts(rows)
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("support-set independence authority verifier failed closed") from exc
        if (not isinstance(verdict,SupportSetIndependenceAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.independence_id!=draft.independence_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("support-set independence verifier did not approve exact attestation")
        existing=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.independence_id); idem=existing is not None
        if existing is not None:
            if (existing.get("relation")!="INDEPENDENT" or existing.get("external_support_set_independence_attestation_id")!=attestation.attestation_id or existing.get("external_support_set_independence_authority_id")!=attestation.authority_id or existing.get("external_support_set_independence_commitment")!=attestation.independence_commitment): raise ValueError("support-set independence id already exists with different or unattested content")
            cert=_engine.SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.get(draft.independence_id)
            if cert is None or not _engine.validate_support_set_independence_certificate(cert,draft.claim_id,draft.retrieval_scope_id,facts,draft.as_of_date): raise ValueError("installed support-set independence certificate is invalid")
        else:
            _engine.authorize_support_set_independence(draft.independence_id,draft.claim_id,draft.retrieval_scope_id,facts,draft.reason,as_of_date=draft.as_of_date)
            row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY[draft.independence_id]
            row.update({"external_support_set_independence_attestation_schema":attestation.schema,"external_support_set_independence_authority_id":attestation.authority_id,"external_support_set_independence_attestation_id":attestation.attestation_id,"external_support_set_independence_commitment":attestation.independence_commitment,"external_support_set_independence_verifier_id":verdict.verifier_id,"external_support_set_independence_verification_method":verdict.verification_method})
            cert=_engine.issue_support_set_independence_certificate(draft.independence_id,draft.claim_id,draft.retrieval_scope_id,facts,draft.as_of_date)
        runtime=self._support_set_independence_runtime_commitment(draft.independence_id)
        if runtime is None: raise ValueError("support-set independence runtime commitment unavailable")
        _VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME[draft.independence_id]=runtime; _VERIFIED_SUPPORT_SET_INDEPENDENCE_METADATA[draft.independence_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return SupportSetIndependenceInstallation(draft.independence_id,cert.certificate_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.independence_commitment,True,idem)

    @_requires_host_trust("SUPPORT_SET_INDEPENDENCE")
    def reverify_installed_support_set_independence(self,draft,evidence,attestation,verifier,*,as_of) -> SupportRelationInspection:
        rows=self._canonical_dependency_evidence(evidence); self._validate_support_set_independence_attestation(draft,rows,attestation,as_of=as_of); facts=self._trusted_dependency_facts(rows); row=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.independence_id); cert=_engine.SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.get(draft.independence_id)
        if not isinstance(row,dict) or cert is None or not _engine.validate_support_set_independence_certificate(cert,draft.claim_id,draft.retrieval_scope_id,facts,draft.as_of_date): raise ValueError("support-set independence is not installed and valid")
        if (row.get("external_support_set_independence_attestation_id")!=attestation.attestation_id or row.get("external_support_set_independence_authority_id")!=attestation.authority_id or row.get("external_support_set_independence_commitment")!=attestation.independence_commitment): raise ValueError("installed support-set independence does not match attestation")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("support-set independence authority verifier failed closed") from exc
        if (not isinstance(verdict,SupportSetIndependenceAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.independence_id!=draft.independence_id): raise ValueError("support-set independence verifier did not re-approve exact attestation")
        runtime=self._support_set_independence_runtime_commitment(draft.independence_id); _VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME[draft.independence_id]=runtime; _VERIFIED_SUPPORT_SET_INDEPENDENCE_METADATA[draft.independence_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return self.inspect_support_relation(SupportRelationDraft(draft.independence_id,"INDEPENDENT","NON_DECISION_RELEVANT",draft.claim_id,draft.retrieval_scope_id,draft.evidence_ids,draft.reason))

    def _dependency_relation_integration_errors(self,evidence:Sequence[Mapping[str,Any]],retrieval_scope:str) -> list[dict[str,Any]]:
        ids={dict(x).get("evidence_id") for x in evidence if isinstance(x,Mapping)}; ids={x for x in ids if isinstance(x,str)}; errors=[]
        fact_by_id={}
        for i,raw in enumerate(evidence,1):
            if not isinstance(raw,Mapping): continue
            fact,fe=_engine.normalize_fact(dict(raw),i)
            if fact is not None and not fe: fact_by_id[fact.evidence_id]=fact
        for iid,row in sorted(_engine.SOURCE_INDEPENDENCE_AUTHORIZATION_REGISTRY.items()):
            reids=tuple(row.get("evidence_ids",())) if isinstance(row,dict) else ()
            if not isinstance(row,dict) or not set(reids).issubset(ids): continue
            if row.get("external_source_independence_attestation_id") is None: errors.append({"type":"SOURCE_INDEPENDENCE_AUTHORITY_UNATTESTED","independence_id":iid}); continue
            pair=tuple(fact_by_id.get(x) for x in reids)
            cert=_engine.SOURCE_INDEPENDENCE_CERTIFICATE_REGISTRY.get(iid)
            if len(pair)!=2 or any(x is None for x in pair) or cert is None or not _engine.validate_source_independence_certificate(cert,*pair):
                errors.append({"type":"SOURCE_INDEPENDENCE_CERTIFICATE_INVALID","independence_id":iid}); continue
            runtime=self._source_independence_runtime_commitment(iid)
            if runtime is None or _VERIFIED_SOURCE_INDEPENDENCE_RUNTIME.get(iid)!=runtime: errors.append({"type":"SOURCE_INDEPENDENCE_AUTHORITY_RUNTIME_NOT_VERIFIED","independence_id":iid})
        for rid,row in sorted(_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.items()):
            if not isinstance(row,dict): continue
            rel=row.get("relation"); reids=set(row.get("evidence_ids",())); scope=row.get("retrieval_scope_id")
            relevant=((rel in {"COMMON_MODE","UNKNOWN"} and len(reids & ids)>=2) or (rel=="INDEPENDENT" and reids.issubset(ids))) and scope in {"*",retrieval_scope}
            if not relevant: continue
            if rel=="INDEPENDENT":
                if row.get("external_support_set_independence_attestation_id") is None: errors.append({"type":"SUPPORT_SET_INDEPENDENCE_AUTHORITY_UNATTESTED","independence_id":rid}); continue
                facts=tuple(fact_by_id.get(x) for x in row.get("evidence_ids",()))
                cert=_engine.SUPPORT_SET_INDEPENDENCE_CERTIFICATE_REGISTRY.get(rid)
                cert_asof=getattr(cert,"equivalence_as_of_date",None) if cert is not None else None
                if any(x is None for x in facts) or cert is None or not _engine.validate_support_set_independence_certificate(cert,row.get("claim_id"),row.get("retrieval_scope_id"),facts,cert_asof):
                    errors.append({"type":"SUPPORT_SET_INDEPENDENCE_CERTIFICATE_INVALID","independence_id":rid}); continue
                runtime=self._support_set_independence_runtime_commitment(rid)
                if runtime is None or _VERIFIED_SUPPORT_SET_INDEPENDENCE_RUNTIME.get(rid)!=runtime: errors.append({"type":"SUPPORT_SET_INDEPENDENCE_AUTHORITY_RUNTIME_NOT_VERIFIED","independence_id":rid})
            else:
                if row.get("external_support_relation_attestation_id") is None: errors.append({"type":"SUPPORT_RELATION_AUTHORITY_UNATTESTED","relation_id":rid}); continue
                runtime=_engine.canonical_hash(row)
                if _VERIFIED_SUPPORT_RELATION_RUNTIME.get(rid)!=runtime: errors.append({"type":"SUPPORT_RELATION_AUTHORITY_RUNTIME_NOT_VERIFIED","relation_id":rid})
        return errors

    def decision_context_commitment(self, text, evidence, claim_identity_map, *, as_of, retrieval_scope, requirements=None, waivers=None) -> str:
        if not isinstance(text,str) or not text.strip(): raise ValueError("text must be nonblank")
        if not isinstance(claim_identity_map,Mapping): raise TypeError("claim_identity_map must be a mapping")
        raw=[]
        for item in evidence:
            if isinstance(item,EvidenceRecordDraft): raw.append(self.evidence_record_mapping(self._canonical_evidence_draft(item)))
            elif isinstance(item,Mapping): raw.append(dict(item))
            else: raise TypeError("decision evidence must contain EvidenceRecordDraft or mapping rows")
        ids=[x.get("evidence_id") for x in raw]
        if not raw or any(not isinstance(x,str) or not x.strip() for x in ids) or len(ids)!=len(set(ids)):
            raise ValueError("decision evidence requires unique nonblank evidence_id values")
        rr=_engine.RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope)
        if not isinstance(rr,dict): raise ValueError("retrieval scope is not installed")
        try:
            claims=_engine.parse_claims(text); reqs=_engine.normalize_requirements(claims,requirements)
            _engine.strict_date(as_of)
        except Exception as exc: raise ValueError("invalid decision context") from exc
        return _engine.canonical_hash({
            "schema":"CFC_DECISION_AUTHORITY_CONTEXT_V1","input_hash":_engine.sha(text),
            "raw_evidence_hash":_engine.sha(raw),"claim_identity_map_hash":_engine.sha(dict(claim_identity_map)),
            "as_of_date":as_of,"scope_spec_hash":_engine.sha(self.scope),"extraction_spec_hash":_engine.sha(self.extraction),
            "retrieval_scope_id":retrieval_scope,"retrieval_scope_record_hash":_engine.canonical_hash(rr),
            "per_claim_requirements_hash":_engine.sha(reqs),"waiver_hash":_engine.sha(dict(waivers or {})),
            "support_set_common_mode_registry_hash":_engine.support_set_common_mode_registry_hash(),
            "source_independence_certificate_registry_hash":_engine.source_independence_certificate_registry_hash(),
            "support_set_independence_certificate_registry_hash":_engine.support_set_independence_certificate_registry_hash(),
            "support_universe_policy_hash":_engine.support_universe_policy_hash(),
            "relation_discovery_policy_hash":_engine.relation_discovery_policy_hash(),
            "relation_resolution_policy_hash":_engine.relation_resolution_policy_hash(),
            "relation_decision_relevance_policy_hash":_engine.relation_decision_relevance_policy_hash(),
        })

    def _canonical_decision_evidence(self,evidence):
        rows=tuple(self._canonical_evidence_draft(x) for x in evidence)
        ids=tuple(x.evidence_id for x in rows)
        if not rows or len(ids)!=len(set(ids)): raise ValueError("decision evidence requires unique evidence_id values")
        self._trusted_dependency_facts(rows)
        return rows

    def draft_support_selection(self, *, selection_id, claim_id, retrieval_scope_id, matching_evidence_ids, selected_support_ids,
                                required_supports, exclusion_classifications, exclusion_reasons, justification_reason,
                                text, evidence, claim_identity_map, as_of, requirements=None, waivers=None):
        matching=tuple(sorted(set(matching_evidence_ids or ()))) ; selected=tuple(sorted(set(selected_support_ids or ())))
        if not all(isinstance(x,str) and x.strip() for x in (selection_id,claim_id,retrieval_scope_id,justification_reason)):
            raise ValueError("invalid support selection draft")
        if len(matching)!=len(tuple(matching_evidence_ids or ())) or len(selected)!=len(tuple(selected_support_ids or ())): raise ValueError("duplicate evidence id in support selection draft")
        if type(required_supports) is not int or required_supports<1 or len(selected)!=required_supports or not set(selected).issubset(set(matching)):
            raise ValueError("invalid selected support set")
        excluded=tuple(sorted(set(matching)-set(selected))); classes=dict(exclusion_classifications or {}); reasons=dict(exclusion_reasons or {})
        if set(classes)!=set(excluded) or set(reasons)!=set(excluded): raise ValueError("every excluded support requires classification and reason")
        if any(v not in set(_engine.SUPPORT_EXCLUSION_CLASSES) for v in classes.values()) or any(not isinstance(v,str) or not v.strip() for v in reasons.values()): raise ValueError("invalid support exclusion")
        ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope_id,requirements=requirements,waivers=waivers)
        return SupportSelectionDraft(selection_id,claim_id,retrieval_scope_id,matching,selected,required_supports,tuple(sorted(classes.items())),tuple(sorted(reasons.items())),justification_reason,ctx)

    def support_selection_commitment(self,draft,evidence) -> str:
        if not isinstance(draft,SupportSelectionDraft): raise TypeError("draft must be SupportSelectionDraft")
        rows=self._canonical_decision_evidence(evidence); ids=tuple(sorted(x.evidence_id for x in rows))
        if ids!=draft.matching_evidence_ids: raise ValueError("evidence does not match support selection universe")
        return _engine.canonical_hash({"schema":"CFC_SUPPORT_SELECTION_PROJECTION_V1","draft":_engine.asdict(draft),
            "evidence_record_commitments":tuple(sorted(self.evidence_record_commitment(x) for x in rows)),
            "support_universe_policy_hash":_engine.support_universe_policy_hash(),"relation_registry_hash":_engine.support_set_common_mode_registry_hash()})

    def _validate_decision_attestation(self,attestation,expected_schema,reserved_authority,expected_commitment,*,as_of,commitment_field):
        if getattr(attestation,"schema",None)!=expected_schema: raise ValueError("unsupported decision authority attestation schema")
        if getattr(attestation,"authority_id",None)==reserved_authority: raise ValueError("engine-local decision authority cannot pose as external attestor")
        for name in ("attestation_id","authority_id",commitment_field,"issued_at","valid_from","valid_to"):
            v=getattr(attestation,name,None)
            if not isinstance(v,str) or not v.strip(): raise ValueError(f"decision authority attestation {name} must be nonblank")
        if getattr(attestation,commitment_field)!=expected_commitment: raise ValueError("attestation does not bind exact decision projection")
        self._validate_external_relation_attestation_dates(attestation,as_of=as_of)

    @staticmethod
    def _support_selection_runtime_commitment(selection_id):
        row=_engine.SUPPORT_SELECTION_REGISTRY.get(selection_id)
        return _engine.canonical_hash(row) if isinstance(row,dict) and row.get("selection_id")==selection_id else None

    @_requires_host_trust("SUPPORT_SELECTION")
    def install_verified_support_selection(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        if not isinstance(draft,SupportSelectionDraft): raise TypeError("draft must be SupportSelectionDraft")
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(draft.retrieval_scope_id)
        current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        if draft.decision_context_commitment!=current_ctx: raise ValueError("support selection draft is not bound to this decision context")
        expected=self.support_selection_commitment(draft,rows); self._validate_decision_attestation(attestation,_SUPPORT_SELECTION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_SUPPORT_SELECTION_AUTHORITY,expected,as_of=as_of,commitment_field="selection_commitment")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("support selection authority verifier failed closed") from exc
        if (not isinstance(verdict,SupportSelectionAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.selection_id!=draft.selection_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("support selection verifier did not approve exact attestation")
        existing=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.selection_id); idem=existing is not None
        if existing is None and any(isinstance(r,dict) and r.get("claim_id")==draft.claim_id and r.get("retrieval_scope_id")==draft.retrieval_scope_id and r.get("authorization_binding_state")=="BOUND" for r in _engine.RELATION_RESOLUTION_REGISTRY.values()):
            raise ValueError("cannot add a new support selection after relation-resolution context is BOUND")
        if existing is None:
            _engine.register_support_selection(draft.selection_id,draft.claim_id,draft.retrieval_scope_id,draft.matching_evidence_ids,draft.selected_support_ids,draft.required_supports,dict(draft.exclusion_classifications),draft.justification_reason,dict(draft.exclusion_reasons),authorizer_id=_RESERVED_ENGINE_SUPPORT_SELECTION_AUTHORITY)
            row=_engine.SUPPORT_SELECTION_REGISTRY[draft.selection_id]; row.update({"external_support_selection_attestation_schema":attestation.schema,"external_support_selection_authority_id":attestation.authority_id,"external_support_selection_attestation_id":attestation.attestation_id,"external_support_selection_commitment":attestation.selection_commitment,"external_support_selection_verifier_id":verdict.verifier_id,"external_support_selection_verification_method":verdict.verification_method,"external_decision_context_commitment":draft.decision_context_commitment})
        else:
            row=existing
            if (row.get("external_support_selection_attestation_id")!=attestation.attestation_id or row.get("external_support_selection_authority_id")!=attestation.authority_id or row.get("external_support_selection_commitment")!=attestation.selection_commitment or row.get("external_decision_context_commitment")!=draft.decision_context_commitment): raise ValueError("support selection id already exists with different or unattested content")
        runtime=self._support_selection_runtime_commitment(draft.selection_id)
        if runtime is None: raise ValueError("support selection runtime commitment unavailable")
        _VERIFIED_SUPPORT_SELECTION_RUNTIME[draft.selection_id]=runtime; _VERIFIED_SUPPORT_SELECTION_METADATA[draft.selection_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return SupportSelectionInstallation(draft.selection_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.selection_commitment,True,idem)

    @_requires_host_trust("SUPPORT_SELECTION")
    def reverify_installed_support_selection(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        expected=self.support_selection_commitment(draft,evidence); self._validate_decision_attestation(attestation,_SUPPORT_SELECTION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_SUPPORT_SELECTION_AUTHORITY,expected,as_of=as_of,commitment_field="selection_commitment")
        current_ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        row=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.selection_id)
        if not isinstance(row,dict) or row.get("external_decision_context_commitment")!=current_ctx or row.get("external_support_selection_attestation_id")!=attestation.attestation_id: raise ValueError("installed support selection does not match exact attestation/context")
        verify=getattr(verifier,"verify",None); verdict=verify(attestation,draft=draft,evidence=tuple(self._canonical_evidence_draft(x) for x in evidence)) if callable(verify) else None
        if not isinstance(verdict,SupportSelectionAuthorityVerdict) or verdict.approved is not True or verdict.selection_id!=draft.selection_id or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id: raise ValueError("support selection verifier did not re-approve exact attestation")
        runtime=self._support_selection_runtime_commitment(draft.selection_id); _VERIFIED_SUPPORT_SELECTION_RUNTIME[draft.selection_id]=runtime; _VERIFIED_SUPPORT_SELECTION_METADATA[draft.selection_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}; return True

    def draft_relation_resolution(self, *, resolution_id, relation_id, claim_id, retrieval_scope_id, selected_support_ids, resolution_type, justification_reason,
                                  text,evidence,claim_identity_map,as_of,requirements=None,waivers=None):
        selected=tuple(sorted(set(selected_support_ids or ())))
        if not selected or len(selected)!=len(tuple(selected_support_ids or ())) or not all(isinstance(x,str) and x.strip() for x in (resolution_id,relation_id,claim_id,retrieval_scope_id,resolution_type,justification_reason)): raise ValueError("invalid relation resolution draft")
        rel=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(relation_id)
        if not isinstance(rel,dict): raise ValueError("relation is not installed")
        effect=_engine._relation_row_effect(rel)
        if resolution_type not in set(_engine.RELATION_EFFECT_RESOLUTION_COMPATIBILITY.get(effect,())): raise ValueError("resolution type incompatible with relation effect")
        ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope_id,requirements=requirements,waivers=waivers)
        return RelationResolutionDraft(resolution_id,relation_id,claim_id,retrieval_scope_id,selected,resolution_type,justification_reason,ctx)

    def relation_resolution_commitment(self,draft,evidence) -> str:
        if not isinstance(draft,RelationResolutionDraft): raise TypeError("draft must be RelationResolutionDraft")
        rows=self._canonical_decision_evidence(evidence); rel=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.relation_id)
        if not isinstance(rel,dict): raise ValueError("relation is not installed")
        if not set(draft.selected_support_ids).issubset({x.evidence_id for x in rows}): raise ValueError("selected support outside evidence")
        return _engine.canonical_hash({"schema":"CFC_RELATION_RESOLUTION_PROJECTION_V1","draft":_engine.asdict(draft),"relation_record_hash":_engine.canonical_hash(rel),"evidence_record_commitments":tuple(sorted(self.evidence_record_commitment(x) for x in rows)),"relation_resolution_policy_hash":_engine.relation_resolution_policy_hash(),"relation_decision_relevance_policy_hash":_engine.relation_decision_relevance_policy_hash()})

    @staticmethod
    def _relation_resolution_runtime_commitment(resolution_id):
        row=_engine.RELATION_RESOLUTION_REGISTRY.get(resolution_id)
        return _engine.canonical_hash(row) if isinstance(row,dict) and row.get("resolution_id")==resolution_id else None

    @_requires_host_trust("RELATION_RESOLUTION")
    def install_verified_relation_resolution(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(draft.retrieval_scope_id)
        current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        if draft.decision_context_commitment!=current_ctx: raise ValueError("relation resolution draft is not bound to this decision context")
        rel=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(draft.relation_id)
        if not isinstance(rel,dict) or rel.get("external_support_relation_attestation_id") is None or _VERIFIED_SUPPORT_RELATION_RUNTIME.get(draft.relation_id)!=_engine.canonical_hash(rel): raise ValueError("relation resolution requires externally verified relation authority")
        expected=self.relation_resolution_commitment(draft,rows); self._validate_decision_attestation(attestation,_RELATION_RESOLUTION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_RELATION_RESOLUTION_AUTHORITY,expected,as_of=as_of,commitment_field="resolution_commitment")
        verify=getattr(verifier,"verify",None)
        try: verdict=verify(attestation,draft=draft,evidence=rows) if callable(verify) else None
        except Exception as exc: raise ValueError("relation resolution authority verifier failed closed") from exc
        if (not isinstance(verdict,RelationResolutionAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.resolution_id!=draft.resolution_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("relation resolution verifier did not approve exact attestation")
        existing=_engine.RELATION_RESOLUTION_REGISTRY.get(draft.resolution_id); idem=existing is not None
        if existing is None:
            _engine.register_relation_resolution(draft.resolution_id,draft.relation_id,draft.claim_id,draft.retrieval_scope_id,draft.selected_support_ids,draft.resolution_type,draft.justification_reason,authorizer_id=_RESERVED_ENGINE_RELATION_RESOLUTION_AUTHORITY)
            row=_engine.RELATION_RESOLUTION_REGISTRY[draft.resolution_id]; row.update({"external_relation_resolution_attestation_schema":attestation.schema,"external_relation_resolution_authority_id":attestation.authority_id,"external_relation_resolution_attestation_id":attestation.attestation_id,"external_relation_resolution_commitment":attestation.resolution_commitment,"external_relation_resolution_verifier_id":verdict.verifier_id,"external_relation_resolution_verification_method":verdict.verification_method,"external_decision_context_commitment":draft.decision_context_commitment})
        else:
            row=existing
            if row.get("external_relation_resolution_attestation_id")!=attestation.attestation_id or row.get("external_relation_resolution_commitment")!=attestation.resolution_commitment or row.get("external_decision_context_commitment")!=draft.decision_context_commitment: raise ValueError("relation resolution id already exists with different or unattested content")
        row=_engine.RELATION_RESOLUTION_REGISTRY[draft.resolution_id]
        runtime=self._relation_resolution_runtime_commitment(draft.resolution_id); _VERIFIED_RELATION_RESOLUTION_RUNTIME[draft.resolution_id]=runtime; _VERIFIED_RELATION_RESOLUTION_METADATA[draft.resolution_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        # Deliberately remain PENDING here.  R255 final binding happens only after all
        # selection/resolution/disposition declarations are installed, because those
        # registries are part of the engine audit-context seed.
        return RelationResolutionInstallation(draft.resolution_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.resolution_commitment,True,row.get("authorization_binding_state")=="BOUND",idem)

    @_requires_host_trust("RELATION_RESOLUTION")
    def reverify_installed_relation_resolution(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        expected=self.relation_resolution_commitment(draft,evidence); self._validate_decision_attestation(attestation,_RELATION_RESOLUTION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_RELATION_RESOLUTION_AUTHORITY,expected,as_of=as_of,commitment_field="resolution_commitment")
        current_ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers); row=_engine.RELATION_RESOLUTION_REGISTRY.get(draft.resolution_id)
        if not isinstance(row,dict) or row.get("authorization_binding_state")!="BOUND" or row.get("external_decision_context_commitment")!=current_ctx or row.get("external_relation_resolution_attestation_id")!=attestation.attestation_id: raise ValueError("installed relation resolution does not match exact attestation/context")
        verify=getattr(verifier,"verify",None); verdict=verify(attestation,draft=draft,evidence=tuple(self._canonical_evidence_draft(x) for x in evidence)) if callable(verify) else None
        if not isinstance(verdict,RelationResolutionAuthorityVerdict) or verdict.approved is not True or verdict.resolution_id!=draft.resolution_id or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id: raise ValueError("relation resolution verifier did not re-approve exact attestation")
        runtime=self._relation_resolution_runtime_commitment(draft.resolution_id); _VERIFIED_RELATION_RESOLUTION_RUNTIME[draft.resolution_id]=runtime; _VERIFIED_RELATION_RESOLUTION_METADATA[draft.resolution_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}; return True

    def finalize_verified_decision_authorities_for_prepare(self, text, evidence, claim_identity_map, *, as_of, retrieval_scope, requirements=None, waivers=None):
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(retrieval_scope)
        current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers)
        claim_ids={c.id for c in _engine.parse_claims(text)}
        resolution_ids=[]
        # Selection and disposition rows are already final declarations.  They must be
        # externally attested, context-exact, and runtime-pinned before any resolution bind.
        for key,row in _engine.SUPPORT_SELECTION_REGISTRY.items():
            if not isinstance(row,dict) or row.get("selection_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_support_selection_attestation_id") is None or row.get("external_decision_context_commitment")!=current_ctx or _VERIFIED_SUPPORT_SELECTION_RUNTIME.get(key)!=self._support_selection_runtime_commitment(key):
                raise ValueError("support selection authority is not ready for final decision binding")
        for key,row in _engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.items():
            if not isinstance(row,dict) or row.get("disposition_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_excluded_disposition_attestation_id") is None or row.get("external_decision_context_commitment")!=current_ctx or _VERIFIED_EXCLUDED_DISPOSITION_RUNTIME.get(key)!=self._excluded_disposition_runtime_commitment(key):
                raise ValueError("excluded-support disposition authority is not ready for final decision binding")
        for key,row in _engine.RELATION_RESOLUTION_REGISTRY.items():
            if not isinstance(row,dict) or row.get("resolution_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_relation_resolution_attestation_id") is None or row.get("external_decision_context_commitment")!=current_ctx or _VERIFIED_RELATION_RESOLUTION_RUNTIME.get(key)!=self._relation_resolution_runtime_commitment(key):
                raise ValueError("relation resolution authority is not ready for final decision binding")
            resolution_ids.append(key)
        if not resolution_ids: return tuple()
        ok=_engine.bind_relation_resolution_authorizations_for_prepare(
            text,[self.evidence_record_mapping(x) for x in rows],dict(claim_identity_map),as_of,self.scope,self.extraction,
            retrieval_scope,requirements,resolution_ids=tuple(sorted(resolution_ids))
        )
        if not ok: raise ValueError("engine refused final exact decision-context binding")
        for key in resolution_ids:
            row=_engine.RELATION_RESOLUTION_REGISTRY.get(key)
            if not isinstance(row,dict) or row.get("authorization_binding_state")!="BOUND": raise ValueError("relation resolution did not become BOUND")
            runtime=self._relation_resolution_runtime_commitment(key)
            _VERIFIED_RELATION_RESOLUTION_RUNTIME[key]=runtime
        return tuple(sorted(resolution_ids))

    def draft_excluded_support_disposition(self, *, disposition_id, claim_id, retrieval_scope_id, excluded_evidence_id, selected_evidence_ids, supporting_relation_ids, justification_reason,
                                           text,evidence,claim_identity_map,as_of,requirements=None,waivers=None):
        selected=tuple(sorted(set(selected_evidence_ids or ()))); relids=tuple(sorted(set(supporting_relation_ids or ())))
        if not selected or not relids or len(selected)!=len(tuple(selected_evidence_ids or ())) or len(relids)!=len(tuple(supporting_relation_ids or ())) or excluded_evidence_id in set(selected): raise ValueError("invalid excluded-support disposition draft")
        if not all(isinstance(x,str) and x.strip() for x in (disposition_id,claim_id,retrieval_scope_id,excluded_evidence_id,justification_reason)): raise ValueError("invalid excluded-support disposition draft")
        ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope_id,requirements=requirements,waivers=waivers)
        return ExcludedSupportDispositionDraft(disposition_id,claim_id,retrieval_scope_id,excluded_evidence_id,selected,relids,justification_reason,ctx)

    def excluded_support_disposition_commitment(self,draft,evidence) -> str:
        if not isinstance(draft,ExcludedSupportDispositionDraft): raise TypeError("draft must be ExcludedSupportDispositionDraft")
        rows=self._canonical_decision_evidence(evidence); relhash=[]; rrhash=[]
        for rid in draft.supporting_relation_ids:
            rel=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(rid); res=[r for r in _engine.RELATION_RESOLUTION_REGISTRY.values() if isinstance(r,dict) and r.get("relation_id")==rid and r.get("claim_id")==draft.claim_id and r.get("retrieval_scope_id")==draft.retrieval_scope_id]
            if not isinstance(rel,dict) or len(res)!=1: raise ValueError("disposition requires exactly one supporting relation resolution")
            relhash.append((rid,_engine.canonical_hash(rel))); 
            ext_commit=res[0].get("external_relation_resolution_commitment")
            if not isinstance(ext_commit,str) or not ext_commit: raise ValueError("supporting resolution is not externally attested")
            rrhash.append((res[0]["resolution_id"],ext_commit))
        return _engine.canonical_hash({"schema":"CFC_EXCLUDED_SUPPORT_DISPOSITION_PROJECTION_V1","draft":_engine.asdict(draft),"supporting_relation_hashes":tuple(relhash),"supporting_resolution_hashes":tuple(rrhash),"evidence_record_commitments":tuple(sorted(self.evidence_record_commitment(x) for x in rows)),"relation_resolution_policy_hash":_engine.relation_resolution_policy_hash()})

    @staticmethod
    def _excluded_disposition_runtime_commitment(disposition_id):
        row=_engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.get(disposition_id)
        return _engine.canonical_hash(row) if isinstance(row,dict) and row.get("disposition_id")==disposition_id else None

    @_requires_host_trust("EXCLUDED_SUPPORT_DISPOSITION")
    def install_verified_excluded_support_disposition(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(draft.retrieval_scope_id); current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        if draft.decision_context_commitment!=current_ctx: raise ValueError("excluded-support draft is not bound to this decision context")
        selections=[(k,r) for k,r in _engine.SUPPORT_SELECTION_REGISTRY.items() if isinstance(r,dict) and r.get("selection_id")==k and r.get("claim_id")==draft.claim_id and r.get("retrieval_scope_id")==draft.retrieval_scope_id and tuple(r.get("selected_support_ids",()))==draft.selected_evidence_ids and draft.excluded_evidence_id in set(r.get("excluded_support_ids",()))]
        if len(selections)!=1: raise ValueError("excluded-support disposition requires exactly one matching explicit support selection")
        sk,srow=selections[0]
        if srow.get("external_support_selection_attestation_id") is None or _VERIFIED_SUPPORT_SELECTION_RUNTIME.get(sk)!=self._support_selection_runtime_commitment(sk) or srow.get("external_decision_context_commitment")!=current_ctx: raise ValueError("support selection authority is not externally/runtime verified")
        existing=_engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.get(draft.disposition_id); idem=existing is not None
        for rid in draft.supporting_relation_ids:
            rel=_engine.SUPPORT_SET_COMMON_MODE_REGISTRY.get(rid)
            if not isinstance(rel,dict) or _VERIFIED_SUPPORT_RELATION_RUNTIME.get(rid)!=_engine.canonical_hash(rel): raise ValueError("supporting relation authority is not runtime verified")
            resolutions=[(k,r) for k,r in _engine.RELATION_RESOLUTION_REGISTRY.items() if isinstance(r,dict) and r.get("resolution_id")==k and r.get("relation_id")==rid and r.get("claim_id")==draft.claim_id and r.get("retrieval_scope_id")==draft.retrieval_scope_id]
            if len(resolutions)!=1: raise ValueError("supporting relation lacks exact resolution")
            rk,rrow=resolutions[0]
            allowed_states={"PENDING","BOUND"} if idem else {"PENDING"}
            if rrow.get("authorization_binding_state") not in allowed_states or rrow.get("external_relation_resolution_attestation_id") is None or _VERIFIED_RELATION_RESOLUTION_RUNTIME.get(rk)!=self._relation_resolution_runtime_commitment(rk) or rrow.get("external_decision_context_commitment")!=current_ctx: raise ValueError("supporting relation resolution authority is not externally/runtime verified or decision context is already finalized")
        expected=self.excluded_support_disposition_commitment(draft,rows); self._validate_decision_attestation(attestation,_EXCLUDED_DISPOSITION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_EXCLUDED_DISPOSITION_AUTHORITY,expected,as_of=as_of,commitment_field="disposition_commitment")
        verify=getattr(verifier,"verify",None)
        try: verdict=verify(attestation,draft=draft,evidence=rows) if callable(verify) else None
        except Exception as exc: raise ValueError("excluded-support disposition verifier failed closed") from exc
        if (not isinstance(verdict,ExcludedSupportDispositionAuthorityVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id or verdict.disposition_id!=draft.disposition_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("excluded-support disposition verifier did not approve exact attestation")
        if existing is None:
            _engine.register_excluded_support_disposition(draft.disposition_id,draft.claim_id,draft.retrieval_scope_id,draft.excluded_evidence_id,draft.selected_evidence_ids,draft.supporting_relation_ids,draft.justification_reason,authorizer_id=_RESERVED_ENGINE_EXCLUDED_DISPOSITION_AUTHORITY)
            row=_engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY[draft.disposition_id]; row.update({"external_excluded_disposition_attestation_schema":attestation.schema,"external_excluded_disposition_authority_id":attestation.authority_id,"external_excluded_disposition_attestation_id":attestation.attestation_id,"external_excluded_disposition_commitment":attestation.disposition_commitment,"external_excluded_disposition_verifier_id":verdict.verifier_id,"external_excluded_disposition_verification_method":verdict.verification_method,"external_decision_context_commitment":draft.decision_context_commitment})
        else:
            row=existing
            if row.get("external_excluded_disposition_attestation_id")!=attestation.attestation_id or row.get("external_excluded_disposition_commitment")!=attestation.disposition_commitment or row.get("external_decision_context_commitment")!=draft.decision_context_commitment: raise ValueError("disposition id already exists with different or unattested content")
        runtime=self._excluded_disposition_runtime_commitment(draft.disposition_id); _VERIFIED_EXCLUDED_DISPOSITION_RUNTIME[draft.disposition_id]=runtime; _VERIFIED_EXCLUDED_DISPOSITION_METADATA[draft.disposition_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}
        return ExcludedSupportDispositionInstallation(draft.disposition_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.disposition_commitment,True,idem)

    @_requires_host_trust("EXCLUDED_SUPPORT_DISPOSITION")
    def reverify_installed_excluded_support_disposition(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        expected=self.excluded_support_disposition_commitment(draft,evidence); self._validate_decision_attestation(attestation,_EXCLUDED_DISPOSITION_ATTESTATION_SCHEMA,_RESERVED_ENGINE_EXCLUDED_DISPOSITION_AUTHORITY,expected,as_of=as_of,commitment_field="disposition_commitment"); current_ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers); row=_engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.get(draft.disposition_id)
        if not isinstance(row,dict) or row.get("external_decision_context_commitment")!=current_ctx or row.get("external_excluded_disposition_attestation_id")!=attestation.attestation_id: raise ValueError("installed excluded-support disposition does not match exact attestation/context")
        verify=getattr(verifier,"verify",None); verdict=verify(attestation,draft=draft,evidence=tuple(self._canonical_evidence_draft(x) for x in evidence)) if callable(verify) else None
        if not isinstance(verdict,ExcludedSupportDispositionAuthorityVerdict) or verdict.approved is not True or verdict.disposition_id!=draft.disposition_id or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id: raise ValueError("excluded-support disposition verifier did not re-approve exact attestation")
        runtime=self._excluded_disposition_runtime_commitment(draft.disposition_id); _VERIFIED_EXCLUDED_DISPOSITION_RUNTIME[draft.disposition_id]=runtime; _VERIFIED_EXCLUDED_DISPOSITION_METADATA[draft.disposition_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id}; return True

    @staticmethod
    def _canonical_decision_selected_support_map(selected_support_map: Mapping[str, Sequence[str]]) -> tuple[tuple[str, tuple[str, ...]], ...]:
        if not isinstance(selected_support_map, Mapping):
            raise TypeError("selected_support_map must be a mapping")
        out=[]
        for cid,eids in selected_support_map.items():
            if not isinstance(cid,str) or not cid.strip(): raise ValueError("claim ids must be nonblank")
            vals=tuple(sorted(set(eids or ())))
            if not vals or len(vals)!=len(tuple(eids or ())) or any(not isinstance(x,str) or not x.strip() for x in vals):
                raise ValueError("selected support map requires unique nonblank evidence ids")
            out.append((cid,vals))
        result=tuple(sorted(out))
        if not result: raise ValueError("selected support map must not be empty")
        return result

    def draft_decision_source_dependency_accounting(self, *, accounting_id, retrieval_scope_id, claim_ids, selected_support_map,
                                                     evidence_ids, reason, text, evidence, claim_identity_map, as_of,
                                                     requirements=None, waivers=None):
        if not all(isinstance(x,str) and x.strip() for x in (accounting_id,retrieval_scope_id,reason)):
            raise ValueError("invalid decision source dependency accounting draft")
        cids=tuple(sorted(set(claim_ids or ())))
        if not cids or len(cids)!=len(tuple(claim_ids or ())) or any(not isinstance(x,str) or not x.strip() for x in cids):
            raise ValueError("invalid decision claim ids")
        smap=self._canonical_decision_selected_support_map(selected_support_map)
        if tuple(cid for cid,_ in smap)!=cids: raise ValueError("selected support map must exactly cover claim ids")
        eids=tuple(sorted(set(evidence_ids or ())))
        if len(eids)!=2 or len(eids)!=len(tuple(evidence_ids or ())): raise ValueError("source dependency accounting requires exactly two unique evidence ids")
        rows=self._canonical_decision_evidence(evidence); known={x.evidence_id for x in rows}
        if not set(eids).issubset(known): raise ValueError("source dependency endpoints must be present in evidence")
        selected_all={x for _cid,vals in smap for x in vals}
        if not set(eids).issubset(selected_all): raise ValueError("source dependency endpoints must be selected supports")
        ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope_id,requirements=requirements,waivers=waivers)
        return DecisionSourceDependencyAccountingDraft(accounting_id,retrieval_scope_id,cids,smap,(eids[0],eids[1]),
            _engine.SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_resolution_type'],reason,ctx)

    def decision_source_dependency_accounting_commitment(self,draft,evidence) -> str:
        if not isinstance(draft,DecisionSourceDependencyAccountingDraft): raise TypeError("draft must be DecisionSourceDependencyAccountingDraft")
        rows=self._canonical_decision_evidence(evidence); known={x.evidence_id for x in rows}
        if not set(draft.evidence_ids).issubset(known): raise ValueError("accounting evidence does not match draft")
        return _engine.canonical_hash({"schema":"CFC_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_PROJECTION_V1","draft":_engine.asdict(draft),
            "evidence_record_commitments":tuple(sorted(self.evidence_record_commitment(x) for x in rows if x.evidence_id in set(draft.evidence_ids))),
            "support_universe_policy_hash":_engine.support_universe_policy_hash(),"source_semantics_policy_hash":_engine.source_semantics_policy_hash(),
            "source_semantics_registry_hash":_engine.source_semantics_registry_hash(),"source_semantics_resolution_certificate_registry_hash":_engine.source_semantics_resolution_certificate_registry_hash(),
            "failure_domain_relation_registry_hash":_engine.failure_domain_relation_registry_hash(),"source_independence_policy_hash":_engine.source_independence_policy_hash()})

    @staticmethod
    def _decision_accounting_runtime_commitment(accounting_id,record_type):
        row=_engine.SUPPORT_SELECTION_REGISTRY.get(accounting_id)
        return _engine.canonical_hash(row) if isinstance(row,dict) and row.get("accounting_id")==accounting_id and row.get("record_type")==record_type else None

    @_requires_host_trust("DECISION_SOURCE_DEPENDENCY_ACCOUNTING")
    def install_verified_decision_source_dependency_accounting(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        if not isinstance(draft,DecisionSourceDependencyAccountingDraft): raise TypeError("draft must be DecisionSourceDependencyAccountingDraft")
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(draft.retrieval_scope_id)
        current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        if current_ctx!=draft.decision_context_commitment: raise ValueError("accounting draft is not bound to this decision context")
        expected=self.decision_source_dependency_accounting_commitment(draft,rows)
        self._validate_decision_attestation(attestation,_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA,_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY,expected,as_of=as_of,commitment_field="accounting_commitment")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("decision source dependency accounting verifier failed closed") from exc
        if (not isinstance(verdict,DecisionSourceDependencyAccountingVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id
            or verdict.authority_id!=attestation.authority_id or verdict.accounting_id!=draft.accounting_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip()
            or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()): raise ValueError("source dependency accounting verifier did not approve exact attestation")
        existing=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.accounting_id); idem=existing is not None
        if existing is None:
            _engine.register_decision_dependency_accounting(draft.accounting_id,draft.retrieval_scope_id,draft.claim_ids,dict(draft.selected_support_map),draft.evidence_ids,draft.resolution_type,draft.reason,authorizer_id=_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY)
            row=_engine.SUPPORT_SELECTION_REGISTRY[draft.accounting_id]
        else:
            row=existing
            if (row.get("record_type")!=_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE or tuple(row.get("claim_ids",()))!=draft.claim_ids
                or tuple(row.get("selected_support_map",()))!=draft.selected_support_map or tuple(row.get("evidence_ids",()))!=draft.evidence_ids
                or row.get("retrieval_scope_id")!=draft.retrieval_scope_id or row.get("resolution_type")!=draft.resolution_type or row.get("reason")!=draft.reason):
                raise ValueError("source dependency accounting id already exists with different content")
        runtime=self._decision_accounting_runtime_commitment(draft.accounting_id,_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE)
        _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME[draft.accounting_id]=runtime
        _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA[draft.accounting_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id,"accounting_commitment":attestation.accounting_commitment,"decision_context_commitment":draft.decision_context_commitment}
        return DecisionSourceDependencyAccountingInstallation(draft.accounting_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.accounting_commitment,True,row.get("binding_state")=="BOUND",idem)

    @_requires_host_trust("DECISION_SOURCE_DEPENDENCY_ACCOUNTING")
    def reverify_installed_decision_source_dependency_accounting(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        expected=self.decision_source_dependency_accounting_commitment(draft,evidence); self._validate_decision_attestation(attestation,_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA,_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY,expected,as_of=as_of,commitment_field="accounting_commitment")
        current_ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        row=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.accounting_id)
        if (not isinstance(row,dict) or current_ctx!=draft.decision_context_commitment or row.get("record_type")!=_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE
            or tuple(row.get("claim_ids",()))!=draft.claim_ids or tuple(row.get("selected_support_map",()))!=draft.selected_support_map
            or tuple(row.get("evidence_ids",()))!=draft.evidence_ids or row.get("retrieval_scope_id")!=draft.retrieval_scope_id
            or row.get("resolution_type")!=draft.resolution_type or row.get("reason")!=draft.reason): raise ValueError("installed source dependency accounting does not match draft/context")
        verify=getattr(verifier,"verify",None); verdict=verify(attestation,draft=draft,evidence=tuple(self._canonical_evidence_draft(x) for x in evidence)) if callable(verify) else None
        if not isinstance(verdict,DecisionSourceDependencyAccountingVerdict) or verdict.approved is not True or verdict.accounting_id!=draft.accounting_id or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id: raise ValueError("source dependency accounting verifier did not re-approve exact attestation")
        runtime=self._decision_accounting_runtime_commitment(draft.accounting_id,_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE); _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME[draft.accounting_id]=runtime
        _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA[draft.accounting_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id,"accounting_commitment":attestation.accounting_commitment,"decision_context_commitment":draft.decision_context_commitment}; return True

    def draft_decision_generic_dependency_accounting(self, *, accounting_id, retrieval_scope_id, claim_ids, selected_support_map,
                                                      generic_dependency_node, evidence_ids, reason, text, evidence, claim_identity_map, as_of,
                                                      requirements=None, waivers=None):
        if not all(isinstance(x,str) and x.strip() for x in (accounting_id,retrieval_scope_id,reason)): raise ValueError("invalid decision generic dependency accounting draft")
        cids=tuple(sorted(set(claim_ids or ())))
        if not cids or len(cids)!=len(tuple(claim_ids or ())) or any(not isinstance(x,str) or not x.strip() for x in cids): raise ValueError("invalid decision claim ids")
        smap=self._canonical_decision_selected_support_map(selected_support_map)
        if tuple(cid for cid,_ in smap)!=cids: raise ValueError("selected support map must exactly cover claim ids")
        node=tuple(generic_dependency_node or ())
        if len(node)!=3 or any(not isinstance(x,str) or not x.strip() for x in node): raise ValueError("invalid generic dependency node")
        eids=tuple(sorted(set(evidence_ids or ())))
        if len(eids)<2 or len(eids)!=len(tuple(evidence_ids or ())): raise ValueError("generic dependency accounting requires at least two unique evidence ids")
        rows=self._canonical_decision_evidence(evidence); known={x.evidence_id for x in rows}
        if not set(eids).issubset(known): raise ValueError("generic dependency endpoints must be present in evidence")
        selected_all={x for _cid,vals in smap for x in vals}
        if not set(eids).issubset(selected_all): raise ValueError("generic dependency endpoints must be selected supports")
        ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope_id,requirements=requirements,waivers=waivers)
        return DecisionGenericDependencyAccountingDraft(accounting_id,retrieval_scope_id,cids,smap,(node[0],node[1],node[2]),eids,
            _engine.SUPPORT_UNIVERSE_POLICY['decision_dependency_accounting_resolution_type'],reason,ctx)

    def decision_generic_dependency_accounting_commitment(self,draft,evidence) -> str:
        if not isinstance(draft,DecisionGenericDependencyAccountingDraft): raise TypeError("draft must be DecisionGenericDependencyAccountingDraft")
        rows=self._canonical_decision_evidence(evidence); known={x.evidence_id for x in rows}
        if not set(draft.evidence_ids).issubset(known): raise ValueError("accounting evidence does not match draft")
        return _engine.canonical_hash({"schema":"CFC_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_PROJECTION_V1","draft":_engine.asdict(draft),
            "evidence_record_commitments":tuple(sorted(self.evidence_record_commitment(x) for x in rows if x.evidence_id in set(draft.evidence_ids))),
            "support_universe_policy_hash":_engine.support_universe_policy_hash(),"provenance_policy_hash":_engine.provenance_policy_hash(),
            "dependency_ontology_hash":_engine.dependency_ontology_hash(),"dependency_justification_registry_hash":_engine.dependency_justification_registry_hash(),
            "representation_equivalence_policy_hash":_engine.generic_relation_source_identity_policy_hash(),
            "representation_equivalence_registry_hash":_engine.generic_representation_equivalence_registry_hash(),
            "representation_equivalence_certificate_registry_hash":_engine.generic_representation_equivalence_certificate_registry_hash()})

    @_requires_host_trust("DECISION_GENERIC_DEPENDENCY_ACCOUNTING")
    def install_verified_decision_generic_dependency_accounting(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        if not isinstance(draft,DecisionGenericDependencyAccountingDraft): raise TypeError("draft must be DecisionGenericDependencyAccountingDraft")
        rows=self._canonical_decision_evidence(evidence); self._require_retrieval_runtime_verified(draft.retrieval_scope_id)
        current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        if current_ctx!=draft.decision_context_commitment: raise ValueError("accounting draft is not bound to this decision context")
        expected=self.decision_generic_dependency_accounting_commitment(draft,rows)
        self._validate_decision_attestation(attestation,_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA,_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY,expected,as_of=as_of,commitment_field="accounting_commitment")
        verify=getattr(verifier,"verify",None)
        if not callable(verify): raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try: verdict=verify(attestation,draft=draft,evidence=rows)
        except Exception as exc: raise ValueError("decision generic dependency accounting verifier failed closed") from exc
        if (not isinstance(verdict,DecisionGenericDependencyAccountingVerdict) or verdict.approved is not True or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id
            or verdict.accounting_id!=draft.accounting_id or not isinstance(verdict.verifier_id,str) or not verdict.verifier_id.strip() or not isinstance(verdict.verification_method,str) or not verdict.verification_method.strip()):
            raise ValueError("generic dependency accounting verifier did not approve exact attestation")
        existing=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.accounting_id); idem=existing is not None
        if existing is None:
            _engine.register_decision_generic_dependency_accounting(draft.accounting_id,draft.retrieval_scope_id,draft.claim_ids,dict(draft.selected_support_map),draft.generic_dependency_node,draft.evidence_ids,draft.resolution_type,draft.reason,authorizer_id=_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY)
            row=_engine.SUPPORT_SELECTION_REGISTRY[draft.accounting_id]
        else:
            row=existing
            if (row.get("record_type")!=_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE or tuple(row.get("claim_ids",()))!=draft.claim_ids
                or tuple(row.get("selected_support_map",()))!=draft.selected_support_map or tuple(row.get("generic_dependency_node",()))!=draft.generic_dependency_node
                or tuple(row.get("evidence_ids",()))!=draft.evidence_ids or row.get("retrieval_scope_id")!=draft.retrieval_scope_id
                or row.get("resolution_type")!=draft.resolution_type or row.get("reason")!=draft.reason): raise ValueError("generic dependency accounting id already exists with different content")
        runtime=self._decision_accounting_runtime_commitment(draft.accounting_id,_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE)
        _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME[draft.accounting_id]=runtime
        _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA[draft.accounting_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id,"accounting_commitment":attestation.accounting_commitment,"decision_context_commitment":draft.decision_context_commitment}
        return DecisionGenericDependencyAccountingInstallation(draft.accounting_id,attestation.authority_id,attestation.attestation_id,verdict.verifier_id,verdict.verification_method,attestation.accounting_commitment,True,row.get("binding_state")=="BOUND",idem)

    @_requires_host_trust("DECISION_GENERIC_DEPENDENCY_ACCOUNTING")
    def reverify_installed_decision_generic_dependency_accounting(self,draft,evidence,attestation,verifier,*,text,claim_identity_map,as_of,requirements=None,waivers=None):
        expected=self.decision_generic_dependency_accounting_commitment(draft,evidence); self._validate_decision_attestation(attestation,_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_ATTESTATION_SCHEMA,_RESERVED_ENGINE_DECISION_DEPENDENCY_ACCOUNTING_AUTHORITY,expected,as_of=as_of,commitment_field="accounting_commitment")
        current_ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=draft.retrieval_scope_id,requirements=requirements,waivers=waivers)
        row=_engine.SUPPORT_SELECTION_REGISTRY.get(draft.accounting_id)
        if (not isinstance(row,dict) or current_ctx!=draft.decision_context_commitment or row.get("record_type")!=_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE
            or tuple(row.get("claim_ids",()))!=draft.claim_ids or tuple(row.get("selected_support_map",()))!=draft.selected_support_map
            or tuple(row.get("generic_dependency_node",()))!=draft.generic_dependency_node or tuple(row.get("evidence_ids",()))!=draft.evidence_ids
            or row.get("retrieval_scope_id")!=draft.retrieval_scope_id or row.get("resolution_type")!=draft.resolution_type or row.get("reason")!=draft.reason):
            raise ValueError("installed generic dependency accounting does not match draft/context")
        verify=getattr(verifier,"verify",None); verdict=verify(attestation,draft=draft,evidence=tuple(self._canonical_evidence_draft(x) for x in evidence)) if callable(verify) else None
        if not isinstance(verdict,DecisionGenericDependencyAccountingVerdict) or verdict.approved is not True or verdict.accounting_id!=draft.accounting_id or verdict.attestation_id!=attestation.attestation_id or verdict.authority_id!=attestation.authority_id: raise ValueError("generic dependency accounting verifier did not re-approve exact attestation")
        runtime=self._decision_accounting_runtime_commitment(draft.accounting_id,_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE); _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME[draft.accounting_id]=runtime
        _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA[draft.accounting_id]={"authority_id":attestation.authority_id,"attestation_id":attestation.attestation_id,"verifier_id":verdict.verifier_id,"accounting_commitment":attestation.accounting_commitment,"decision_context_commitment":draft.decision_context_commitment}; return True

    def finalize_verified_decision_dependency_accountings_for_prepare(self,text,evidence,claim_identity_map,*,as_of,retrieval_scope,requirements=None,waivers=None):
        rows=self._canonical_decision_evidence(evidence); current_ctx=self.decision_context_commitment(text,rows,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers)
        source_ids=[]; generic_ids=[]
        for key,row in _engine.SUPPORT_SELECTION_REGISTRY.items():
            if not isinstance(row,dict) or row.get("retrieval_scope_id")!=retrieval_scope: continue
            if row.get("record_type")==_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE:
                meta=_VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA.get(key)
                if not isinstance(meta,dict): continue
                if meta.get("decision_context_commitment")!=current_ctx: raise ValueError("source dependency accounting belongs to a different decision context")
                if _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME.get(key)!=self._decision_accounting_runtime_commitment(key,_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE): raise ValueError("source dependency accounting is not externally/runtime verified before bind")
                source_ids.append(key)
            elif row.get("record_type")==_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE:
                meta=_VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA.get(key)
                if not isinstance(meta,dict): continue
                if meta.get("decision_context_commitment")!=current_ctx: raise ValueError("generic dependency accounting belongs to a different decision context")
                if _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME.get(key)!=self._decision_accounting_runtime_commitment(key,_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE): raise ValueError("generic dependency accounting is not externally/runtime verified before bind")
                generic_ids.append(key)
        raw=[self.evidence_record_mapping(x) for x in rows]
        _engine.bind_decision_dependency_accountings_for_prepare(text,raw,dict(claim_identity_map),as_of,self.scope,self.extraction,retrieval_scope,requirements)
        _engine.bind_decision_generic_dependency_accountings_for_prepare(text,raw,dict(claim_identity_map),as_of,self.scope,self.extraction,retrieval_scope,requirements,tuple(generic_ids))
        for key in source_ids:
            row=_engine.SUPPORT_SELECTION_REGISTRY.get(key)
            if not isinstance(row,dict) or row.get("binding_state")!="BOUND": raise ValueError("source dependency accounting did not bind to exact decision context")
            _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME[key]=self._decision_accounting_runtime_commitment(key,_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE)
        for key in generic_ids:
            row=_engine.SUPPORT_SELECTION_REGISTRY.get(key)
            if not isinstance(row,dict) or row.get("binding_state")!="BOUND": raise ValueError("generic dependency accounting did not bind to exact decision context")
            _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME[key]=self._decision_accounting_runtime_commitment(key,_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE)
        return tuple(sorted(source_ids)),tuple(sorted(generic_ids))

    def _decision_dependency_accounting_integration_errors(self,text,evidence,claim_identity_map,*,as_of,retrieval_scope,requirements=None,waivers=None):
        errors=[]
        try:
            ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers)
            claim_ids=tuple(sorted(c.id for c in _engine.parse_claims(text)))
        except Exception:
            return [{"type":"DECISION_DEPENDENCY_ACCOUNTING_CONTEXT_INVALID"}]
        for key,row in sorted(_engine.SUPPORT_SELECTION_REGISTRY.items()):
            if not isinstance(row,dict) or row.get("retrieval_scope_id")!=retrieval_scope or tuple(row.get("claim_ids",()))!=claim_ids: continue
            rt=row.get("record_type")
            if rt==_engine.DECISION_DEPENDENCY_ACCOUNTING_RECORD_TYPE:
                meta=_VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_METADATA.get(key)
                if not isinstance(meta,dict): errors.append({"type":"DECISION_SOURCE_DEPENDENCY_ACCOUNTING_EXTERNAL_TRUST_NOT_VERIFIED","accounting_id":key}); continue
                if meta.get("decision_context_commitment")!=ctx: errors.append({"type":"DECISION_SOURCE_DEPENDENCY_ACCOUNTING_CONTEXT_MISMATCH","accounting_id":key}); continue
                if row.get("binding_state")!="BOUND": errors.append({"type":"DECISION_SOURCE_DEPENDENCY_ACCOUNTING_NOT_BOUND","accounting_id":key}); continue
                if _VERIFIED_DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME.get(key)!=self._decision_accounting_runtime_commitment(key,rt): errors.append({"type":"DECISION_SOURCE_DEPENDENCY_ACCOUNTING_RUNTIME_NOT_VERIFIED","accounting_id":key})
            elif rt==_engine.DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RECORD_TYPE:
                meta=_VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_METADATA.get(key)
                if not isinstance(meta,dict): errors.append({"type":"DECISION_GENERIC_DEPENDENCY_ACCOUNTING_EXTERNAL_TRUST_NOT_VERIFIED","accounting_id":key}); continue
                if meta.get("decision_context_commitment")!=ctx: errors.append({"type":"DECISION_GENERIC_DEPENDENCY_ACCOUNTING_CONTEXT_MISMATCH","accounting_id":key}); continue
                if row.get("binding_state")!="BOUND": errors.append({"type":"DECISION_GENERIC_DEPENDENCY_ACCOUNTING_NOT_BOUND","accounting_id":key}); continue
                if _VERIFIED_DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME.get(key)!=self._decision_accounting_runtime_commitment(key,rt): errors.append({"type":"DECISION_GENERIC_DEPENDENCY_ACCOUNTING_RUNTIME_NOT_VERIFIED","accounting_id":key})
        return errors

    def _decision_authority_integration_errors(self,text,evidence,claim_identity_map,*,as_of,retrieval_scope,requirements=None,waivers=None):
        errors=[]
        try:
            ctx=self.decision_context_commitment(text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers)
            claim_ids={c.id for c in _engine.parse_claims(text)}
        except Exception:
            return [{"type":"DECISION_AUTHORITY_CONTEXT_INVALID"}]
        for key,row in sorted(_engine.SUPPORT_SELECTION_REGISTRY.items()):
            if not isinstance(row,dict) or row.get("selection_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_support_selection_attestation_id") is None: errors.append({"type":"SUPPORT_SELECTION_AUTHORITY_UNATTESTED","selection_id":key}); continue
            if row.get("external_decision_context_commitment")!=ctx: errors.append({"type":"SUPPORT_SELECTION_CONTEXT_MISMATCH","selection_id":key}); continue
            if _VERIFIED_SUPPORT_SELECTION_RUNTIME.get(key)!=self._support_selection_runtime_commitment(key): errors.append({"type":"SUPPORT_SELECTION_AUTHORITY_RUNTIME_NOT_VERIFIED","selection_id":key})
        for key,row in sorted(_engine.RELATION_RESOLUTION_REGISTRY.items()):
            if not isinstance(row,dict) or row.get("resolution_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_relation_resolution_attestation_id") is None: errors.append({"type":"RELATION_RESOLUTION_AUTHORITY_UNATTESTED","resolution_id":key}); continue
            if row.get("authorization_binding_state")!="BOUND": errors.append({"type":"RELATION_RESOLUTION_NOT_BOUND","resolution_id":key}); continue
            if row.get("external_decision_context_commitment")!=ctx: errors.append({"type":"RELATION_RESOLUTION_CONTEXT_MISMATCH","resolution_id":key}); continue
            if _VERIFIED_RELATION_RESOLUTION_RUNTIME.get(key)!=self._relation_resolution_runtime_commitment(key): errors.append({"type":"RELATION_RESOLUTION_AUTHORITY_RUNTIME_NOT_VERIFIED","resolution_id":key})
        for key,row in sorted(_engine.EXCLUDED_SUPPORT_DISPOSITION_REGISTRY.items()):
            if not isinstance(row,dict) or row.get("disposition_id")!=key or row.get("retrieval_scope_id")!=retrieval_scope or row.get("claim_id") not in claim_ids: continue
            if row.get("external_excluded_disposition_attestation_id") is None: errors.append({"type":"EXCLUDED_SUPPORT_DISPOSITION_AUTHORITY_UNATTESTED","disposition_id":key}); continue
            if row.get("external_decision_context_commitment")!=ctx: errors.append({"type":"EXCLUDED_SUPPORT_DISPOSITION_CONTEXT_MISMATCH","disposition_id":key}); continue
            if _VERIFIED_EXCLUDED_DISPOSITION_RUNTIME.get(key)!=self._excluded_disposition_runtime_commitment(key): errors.append({"type":"EXCLUDED_SUPPORT_DISPOSITION_AUTHORITY_RUNTIME_NOT_VERIFIED","disposition_id":key})
        return errors

    def draft_snapshot(
        self,
        evidence: Sequence[Mapping[str, Any]],
        *,
        scope_id: str,
        snapshot_id: str,
        applicability_group_id: str | None = None,
        semantic_scope: str | None = None,
        snapshot_created_at: str = "2000-01-01",
        snapshot_available_at: str = "2000-01-01",
        valid_from: str = "2000-01-01",
        valid_to: str = "2099-12-31",
        snapshot_version: int = 1,
        supersedes: str | None = None,
        retracted_evidence_ids: Sequence[str] | None = None,
    ) -> SnapshotDraft:
        """Create a deterministic snapshot description without mutating engine state."""
        records = [dict(r) for r in evidence]
        if not isinstance(scope_id, str) or not scope_id.strip():
            raise ValueError("scope_id must be nonblank")
        if not isinstance(snapshot_id, str) or not snapshot_id.strip():
            raise ValueError("snapshot_id must be nonblank")
        if type(snapshot_version) is not int or snapshot_version < 1:
            raise ValueError("snapshot_version must be a positive exact int")

        ids: list[str] = []
        manifest: dict[str, str] = {}
        entities: set[str] = set()
        events: set[str] = set()
        versions: set[str] = set()
        predicates: set[str] = set()
        for record in records:
            eid = record.get("evidence_id")
            if not isinstance(eid, str) or not eid.strip():
                raise ValueError("every evidence record requires a nonblank evidence_id")
            if eid in manifest:
                raise ValueError("duplicate evidence_id in snapshot draft")
            identity_id = record.get("identity_registry_entry_id")
            identity = _engine.IDENTITY_REGISTRY.get(identity_id)
            if identity is None:
                raise ValueError(f"identity unresolved for evidence {eid!r}")
            ids.append(eid)
            manifest[eid] = _engine.evidence_record_hash(record)
            entities.add(identity["entity_id"])
            events.add(identity["event_id"])
            versions.add(identity["version_id"])
            pred = record.get("predicate")
            if isinstance(pred, str) and pred.strip():
                predicates.add(_engine.pkey(pred))

        try:
            created = _engine.strict_date(snapshot_created_at)
            available = _engine.strict_date(snapshot_available_at)
            vf = _engine.strict_date(valid_from)
            vt = _engine.strict_date(valid_to)
        except Exception as exc:
            raise ValueError("invalid snapshot date metadata") from exc
        if created > available or vf > vt:
            raise ValueError("invalid snapshot date ordering")

        semantic = semantic_scope or self.scope
        ent = tuple(sorted(entities))
        evt = tuple(sorted(events))
        ver = tuple(sorted(versions))
        pre = tuple(sorted(predicates))
        universe = _engine.canonical_retrieval_universe_id(semantic, ent, evt, ver, pre)
        retracted = tuple(sorted(set(retracted_evidence_ids or ())))
        if any(not isinstance(x, str) or not x.strip() for x in retracted):
            raise ValueError("invalid retracted_evidence_ids")

        return SnapshotDraft(
            scope_id=scope_id,
            snapshot_id=snapshot_id,
            expected_evidence_ids=tuple(sorted(ids)),
            expected_record_hashes=tuple(sorted(manifest.items())),
            semantic_scope=semantic,
            entity_ids=ent,
            event_ids=evt,
            version_ids=ver,
            predicates=pre,
            retrieval_universe_id=universe,
            applicability_group_id=applicability_group_id or scope_id,
            snapshot_created_at=snapshot_created_at,
            snapshot_available_at=snapshot_available_at,
            valid_from=valid_from,
            valid_to=valid_to,
            snapshot_version=snapshot_version,
            supersedes=supersedes,
            retracted_evidence_ids=retracted,
        )

    def inspect_snapshot(self, draft: SnapshotDraft) -> SnapshotInspection:
        """Inspect whether controller state already contains a matching snapshot.

        This method never writes controller state and does not validate or create
        epistemic authority.
        """
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        with _ENGINE_LOCK:
            row = _engine.RETRIEVAL_SCOPE_REGISTRY.get(draft.scope_id)
            if row is None:
                return SnapshotInspection(draft.scope_id, draft.snapshot_id, "DRAFT_ONLY", False, False)
            exact = (
                row.get("snapshot_id") == draft.snapshot_id
                and tuple(row.get("expected_evidence_ids", ())) == draft.expected_evidence_ids
                and dict(row.get("expected_record_hashes", {})) == dict(draft.expected_record_hashes)
                and row.get("retrieval_universe_id") == draft.retrieval_universe_id
                and row.get("semantic_scope") == draft.semantic_scope
                and tuple(row.get("entity_ids", ())) == draft.entity_ids
                and tuple(row.get("event_ids", ())) == draft.event_ids
                and tuple(row.get("version_ids", ())) == draft.version_ids
                and tuple(row.get("predicates", ())) == draft.predicates
                and row.get("applicability_group_id") == draft.applicability_group_id
                and row.get("snapshot_created_at") == draft.snapshot_created_at
                and row.get("snapshot_available_at") == draft.snapshot_available_at
                and row.get("valid_from") == draft.valid_from
                and row.get("valid_to") == draft.valid_to
                and row.get("snapshot_version") == draft.snapshot_version
                and row.get("supersedes") == draft.supersedes
                and tuple(row.get("retracted_evidence_ids", ())) == draft.retracted_evidence_ids
            )
            return SnapshotInspection(
                draft.scope_id,
                draft.snapshot_id,
                "INSTALLED_MATCH" if exact else "INSTALLED_MISMATCH",
                True,
                exact,
            )

    def evaluate_snapshot(
        self,
        draft: SnapshotDraft,
        text: str,
        evidence: Sequence[Mapping[str, Any]],
        claim_identity_map: Mapping[str, str],
        *,
        as_of: str,
        requirements: Mapping[str, Any] | None = None,
        waivers: Mapping[str, Any] | None = None,
        resource_exhausted: bool = False,
    ) -> EvaluationResult:
        """Evaluate using a draft's scope without registering or authorizing it.

        The supplied evidence must match the draft manifest.  If the engine has no
        matching registered snapshot, the underlying controller remains fail-closed.
        """
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        current_ids = tuple(sorted(str(r.get("evidence_id", "")) for r in evidence))
        current_manifest = {
            str(r.get("evidence_id", "")): _engine.evidence_record_hash(dict(r)) for r in evidence
        }
        if current_ids != draft.expected_evidence_ids or current_manifest != dict(draft.expected_record_hashes):
            raise ValueError("evidence does not match SnapshotDraft")
        return self.evaluate(
            text,
            evidence,
            claim_identity_map,
            as_of=as_of,
            retrieval_scope=draft.scope_id,
            requirements=requirements,
            waivers=waivers,
            resource_exhausted=resource_exhausted,
        )

    def snapshot_commitment(self, draft: SnapshotDraft) -> str:
        """Canonical commitment to every public field of a SnapshotDraft."""
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        payload = {
            "schema": "CFC_SNAPSHOT_DRAFT_V1",
            "scope_id": draft.scope_id,
            "snapshot_id": draft.snapshot_id,
            "expected_evidence_ids": draft.expected_evidence_ids,
            "expected_record_hashes": draft.expected_record_hashes,
            "semantic_scope": draft.semantic_scope,
            "entity_ids": draft.entity_ids,
            "event_ids": draft.event_ids,
            "version_ids": draft.version_ids,
            "predicates": draft.predicates,
            "retrieval_universe_id": draft.retrieval_universe_id,
            "applicability_group_id": draft.applicability_group_id,
            "snapshot_created_at": draft.snapshot_created_at,
            "snapshot_available_at": draft.snapshot_available_at,
            "valid_from": draft.valid_from,
            "valid_to": draft.valid_to,
            "snapshot_version": draft.snapshot_version,
            "supersedes": draft.supersedes,
            "retracted_evidence_ids": draft.retracted_evidence_ids,
        }
        return _engine.canonical_hash(payload)

    def _canonicalize_draft_from_evidence(
        self, draft: SnapshotDraft, evidence: Sequence[Mapping[str, Any]]
    ) -> SnapshotDraft:
        rebuilt = self.draft_snapshot(
            evidence,
            scope_id=draft.scope_id,
            snapshot_id=draft.snapshot_id,
            applicability_group_id=draft.applicability_group_id,
            semantic_scope=draft.semantic_scope,
            snapshot_created_at=draft.snapshot_created_at,
            snapshot_available_at=draft.snapshot_available_at,
            valid_from=draft.valid_from,
            valid_to=draft.valid_to,
            snapshot_version=draft.snapshot_version,
            supersedes=draft.supersedes,
            retracted_evidence_ids=draft.retracted_evidence_ids,
        )
        if rebuilt != draft:
            raise ValueError("SnapshotDraft is not the canonical projection of supplied evidence")
        return rebuilt

    def _validate_attestation(
        self, draft: SnapshotDraft, attestation: RetrievalAuthorityAttestation, *, as_of: str
    ) -> None:
        if not isinstance(attestation, RetrievalAuthorityAttestation):
            raise TypeError("attestation must be RetrievalAuthorityAttestation")
        if attestation.schema != _RETRIEVAL_ATTESTATION_SCHEMA:
            raise ValueError("unsupported retrieval authority attestation schema")
        if attestation.authority_id == "LOCAL_RETRIEVAL_AUTHORITY":
            raise ValueError("LOCAL_RETRIEVAL_AUTHORITY is reserved for DeveloperFixtureSession")
        for name in ("attestation_id", "authority_id", "snapshot_commitment", "issued_at", "valid_from", "valid_to"):
            value = getattr(attestation, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"attestation {name} must be nonblank")
        if not _engine._valid_hash64(attestation.snapshot_commitment):
            raise ValueError("attestation snapshot_commitment must be a SHA-256 hex digest")
        if attestation.snapshot_commitment != self.snapshot_commitment(draft):
            raise ValueError("attestation does not bind this SnapshotDraft")
        try:
            issued = _engine.strict_date(attestation.issued_at)
            vf = _engine.strict_date(attestation.valid_from)
            vt = _engine.strict_date(attestation.valid_to)
            when = _engine.strict_date(as_of)
        except Exception as exc:
            raise ValueError("invalid retrieval authority attestation dates") from exc
        if vf > vt or issued > when or not (vf <= when <= vt):
            raise ValueError("retrieval authority attestation is not applicable at as_of")
        sup = attestation.supersession_authority_id
        if sup is not None and (not isinstance(sup, str) or not sup.strip()):
            raise ValueError("invalid supersession_authority_id")
        if draft.supersedes is not None and sup != attestation.authority_id:
            raise ValueError("superseding snapshot requires explicit same-authority supersession permission")
        if sup is not None and sup != attestation.authority_id:
            raise ValueError("supersession authority must equal retrieval authority in engine V6 semantics")

    def _verified_registry_row(
        self,
        draft: SnapshotDraft,
        evidence: Sequence[Mapping[str, Any]],
        attestation: RetrievalAuthorityAttestation,
        verdict: RetrievalAuthorityVerdict,
        *,
        as_of: str,
    ) -> dict[str, Any]:
        manifest = dict(draft.expected_record_hashes)
        summaries = []
        for record in evidence:
            rec = dict(record)
            eid = rec["evidence_id"]
            identity = _engine.IDENTITY_REGISTRY.get(rec.get("identity_registry_entry_id"))
            if identity is None:
                raise ValueError(f"identity unresolved for evidence {eid!r}")
            summaries.append({
                "evidence_id": eid,
                "entity_id": identity["entity_id"],
                "event_id": identity["event_id"],
                "version_id": identity["version_id"],
                "predicate": _engine.pkey(rec.get("predicate", "")),
                "value_key": _engine.norm(rec.get("value", "")),
                "polarity": rec.get("polarity", "POSITIVE"),
                "record_hash": manifest[eid],
            })
        return {
            "expected_evidence_ids": draft.expected_evidence_ids,
            "expected_record_hashes": manifest,
            "record_projection_index": tuple(summaries),
            "snapshot_id": draft.snapshot_id,
            "retrieval_authority_id": attestation.authority_id,
            "applicability_group_id": draft.applicability_group_id,
            "retrieval_universe_id": draft.retrieval_universe_id,
            "semantic_scope": draft.semantic_scope,
            "entity_ids": draft.entity_ids,
            "event_ids": draft.event_ids,
            "version_ids": draft.version_ids,
            "predicates": draft.predicates,
            "snapshot_created_at": draft.snapshot_created_at,
            "snapshot_available_at": draft.snapshot_available_at,
            "valid_from": draft.valid_from,
            "valid_to": draft.valid_to,
            "snapshot_version": draft.snapshot_version,
            "supersedes": draft.supersedes,
            "retracted_evidence_ids": draft.retracted_evidence_ids,
            "supersession_authority_id": attestation.supersession_authority_id,
            "retrieval_authority_snapshot_commitment": attestation.snapshot_commitment,
            "retrieval_authority_attestation_schema": attestation.schema,
            "retrieval_authority_attestation_id": attestation.attestation_id,
            "retrieval_authority_attestation_commitment": _engine.canonical_hash({
                "schema": attestation.schema,
                "attestation_id": attestation.attestation_id,
                "authority_id": attestation.authority_id,
                "snapshot_commitment": attestation.snapshot_commitment,
                "issued_at": attestation.issued_at,
                "valid_from": attestation.valid_from,
                "valid_to": attestation.valid_to,
                "supersession_authority_id": attestation.supersession_authority_id,
            }),
            "retrieval_authority_verifier_id": verdict.verifier_id,
            "retrieval_authority_verification_method": verdict.verification_method,
        }

    @_requires_host_trust("RETRIEVAL")
    def install_verified_snapshot(
        self,
        draft: SnapshotDraft,
        evidence: Sequence[Mapping[str, Any]],
        attestation: RetrievalAuthorityAttestation,
        verifier: RetrievalAuthorityVerifier,
        *,
        as_of: str,
    ) -> RetrievalInstallation:
        """Install a snapshot only after an external host verifier approves exact binding.

        The package intentionally ships no default verifier.  Choosing trust roots,
        signatures, IAM/HSM policy, or an allow-list belongs to the host integration.
        """
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        records = [dict(r) for r in evidence]
        self._canonicalize_draft_from_evidence(draft, records)
        self._validate_attestation(draft, attestation, as_of=as_of)
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try:
            verdict = verify(attestation, draft=draft, evidence=tuple(records))
        except Exception as exc:
            raise ValueError("retrieval authority verifier failed closed") from exc
        if not isinstance(verdict, RetrievalAuthorityVerdict) or verdict.approved is not True:
            raise ValueError("retrieval authority verifier did not approve attestation")
        if (verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id
            or not isinstance(verdict.verifier_id, str) or not verdict.verifier_id.strip()
            or not isinstance(verdict.verification_method, str) or not verdict.verification_method.strip()):
            raise ValueError("verifier verdict is not exactly bound to attestation")
        row = self._verified_registry_row(draft, records, attestation, verdict, as_of=as_of)
        row_hash = _engine.canonical_hash(row)
        with _ENGINE_LOCK:
            existing = _engine.RETRIEVAL_SCOPE_REGISTRY.get(draft.scope_id)
            idempotent = existing is not None
            if existing is not None and _engine.canonical_hash(existing) != row_hash:
                raise ValueError("retrieval scope_id already exists with different content or authority")
            if existing is None:
                _engine.RETRIEVAL_SCOPE_REGISTRY[draft.scope_id] = copy.deepcopy(row)
            _VERIFIED_RETRIEVAL_RUNTIME[draft.scope_id] = row_hash
            registry_hash = _engine.retrieval_registry_hash()
        return RetrievalInstallation(
            scope_id=draft.scope_id,
            snapshot_id=draft.snapshot_id,
            authority_id=attestation.authority_id,
            attestation_id=attestation.attestation_id,
            verifier_id=verdict.verifier_id,
            verification_method=verdict.verification_method,
            snapshot_commitment=attestation.snapshot_commitment,
            registry_hash=registry_hash,
            idempotent=idempotent,
        )

    @_requires_host_trust("RETRIEVAL")
    def reverify_installed_snapshot(
        self,
        draft: SnapshotDraft,
        evidence: Sequence[Mapping[str, Any]],
        attestation: RetrievalAuthorityAttestation,
        verifier: RetrievalAuthorityVerifier,
        *,
        as_of: str,
    ) -> RetrievalAuthorityInspection:
        """Re-establish runtime authorization after process restart without rewriting registry."""
        records = [dict(r) for r in evidence]
        self._canonicalize_draft_from_evidence(draft, records)
        self._validate_attestation(draft, attestation, as_of=as_of)
        verify = getattr(verifier, "verify", None)
        if not callable(verify):
            raise TypeError("verifier must implement verify(attestation, *, draft, evidence)")
        try:
            verdict = verify(attestation, draft=draft, evidence=tuple(records))
        except Exception as exc:
            raise ValueError("retrieval authority verifier failed closed") from exc
        if (not isinstance(verdict, RetrievalAuthorityVerdict) or verdict.approved is not True
            or verdict.attestation_id != attestation.attestation_id
            or verdict.authority_id != attestation.authority_id):
            raise ValueError("retrieval authority verifier did not re-approve exact attestation")
        attestation_commitment = _engine.canonical_hash({
            "schema": attestation.schema,
            "attestation_id": attestation.attestation_id,
            "authority_id": attestation.authority_id,
            "snapshot_commitment": attestation.snapshot_commitment,
            "issued_at": attestation.issued_at,
            "valid_from": attestation.valid_from,
            "valid_to": attestation.valid_to,
            "supersession_authority_id": attestation.supersession_authority_id,
        })
        with _ENGINE_LOCK:
            installed = _engine.RETRIEVAL_SCOPE_REGISTRY.get(draft.scope_id)
            if installed is None:
                raise ValueError("retrieval snapshot is not installed")
            if not self.inspect_snapshot(draft).exact_match:
                raise ValueError("installed retrieval row does not match SnapshotDraft")
            if (installed.get("retrieval_authority_id") != attestation.authority_id
                or installed.get("retrieval_authority_snapshot_commitment") != attestation.snapshot_commitment
                or installed.get("retrieval_authority_attestation_schema") != attestation.schema
                or installed.get("retrieval_authority_attestation_id") != attestation.attestation_id
                or installed.get("retrieval_authority_attestation_commitment") != attestation_commitment
                or installed.get("supersession_authority_id") != attestation.supersession_authority_id):
                raise ValueError("installed retrieval row does not match externally verified attestation")
            _VERIFIED_RETRIEVAL_RUNTIME[draft.scope_id] = _engine.canonical_hash(installed)
        return self.inspect_retrieval_authority(draft)

    def inspect_retrieval_authority(self, draft: SnapshotDraft) -> RetrievalAuthorityInspection:
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        with _ENGINE_LOCK:
            row = _engine.RETRIEVAL_SCOPE_REGISTRY.get(draft.scope_id)
            if row is None:
                return RetrievalAuthorityInspection(
                    draft.scope_id, draft.snapshot_id, "DRAFT_ONLY", False, False, False, None, None, None
                )
            exact = self.inspect_snapshot(draft).exact_match
            att_id = row.get("retrieval_authority_attestation_id")
            verifier_id = row.get("retrieval_authority_verifier_id")
            authority_id = row.get("retrieval_authority_id")
            runtime = _VERIFIED_RETRIEVAL_RUNTIME.get(draft.scope_id) == _engine.canonical_hash(row)
            local_fixture = authority_id == "LOCAL_RETRIEVAL_AUTHORITY"
            fixture_runtime = _DEVELOPER_FIXTURE_RUNTIME.get(draft.scope_id) == _engine.canonical_hash(row)
            snapshot_commitment_match = row.get("retrieval_authority_snapshot_commitment") == self.snapshot_commitment(draft)
            if local_fixture and fixture_runtime:
                state = "INSTALLED_DEVELOPER_FIXTURE_ACTIVE"
                runtime = True
            elif local_fixture:
                state = "INSTALLED_DEVELOPER_FIXTURE_INACTIVE"
                runtime = False
            elif att_id is None:
                state = "INSTALLED_EXTERNAL_AUTHORITY_UNATTESTED"
                runtime = False
            elif exact and snapshot_commitment_match and runtime:
                state = "INSTALLED_VERIFIED_RUNTIME"
            elif exact and snapshot_commitment_match:
                state = "INSTALLED_ATTESTED_NOT_RUNTIME_VERIFIED"
            else:
                state = "INSTALLED_ATTESTED_MISMATCH"
            return RetrievalAuthorityInspection(
                draft.scope_id, draft.snapshot_id, state, True, exact, runtime,
                authority_id if isinstance(authority_id, str) else None,
                att_id if isinstance(att_id, str) else None,
                verifier_id if isinstance(verifier_id, str) else None,
            )

    def developer_fixture_session(self) -> "DeveloperFixtureSession":
        """Production facade guard: fixture capability moved to cfc_anchor.testing."""
        raise RuntimeError("DeveloperFixtureSession is test-only; use cfc_anchor.testing.fixture_session(controller)")

    def evaluate(
        self,
        text: str,
        evidence: Sequence[Mapping[str, Any]],
        claim_identity_map: Mapping[str, str],
        *,
        as_of: str,
        retrieval_scope: str,
        requirements: Mapping[str, Any] | None = None,
        waivers: Mapping[str, Any] | None = None,
        resource_exhausted: bool = False,
    ) -> EvaluationResult:
        """Run the existing prepare -> audit path without minting missing authority.

        External retrieval authorities installed through R249 must also have a
        live runtime verification pin.  A persisted/forged registry row alone is
        not sufficient through this public wrapper.
        """
        with _ENGINE_LOCK:
            rehydration = _engine.decision_rehydration_status()
            if rehydration.get("active") is True:
                raw = {
                    "claims": [],
                    "gates": {"integration_persistence_rehydration_complete": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": [{
                        "type": "ENGINE_REHYDRATION_INCOMPLETE",
                        "expected_history_commitment": rehydration.get("expected_history_commitment"),
                        "current_history_commitment": rehydration.get("current_history_commitment"),
                    }],
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            evidence_schema_errors = self._evidence_schema_integration_errors(evidence)
            if evidence_schema_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_evidence_input_schema_valid": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": evidence_schema_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            identity_errors = self._identity_integration_errors(evidence, claim_identity_map)
            if identity_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_identity_authority_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": identity_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            failure_domain_topology_errors = self._failure_domain_topology_integration_errors()
            if failure_domain_topology_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_failure_domain_topology_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": failure_domain_topology_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            generic_representation_errors = self._generic_representation_integration_errors()
            if generic_representation_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_generic_representation_authority_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": generic_representation_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            provenance_source_errors = self._provenance_source_semantics_integration_errors(evidence)
            if provenance_source_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_provenance_source_semantics_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": provenance_source_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            evidence_authority_role_errors = self._evidence_authority_role_integration_errors(evidence)
            if evidence_authority_role_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_evidence_authority_epistemic_role_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": evidence_authority_role_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            dependency_errors = self._dependency_relation_integration_errors(evidence,retrieval_scope)
            if dependency_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_dependency_relation_authority_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": dependency_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            decision_dependency_accounting_errors = self._decision_dependency_accounting_integration_errors(
                text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers
            )
            if decision_dependency_accounting_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_decision_dependency_accounting_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": decision_dependency_accounting_errors,
                }
                return EvaluationResult(stop_type="NONE", control_closure=False, claims=(), gates=dict(raw["gates"]), raw=raw)
            decision_authority_errors = self._decision_authority_integration_errors(
                text,evidence,claim_identity_map,as_of=as_of,retrieval_scope=retrieval_scope,requirements=requirements,waivers=waivers
            )
            if decision_authority_errors:
                raw = {
                    "claims": [],
                    "gates": {"integration_decision_authority_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": decision_authority_errors,
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            retrieval_row = _engine.RETRIEVAL_SCOPE_REGISTRY.get(retrieval_scope)
            integration_error = None
            if isinstance(retrieval_row, dict):
                row_hash = _engine.canonical_hash(retrieval_row)
                authority_id = retrieval_row.get("retrieval_authority_id")
                if authority_id == "LOCAL_RETRIEVAL_AUTHORITY":
                    if _DEVELOPER_FIXTURE_RUNTIME.get(retrieval_scope) != row_hash:
                        integration_error = "DEVELOPER_FIXTURE_RUNTIME_NOT_ACTIVE"
                else:
                    if retrieval_row.get("retrieval_authority_attestation_id") is None:
                        integration_error = "EXTERNAL_RETRIEVAL_AUTHORITY_UNATTESTED"
                    elif _VERIFIED_RETRIEVAL_RUNTIME.get(retrieval_scope) != row_hash:
                        integration_error = "RETRIEVAL_AUTHORITY_RUNTIME_NOT_VERIFIED"
            if integration_error is not None:
                raw = {
                    "claims": [],
                    "gates": {"integration_retrieval_authority_runtime_verified": False},
                    "stop_type": "NONE",
                    "control_closure": False,
                    "integration_errors": [{
                        "type": integration_error,
                        "retrieval_scope_id": retrieval_scope,
                    }],
                }
                return EvaluationResult(
                    stop_type="NONE", control_closure=False, claims=(),
                    gates=dict(raw["gates"]), raw=raw,
                )
            bundle = _engine.prepare(
                text,
                list(evidence),
                dict(claim_identity_map),
                as_of,
                self.scope,
                self.extraction,
                retrieval_scope,
                requirements,
                waivers,
            )
            result = _engine.audit_text(
                text,
                list(evidence),
                dict(claim_identity_map),
                as_of,
                self.scope,
                self.extraction,
                retrieval_scope,
                requirements,
                waivers,
                *bundle,
                resource_exhausted=resource_exhausted,
            )
        return EvaluationResult(
            stop_type=str(result.get("stop_type", "NONE")),
            control_closure=bool(result.get("control_closure", False)),
            claims=tuple(result.get("claims", ())),
            gates=dict(result.get("gates", {})),
            raw=result,
        )


class DeveloperFixtureSession:
    """TEST-ONLY retrieval-snapshot installer.

    This context calls the engine's private fixture registrar and restores the
    retrieval registry on exit.  It MUST NOT be treated as production retrieval
    authority or as a public authority-issuance API.
    """

    def __init__(self, controller: Controller):
        self._controller = controller
        self._backup: dict[str, Any] | None = None
        self._identity_backup: dict[str, Any] | None = None
        self._developer_identity_runtime_backup: dict[str, str] | None = None
        self._developer_provenance_runtime_backup: dict[str, str] | None = None
        self._developer_source_semantics_runtime_backup: dict[str, str] | None = None
        self._developer_evidence_authority_runtime_backup: dict[str, str] | None = None
        self._developer_epistemic_role_runtime_backup: dict[str, str] | None = None
        self._active = False
        self._installed_scope_ids: set[str] = set()

    def __enter__(self) -> "DeveloperFixtureSession":
        _ENGINE_LOCK.acquire()
        if _engine.decision_rehydration_status().get("active") is True:
            _ENGINE_LOCK.release()
            raise RuntimeError("DeveloperFixtureSession cannot run during production rehydration")
        self._backup = copy.deepcopy(_engine.RETRIEVAL_SCOPE_REGISTRY)
        self._identity_backup = copy.deepcopy(_engine.IDENTITY_REGISTRY)
        self._developer_identity_runtime_backup = dict(_DEVELOPER_IDENTITY_RUNTIME)
        self._developer_provenance_runtime_backup = dict(_DEVELOPER_PROVENANCE_RUNTIME)
        self._developer_source_semantics_runtime_backup = dict(_DEVELOPER_SOURCE_SEMANTICS_RUNTIME)
        self._developer_evidence_authority_runtime_backup = dict(_DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME)
        self._developer_epistemic_role_runtime_backup = dict(_DEVELOPER_EPISTEMIC_ROLE_RUNTIME)
        for identity_id, expected_hash in _BUILTIN_IDENTITY_FIXTURE_HASHES.items():
            row = _engine.IDENTITY_REGISTRY.get(identity_id)
            if isinstance(row, dict) and _engine.canonical_hash(row) == expected_hash:
                _DEVELOPER_IDENTITY_RUNTIME[identity_id] = expected_hash
        self._active = True
        return self

    def install_identity(self, draft: IdentityDraft) -> IdentityAuthorityInspection:
        """Install an identity for this TEST-ONLY session; restored on exit."""
        if not self._active:
            raise RuntimeError("DeveloperFixtureSession must be used as a context manager")
        self._controller._canonical_identity_draft(draft)
        base_row = {
            "surface_subject": draft.surface_subject,
            "domain_id": draft.domain_id,
            "entity_id": draft.entity_id,
            "event_id": draft.event_id,
            "version_id": draft.version_id,
        }
        current = _engine.IDENTITY_REGISTRY.get(draft.registry_entry_id)
        if current is None:
            _engine.IDENTITY_REGISTRY[draft.registry_entry_id] = copy.deepcopy(base_row)
        elif current != base_row and not (
            draft.registry_entry_id in _BUILTIN_IDENTITY_FIXTURES
            and _engine.canonical_hash(current) == _BUILTIN_IDENTITY_FIXTURE_HASHES[draft.registry_entry_id]
            and all(current.get(k) == v for k, v in base_row.items())
        ):
            raise ValueError("identity registry entry already exists with different content")
        _DEVELOPER_IDENTITY_RUNTIME[draft.registry_entry_id] = _engine.canonical_hash(
            _engine.IDENTITY_REGISTRY[draft.registry_entry_id]
        )
        return self._controller.inspect_identity_authority(draft)

    def install_snapshot(self, draft: SnapshotDraft, evidence: Sequence[Mapping[str, Any]]) -> SnapshotInspection:
        if not self._active:
            raise RuntimeError("DeveloperFixtureSession must be used as a context manager")
        if not isinstance(draft, SnapshotDraft):
            raise TypeError("draft must be SnapshotDraft")
        current_ids = tuple(sorted(str(r.get("evidence_id", "")) for r in evidence))
        current_manifest = {
            str(r.get("evidence_id", "")): _engine.evidence_record_hash(dict(r)) for r in evidence
        }
        if current_ids != draft.expected_evidence_ids or current_manifest != dict(draft.expected_record_hashes):
            raise ValueError("evidence does not match SnapshotDraft")
        for raw in evidence:
            edraft = self._controller._draft_evidence_from_mapping(raw)
            if edraft is not None:
                _DEVELOPER_PROVENANCE_RUNTIME[edraft.evidence_id] = self._controller.provenance_commitment(edraft)
                if edraft.authority_id in _engine.AUTHORITY_POLICIES:
                    _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME[edraft.evidence_id] = self._controller.evidence_authority_commitment(edraft)
                sid = edraft.source_semantics_id
                if sid is not None:
                    row = _engine.SOURCE_SEMANTICS_REGISTRY.get(sid)
                    cert = _engine.SOURCE_SEMANTICS_RESOLUTION_CERTIFICATE_REGISTRY.get(sid)
                    if isinstance(row, dict) and _engine.validate_source_semantics_resolution_certificate(cert):
                        _DEVELOPER_SOURCE_SEMANTICS_RUNTIME[sid] = _engine.canonical_hash(row)
        _engine._register_fixture_retrieval_scope(
            draft.scope_id,
            [dict(r) for r in evidence],
            draft.snapshot_id,
            applicability_group_id=draft.applicability_group_id,
            semantic_scope=draft.semantic_scope,
            snapshot_created_at=draft.snapshot_created_at,
            snapshot_available_at=draft.snapshot_available_at,
            valid_from=draft.valid_from,
            valid_to=draft.valid_to,
            snapshot_version=draft.snapshot_version,
            supersedes=draft.supersedes,
            retracted_evidence_ids=list(draft.retracted_evidence_ids),
            retrieval_universe_id=draft.retrieval_universe_id,
        )
        _DEVELOPER_FIXTURE_RUNTIME[draft.scope_id] = _engine.canonical_hash(
            _engine.RETRIEVAL_SCOPE_REGISTRY[draft.scope_id]
        )
        self._installed_scope_ids.add(draft.scope_id)
        return self._controller.inspect_snapshot(draft)

    def issue_epistemic_role(
        self, evidence: EvidenceRecordDraft, *, epistemic_role: str
    ) -> EvidenceRecordDraft:
        """TEST-ONLY role issuance through the engine's isolated fixture issuer."""
        if not self._active:
            raise RuntimeError("DeveloperFixtureSession must be used as a context manager")
        evidence=self._controller._canonical_evidence_draft(evidence)
        raw=self._controller.evidence_record_mapping(evidence)
        cert=_engine._controller_issue_evidence_epistemic_role(
            raw,epistemic_role,_capability=_engine._SELF_TEST_ROLE_ISSUER_CAPABILITY,
        )
        if cert is None: raise ValueError("fixture epistemic role could not be issued")
        bound=replace(evidence,epistemic_role_record_id=cert.role_record_id)
        role=self._controller.draft_epistemic_role(evidence,epistemic_role=epistemic_role)
        artifact=_engine._SELF_TEST_EVIDENCE_EPISTEMIC_ROLE_AUTHORIZATION_REGISTRY.get(cert.authorization_artifact_id)
        if artifact is None: raise ValueError("fixture role authorization artifact missing")
        ext=_engine.canonical_hash({
            "role_commitment":role.role_commitment,"role_record_id":cert.role_record_id,
            "authorization_artifact_id":cert.authorization_artifact_id,
            "authorization_artifact_fingerprint":cert.authorization_artifact_fingerprint,
        })
        _DEVELOPER_EPISTEMIC_ROLE_RUNTIME[evidence.evidence_id]=ext
        return bound

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            _engine.RETRIEVAL_SCOPE_REGISTRY.clear()
            _engine.RETRIEVAL_SCOPE_REGISTRY.update(self._backup or {})
            _engine.IDENTITY_REGISTRY.clear()
            _engine.IDENTITY_REGISTRY.update(self._identity_backup or {})
            _DEVELOPER_IDENTITY_RUNTIME.clear()
            _DEVELOPER_IDENTITY_RUNTIME.update(self._developer_identity_runtime_backup or {})
            _DEVELOPER_PROVENANCE_RUNTIME.clear()
            _DEVELOPER_PROVENANCE_RUNTIME.update(self._developer_provenance_runtime_backup or {})
            _DEVELOPER_SOURCE_SEMANTICS_RUNTIME.clear()
            _DEVELOPER_SOURCE_SEMANTICS_RUNTIME.update(self._developer_source_semantics_runtime_backup or {})
            _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME.clear()
            _DEVELOPER_EVIDENCE_AUTHORITY_RUNTIME.update(self._developer_evidence_authority_runtime_backup or {})
            _DEVELOPER_EPISTEMIC_ROLE_RUNTIME.clear()
            _DEVELOPER_EPISTEMIC_ROLE_RUNTIME.update(self._developer_epistemic_role_runtime_backup or {})
            for scope_id in self._installed_scope_ids:
                _DEVELOPER_FIXTURE_RUNTIME.pop(scope_id, None)
        finally:
            self._installed_scope_ids.clear()
            self._active = False
            self._backup = None
            self._identity_backup = None
            self._developer_identity_runtime_backup = None
            self._developer_provenance_runtime_backup = None
            self._developer_source_semantics_runtime_backup = None
            self._developer_evidence_authority_runtime_backup = None
            self._developer_epistemic_role_runtime_backup = None
            _ENGINE_LOCK.release()


# R263 applies trust-context scoping uniformly to every public Controller method.
# This is intentionally installed after class construction so future public methods
# added before interface freeze inherit the same isolation unless explicitly private.
def _runtime_scoped_public_method(fn):
    if getattr(fn, "__cfc_runtime_scoped__", False):
        return fn
    @functools.wraps(fn)
    def wrapped(self, *args, **kwargs):
        with self._runtime_trust_scope():
            return fn(self, *args, **kwargs)
    wrapped.__cfc_runtime_scoped__ = True
    return wrapped


for _name, _member in tuple(Controller.__dict__.items()):
    if _name.startswith("_") or _name in {
        "developer_fixture_session",
        "export_persistence_checkpoint", "rehydration_status",
        "begin_rehydration", "complete_rehydration",
    }:
        continue
    if inspect.isfunction(_member):
        setattr(Controller, _name, _runtime_scoped_public_method(_member))
